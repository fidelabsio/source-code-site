import { reactRouter } from "@react-router/dev/vite";
import { defineConfig } from "vite";
import tsconfigPaths from "vite-tsconfig-paths";

// Related: https://github.com/remix-run/remix/issues/2835#issuecomment-1144102176
// Replace the HOST env var with SHOPIFY_APP_URL so that it doesn't break the Vite server.
// The CLI will eventually stop passing in HOST,
// so we can remove this workaround after the next major release.
if (
  process.env.HOST &&
  (!process.env.SHOPIFY_APP_URL ||
    process.env.SHOPIFY_APP_URL === process.env.HOST)
) {
  process.env.SHOPIFY_APP_URL = process.env.HOST;
  delete process.env.HOST;
}

const host = new URL(process.env.SHOPIFY_APP_URL || "http://localhost")
  .hostname;
let hmrConfig;

if (host === "localhost") {
  hmrConfig = {
    protocol: "ws",
    host: "localhost",
    port: 64999,
    clientPort: 64999,
  };
} else {
  hmrConfig = {
    protocol: "wss",
    host: host,
    port: parseInt(process.env.FRONTEND_PORT) || 8002,
    clientPort: 443,
  };
}

export default defineConfig({
  server: {
    allowedHosts: [host],
    cors: {
      preflightContinue: true,
    },
    port: Number(process.env.PORT || 3000),
    hmr: hmrConfig,
    fs: {
      // See https://vitejs.dev/config/server-options.html#server-fs-allow for more information
      allow: ["app", "node_modules"],
    },
    watch: {
      ignored: ["**/node_modules/**", "**/.git/**", "**/docs/**", "**/.agents/**"],
    },
  },
  plugins: [reactRouter(), tsconfigPaths()],
  // Force a single React instance. Vite's dev server can otherwise load two
  // copies (one pre-bundled in .vite/deps), which nulls React's hook dispatcher
  // and triggers "Cannot read properties of null (reading 'useState')".
  resolve: {
    dedupe: ["react", "react-dom"],
  },
  build: {
    // Disable Vite's default base64-inlining of small assets — this app
    // references some static assets (e.g. Polaris's stylesheet) via an
    // explicit `?url` import expecting a real file URL back; inlining would
    // silently swap that for a data: URI instead.
    assetsInlineLimit: 0,
  },
  optimizeDeps: {
    // Pre-bundle explicitly: App Bridge React is loaded dynamically enough
    // (via a script tag / embedded context) that Vite's dependency scanner
    // can miss it on first run, causing a dev-server reload the first time
    // a page imports it.
    include: ["@shopify/app-bridge-react"],
  },
});

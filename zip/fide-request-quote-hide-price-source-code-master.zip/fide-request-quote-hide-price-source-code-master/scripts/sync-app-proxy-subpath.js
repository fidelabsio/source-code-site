#!/usr/bin/env node
// Single source of truth is shopify.app.toml's [app_proxy].subpath — that's
// the value actually registered with Shopify Partners. This copies it into
// app/config/app-proxy.json (so Node doesn't need a TOML parser at runtime)
// and into the static theme extension asset, which is deployed separately
// and can't import either file at runtime.
import { readFileSync, writeFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const rootDir = join(dirname(fileURLToPath(import.meta.url)), "..");
const tomlPath = join(rootDir, "shopify.app.staging.toml");
const jsonPath = join(rootDir, "app/config/app-proxy.json");
const jsPath = join(rootDir, "extensions/quote-request/assets/quote-request-utils.js");

const toml = readFileSync(tomlPath, "utf-8");
const sectionMatch = toml.match(/\[app_proxy\]([^[]*)/);
if (!sectionMatch) {
  throw new Error(`Could not find [app_proxy] section in ${tomlPath}`);
}
const subpathMatch = sectionMatch[1].match(/subpath\s*=\s*"([^"]*)"/);
if (!subpathMatch) {
  throw new Error(`Could not find subpath in [app_proxy] section of ${tomlPath}`);
}
const subpath = subpathMatch[1];

const jsonSource = readFileSync(jsonPath, "utf-8");
const currentJson = JSON.parse(jsonSource).subpath;
if (currentJson !== subpath) {
  writeFileSync(jsonPath, JSON.stringify({ subpath }, null, 2) + "\n");
  console.log(`Synced app-proxy.json -> subpath "${subpath}"`);
}

const jsSource = readFileSync(jsPath, "utf-8");
const pattern = /app\.PROXY_SUBPATH\s*=\s*"([^"]*)";/;
const jsMatch = jsSource.match(pattern);
if (!jsMatch) {
  throw new Error(`Could not find app.PROXY_SUBPATH assignment in ${jsPath}`);
}
if (jsMatch[1] !== subpath) {
  writeFileSync(jsPath, jsSource.replace(pattern, `app.PROXY_SUBPATH = "${subpath}";`));
  console.log(`Synced quote-request-utils.js -> app.PROXY_SUBPATH "${subpath}"`);
}

import { PrismaClient } from "@prisma/client";

// Single client per Node process — works in both dev (survives HMR) and production
if (!global.prismaGlobal) {
  global.prismaGlobal = new PrismaClient();
}

export default global.prismaGlobal;

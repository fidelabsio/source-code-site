import { useState, useEffect } from "react";
import { useParams, useLoaderData, useFetcher, useNavigate } from "react-router";
import { useAppBridge } from "@shopify/app-bridge-react";
import { useIsMobile } from "../useIsMobile";
import { useTemplateDirtyState } from "../useTemplateDirtyState";
import { isValidEmail } from "../../utils/validation";

// Builds the same shape the route expects (title/description/subject/heading/
// content/action/redirectUrl/variables) from labels.templates[id] — the
// single source of truth for this content, shared with the Settings page's
// email-list rows (which read the same title/description, not a duplicate).
function buildConfig(id, labels) {
  const t = labels.templates[id] || labels.templates.notification;
  return {
    title: t.title,
    description: t.description,
    subject: t.subjectDefault,
    heading: t.headingDefault,
    content: t.contentDefault,
    action: t.actionDefault,
    redirectUrl: "",
    variables: t.variables,
  };
}

/**
 * All state and handlers for the email template editor (app.email-edit.$id.jsx):
 * seeds form fields from the saved template (or the config default), wires
 * unsaved-changes tracking, and exposes save/test/discard actions.
 */
export function useEmailTemplateEditor() {
  const { id } = useParams();
  const { saved, isEnabled, headerColor, ctaColor, logoUrl, signature, labels } = useLoaderData();
  const fetcher = useFetcher();
  const shopify = useAppBridge();
  const isMobile = useIsMobile();
  const navigate = useNavigate();

  const config = buildConfig(id, labels);

  // Parse saved JSON body or fall back to defaults
  const savedBody = (() => {
    try { return saved ? JSON.parse(saved.htmlBody) : null; } catch { return null; }
  })();

  // isEnabled from EmailConfig is the source of truth (synced with settings page toggles)
  const [status, setStatus] = useState(isEnabled ? "enabled" : "disabled");
  const [subject, setSubject] = useState(saved?.subject ?? config.subject);
  const [heading, setHeading] = useState(savedBody?.heading ?? config.heading);
  const [content, setContent] = useState(savedBody?.content ?? config.content);
  const [action, setAction] = useState(savedBody?.action ?? config.action);
  const [redirectUrl, setRedirectUrl] = useState(savedBody?.redirectUrl ?? config.redirectUrl);
  const [testToEmail, setTestToEmail] = useState("");

  const isSaving = fetcher.state !== "idle" && fetcher.formData?.get("intent") !== "testEmail";
  const saved_ok = fetcher.data?.success && fetcher.data?.intent !== "testEmail";

  const currentValues = { status, subject, heading, content, action, redirectUrl };
  const { markClean, getBaseline } = useTemplateDirtyState(currentValues, "email-save-bar");

  useEffect(() => {
    if (!fetcher.data || fetcher.state !== "idle") return;
    if (fetcher.data.intent === "testEmail") {
      if (fetcher.data.success) shopify.toast.show(labels.toasts.testEmailSent);
      else shopify.toast.show(fetcher.data.error || labels.toasts.testEmailFailed, { isError: true });
    } else if (fetcher.data.success) {
      shopify.toast.show(labels.toasts.templateSaved);
      markClean();
    }
  }, [fetcher.data, fetcher.state]);

  const handleSave = () => {
    fetcher.submit(
      { subject, heading, content, action, redirectUrl, status },
      { method: "post" },
    );
  };

  const handleTest = () => {
    fetcher.submit(
      { intent: "testEmail", subject, heading, content, action, redirectUrl, status, toEmail: testToEmail },
      { method: "post" },
    );
  };

  const isValidTestEmail = isValidEmail(testToEmail);
  const isTesting = fetcher.state !== "idle" && fetcher.formData?.get("intent") === "testEmail";

  const handleDiscard = () => {
    const base = getBaseline();
    if (!base) return;
    setStatus(base.status);
    setSubject(base.subject);
    setHeading(base.heading);
    setContent(base.content);
    setAction(base.action);
    setRedirectUrl(base.redirectUrl);
  };

  return {
    config, isMobile, navigate, headerColor, ctaColor, logoUrl, signature, labels,
    status, setStatus,
    subject, setSubject,
    heading, setHeading,
    content, setContent,
    action, setAction,
    redirectUrl, setRedirectUrl,
    testToEmail, setTestToEmail,
    isSaving, saved_ok, isTesting, isValidTestEmail,
    handleSave, handleTest, handleDiscard,
  };
}

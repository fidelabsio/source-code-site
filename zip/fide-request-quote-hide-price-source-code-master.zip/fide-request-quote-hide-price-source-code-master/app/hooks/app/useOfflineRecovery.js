import { useEffect } from "react";

/**
 * Offline / connectivity recovery helpers for route ErrorBoundaries. Reusable
 * across any route boundary that wants to auto-recover from a network blip
 * rather than show a dead "Application Error" page.
 */

/**
 * Detects whether a thrown error looks like a transient network failure
 * rather than a real app bug. A navigation that races a dropped/flaky
 * connection fails in ways that aren't real app bugs: React Router's lazy
 * route discovery (patchRoutesOnNavigation / fetchAndApplyManifestPatches)
 * can't fetch the manifest patch, a code-split chunk fails to load, or the
 * request resolves with a 5xx (e.g. a Cloudflare 530 from a dropped dev
 * tunnel). Without this, React Router has no boundary for a failed route
 * discovery and shows the raw "Application Error" stack. A reload once the
 * connection is healthy recovers cleanly.
 *
 * @param {unknown} error - the error caught by the route ErrorBoundary
 * @returns {boolean} true if the error matches a known transient/offline pattern
 */
export function isTransientNavigationError(error) {
  if (!error) return false;
  const msg = String(error?.message ?? error);
  return (
    /failed to fetch/i.test(msg) ||
    /load failed/i.test(msg) ||
    /networkerror/i.test(msg) ||
    /(dynamically imported|imported module|module script).*(fail)/i.test(msg) ||
    /patchRoutesOnNavigation|fetchAndApplyManifestPatches|manifest/i.test(msg) ||
    /\b5\d\d\b/.test(msg) // 5xx incl. Cloudflare 530
  );
}

/**
 * Offline / transient-error recovery for a route ErrorBoundary. Unlike the
 * proactive OfflineOverlay (which lives inside the App tree and removes
 * itself on reconnect), this runs AFTER the App tree was torn down by a
 * failed navigation, so it has no way back on its own. It reloads when the
 * connection returns and — if already back online (the error surfaced just
 * after reconnect, exactly the route-discovery 530 case) — reloads once
 * immediately, guarded so it can never loop. Used in the app shell's
 * ErrorBoundary (app/routes/app.jsx).
 */
export function useOfflineReload() {
  useEffect(() => {
    const reload = () => window.location.reload();
    window.addEventListener("online", reload);

    if (navigator.onLine) {
      const KEY = "qr_recovery_reload_at";
      const last = Number(sessionStorage.getItem(KEY) || 0);
      // Only auto-reload if we haven't just done so — prevents a reload loop if
      // the failure turns out to be persistent rather than a reconnect blip.
      if (!last || Date.now() - last > 10000) {
        sessionStorage.setItem(KEY, String(Date.now()));
        reload();
      }
    }

    return () => window.removeEventListener("online", reload);
  }, []);
}

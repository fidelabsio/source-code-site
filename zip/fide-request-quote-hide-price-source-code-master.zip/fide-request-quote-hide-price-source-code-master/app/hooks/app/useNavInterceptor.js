import { useEffect } from "react";
import { useNavigate } from "react-router";
import { useAppBridge } from "@shopify/app-bridge-react";

/**
 * NavMenu <a href> tags cause full iframe reloads by default in App Bridge,
 * bypassing React Router entirely so useNavigation() never fires. This
 * intercepts those clicks first and routes them through React Router's
 * navigate(), which makes useNavigation() work correctly.
 * Used once, at the root of the app shell (app/routes/app.jsx).
 */
export function useNavInterceptor() {
  const navigate = useNavigate();
  const shopify = useAppBridge();

  useEffect(() => {
    const handler = (e) => {
      const link = e.target.closest("a");
      if (!link) return;
      const navMenu = link.closest("ui-nav-menu");
      if (!navMenu) return;
      const href = link.getAttribute("href");
      if (!href || !href.startsWith("/")) return;

      e.preventDefault();
      e.stopPropagation();

      // Offline: don't kick off a navigation that can't complete. Its loader
      // fetch would fail, tear down this tree into the ErrorBoundary, and leave
      // the App Bridge progress bar stuck on. The OfflineOverlay is already
      // covering the screen, so just stay put until the connection returns.
      if (typeof navigator !== "undefined" && !navigator.onLine) return;

      shopify.loading(true);
      navigate(href);
    };

    document.addEventListener("click", handler, true);
    return () => document.removeEventListener("click", handler, true);
  }, [navigate, shopify]);
}

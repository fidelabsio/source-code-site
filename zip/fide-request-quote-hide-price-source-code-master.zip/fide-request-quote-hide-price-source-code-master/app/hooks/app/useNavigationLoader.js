import { useCallback, useEffect, useRef } from "react";
import { useNavigation } from "react-router";
import { useAppBridge } from "@shopify/app-bridge-react";
import { useIsomorphicLayoutEffect } from "../useIsomorphicLayoutEffect";

/**
 * Drives the App Bridge top progress bar off React Router's navigation
 * state: shows it immediately when a navigation starts, hides it ~350ms
 * after it settles back to idle (avoids a flash on very fast navigations).
 * Used once, at the root of the app shell (app/routes/app.jsx).
 */
export function useNavigationLoader() {
  const shopify = useAppBridge();
  const navigation = useNavigation();
  const hideTimer = useRef(null);
  const showing = useRef(false);

  // Immediately turn the App Bridge progress bar off and forget any pending
  // hide timer. Used by the offline handler and the unmount cleanup below.
  const hideLoader = useCallback(() => {
    clearTimeout(hideTimer.current);
    showing.current = false;
    try {
      shopify.loading(false);
    } catch {
      // App Bridge may be gone during teardown — ignore.
    }
  }, [shopify]);

  useIsomorphicLayoutEffect(() => {
    if (navigation.state !== "idle") {
      clearTimeout(hideTimer.current);
      showing.current = true;
      shopify.loading(true);
    } else if (showing.current) {
      clearTimeout(hideTimer.current);
      hideTimer.current = setTimeout(() => {
        showing.current = false;
        shopify.loading(false);
      }, 350);
    }
  }, [navigation.state, shopify]);

  // A navigation interrupted by going offline never reaches "idle", so the
  // loop above would never clear the progress bar — it stays stuck even after
  // the connection returns. Clear it as soon as we go offline, and on unmount
  // (e.g. when the route ErrorBoundary replaces this tree on a failed loader),
  // so the indicator can never be orphaned.
  useEffect(() => {
    window.addEventListener("offline", hideLoader);
    return () => {
      window.removeEventListener("offline", hideLoader);
      hideLoader();
    };
  }, [hideLoader]);
}

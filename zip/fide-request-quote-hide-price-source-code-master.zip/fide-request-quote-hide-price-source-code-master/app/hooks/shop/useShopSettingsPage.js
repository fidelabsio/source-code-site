import { useState, useEffect } from "react";
import { useLoaderData, useFetcher, useSearchParams } from "react-router";
import { useAppBridge } from "@shopify/app-bridge-react";
import { useIsMobile } from "../useIsMobile";
import { useTemplateDirtyState } from "../useTemplateDirtyState";

// Map DB field names → EMAIL_ITEMS ids
const TOGGLE_FIELD = {
  "notification": "notificationEnabled",
  "auto-response": "autoResponseEnabled",
  "accept-quote": "acceptQuoteEnabled",
  "reject-quote": "rejectQuoteEnabled",
};

/**
 * All state and handlers for the Settings page (app.settings.jsx): the
 * active email/pdf tab (kept in the URL so returning from an editor lands
 * back on the right tab), SMTP form state + save/discard/test actions, and
 * the per-email enabled/disabled toggle.
 *
 * @param {string[]} emailTemplateIds - ordered template ids to show as rows;
 *   title/description for each comes from emailLabels.templates[id] — the
 *   same source the email template editor reads, so this list carries no
 *   copy of its own, only which ids to show and in what order.
 */
export function useShopSettingsPage(emailTemplateIds) {
  const { config, notifyEmail: initialNotifyEmail, shop, appName, emailLabels, pdfLabels } = useLoaderData();
  const fetcher = useFetcher();
  const shopify = useAppBridge();
  const isMobile = useIsMobile();

  const [searchParams, setSearchParams] = useSearchParams();
  const active = searchParams.get("tab") === "pdf" ? "pdf" : "email";
  const setActive = (id) =>
    setSearchParams({ tab: id }, { replace: true, preventScrollReset: true });
  const [testing, setTesting] = useState(false);
  const [testToEmail, setTestToEmail] = useState(initialNotifyEmail ?? "");

  // Seed email toggle states from DB; title/description come from
  // emailLabels.templates[id], not a locally-duplicated copy.
  const [emailItems, setEmailItems] = useState(() =>
    emailTemplateIds.map((id) => ({
      id,
      title: emailLabels.templates[id]?.title,
      description: emailLabels.templates[id]?.description,
      enabled: config?.[TOGGLE_FIELD[id]] ?? true,
    }))
  );

  // Seed SMTP state from DB
  const [smtp, setSmtp] = useState({
    provider: config?.provider ?? "app_default",
    host: config?.smtpHost ?? "",
    port: String(config?.smtpPort ?? 587),
    username: config?.smtpUser ?? "",
    password: config?.smtpPassEnc ? "••••••••" : "",
    apiKey: config?.apiKeyEnc ? "••••••••" : "",
    region: config?.apiRegion ?? "us-east-1",
    fromName: config?.fromName ?? "",
    fromEmail: config?.fromEmail ?? "",
    notifyEmail: initialNotifyEmail ?? "",
  });

  const { markClean: markSmtpClean, getBaseline: getSmtpBaseline } =
    useTemplateDirtyState(smtp, "smtp-save-bar");

  useEffect(() => {
    if (!fetcher.data || fetcher.state !== "idle") return;
    setTesting(false);
    if (fetcher.data.success) {
      if (fetcher.data.intent === "testSmtp") {
        shopify.toast.show(emailLabels.toasts.testEmailSentFull);
      } else if (fetcher.data.intent === "saveSmtp") {
        shopify.toast.show(emailLabels.toasts.settingsSaved);
        markSmtpClean();
      } else {
        shopify.toast.show(emailLabels.toasts.settingsSaved);
      }
    } else if (fetcher.data.error) {
      shopify.toast.show(fetcher.data.error, { isError: true });
    }
  }, [fetcher.data, fetcher.state]);

  const handleSmtpChange = (field, value) =>
    setSmtp((prev) => ({ ...prev, [field]: value }));

  const handleSaveSmtp = () => {
    fetcher.submit(
      {
        intent: "saveSmtp",
        provider: smtp.provider,
        host: smtp.host,
        port: smtp.port,
        username: smtp.username,
        password: smtp.password,
        apiKey: smtp.apiKey,
        region: smtp.region,
        fromName: smtp.fromName,
        fromEmail: smtp.fromEmail,
        notifyEmail: smtp.notifyEmail,
      },
      { method: "post" },
    );
  };

  const handleDiscardSmtp = () => {
    const base = getSmtpBaseline();
    if (base) setSmtp(base);
  };

  const handleTestSmtp = () => {
    setTesting(true);
    fetcher.submit(
      { intent: "testSmtp", toEmail: testToEmail },
      { method: "post" },
    );
  };

  const handleToggle = (id) => {
    const field = TOGGLE_FIELD[id];
    const current = emailItems.find((i) => i.id === id)?.enabled ?? false;
    setEmailItems((prev) =>
      prev.map((item) => item.id === id ? { ...item, enabled: !item.enabled } : item)
    );
    fetcher.submit(
      { intent: "toggleEmail", field, value: String(!current) },
      { method: "post" },
    );
  };

  return {
    shop, appName, active, setActive, isMobile,
    testing, testToEmail, setTestToEmail,
    emailItems, smtp, emailLabels, pdfLabels,
    handleSmtpChange, handleSaveSmtp, handleDiscardSmtp, handleTestSmtp, handleToggle,
  };
}

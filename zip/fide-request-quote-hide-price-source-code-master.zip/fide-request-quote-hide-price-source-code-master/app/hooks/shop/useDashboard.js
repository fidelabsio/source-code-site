import { useState } from "react";
import { useLoaderData, useNavigate } from "react-router";
import { useIsMobile } from "../useIsMobile";
import { CURRENCY_SYMBOLS } from "../../utils/currency";

/**
 * All state and derived values for the app dashboard (app._index.jsx):
 * loader data passthrough, the setup-guide's dismiss/collapse/step-completion
 * state, and the currency formatter used by the stat cards.
 *
 * @param {number} stepCount - number of setup-guide steps (STEPS.length in the route)
 */
export function useDashboard(stepCount) {
  const {
    shop, embedEditorUrl, recent, stats, topProducts, shopCurrency, appName, primaryColor,
    statTextColor, statCardBackgroundColor, cardBackgroundColor, labels,
  } = useLoaderData();
  const navigate = useNavigate();
  const isMobile = useIsMobile();

  const currSym = CURRENCY_SYMBOLS[shopCurrency] || shopCurrency || "$";

  const fmt = (n) => {
    if (!n) return currSym + "0";
    return currSym + n.toLocaleString(undefined, { maximumFractionDigits: 0 });
  };

  const statCards = [
    { label: labels.statCards.totalQuotes, value: String(stats.total) },
    { label: labels.statCards.thisMonth, value: String(stats.thisMonth) },
    { label: labels.statCards.accepted, value: String(stats.accepted) },
    { label: labels.statCards.revenue, value: fmt(stats.revenue) },
  ];

  const [dismissed, setDismissed] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const [completed, setCompleted] = useState([]);
  const [expanded, setExpanded] = useState(0);

  const dismiss = () => setDismissed(true);
  const collapse = () => setCollapsed((c) => !c);

  const completedCount = completed.length;
  const progress = Math.round((completedCount / stepCount) * 100);

  const markDone = (index) => {
    if (completed.includes(index)) return;
    const next = [...completed, index];
    setCompleted(next);
    const nextOpen = Array.from({ length: stepCount }, (_, i) => i).find((i) => !next.includes(i));
    setExpanded(nextOpen === undefined ? -1 : nextOpen);
  };

  return {
    shop, embedEditorUrl, recent, stats, topProducts, appName, primaryColor,
    statTextColor, statCardBackgroundColor, cardBackgroundColor, labels,
    navigate, isMobile, fmt, statCards,
    dismissed, collapsed, completed, expanded, setExpanded,
    dismiss, collapse, completedCount, progress, markDone,
  };
}

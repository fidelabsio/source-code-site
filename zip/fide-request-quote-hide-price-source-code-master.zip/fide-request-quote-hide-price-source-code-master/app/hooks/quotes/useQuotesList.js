import { useState, useCallback, useEffect, useRef } from "react";
import { useLoaderData, useNavigate, useSearchParams, useNavigation, useFetcher } from "react-router";
import { useAppBridge } from "@shopify/app-bridge-react";
import { useIsMobile } from "../useIsMobile";
import { formatQuoteNumber } from "../../domain/quotes/quoteNumber";
import { formatShortDate } from "../../utils/date";
import { formatMoney } from "../../utils/currency";
import { escapeHtml } from "../../utils/html";
import { printHtmlDocument } from "../../utils/printWindow";
import { buildCsv } from "../../utils/csv";
import { downloadBlob } from "../../utils/download";

// Tab keys for the Quote List page's filter tabs — must match the loader's
// `tab` query param. Display labels come from labels.tabs (text-labels.json);
// this stays a plain key list since the key itself is functional, not copy.
const TAB_KEYS = ["all", "unread", "read", "cancelled", "accepted", "done"];

/**
 * Maps a quote row to the Polaris Badge tone/label to render for its status.
 * `quoteStatus` (merchant-driven: accepted/rejected/paid/quoted) takes
 * priority over the plain read/unread `status` used for new submissions.
 *
 * @param {{quoteStatus?: string, status?: string}} q - a quote row
 * @param {object} statusLabels - labels.quotesList.statusBadges
 * @returns {{tone: string, label: string}}
 */
export function getQuoteStatusBadge(q, statusLabels) {
  if (q.quoteStatus === "accepted") return { tone: "success", label: statusLabels.accepted };
  if (q.quoteStatus === "rejected") return { tone: "critical", label: statusLabels.rejected };
  if (q.quoteStatus === "paid") return { tone: "success", label: statusLabels.paid };
  if (q.quoteStatus === "quoted") return { tone: "warning", label: statusLabels.quoted };
  const STATUS_BADGE = {
    new: { tone: "attention", label: statusLabels.new },
    read: { tone: "info", label: statusLabels.read },
  };
  return STATUS_BADGE[q.status] || { tone: "default", label: q.status };
}

/** Short date formatter used for the quote list's date column. */
export const formatDate = formatShortDate;

/**
 * Derives up to two uppercase initials from a display name, for the row
 * avatar (e.g. "Jane Doe" → "JD").
 *
 * @param {string} [name=""]
 * @returns {string}
 */
export function initials(name = "") {
  return name.split(" ").map((w) => w[0]).join("").toUpperCase().slice(0, 2);
}

/**
 * Build the list of page buttons to render: always show first & last, plus a
 * window around the current page; collapse gaps with "…".
 *
 * @param {number} current - current 1-indexed page
 * @param {number} total - total number of pages
 * @returns {(number|string)[]} page numbers interspersed with "…" placeholders
 */
export function getPageItems(current, total) {
  if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
  const items = [1];
  const start = Math.max(2, current - 1);
  const end = Math.min(total - 1, current + 1);
  if (start > 2) items.push("…");
  for (let p = start; p <= end; p++) items.push(p);
  if (end < total - 1) items.push("…");
  items.push(total);
  return items;
}

const AVATAR_COLORS = [
  "#4f7cff", "#ff6b6b", "#ffa726", "#26c6da", "#66bb6a", "#ab47bc", "#ec407a", "#8d6e63",
];

/**
 * Deterministically picks an avatar background color from a fixed palette
 * based on a hash of the input string (e.g. customer name), so the same
 * customer always gets the same color without storing one.
 *
 * @param {string} [str=""]
 * @returns {string} a hex color from AVATAR_COLORS
 */
export function avatarColor(str = "") {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = str.charCodeAt(i) + ((h << 5) - h);
  return AVATAR_COLORS[Math.abs(h) % AVATAR_COLORS.length];
}

/**
 * All state, derived values, and handlers for the Quote List page
 * (app.quotes.jsx): URL-param-driven filtering/sorting/pagination, row
 * selection + bulk delete, the quote-detail/delete/convert modals, and the
 * CSV export flow (fetch full matching set → build CSV → download).
 */
export function useQuotesList() {
  const {
    quotes, tabCounts,
    page, pageSize, totalCount, totalPages,
    tab: activeTab, search: activeSearch, sortKey,
    appName, primaryColor, successColor, warningColor, cardBackgroundColor,
    labels,
  } = useLoaderData();
  const [, setSearchParams] = useSearchParams();
  const navigation = useNavigation();
  const fetcher = useFetcher();
  const exportFetcher = useFetcher();
  const shopify = useAppBridge();
  const isMobile = useIsMobile();
  const navigate = useNavigate();

  const tabs = TAB_KEYS.map((key) => ({ key, label: labels.tabs[key] }));
  const getStatusBadge = (q) => getQuoteStatusBadge(q, labels.statusBadges);

  // True while a page/tab/search/sort change is being fetched from the backend
  const isFetchingPage = navigation.state === "loading";

  // Update URL search params → triggers a fresh backend fetch via the loader.
  // Any change other than `page` resets back to page 1.
  const updateParams = useCallback((changes, { keepPage = false } = {}) => {
    setSearchParams((prev) => {
      const next = new URLSearchParams(prev);
      Object.entries(changes).forEach(([k, v]) => {
        if (v === null || v === undefined || v === "") next.delete(k);
        else next.set(k, String(v));
      });
      if (!keepPage && !("page" in changes)) next.delete("page");
      return next;
    }, { replace: true, preventScrollReset: true });
  }, [setSearchParams]);

  const [searchQuery, setSearchQuery] = useState(activeSearch || "");
  const [searchOpen, setSearchOpen] = useState(Boolean(activeSearch));
  const [sortPopover, setSortPopover] = useState(false);
  const [selectedQuote, setSelectedQuote] = useState(null);

  // Keep the search box in sync if the URL param changes (e.g. tab reset clears it)
  useEffect(() => { setSearchQuery(activeSearch || ""); }, [activeSearch]);

  // Debounce search input → URL param (so we don't refetch on every keystroke)
  const searchDebounce = useRef(null);
  const onSearchChange = useCallback((v) => {
    setSearchQuery(v);
    if (searchDebounce.current) clearTimeout(searchDebounce.current);
    searchDebounce.current = setTimeout(() => {
      updateParams({ q: v.trim() || null });
    }, 350);
  }, [updateParams]);

  // Bulk selection
  const [selectedIds, setSelectedIds] = useState([]);
  const [bulkDeleteModal, setBulkDeleteModal] = useState(false);

  const toggleOne = (id) =>
    setSelectedIds((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]);

  // Modals
  const [deleteModal, setDeleteModal] = useState({ open: false, quote: null });
  const [convertModal, setConvertModal] = useState({ open: false, quote: null });

  const isBusy = fetcher.state !== "idle";

  // Side effects — fire once per submission cycle
  const lastHandledRef = useRef(null);
  useEffect(() => {
    // Reset when a new submission starts so the next response always fires
    if (fetcher.state === "submitting") {
      lastHandledRef.current = null;
      return;
    }
    if (fetcher.state !== "idle" || !fetcher.data) return;
    if (fetcher.data === lastHandledRef.current) return;
    lastHandledRef.current = fetcher.data;

    const d = fetcher.data;
    if (d.success) {
      const msgs = {
        convertToDraft: `Draft order ${d.draftOrderName} created`,
        duplicate: "Quote duplicated",
        delete: "Quote deleted",
        bulkDelete: `${d.ids?.length ?? 0} quotes deleted`,
        acceptQuote: "Quote accepted — customer notified",
        rejectQuote: "Quote rejected — customer notified",
      };
      if (d.intent !== "markAsRead") {
        shopify.toast.show(msgs[d.intent] || "Done");
      }
      // The loader auto-revalidates after each action, so the current page
      // refreshes from the backend on its own — we just close modals / clear selection.
      if (d.intent === "delete") setDeleteModal({ open: false, quote: null });
      if (d.intent === "bulkDelete") { setSelectedIds([]); setBulkDeleteModal(false); }
      if (d.intent === "convertToDraft") setConvertModal({ open: false, quote: null });
    } else if (d.error) {
      shopify.toast.show(d.error, { isError: true });
    }
  }, [fetcher.state, fetcher.data, shopify]);

  // If the current page ends up past the last page (e.g. after deletes), step back.
  useEffect(() => {
    if (!isFetchingPage && page > totalPages) {
      updateParams({ page: totalPages > 1 ? totalPages : null }, { keepPage: true });
    }
  }, [isFetchingPage, page, totalPages, updateParams]);

  // `quotes` is already the filtered/sorted/paginated slice from the backend.
  const isAllSelected = quotes.length > 0 && quotes.every((q) => selectedIds.includes(q.id));
  const isIndeterminate = selectedIds.length > 0 && !isAllSelected;

  const toggleAll = () =>
    setSelectedIds(isAllSelected ? [] : quotes.map((q) => q.id));

  const handleTabChange = (key) => {
    setSelectedIds([]);
    updateParams({ tab: key === "all" ? null : key, q: null });
  };

  const goToPage = (p) =>
    updateParams({ page: p <= 1 ? null : p }, { keepPage: true });

  const handleRowClick = useCallback((quote) => {
    navigate(`/app/quote/${quote.id}`);
  }, [navigate]);

  const handleConvertToDraft = useCallback((quote) => {
    setConvertModal({ open: true, quote });
  }, []);

  const handleConvertConfirm = useCallback(() => {
    if (!convertModal.quote) return;
    fetcher.submit(
      { intent: "convertToDraft", quoteId: convertModal.quote.id },
      { method: "post" },
    );
  }, [fetcher, convertModal]);

  const handlePrintPDF = useCallback((quote) => {
    // Customer-submitted fields are untrusted — escape before interpolating into
    // document.write(), otherwise a name/message containing markup executes in
    // this authenticated admin window (stored XSS).
    const esc = escapeHtml;
    const pw = labels.printWindow;

    printHtmlDocument(`
      <html><head><title>${esc(pw.titleTemplate.replace("{name}", quote.customerName))}</title>
      <style>body{font-family:sans-serif;padding:32px;color:#1a1a1a}
      h1{font-size:22px;margin-bottom:4px}
      .sub{color:#666;margin-bottom:24px;font-size:14px}
      table{width:100%;border-collapse:collapse}
      td{padding:8px 0;border-bottom:1px solid #eee;font-size:14px}
      td:first-child{color:#666;width:140px}
      </style></head><body>
      <h1>${esc(appName)}</h1>
      <div class="sub">${esc(pw.generatedOnPrefix)} ${esc(new Date().toLocaleDateString())}</div>
      <table>
        <tr><td>${esc(pw.rowCustomer)}</td><td>${esc(quote.customerName)}</td></tr>
        <tr><td>${esc(pw.rowEmail)}</td><td>${esc(quote.customerEmail)}</td></tr>
        ${quote.customerPhone ? `<tr><td>${esc(pw.rowPhone)}</td><td>${esc(quote.customerPhone)}</td></tr>` : ""}
        ${quote.companyName ? `<tr><td>${esc(pw.rowCompany)}</td><td>${esc(quote.companyName)}</td></tr>` : ""}
        <tr><td>${esc(pw.rowProduct)}</td><td>${esc(quote.productTitle)}</td></tr>
        ${quote.quantity ? `<tr><td>${esc(pw.rowQuantity)}</td><td>${esc(quote.quantity)}</td></tr>` : ""}
        ${quote.message ? `<tr><td>${esc(pw.rowMessage)}</td><td>${esc(quote.message)}</td></tr>` : ""}
        <tr><td>${esc(pw.rowStatus)}</td><td>${esc(quote.status)}</td></tr>
        <tr><td>${esc(pw.rowSubmitted)}</td><td>${esc(new Date(quote.createdAt).toLocaleString())}</td></tr>
      </table>
      </body></html>
    `);
  }, [appName, labels.printWindow]);

  const handleDuplicate = useCallback((quote) => {
    fetcher.submit({ intent: "duplicate", quoteId: quote.id }, { method: "post" });
  }, [fetcher]);

  const handleDeleteClick = useCallback((quote) => {
    setDeleteModal({ open: true, quote });
  }, []);

  const handleDeleteConfirm = useCallback(() => {
    if (!deleteModal.quote) return;
    fetcher.submit({ intent: "delete", quoteId: deleteModal.quote.id }, { method: "post" });
  }, [fetcher, deleteModal]);

  // Export pulls the FULL matching set from the backend (not just the visible
  // page): selected rows if any, otherwise everything in the current tab/search.
  const handleExportCSV = useCallback(() => {
    const params = new URLSearchParams();
    if (selectedIds.length) {
      params.set("ids", selectedIds.join(","));
    } else {
      if (activeTab !== "all") params.set("tab", activeTab);
      if (activeSearch) params.set("q", activeSearch);
    }
    exportFetcher.load(`/app/export-quotes?${params.toString()}`);
  }, [selectedIds, activeTab, activeSearch, exportFetcher]);

  // When the export data arrives, build the CSV and trigger a download.
  const exportDoneRef = useRef(null);
  useEffect(() => {
    if (exportFetcher.state !== "idle" || !exportFetcher.data?.quotes) return;
    if (exportFetcher.data === exportDoneRef.current) return;
    exportDoneRef.current = exportFetcher.data;

    const scope = exportFetcher.data.quotes;
    const headers = ["Quote #", "ID", "Customer", "Email", "Phone", "Company", "Product", "Qty", "Status", "Date"];
    const rows = scope.map((q) => [
      formatQuoteNumber(q), q.id, q.customerName, q.customerEmail, q.customerPhone || "",
      q.companyName || "", q.productTitle, q.quantity || "",
      q.status, new Date(q.createdAt).toLocaleDateString(),
    ]);
    const csv = buildCsv(headers, rows);
    downloadBlob(new Blob([csv], { type: "text/csv" }), "quotes.csv");
  }, [exportFetcher.state, exportFetcher.data]);

  const setSort = (key) => {
    updateParams({ sort: key === "date_desc" ? null : key });
    setSortPopover(false);
  };
  const sortOptions = [
    { content: labels.sortOptions.dateDesc, onAction: () => setSort("date_desc") },
    { content: labels.sortOptions.dateAsc, onAction: () => setSort("date_asc") },
    { content: labels.sortOptions.nameAsc, onAction: () => setSort("name_asc") },
    { content: labels.sortOptions.nameDesc, onAction: () => setSort("name_desc") },
  ];

  const sortLabel = {
    date_desc: labels.sortOptions.dateDesc,
    date_asc: labels.sortOptions.dateAsc,
    name_asc: labels.sortOptions.nameAsc,
    name_desc: labels.sortOptions.nameDesc,
  }[sortKey];

  // Parse cart items from formData (set by cart-page submissions)
  const parsedCartItems = (() => {
    if (!selectedQuote?.formData) return null;
    try {
      const parsed = JSON.parse(selectedQuote.formData);
      // v2 format: { __v: 2, cartItems: [...] }
      if (parsed?.__v === 2 && Array.isArray(parsed.cartItems) && parsed.cartItems.length > 0) return parsed.cartItems;
      // legacy array format
      if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].productTitle !== undefined) return parsed;
    } catch {}
    return null;
  })();

  const fmtPrice = formatMoney;

  return {
    quotes, tabCounts, page, pageSize, totalCount, totalPages,
    activeTab, activeSearch, isFetchingPage, isMobile, navigate,
    primaryColor, successColor, warningColor, cardBackgroundColor,
    labels, tabs, getStatusBadge,
    fetcher, exportFetcher, isBusy,
    searchQuery, onSearchChange, searchOpen, setSearchOpen,
    sortPopover, setSortPopover, sortOptions, sortLabel,
    selectedQuote, setSelectedQuote, parsedCartItems, fmtPrice,
    selectedIds, isAllSelected, isIndeterminate, toggleOne, toggleAll,
    bulkDeleteModal, setBulkDeleteModal,
    deleteModal, setDeleteModal,
    convertModal, setConvertModal,
    handleTabChange, goToPage, handleRowClick,
    handleConvertToDraft, handleConvertConfirm,
    handlePrintPDF, handleDuplicate,
    handleDeleteClick, handleDeleteConfirm,
    handleExportCSV,
  };
}

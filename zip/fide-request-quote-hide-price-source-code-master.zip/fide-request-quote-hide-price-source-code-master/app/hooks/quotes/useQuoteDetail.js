import { useState, useMemo, useCallback, useEffect, useRef } from "react";
import { useLoaderData, useFetcher, useNavigate } from "react-router";
import { useAppBridge } from "@shopify/app-bridge-react";
import { useIsMobile } from "../useIsMobile";
import { useTemplateDirtyState } from "../useTemplateDirtyState";
import { quoteFormSchema, flattenZodErrors } from "../../domain/quotes/quoteSchema";
import { formatQuoteNumber } from "../../domain/quotes/quoteNumber";
import { CURRENCY_SYMBOLS } from "../../utils/currency";
import { formatDateTime, formatTimeOnly, formatDayLabel, toMidnight } from "../../utils/date";
import { downloadBlob } from "../../utils/download";
import { printHtmlDocument } from "../../utils/printWindow";

// ─── Status config ────────────────────────────────────────────────────────────

// Tone is a Polaris visual token (functional), not copy — stays as code.
// Display label for each status comes from labels.statusBadges (text-labels.json).
const STATUS_TONES = {
  new:      "attention",
  viewed:   "info",
  quoted:   "warning",
  accepted: "success",
  rejected: "critical",
  paid:     "success",
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

const makeFmt = (currency) => (n) =>
  new Intl.NumberFormat(undefined, {
    style: "currency", currency: currency || "USD", minimumFractionDigits: 2,
  }).format(n || 0);

/** Re-exported date/time formatters, kept under this hook's name for the route's convenience. */
export const fmtDate = formatDateTime;
/** @see fmtDate */
export const fmtTimeOnly = formatTimeOnly;

function getProductImage(p) {
  return p?.media?.edges?.[0]?.node?.image?.url ?? null;
}

// The schema reports every line-item problem under the single "lineItems" key,
// but the form surfaces them in two different places: an empty cart shows the
// error on the product list, while priced-wrong items show it on each item's
// price field. Translate the raw zod errors into the keys the inputs actually
// read (productList / price_<key>) so they render inline instead of vanishing.
// Used for both client-side and server-side (fetcher) validation results.
function mapValidationErrors(rawErrors, items, labels) {
  const mapped = { ...rawErrors };
  if (mapped.lineItems) {
    if (!items.length) {
      mapped.productList = mapped.lineItems; // "Add at least one product" (from the Zod schema)
    } else {
      items.forEach((item) => {
        if (!(parseFloat(item.price) > 0)) mapped[`price_${item._key}`] = labels.validation.priceRequired;
      });
    }
    delete mapped.lineItems;
  }
  return mapped;
}

/**
 * All state, derived values, and handlers for the Quote Detail page
 * (app.quote.$id.jsx): line-item editing, customer/shipping fields, tags,
 * timeline notes, accept/reject email editors, draft-order conversion,
 * PDF printing, and the unsaved-changes tracking for the sticky save bar.
 *
 * @returns {object} everything the route needs to render, grouped (see the
 *   return statement below for the full list) into: loader-derived fields,
 *   core editable state + setters (line items, customer/shipping, tags,
 *   notes), modal open/close state, accept/reject email editor state,
 *   derived values (totals, status flags, unsaved-changes flag), and
 *   handlers (save, print PDF, download attachments, etc).
 */
export function useQuoteDetail() {
  const {
    isNew,
    quote: initial,
    prevId,
    nextId,
    customerQuoteCount,
    productData,
    shopCurrency,
    quoteConfigAccentColor,
    secondaryColor,
    linkColor,
    cardBackgroundColor,
    pdfTemplate,
    acceptTemplate,
    rejectTemplate,
    labels,
  } = useLoaderData();

  const fmt     = makeFmt(shopCurrency);
  const currSym = CURRENCY_SYMBOLS[shopCurrency] || shopCurrency || "$";

  const shopify  = useAppBridge();
  const fetcher  = useFetcher();
  const navigate = useNavigate();
  const isMobile = useIsMobile();

  const [quote, setQuote] = useState(initial);

  // Multi-product line items — restore saved items (admin-edited or cart-page format)
  const [lineItems, setLineItems] = useState(() => {
    try {
      const raw    = JSON.parse(initial.formData || "[]");
      // v2 combined format: { __v: 2, cartItems: [...], formFields: [...] }
      const parsed = (!Array.isArray(raw) && raw?.__v === 2) ? raw.cartItems : raw;
      if (Array.isArray(parsed) && parsed.length > 0) {
        const first = parsed[0];
        // Admin-saved format: { title, qty, price, ... } (saved by handleSave)
        if ("title" in first && "qty" in first && !("key" in first) && !("label" in first)) {
          return parsed.map((item, i) => ({ ...item, _key: `saved-${i}` }));
        }
        // Cart-page format: { productTitle, quantity, offerPrice, price, variantId, note, ... }
        if ("productTitle" in first) {
          const normId = (id) => id ? String(id).replace(/^gid:\/\/shopify\/Product\//, "") : null;
          const pdImg = productData ? getProductImage(productData) : null;
          return parsed.map((item, i) => ({
            _key:               `saved-${i}`,
            productId:          item.productId  || null,
            variantId:          item.variantId  || null,
            title:              item.productTitle || "Product",
            image:              item.image  || (pdImg && normId(item.productId) === normId(initial.productId) ? pdImg : null) || null,
            vendor:             item.vendor || null,
            sku:                item.sku    || null,
            options:            [],
            qty:                String(item.quantity || "1"),
            price:              item.offerPrice != null ? String(parseFloat(item.offerPrice) || "") : String(item.price || ""),
            customerOfferPrice: item.offerPrice != null ? parseFloat(item.offerPrice) : null,
            note:               item.note   || null,
          }));
        }
      }
    } catch {}
    if (!initial.productId && !initial.productTitle) return [];
    return [{
      _key:      "initial",
      productId: initial.productId,
      variantId: productData?.variants?.edges?.[0]?.node?.id ?? null,
      title:     initial.productTitle,
      image:     productData ? getProductImage(productData) : null,
      vendor:    productData?.vendor ?? initial.companyName ?? null,
      sku:       productData?.variants?.edges?.[0]?.node?.sku ?? null,
      options:   productData?.variants?.edges?.[0]?.node?.selectedOptions ?? [],
      qty:       String(initial.quantity   || "1"),
      price:     String(initial.quotedPrice || ""),
    }];
  });

  const updateLineItem = (key, field, val) => {
    let safe = val;
    if (field === "qty") {
      safe = val.replace(/[^0-9]/g, "") || "1";
      if (parseInt(safe, 10) < 1) safe = "1";
    } else if (field === "price") {
      safe = val.replace(/[^0-9.]/g, "").replace(/^(\d*\.?\d*).*$/, "$1");
    }
    setLineItems((prev) => prev.map((i) => i._key === key ? { ...i, [field]: safe } : i));
  };

  const removeLineItem = (key) =>
    setLineItems((prev) => prev.filter((i) => i._key !== key));

  // Mobile quirk: closing the resource picker returns focus to the readOnly
  // trigger field, which re-fires its onFocus and reopens the picker — and the
  // reopened pick re-adds the same products (the old dedup read a stale
  // `lineItems` closure, so concurrent calls both saw an empty list). This ref
  // makes the handler non-reentrant so a refocus can't relaunch it mid-pick.
  const pickerBusyRef = useRef(false);

  const handlePickProduct = async () => {
    if (pickerBusyRef.current) return;
    pickerBusyRef.current = true;
    try {
      const selection = await shopify.resourcePicker({ type: "product", multiple: true });
      if (!selection?.length) return;
      const existingIds = new Set(lineItems.map((i) => i.productId));
      const toAdd = selection
        .filter((p) => !existingIds.has(p.id))
        .map((p) => {
          const variant = p.variants?.[0];
          return {
            _key:      `${p.id}-${Date.now()}`,
            productId: p.id,
            variantId: variant?.id ?? null,
            title:     p.title,
            image:     p.images?.[0]?.originalSrc ?? null,
            vendor:    p.vendor ?? null,
            sku:       variant?.sku ?? null,
            options:   variant?.selectedOptions ?? [],
            qty:       "1",
            price:     String(variant?.price ?? ""),
          };
        });
      if (!toAdd.length) { shopify.toast.show(labels.productsCard.alreadyAddedToast); return; }
      setLineItems((prev) => {
        // Guard again at commit time: skip any product the freshest state
        // already has, so a stale closure can never duplicate a row.
        const have = new Set(prev.map((i) => i.productId));
        const fresh = toAdd.filter((p) => !have.has(p.productId));
        return fresh.length ? [...prev, ...fresh] : prev;
      });
      shopify.toast.show(
        labels.productsCard.productsAddedToastTemplate
          .replace("{count}", toAdd.length)
          .replace("{plural}", toAdd.length !== 1 ? "s" : ""),
      );
    } finally {
      pickerBusyRef.current = false;
    }
  };
  const [customerName,  setCustomerName]  = useState(initial.customerName  || "");
  const [customerEmail, setCustomerEmail] = useState(initial.customerEmail || "");
  const [customerPhone, setCustomerPhone] = useState(initial.customerPhone || "");
  const [companyName]   = useState(initial.companyName   || "");
  const [message,       setMessage]       = useState(initial.message       || "");
  // Customer + shipping details default to read-only when reviewing an existing
  // quote; new quotes start in edit mode so the merchant can fill them in.
  const [customerEditMode, setCustomerEditMode] = useState(isNew);
  const [lightbox, setLightbox] = useState({ open: false, images: [], index: 0 });
  const [shippingAddr,  setShippingAddr]  = useState(() => {
    const empty = { street: "", city: "", state: "", postal: "", country: "", district: "" };
    try {
      const raw = JSON.parse(initial.formData || "{}");
      // Merchant-saved address (explicit key) — highest priority
      if (raw.__shippingAddr && Object.values(raw.__shippingAddr).some(Boolean)) {
        return { ...empty, ...raw.__shippingAddr };
      }
      // Extract from customer-submitted form fields
      const fields = (!Array.isArray(raw) && raw?.__v === 2)
        ? (raw.formFields || [])
        : (Array.isArray(raw) ? raw : []);
      if (fields.length > 0 && ("key" in fields[0] || "label" in fields[0])) {
        const addr = { ...empty };
        for (const f of fields) {
          const lbl = (f.label || f.key || "").toLowerCase().trim();
          if (/street|address\b/.test(lbl))   addr.street   = String(f.value || "");
          else if (/\bcity\b/.test(lbl))       addr.city     = String(f.value || "");
          else if (/state|province/.test(lbl)) addr.state    = String(f.value || "");
          else if (/district/.test(lbl))       addr.district = String(f.value || "");
          else if (/zip|postal/.test(lbl))     addr.postal   = String(f.value || "");
          else if (/^country$/.test(lbl))      addr.country  = String(f.value || "");
        }
        return addr;
      }
    } catch {}
    return empty;
  });
  const [quotedCurrency] = useState(initial.quotedCurrency || shopCurrency || "USD");
  const [expiresAt]      = useState(initial.expiresAt ? new Date(initial.expiresAt).toISOString().split("T")[0] : "");
  const [internalNotes] = useState(initial.internalNotes || "");
  const [discount,      setDiscount]      = useState(String(initial.discount   || "0"));
  const [shipping,      setShipping]      = useState(String(initial.shipping   || "0"));
  const [tax,           setTax]           = useState(String(initial.tax        || "0"));
  const [tags,          setTags]          = useState(() => { try { return JSON.parse(initial.tags || "[]"); } catch { return []; } });
  const [tagOptions,    setTagOptions]    = useState(() => { try { return JSON.parse(initial.tags || "[]"); } catch { return []; } });
  const [tagInput,      setTagInput]      = useState("");
  const [fieldErrors,   setFieldErrors]   = useState({});

  const filteredTagOptions = useMemo(() => {
    if (!tagInput) return tagOptions;
    const re = new RegExp(tagInput, "i");
    return tagOptions.filter((t) => re.test(t));
  }, [tagInput, tagOptions]);

  const saveTags = useCallback((nextTags) => {
    fetcher.submit(
      { intent: "updateTags", tagsJson: JSON.stringify(nextTags) },
      { method: "post" },
    );
  }, [fetcher]);

  const handleTagSelect = useCallback((value) => {
    setTags((prev) => {
      const next = prev.includes(value) ? prev.filter((t) => t !== value) : [...prev, value];
      saveTags(next);
      return next;
    });
    setTagOptions((prev) => prev.includes(value) ? prev : [...prev, value]);
    setTagInput("");
  }, [saveTags]);

  const removeTag = useCallback((tag) => {
    setTags((prev) => {
      const next = prev.filter((t) => t !== tag);
      saveTags(next);
      return next;
    });
  }, [saveTags]);

  // Timeline notes
  const [noteText,     setNoteText]     = useState("");
  const [notesHistory, setNotesHistory] = useState(() => {
    try { return JSON.parse(initial.notesHistory || "[]"); } catch { return []; }
  });

  // Modals
  const [acceptModal,   setAcceptModal]   = useState(false);
  const [rejectModal,   setRejectModal]   = useState(false);
  const [draftModal,    setDraftModal]    = useState(false);
  const [draftResult,   setDraftResult]   = useState(null);
  const [acceptShowCta, setAcceptShowCta] = useState(true);
  const [rejectShowCta, setRejectShowCta] = useState(true);

  // Accept email editor — synced from saved template, falls back to
  // labels.acceptModal's defaults (buyer-editable copy)
  const [acceptEmailSubject, setAcceptEmailSubject] = useState(
    acceptTemplate?.subject ?? labels.acceptModal.defaultEmailSubjectTemplate.replace("{productTitle}", initial.productTitle)
  );
  const [acceptEmailHeading, setAcceptEmailHeading] = useState(
    acceptTemplate?.heading ?? labels.acceptModal.defaultEmailHeading
  );
  const [acceptEmailContent, setAcceptEmailContent] = useState(
    acceptTemplate?.content ?? labels.acceptModal.defaultEmailContent
  );
  const [acceptEmailAction,  setAcceptEmailAction]  = useState(
    acceptTemplate?.action ?? labels.acceptModal.defaultEmailAction
  );
  const [acceptEmailCheckoutUrl, setAcceptEmailCheckoutUrl] = useState(initial.checkoutLink || "");

  // Reject email editor — synced from saved template, falls back to
  // labels.rejectModal's defaults (buyer-editable copy)
  const [rejectEmailSubject, setRejectEmailSubject] = useState(
    rejectTemplate?.subject ?? labels.rejectModal.defaultEmailSubjectTemplate.replace("{productTitle}", initial.productTitle)
  );
  const [rejectEmailHeading, setRejectEmailHeading] = useState(
    rejectTemplate?.heading ?? labels.rejectModal.defaultEmailHeading
  );
  const [rejectEmailContent, setRejectEmailContent] = useState(
    rejectTemplate?.content ?? labels.rejectModal.defaultEmailContentTemplate
      .replace("{customerName}", initial.customerName)
      .replace("{productTitle}", initial.productTitle)
  );
  const [rejectEmailAction,  setRejectEmailAction]  = useState(
    rejectTemplate?.action ?? labels.rejectModal.defaultEmailAction
  );

  const isBusy   = fetcher.state !== "idle";
  const subtotal = lineItems.reduce(
    (sum, item) => sum + Math.max(0, parseFloat(item.qty) || 0) * Math.max(0, parseFloat(item.price) || 0), 0,
  );
  const total    = subtotal
    - Math.max(0, parseFloat(discount || 0))
    + Math.max(0, parseFloat(shipping || 0))
    + Math.max(0, parseFloat(tax      || 0));
  const sc        = {
    tone:  STATUS_TONES[quote.quoteStatus] || STATUS_TONES.new,
    label: labels.statusBadges[quote.quoteStatus] || labels.statusBadges.new,
  };
  const isAccepted = quote.quoteStatus === "accepted";
  const isRejected = quote.quoteStatus === "rejected";
  const isPaid     = quote.quoteStatus === "paid";
  const isClosed      = isAccepted || isRejected || isPaid;

  // Track unsaved edits so the details page can show a non-intrusive "unsaved
  // changes" banner (existing quotes only — new quotes are blank until created).
  // Changes are not persisted until the merchant clicks Save; the banner stays
  // until they save (baseline reset below) or leave the page. No saveBarId —
  // this page renders its own StickySaveBar instead of the App Bridge one.
  const formSnapshot = useMemo(() => ({
    customerName, customerEmail, customerPhone, companyName, message,
    shippingAddr, quotedCurrency, expiresAt, internalNotes,
    discount, shipping, tax, tags,
    items: lineItems.map(({ _key, ...rest }) => rest),
  }), [customerName, customerEmail, customerPhone, companyName, message,
       shippingAddr, quotedCurrency, expiresAt, internalNotes,
       discount, shipping, tax, tags, lineItems]);
  const { isDirty: isFormDirty, markClean: markFormClean } = useTemplateDirtyState(formSnapshot);
  const hasUnsavedChanges = !isNew && isFormDirty;

  const hasDraftOrder = !!(quote.draftOrderName || fetcher.data?.intent === "convertToDraft");
  const activeDraftName = quote.draftOrderName || fetcher.data?.draftOrderName || null;
  const activeDraftUrl  = quote.checkoutLink   || fetcher.data?.draftOrderInvoice || null;

  async function downloadFile(url) {
    try {
      const res = await fetch(url);
      const blob = await res.blob();
      downloadBlob(blob, url.split("/").pop().split("?")[0] || "file");
    } catch {
      window.open(url, "_blank");
    }
  }

  async function downloadAll(urls) {
    for (let i = 0; i < urls.length; i++) {
      await downloadFile(urls[i]);
      if (i < urls.length - 1) await new Promise((r) => setTimeout(r, 300));
    }
  }

  // Extra custom form fields from the customer submission, filtered down to
  // whatever isn't already shown in the customer section or address inputs.
  let extraFields = [];
  try {
    const raw = JSON.parse(quote.formData || "[]");
    const fields = (!Array.isArray(raw) && raw?.__v === 2)
      ? (raw.formFields || [])
      : (Array.isArray(raw) ? raw : []);
    if (fields.length > 0 && ("key" in fields[0] || "label" in fields[0])) {
      extraFields = fields;
    }
  } catch {}
  const otherFields = extraFields.filter((f) => {
    const lbl = (f.label || f.key || "").toLowerCase().trim();
    return !/street|address\b|\bcity\b|state|province|district|zip|postal|^country$|first.?name|last.?name|email|phone|message/.test(lbl);
  });

  // Timeline — build the unified, day-grouped event list (raw data only; the
  // route builds the actual JSX rows from these groups).
  const tc = labels.timelineCard;
  const timelineEvents = [
    { type: "activity", label: tc.eventQuoteSubmitted,   date: quote.createdAt,  show: true },
    { type: "activity", label: tc.eventViewedByMerchant, date: quote.updatedAt,  show: quote.quoteStatus !== "new" },
    { type: "activity", label: tc.eventQuoteAccepted,    date: quote.updatedAt, show: isAccepted || isPaid },
    { type: "activity", label: tc.eventPaymentReceived,  date: quote.updatedAt, show: isPaid },
    { type: "activity", label: tc.eventQuoteRejected,    date: quote.updatedAt, show: isRejected },
    ...notesHistory.map((n) => ({
      type: "note",
      label: n.text,
      date:  n.postedAt,
      show:  true,
    })),
  ].filter((e) => e.show).sort((a, b) => new Date(b.date) - new Date(a.date));

  const timelineGroups = [];
  timelineEvents.forEach((ev) => {
    const day = toMidnight(ev.date);
    const last = timelineGroups[timelineGroups.length - 1];
    if (last && last.day === day) { last.events.push(ev); }
    else { timelineGroups.push({ day, label: formatDayLabel(ev.date), events: [ev] }); }
  });

  // Toast — runs after each completed fetch, never during render
  const lastSeenDataRef = useRef(null);
  useEffect(() => {
    if (fetcher.state !== "idle" || !fetcher.data) return;
    if (fetcher.data === lastSeenDataRef.current) return;
    lastSeenDataRef.current = fetcher.data;

    if (fetcher.data.success) {
      const t = labels.toasts;
      const msgs = {
        updateStatus:    t.statusUpdated,
        updateQuote:     t.quoteSaved,
        accept:          t.accepted,
        acceptWithEmail: t.acceptedWithEmail,
        reject:          t.rejected,
        rejectWithEmail: t.rejectedWithEmail,
        paymentReceived: t.paymentReceived,
        reopen:          t.reopened,
        duplicate:       t.duplicated,
        convertToDraft:  t.draftOrderCreatedTemplate.replace("{name}", fetcher.data.draftOrderName),
        addNote:         t.noteAdded,
        updateTags:      t.tagsSaved,
      };
      shopify.toast.show(msgs[fetcher.data.intent] || t.genericDone);

      // Saved — make the current form state the new clean baseline so the
      // "unsaved changes" banner clears.
      if (fetcher.data.intent === "updateQuote") markFormClean();

      if (fetcher.data.intent === "addNote") {
        const text = fetcher.formData?.get("noteText") || "";
        setNoteText("");
        setNotesHistory((prev) => [...prev, { text, postedAt: new Date().toISOString() }]);
      }
      if (fetcher.data.intent === "accept" || fetcher.data.intent === "acceptWithEmail") {
        setQuote((q) => ({ ...q, quoteStatus: "accepted", checkoutLink: fetcher.data.checkoutLink ?? q.checkoutLink }));
        if (fetcher.data.checkoutLink) setAcceptEmailCheckoutUrl(fetcher.data.checkoutLink);
      }
      if (fetcher.data.intent === "reject" || fetcher.data.intent === "rejectWithEmail")
        setQuote((q) => ({ ...q, quoteStatus: "rejected" }));
      if (fetcher.data.intent === "paymentReceived") setQuote((q) => ({ ...q, quoteStatus: "paid" }));
      if (fetcher.data.intent === "reopen")          setQuote((q) => ({ ...q, quoteStatus: "viewed" }));
      if (fetcher.data.intent === "convertToDraft") {
        setDraftResult(fetcher.data);
        setDraftModal(true);
      }
      setAcceptModal(false);
      setRejectModal(false);
    } else if (fetcher.data.error) {
      // Surface server-side validation inline (not just a generic toast) so the
      // user sees which field failed and why — same mapping as the client path.
      if (fetcher.data.fieldErrors && Object.keys(fetcher.data.fieldErrors).length) {
        const mapped = mapValidationErrors(fetcher.data.fieldErrors, lineItems, labels);
        setFieldErrors(mapped);
        if (Object.keys(mapped).some((k) => k.startsWith("customer") || k.startsWith("shippingAddr"))) {
          setCustomerEditMode(true);
        }
        shopify.toast.show(labels.toasts.fixHighlightedFields, { isError: true });
      } else {
        shopify.toast.show(fetcher.data.error, { isError: true });
      }
    }
  }, [fetcher.data, fetcher.state, shopify, labels]);

  const submit = (data) => fetcher.submit(data, { method: "post" });

  const clearError = (field) => setFieldErrors((e) => ({ ...e, [field]: "" }));

  const handleSave = () => {
    const result = quoteFormSchema.safeParse({
      customerName,
      customerEmail,
      customerPhone,
      shippingAddr,
      lineItems,
    });
    const flat = mapValidationErrors(flattenZodErrors(result), lineItems, labels);
    if (!result.success && Object.keys(flat).length > 0) {
      setFieldErrors(flat);
      // Reveal the customer card's fields if any of them failed validation
      if (Object.keys(flat).some((k) => k.startsWith("customer") || k.startsWith("shippingAddr"))) {
        setCustomerEditMode(true);
      }
      return;
    }
    if (parseFloat(discount || 0) > subtotal) {
      // The discount field already shows an inline "cannot exceed subtotal"
      // error; add a toast so it's clear why the Create/Save did nothing.
      shopify.toast.show(labels.paymentCard.discountExceedsSubtotalToast, { isError: true });
      return;
    }
    setFieldErrors({});
    const first = lineItems[0];
    submit({
      intent: "updateQuote",
      customerName,
      customerEmail,
      customerPhone,
      companyName,
      message,
      shippingAddrJson: JSON.stringify(shippingAddr),
      quotedCurrency,
      expiresAt,
      quotedPrice: String(total.toFixed(2)),
      quantity: first?.qty ?? "1",
      internalNotes,
      discount,
      shipping,
      tax,
      lineItemsJson: JSON.stringify(lineItems.map(({ _key, ...rest }) => rest)),
    });
  };

  const handlePrintPDF = () => {
    const pp = labels.pdfPrint;
    const tpl = pdfTemplate || {};
    const accent = tpl.primaryColor || quoteConfigAccentColor || "#2c6ecb";
    const docTitle = tpl.documentTitle || pp.docTitleTemplate.replace("{number}", formatQuoteNumber(quote));

    const headerHtml = tpl.companyName ? `
      <div class="brand">
        ${tpl.companyLogo ? `<img src="${tpl.companyLogo}" alt="${tpl.companyName}" style="max-height:48px;max-width:160px;object-fit:contain;margin-bottom:4px;">` : ""}
        <div class="brand-name">${tpl.companyName}</div>
        ${tpl.companyAddress ? `<div class="brand-sub">${tpl.companyAddress}</div>` : ""}
        ${tpl.companyPhone   ? `<div class="brand-sub">${tpl.companyPhone}</div>`   : ""}
        ${tpl.companyEmail   ? `<div class="brand-sub">${tpl.companyEmail}</div>`   : ""}
      </div>` : "";

    const itemRows = lineItems.map((item) => {
      const qty   = parseFloat(item.qty  || 1);
      const price = parseFloat(item.price || 0);
      return `<tr>
        <td>${item.title || quote.productTitle}</td>
        <td style="text-align:center">${qty}</td>
        <td style="text-align:right">${fmt(price)}</td>
        <td style="text-align:right">${fmt(qty * price)}</td>
      </tr>`;
    }).join("");

    printHtmlDocument(`<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>${docTitle}</title>
<style>
  @media print { body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:system-ui,sans-serif;font-size:13px;color:#1a1a1a;padding:48px;max-width:740px;margin:0 auto}
  .header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:32px;padding-bottom:20px;border-bottom:3px solid ${accent}}
  .brand{text-align:right}
  .brand-name{font-size:15px;font-weight:700;color:${accent}}
  .brand-sub{font-size:11px;color:#666;margin-top:2px}
  .doc-title{font-size:24px;font-weight:800;color:#111;margin-bottom:4px}
  .doc-sub{font-size:12px;color:#888}
  h2{font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#888;margin:24px 0 10px;padding-bottom:6px;border-bottom:1px solid #eee}
  .grid{display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-bottom:8px}
  .lbl{font-size:10px;color:#999;text-transform:uppercase;letter-spacing:.06em;margin-bottom:2px}
  .val{font-size:13px;color:#111}
  table{width:100%;border-collapse:collapse;margin-bottom:4px}
  thead th{background:${accent};color:#fff;padding:8px 10px;text-align:left;font-size:11px;font-weight:600}
  thead th:not(:first-child){text-align:right}
  tbody td{padding:8px 10px;border-bottom:1px solid #f0f0f0;vertical-align:top}
  tbody td:not(:first-child){text-align:right}
  .totals td{padding:6px 10px}
  .totals .grand td{font-weight:700;border-top:2px solid #111;padding-top:10px;font-size:14px}
  .note{font-size:12px;color:#555;line-height:1.6;margin-top:6px}
  .footer{margin-top:40px;padding-top:16px;border-top:1px solid #eee;font-size:11px;color:#aaa;text-align:center}
  @page{margin:24px}
</style></head><body>
<div class="header">
  <div>
    <div class="doc-title">${docTitle}</div>
    <div class="doc-sub">${formatQuoteNumber(quote)} &nbsp;·&nbsp; ${new Date().toLocaleDateString(undefined,{year:"numeric",month:"long",day:"numeric"})} &nbsp;·&nbsp; <span style="color:${accent};font-weight:600">${sc.label}</span></div>
  </div>
  ${headerHtml}
</div>

${tpl.headerNote ? `<p class="note" style="margin-bottom:24px">${tpl.headerNote}</p>` : ""}

<h2>${pp.customerHeading}</h2>
<div class="grid">
  <div>
    <div class="lbl">${pp.nameLabel}</div><div class="val">${quote.customerName}</div>
    ${quote.companyName ? `<div class="lbl" style="margin-top:8px">${pp.companyLabel}</div><div class="val">${quote.companyName}</div>` : ""}
  </div>
  <div>
    <div class="lbl">${pp.emailLabel}</div><div class="val">${quote.customerEmail}</div>
    ${quote.customerPhone ? `<div class="lbl" style="margin-top:8px">${pp.phoneLabel}</div><div class="val">${quote.customerPhone}</div>` : ""}
  </div>
</div>

<h2>${pp.productsHeading}</h2>
<table>
  <thead><tr><th>${pp.columnProduct}</th><th>${pp.columnQty}</th><th>${pp.columnUnitPrice}</th><th>${pp.columnTotal}</th></tr></thead>
  <tbody>${itemRows}</tbody>
</table>

<h2>${pp.summaryHeading}</h2>
<table class="totals" style="max-width:320px;margin-left:auto">
  <tbody>
    <tr><td>${pp.subtotalLabel}</td><td>${fmt(subtotal)}</td></tr>
    ${parseFloat(discount) > 0 ? `<tr><td>${pp.discountLabel}</td><td>-${fmt(parseFloat(discount))}</td></tr>` : ""}
    ${parseFloat(shipping) > 0 ? `<tr><td>${pp.shippingLabel}</td><td>${fmt(parseFloat(shipping))}</td></tr>` : ""}
    ${parseFloat(tax)      > 0 ? `<tr><td>${pp.taxLabel}</td><td>${fmt(parseFloat(tax))}</td></tr>` : ""}
    <tr class="grand"><td>${pp.totalLabel}</td><td>${fmt(total)}</td></tr>
  </tbody>
</table>

${quote.message ? `<h2>${pp.notesHeading}</h2><p class="note">${quote.message}</p>` : ""}
${tpl.footerNote ? `<div class="footer">${tpl.footerNote}</div>` : ""}
</body></html>`);
  };

  return {
    // loader-derived
    isNew, prevId, nextId, customerQuoteCount,
    secondaryColor, linkColor, cardBackgroundColor,
    labels,

    // core state
    quote, setQuote,
    lineItems, updateLineItem, removeLineItem, handlePickProduct,
    customerName, setCustomerName,
    customerEmail, setCustomerEmail,
    customerPhone, setCustomerPhone,
    companyName,
    message, setMessage,
    customerEditMode, setCustomerEditMode,
    lightbox, setLightbox,
    shippingAddr, setShippingAddr,
    quotedCurrency, expiresAt, internalNotes,
    discount, setDiscount,
    shipping, setShipping,
    tax, setTax,
    tags, tagOptions, tagInput, setTagInput,
    filteredTagOptions, handleTagSelect, removeTag,
    fieldErrors, clearError,
    noteText, setNoteText, notesHistory,

    // modals
    acceptModal, setAcceptModal,
    rejectModal, setRejectModal,
    draftModal, setDraftModal, draftResult,
    acceptShowCta, setAcceptShowCta,
    rejectShowCta, setRejectShowCta,

    // accept email editor
    acceptEmailSubject, setAcceptEmailSubject,
    acceptEmailHeading, setAcceptEmailHeading,
    acceptEmailContent, setAcceptEmailContent,
    acceptEmailAction, setAcceptEmailAction,
    acceptEmailCheckoutUrl, setAcceptEmailCheckoutUrl,

    // reject email editor
    rejectEmailSubject, setRejectEmailSubject,
    rejectEmailHeading, setRejectEmailHeading,
    rejectEmailContent, setRejectEmailContent,
    rejectEmailAction, setRejectEmailAction,

    // derived
    fmt, currSym, isMobile, isBusy,
    subtotal, total, sc,
    isAccepted, isRejected, isPaid, isClosed,
    hasUnsavedChanges, markFormClean,
    hasDraftOrder, activeDraftName, activeDraftUrl,
    otherFields, timelineGroups,

    // handlers
    downloadFile, downloadAll,
    submit, handleSave, handlePrintPDF,

    // react-router / app bridge
    navigate, fetcher, shopify,
  };
}

import { useState, useCallback, useMemo, useEffect } from "react";
import { useLoaderData, useFetcher } from "react-router";
import { useAppBridge } from "@shopify/app-bridge-react";
import { useIsMobile } from "../useIsMobile";
import { useTemplateDirtyState } from "../useTemplateDirtyState";
import { useFormFieldList } from "../useFormFieldList";
import { CURRENCY_SYMBOLS } from "../../utils/currency";
import { isValidEmail, isValidPhone } from "../../utils/validation";

/** Polaris <Tabs> definitions for the Quote Settings page's two tabs. */
export const TABS = [
  { id: "tab-1", content: "Quote Settings", panelID: "tab-1-panel" },
  { id: "tab-2", content: "Form Builder", panelID: "tab-2-panel" },
];

// ── makeField and defaults live outside the component (no component deps) ──
const makeField = (id, type, label, placeholder = "", required = false) => ({
  id, type, open: false, label, placeholder, helpText: "", required,
  options: ["Option 1", "Option 2"], content: "", rows: 4, min: "", max: "", accept: "",
});
// Contact + shipping fields are required by default; only the free-form Message
// is optional. New custom fields the merchant adds still default to optional.
const DEFAULT_CONTACT = [
  makeField(1, "Text", "First name", "Enter first name", true),
  makeField(2, "Text", "Last name", "Enter last name", true),
  makeField(3, "Email", "Email address", "Enter email address", true),
  makeField(4, "Phone", "Phone number", "Enter phone number", true),
];
const DEFAULT_SHIPPING = [
  makeField(10, "Text", "Street address", "Enter street address", true),
  makeField(11, "Text", "City", "Enter city", true),
  makeField(15, "Text", "District", "Enter district", true),
  makeField(12, "Text", "State / Province", "Enter state or province", true),
  makeField(13, "Text", "Zip / Postal code", "Enter zip or postal code", true),
  makeField(14, "Country", "Country", "", true),
];
const DEFAULT_EXTRA = [makeField(20, "Textarea", "Message", "Enter your message")];

function parseSchema(formSchemaRow) {
  try { return formSchemaRow?.fields ? JSON.parse(formSchemaRow.fields) : {}; }
  catch { return {}; }
}

// ── FIELD_META — added Dropdown + Checkbox ──
/**
 * Per-field-type metadata for the Form Builder: which badge tone to show and
 * which optional config controls (placeholder, help text, options, min/max,
 * accept, etc.) apply to that field type. Keyed by the same strings used as
 * `el.type` on form-builder elements.
 */
export const FIELD_META = {
  "Text": { badge: "info", hasPlaceholder: true, hasHelpText: true },
  "Textarea": { badge: "info", hasPlaceholder: true, hasHelpText: true, hasRows: true },
  "Email": { badge: "success", hasPlaceholder: true, hasHelpText: true },
  "Phone": { badge: "success", hasPlaceholder: true, hasHelpText: true },
  "Date field": { badge: "warning", hasPlaceholder: false, hasHelpText: true },
  "File Upload": { badge: "attention", hasPlaceholder: false, hasHelpText: true, hasAccept: true, hasMultiple: true },
  "Country": { badge: "new", hasPlaceholder: false, hasHelpText: true },
  "Radio Group": { badge: "new", hasPlaceholder: false, hasHelpText: true, hasOptions: true },
  "Dropdown": { badge: "new", hasPlaceholder: false, hasHelpText: true, hasOptions: true },
  "Checkbox": { badge: "info", hasPlaceholder: false, hasHelpText: true },
  "Number": { badge: "info", hasPlaceholder: true, hasHelpText: true, hasMinMax: true },
  "Paragraph": { badge: "attention", hasPlaceholder: false, hasHelpText: false, hasContent: true },
};

/** The list of selectable Form Builder field types, derived from FIELD_META's keys. */
export const ELEMENT_TYPES = Object.keys(FIELD_META);

/**
 * All state, derived values, and handlers for the Quote Settings / Form
 * Builder page (app.quote-settings.jsx): Tab 1 (button placement, styling,
 * widget, toast, hide-price rules) and Tab 2 (form builder field lists +
 * live/interactive preview). Everything saves through a single `saveAll`
 * action into one `QuoteConfig` row per shop, so this hook tracks one large,
 * flat piece of state rather than per-section forms — see `currentState`
 * (dirty-tracking via useTemplateDirtyState) and `handleSave`/`handleDiscard`
 * below for how that's kept manageable.
 *
 * JSX-building render helpers (renderFieldSection, renderVisualFieldPreview,
 * renderInteractiveFieldPreview) stay in the route component — this is a
 * plain .js file and cannot contain JSX — but the plain data/state/handlers
 * they close over all live here.
 */
export function useQuoteSettingsPage() {
  const { config, targetProducts, hidePriceProductsDb, formSchemaRow, shopCurrency, shop, errorColor, accentColor, successColor } = useLoaderData();
  const currSym = CURRENCY_SYMBOLS[shopCurrency] || shopCurrency || "$";
  const fetcher = useFetcher();
  const shopify = useAppBridge();
  const isMobile = useIsMobile();
  const [selected, setSelected] = useState(0);

  // ── Tab 1 state — seeded from DB ──────────────────────────────────────────
  const [targetMode, setTargetMode] = useState(() => {
    const tm = config?.targetMode ?? "all";
    if (tm === "products") return "specific";
    if (tm === "collections") return "Collections";
    return "all";
  });
  const [selectedProducts, setSelectedProducts] = useState(() =>
    (targetProducts || []).map((p) => ({ id: p.productId, title: p.productTitle, image: p.productImage, handle: p.productHandle }))
  );
  const [selectedCollections, setSelectedCollections] = useState(() => {
    try { return config?.targetCollections ? JSON.parse(config.targetCollections) : []; } catch { return []; }
  });
  const initialDisplayMode = config?.productPageDisplay === "inline_form" ? "button_only" : (config?.productPageDisplay ?? "button_only");
  const [displayMode, setDisplayMode] = useState(initialDisplayMode);
  const [showOnCollectionPage, setShowOnCollectionPage] = useState(config?.showOnProductList ?? false);
  const [showOnHomepage, setShowOnHomepage] = useState(config?.showOnHomepage ?? false);
  const [messageType, setMessageType] = useState(() => {
    const beh = config?.addToQuoteBehaviour ?? "popup_and_form";
    if (beh === "redirect_quote_page") return "popup_and_form";
    if (beh === "toast") return "popup_and_form";
    return beh;
  });
  const [successMessage, setSuccessMessage] = useState(config?.successMessage ?? "Thank you! We will be in touch shortly.");
  const [buttonBorderRadius, setButtonBorderRadius] = useState(config?.buttonBorderRadius ?? 6);
  const [buttonWidth, setButtonWidth] = useState(config?.buttonFullWidth !== false ? "full" : "auto");
  const [visibilityMode, setVisibilityMode] = useState(() => {
    const tags = config?.requiredTags ? JSON.parse(config.requiredTags) : [];
    if (tags.length > 0) return "tagged";
    if (config?.requireLogin) return "loggedin";
    return "everyone";
  });
  const [selectedTags, setSelectedTags] = useState(() => { try { return config?.requiredTags ? JSON.parse(config.requiredTags) : []; } catch { return []; } });
  const [tagOptions, setTagOptions] = useState(() => { try { return config?.requiredTags ? JSON.parse(config.requiredTags) : []; } catch { return []; } });
  const [tagInputValue, setTagInputValue] = useState("");

  const [buttonLabel, setButtonLabel] = useState(config?.buttonText ?? "Request a Quote");
  const [textColorHsb, setTextColorHsb] = useState(config?.buttonTextColor ?? "#ffffff");
  const [buttonColorHsb, setButtonColorHsb] = useState(config?.buttonBgColor ?? "#1a1a18");
  const [fontSize, setFontSize] = useState(config?.buttonFontSize ?? 14);
  const [buttonPosition, setButtonPosition] = useState(config?.buttonPosition ?? "below_atc");

  // ── Floating "quote cart" widget settings ─────────────────────────────────
  const [widgetEnabled, setWidgetEnabled] = useState(config?.widgetEnabled ?? true);
  const [widgetButtonText, setWidgetButtonText] = useState(config?.widgetButtonText ?? "Request a Quote");
  const [widgetPosition, setWidgetPosition] = useState(config?.widgetPosition ?? "bottom_right");
  const [widgetBgColorHsb, setWidgetBgColorHsb] = useState(config?.widgetBgColor ?? "#1a1a18");
  const [widgetTxtColorHsb, setWidgetTxtColorHsb] = useState(config?.widgetTextColor ?? "#ffffff");

  // Notification (toast) settings
  const [toastEnabled, setToastEnabled] = useState(config?.toastEnabled ?? true);
  const [successToastEnabled, setSuccessToastEnabled] = useState(config?.successToastEnabled ?? true);
  const [toastMessage, setToastMessage] = useState(config?.toastMessage ?? "Product added to quote cart.");
  const [toastBgColorHsb, setToastBgColorHsb] = useState(config?.toastBgColor ?? "#0f172a");
  const [toastTxtColorHsb, setToastTxtColorHsb] = useState(config?.toastTextColor ?? "#ffffff");
  const [toastBorderColorHsb, setToastBorderColorHsb] = useState(config?.toastBorderColor ?? "#0f172a");
  const [toastFontSize, setToastFontSize] = useState(config?.toastFontSize ?? 14);
  const [toastBorderRadius, setToastBorderRadius] = useState(config?.toastBorderRadius ?? 40);
  const [toastBorderWidth, setToastBorderWidth] = useState(config?.toastBorderWidth ?? 0);
  const [toastPosition, setToastPosition] = useState(config?.toastPosition ?? "bottom_center");

  // ── Price-hiding rules ─────────────────────────────────────────────────────
  const [hidePriceTarget, setHidePriceTarget] = useState(() => {
    const m = config?.hidePriceMode ?? "all";
    return m === "specific_products" ? "specific" : m === "specific_collections" ? "collections" : "all";
  });
  const [hidePriceProducts, setHidePriceProducts] = useState(() =>
    (hidePriceProductsDb || []).map((p) => ({ id: p.productId, title: p.productTitle, handle: p.productHandle, image: "" }))
  );
  const [hidePriceCollections, setHidePriceCollections] = useState(() => {
    try { return config?.hidePriceCollections ? JSON.parse(config.hidePriceCollections) : []; } catch { return []; }
  });
  const [hidePriceProductPage, setHidePriceProductPage] = useState(config?.hidePriceOnProductPage ?? false);
  const [hidePriceCollectionPage, setHidePriceCollectionPage] = useState(config?.hidePriceOnCollectionPage ?? false);
  const [hidePriceHomePage, setHidePriceHomePage] = useState(config?.hidePriceOnHomePage ?? false);
  const [hidePriceCartPage, setHidePriceCartPage] = useState(config?.hidePriceOnCartPage ?? false);
  const [hidePriceOnly, setHidePriceOnly] = useState(config?.hidePriceOnly ?? false);
  const [hideAddToCart, setHideAddToCart] = useState(config?.hideAddToCart ?? false);
  const [hideBuyItNow, setHideBuyItNow] = useState(config?.hideBuyNow ?? false);
  const [hidePriceReplacement, setHidePriceReplacement] = useState(config?.hidePriceReplacement ?? "text");
  const [replacementText, setReplacementText] = useState(config?.replacementText ?? "Price available on request");
  const [replacementTextColor, setReplacementTextColor] = useState(config?.replacementTextColor ?? "#b4b2a9");

  // ── Tab 2 state — seeded from DB ──────────────────────────────────────────
  const [formTitle, setFormTitle] = useState(config?.modalTitle ?? "Request a Quote");
  const [submitButtonLabel, setSubmitButtonLabel] = useState(config?.submitButtonText ?? "Request a Quote");
  const [formBtnTextColorHsb, setFormBtnTextColorHsb] = useState(config?.formBtnTextColor ?? "#ffffff");
  const [formBtnColorHsb, setFormBtnColorHsb] = useState(config?.formBtnBgColor ?? "#1a1a18");
  const [formBtnFontSize, setFormBtnFontSize] = useState(config?.formBtnFontSize ?? 14);
  const [formBtnBorderRadius, setFormBtnBorderRadius] = useState(config?.formBtnBorderRadius ?? 6);
  const [showVendor, setShowVendor] = useState(config?.showVendorInForm ?? true);
  const [showSku, setShowSku] = useState(config?.showSkuInForm ?? true);
  const [showOption] = useState(config?.showOptionInForm ?? false);
  const [showPrice, setShowPrice] = useState(config?.showPriceInForm ?? false);
  const [showQuotePrice, setShowQuotePrice] = useState(config?.showQuotePriceInForm ?? true);
  const [showNote, setShowNote] = useState(config?.showNoteInForm ?? true);

  const [productInfoOpen, setProductInfoOpen] = useState(true);
  const [desktopPreviewOpen, setDesktopPreviewOpen] = useState(false);
  const [contactSectionOpen, setContactSectionOpen] = useState(true);
  const [showElementPicker, setShowElementPicker] = useState(false);
  const [shippingSectionOpen, setShippingSectionOpen] = useState(true);
  const [showShippingPicker, setShowShippingPicker] = useState(false);

  // Form fields seeded from DB
  const {
    elements: contactElements, setElements: setContactElements,
    add: addContactElement, update: updateContactElement, remove: removeContactElement,
    move: moveElement, addOption, updateOption, removeOption,
  } = useFormFieldList(() => {
    const s = parseSchema(formSchemaRow);
    return (s.contactElements || DEFAULT_CONTACT).map((el) => ({ ...el, open: false }));
  }, { onAdd: () => setShowElementPicker(false) });

  const {
    elements: shippingElements, setElements: setShippingElements,
    add: addShippingElement, update: updateShippingElement, remove: removeShippingElement,
    move: moveShippingElement, addOption: addShippingOption, updateOption: updateShippingOption, removeOption: removeShippingOption,
  } = useFormFieldList(() => {
    const s = parseSchema(formSchemaRow);
    const els = (s.shippingElements || DEFAULT_SHIPPING).map((el) => ({ ...el, open: false }));
    // Inject District after City if missing (migrate existing schemas)
    const hasDistrict = els.some((el) => /district/i.test(el.label));
    if (!hasDistrict) {
      const cityIdx = els.findIndex((el) => /city/i.test(el.label));
      const districtField = { ...makeField(15, "Text", "District", "Enter district"), open: false };
      if (cityIdx >= 0) els.splice(cityIdx + 1, 0, districtField);
      else els.push(districtField);
    }
    return els;
  }, { onAdd: () => setShowShippingPicker(false) });

  const [extraInfoSectionOpen, setExtraInfoSectionOpen] = useState(true);
  const [showExtraInfoPicker, setShowExtraInfoPicker] = useState(false);
  const {
    elements: extraInfoElements, setElements: setExtraInfoElements,
    add: addExtraInfoElement, update: updateExtraInfoElement, remove: removeExtraInfoElement,
    move: moveExtraInfoElement, addOption: addExtraInfoOption, updateOption: updateExtraInfoOption, removeOption: removeExtraInfoOption,
  } = useFormFieldList(() => {
    const s = parseSchema(formSchemaRow);
    return (s.extraInfoElements || DEFAULT_EXTRA).map((el) => ({ ...el, open: false }));
  }, { onAdd: () => setShowExtraInfoPicker(false) });

  const currentState = useMemo(() => ({
    targetMode, selectedProducts, selectedCollections, displayMode, showOnCollectionPage, showOnHomepage, messageType, successMessage, buttonBorderRadius, buttonWidth, visibilityMode, selectedTags, buttonLabel, textColorHsb, buttonColorHsb, fontSize, buttonPosition, widgetEnabled, widgetButtonText, widgetPosition, widgetBgColorHsb, widgetTxtColorHsb, toastMessage, toastBgColorHsb, toastTxtColorHsb, toastBorderColorHsb, toastFontSize, toastBorderRadius, toastBorderWidth, toastPosition, hidePriceTarget, hidePriceProducts, hidePriceCollections, hidePriceProductPage, hidePriceCollectionPage, hidePriceHomePage, hidePriceCartPage, hidePriceOnly, hideAddToCart, hideBuyItNow, hidePriceReplacement, replacementText, replacementTextColor, formTitle, submitButtonLabel, formBtnTextColorHsb, formBtnColorHsb, formBtnFontSize, formBtnBorderRadius, showVendor, showSku, showPrice, showQuotePrice, showNote, contactElements, shippingElements, extraInfoElements
  }), [
    targetMode, selectedProducts, selectedCollections, displayMode, showOnCollectionPage, showOnHomepage, messageType, successMessage, buttonBorderRadius, buttonWidth, visibilityMode, selectedTags, buttonLabel, textColorHsb, buttonColorHsb, fontSize, buttonPosition, widgetEnabled, widgetButtonText, widgetPosition, widgetBgColorHsb, widgetTxtColorHsb, toastMessage, toastBgColorHsb, toastTxtColorHsb, toastBorderColorHsb, toastFontSize, toastBorderRadius, toastBorderWidth, toastPosition, hidePriceTarget, hidePriceProducts, hidePriceCollections, hidePriceProductPage, hidePriceCollectionPage, hidePriceHomePage, hidePriceCartPage, hidePriceOnly, hideAddToCart, hideBuyItNow, hidePriceReplacement, replacementText, replacementTextColor, formTitle, submitButtonLabel, formBtnTextColorHsb, formBtnColorHsb, formBtnFontSize, formBtnBorderRadius, showVendor, showSku, showPrice, showQuotePrice, showNote, contactElements, shippingElements, extraInfoElements
  ]);

  const { markClean, getBaseline } = useTemplateDirtyState(currentState, "my-save-bar");

  // ── Field-removal confirmation ────────────────────────────────────────────
  // Holds { remove, id, label } while a delete confirmation modal is open.
  const [confirmRemove, setConfirmRemove] = useState(null);
  const requestRemoveEl = useCallback((remove, id, label) => setConfirmRemove({ remove, id, label }), []);

  // ── Tag callbacks ─────────────────────────────────────────────────────────
  const filteredTagOptions = useMemo(() => {
    if (!tagInputValue) return tagOptions;
    const re = new RegExp(tagInputValue, "i");
    return tagOptions.filter((t) => re.test(t));
  }, [tagInputValue, tagOptions]);

  const saveTags = useCallback((tags) => {
    fetcher.submit({ intent: "saveTags", tags: JSON.stringify(tags) }, { method: "post" });
  }, [fetcher]);

  const handleTagSelect = useCallback((value) => {
    setSelectedTags((prev) => {
      const next = prev.includes(value) ? prev.filter((t) => t !== value) : [...prev, value];
      saveTags(next);
      return next;
    });
    setTagOptions((prev) => prev.includes(value) ? prev : [...prev, value]);
    setTagInputValue("");
  }, [saveTags]);

  const removeTag = useCallback((tag) => {
    setSelectedTags((prev) => {
      const next = prev.filter((t) => t !== tag);
      saveTags(next);
      return next;
    });
  }, [saveTags]);

  // ── Save all settings ─────────────────────────────────────────────────────
  const handleSave = useCallback(() => {
    fetcher.submit({
      intent: "saveAll",
      targetMode: targetMode === "specific" ? "products" : targetMode === "Collections" ? "collections" : "all",
      targetProducts: JSON.stringify(selectedProducts),
      targetCollections: JSON.stringify(selectedCollections),
      showOnCollectionPage: String(showOnCollectionPage),
      showOnHomepage: String(showOnHomepage),
      displayMode,
      addToQuoteBehaviour: messageType,
      successMessage,
      buttonLabel,
      buttonBgColor: buttonColorHsb,
      buttonTextColor: textColorHsb,
      buttonFontSize: String(fontSize),
      buttonBorderRadius: String(buttonBorderRadius),
      buttonWidth,
      buttonPosition,
      hidePriceTarget,
      hidePriceProducts: JSON.stringify(hidePriceProducts),
      hidePriceCollections: JSON.stringify(hidePriceCollections),
      hidePriceOnProductPage: String(hidePriceProductPage),
      hidePriceOnCollectionPage: String(hidePriceCollectionPage),
      hidePriceOnHomePage: String(hidePriceHomePage),
      hidePriceOnCartPage: String(hidePriceCartPage),
      hidePriceOnly: String(hidePriceOnly),
      hideAddToCart: String(hideAddToCart),
      hideBuyItNow: String(hideBuyItNow),
      hidePriceReplacement,
      replacementText,
      replacementTextColor,
      visibilityMode,
      tags: JSON.stringify(selectedTags),
      formTitle,
      submitButtonLabel,
      formBtnBgColor: formBtnColorHsb,
      formBtnTextColor: formBtnTextColorHsb,
      formBtnFontSize: String(formBtnFontSize),
      formBtnBorderRadius: String(formBtnBorderRadius),
      showVendor: String(showVendor),
      showSku: String(showSku),
      showOption: String(showOption),
      showPrice: String(showPrice),
      showQuotePrice: String(showQuotePrice),
      showNote: String(showNote),
      widgetEnabled: String(widgetEnabled),
      widgetButtonText,
      widgetAction: "popup",
      widgetPosition,
      widgetBgColor: widgetBgColorHsb,
      widgetTextColor: widgetTxtColorHsb,
      toastEnabled,
      successToastEnabled,
      toastMessage,
      toastBgColor: toastBgColorHsb,
      toastTextColor: toastTxtColorHsb,
      toastBorderColor: toastBorderColorHsb,
      toastFontSize: String(toastFontSize),
      toastBorderRadius: String(toastBorderRadius),
      toastBorderWidth: String(toastBorderWidth),
      toastPosition,
      formSchema: JSON.stringify({ contactElements, shippingElements, extraInfoElements }),
    }, { method: "post" });
  }, [
    fetcher, targetMode, selectedProducts, selectedCollections, showOnCollectionPage, showOnHomepage,
    displayMode, messageType, successMessage, buttonLabel, buttonColorHsb, textColorHsb,
    fontSize, buttonBorderRadius, buttonWidth, buttonPosition, hidePriceTarget, hidePriceProducts,
    hidePriceCollections, hidePriceProductPage, hidePriceCollectionPage, hidePriceHomePage,
    hidePriceCartPage, hidePriceOnly, hideAddToCart, hideBuyItNow, hidePriceReplacement, replacementText, replacementTextColor, visibilityMode, selectedTags,
    formTitle, submitButtonLabel, formBtnColorHsb, formBtnTextColorHsb, formBtnFontSize, formBtnBorderRadius,
    showVendor, showSku, showOption, showPrice, showQuotePrice, showNote,
    widgetEnabled, widgetButtonText, widgetPosition, widgetBgColorHsb, widgetTxtColorHsb,
    toastEnabled, successToastEnabled, toastMessage, toastBgColorHsb, toastTxtColorHsb, toastBorderColorHsb, toastFontSize, toastBorderRadius, toastBorderWidth, toastPosition,
    contactElements, shippingElements, extraInfoElements,
  ]);

  // ── Discard — revert every tracked field to the last-saved baseline ────────
  // Replaces Shopify's built-in save bar, whose Discard reloaded the whole page.
  // We read the baseline snapshot (kept by useTemplateDirtyState, refreshed on
  // each successful save via markClean()) and push each value back through its
  // setter. Because the storefront preview is rendered from this same state,
  // it reverts too — all in place, with no page reload.
  const handleDiscard = useCallback(() => {
    const base = getBaseline();
    if (!base) return;
    const SETTERS = {
      targetMode: setTargetMode,
      selectedProducts: setSelectedProducts,
      selectedCollections: setSelectedCollections,
      displayMode: setDisplayMode,
      showOnCollectionPage: setShowOnCollectionPage,
      showOnHomepage: setShowOnHomepage,
      messageType: setMessageType,
      successMessage: setSuccessMessage,
      buttonBorderRadius: setButtonBorderRadius,
      buttonWidth: setButtonWidth,
      visibilityMode: setVisibilityMode,
      selectedTags: setSelectedTags,
      buttonLabel: setButtonLabel,
      textColorHsb: setTextColorHsb,
      buttonColorHsb: setButtonColorHsb,
      fontSize: setFontSize,
      buttonPosition: setButtonPosition,
      widgetEnabled: setWidgetEnabled,
      widgetButtonText: setWidgetButtonText,
      widgetPosition: setWidgetPosition,
      widgetBgColorHsb: setWidgetBgColorHsb,
      widgetTxtColorHsb: setWidgetTxtColorHsb,
      toastMessage: setToastMessage,
      toastBgColorHsb: setToastBgColorHsb,
      toastTxtColorHsb: setToastTxtColorHsb,
      toastBorderColorHsb: setToastBorderColorHsb,
      toastFontSize: setToastFontSize,
      toastBorderRadius: setToastBorderRadius,
      toastBorderWidth: setToastBorderWidth,
      toastPosition: setToastPosition,
      hidePriceTarget: setHidePriceTarget,
      hidePriceProducts: setHidePriceProducts,
      hidePriceCollections: setHidePriceCollections,
      hidePriceProductPage: setHidePriceProductPage,
      hidePriceCollectionPage: setHidePriceCollectionPage,
      hidePriceHomePage: setHidePriceHomePage,
      hidePriceCartPage: setHidePriceCartPage,
      hidePriceOnly: setHidePriceOnly,
      hideAddToCart: setHideAddToCart,
      hideBuyItNow: setHideBuyItNow,
      hidePriceReplacement: setHidePriceReplacement,
      replacementText: setReplacementText,
      replacementTextColor: setReplacementTextColor,
      formTitle: setFormTitle,
      submitButtonLabel: setSubmitButtonLabel,
      formBtnTextColorHsb: setFormBtnTextColorHsb,
      formBtnColorHsb: setFormBtnColorHsb,
      formBtnFontSize: setFormBtnFontSize,
      formBtnBorderRadius: setFormBtnBorderRadius,
      showVendor: setShowVendor,
      showSku: setShowSku,
      showPrice: setShowPrice,
      showQuotePrice: setShowQuotePrice,
      showNote: setShowNote,
      contactElements: setContactElements,
      shippingElements: setShippingElements,
      extraInfoElements: setExtraInfoElements,
    };
    Object.keys(base).forEach((k) => {
      const set = SETTERS[k];
      if (set) set(base[k]);
    });
  }, [getBaseline]);

  // ── Toast on save ─────────────────────────────────────────────────────────
  useEffect(() => {
    if (fetcher.state !== "idle" || !fetcher.data) return;
    if (fetcher.data.success && fetcher.data.intent === "saveAll") {
      shopify.toast.show("Settings saved");
      markClean();
    } else if (fetcher.data.success && fetcher.data.intent === "saveTags") {
      // silent — tag saves are background operations
    } else if (fetcher.data.error) {
      shopify.toast.show(fetcher.data.error, { isError: true });
    }
  }, [fetcher.data, fetcher.state, shopify, markClean]);

  const [previewProducts, setPreviewProducts] = useState([
    { id: 1, title: "Pattern design artistico 2 Carnevale", image: "https://images.unsplash.com/photo-1541560052-77ec1bbc09f7?w=80&h=80&fit=crop&auto=format", qty: 1, vendor: "Vendor 1", sku: "SKU-001", price: `${currSym}100.00`, option: "Option 1", offerPrice: "", noteOpen: false, note: "" },
    { id: 2, title: "Minimalist Leather Wallet Black Edition", image: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=80&h=80&fit=crop&auto=format", qty: 1, vendor: "Vendor 2", sku: "SKU-002", price: `${currSym}250.00`, option: "Medium / Black", offerPrice: "", noteOpen: false, note: "" },
  ]);
  const updatePreviewQty = (id, delta) => setPreviewProducts((prev) => prev.map((p) => p.id === id ? { ...p, qty: Math.max(1, p.qty + delta) } : p));
  const removePreviewProduct = (id) => setPreviewProducts((prev) => prev.filter((p) => p.id !== id));
  const updatePreviewOfferPrice = (id, val) => setPreviewProducts((prev) => prev.map((p) => p.id === id ? { ...p, offerPrice: val } : p));
  const togglePreviewNote = (id) => setPreviewProducts((prev) => prev.map((p) => p.id === id ? { ...p, noteOpen: !p.noteOpen } : p));
  const updatePreviewNote = (id, val) => setPreviewProducts((prev) => prev.map((p) => p.id === id ? { ...p, note: val } : p));

  // ── Interactive Test Form State ─────────────────────────────────────────────
  const [previewTestData, setPreviewTestData] = useState({});
  const [previewSubmitted, setPreviewSubmitted] = useState(false);
  const [previewErrors, setPreviewErrors] = useState({});
  const [previewMode, setPreviewMode] = useState(false); // false = static mockup, true = interactive test
  // previewFiles: { [fieldId]: File[] } — stores actual File objects for image preview
  const [previewFiles, setPreviewFiles] = useState({});
  const [previewSending, setPreviewSending] = useState(false);
  const [previewQuoteId, setPreviewQuoteId] = useState(null);

  const updateTestField = (fieldId, value) => {
    setPreviewTestData((prev) => ({ ...prev, [fieldId]: value }));
    // Live re-validation: only re-run if we've already attempted submit (errors exist)
    setPreviewErrors((prev) => {
      if (!prev[fieldId] && Object.keys(prev).length === 0) return prev; // nothing to update
      const n = { ...prev };
      delete n[fieldId]; // clear error optimistically — full revalidation happens on next submit
      return n;
    });
    if (previewSubmitted) setPreviewSubmitted(false);
  };

  const updateFileField = (fieldId, newFiles, multiple) => {
    setPreviewFiles((prev) => {
      const existing = prev[fieldId] || [];
      let merged;
      if (!multiple) {
        merged = newFiles.slice(0, 1);
      } else {
        const maxLimit = 5;
        merged = [...existing];
        for (const f of newFiles) {
          if (merged.length >= maxLimit) break;
          const isDup = merged.some((x) => x.name === f.name && x.size === f.size);
          if (!isDup) merged.push(f);
        }
      }
      return { ...prev, [fieldId]: merged };
    });
    // Mark field as having files (for validation/display)
    updateTestField(fieldId, "__files__");
  };

  const removeFileFromField = (fieldId, idx) => {
    setPreviewFiles((prev) => {
      const existing = [...(prev[fieldId] || [])];
      existing.splice(idx, 1);
      const updated = { ...prev, [fieldId]: existing };
      // If no files left, clear the text marker too
      if (existing.length === 0) {
        setPreviewTestData((d) => { const n = { ...d }; delete n[fieldId]; return n; });
      }
      return updated;
    });
  };

  const clearTestData = () => {
    setPreviewTestData({});
    setPreviewErrors({});
    setPreviewSubmitted(false);
    setPreviewFiles({});
  };

  // ── Preview validation — mirrors extension's _detectFieldRole + _validateField ─
  const _previewDetectRole = (el) => {
    const t = (el.type || "").toLowerCase().trim();
    const lbl = (el.label || "").toLowerCase().trim();
    if (t === "email" || lbl.indexOf("email") !== -1) return "email";
    if (t === "phone" || lbl.indexOf("phone") !== -1 || lbl.indexOf("mobile") !== -1) return "phone";
    if (t === "country" || lbl === "country") return "country";
    if (lbl.indexOf("zip") !== -1 || lbl.indexOf("postal") !== -1) return "zip";
    if (lbl.indexOf("street") !== -1 || lbl === "address" || lbl === "address line 1" || (lbl.indexOf("address") !== -1 && lbl.indexOf("email") === -1)) return "street";
    if (lbl === "city" || lbl === "town" || lbl === "town/city" || lbl.indexOf("city") !== -1) return "city";
    if (lbl === "district" || lbl.indexOf("district") !== -1) return "district";
    if (lbl.indexOf("state") !== -1 || lbl.indexOf("province") !== -1 || lbl.indexOf("region") !== -1) return "state";
    if (lbl.indexOf("first") !== -1 && (lbl.indexOf("name") !== -1 || lbl === "first")) return "firstname";
    if ((lbl.indexOf("last") !== -1 || lbl.indexOf("surname") !== -1) && lbl.indexOf("company") === -1) return "lastname";
    if (t === "textarea" || lbl.indexOf("message") !== -1 || lbl.indexOf("comment") !== -1 || lbl.indexOf("note") !== -1 || lbl.indexOf("remark") !== -1) return "message";
    if (t === "checkbox") return "checkbox";
    if (t === "paragraph") return "paragraph";
    if (t === "file upload" || t === "file" || t === "fileupload") return "file";
    if (t === "number") return "number";
    if (lbl.indexOf("name") !== -1 && lbl.indexOf("company") === -1 && lbl.indexOf("brand") === -1) return "fullname";
    return "text";
  };

  const _previewValidateField = (role, value, el) => {
    const v = (value || "").trim();
    const lbl = (el && el.label) ? el.label : "This field";
    switch (role) {
      case "firstname":
        if (!v) return (el && el.required) ? "First name is required" : null;
        if (v.length < 2) return "First name must be at least 2 characters";
        if (v.length > 50) return "First name must be 50 characters or less";
        if (!/^[A-Za-z\s\-'\.]+$/.test(v)) return "First name can only contain letters";
        return null;
      case "lastname":
        if (!v) return (el && el.required) ? "Last name is required" : null;
        if (v.length > 50) return "Last name must be 50 characters or less";
        if (!/^[A-Za-z\s\-'\.]+$/.test(v)) return "Last name can only contain letters";
        return null;
      case "fullname":
        if (!v) return (el && el.required) ? lbl + " is required" : null;
        if (v.length < 2) return lbl + " must be at least 2 characters";
        if (v.length > 100) return lbl + " must be 100 characters or less";
        return null;
      case "email":
        if (!v) return (el && el.required) ? "Email address is required" : null;
        if (v.length > 100) return "Email must be 100 characters or less";
        if (!isValidEmail(v)) return "Enter a valid email address (e.g. name@example.com)";
        return null;
      case "phone":
        if (!v) return (el && el.required) ? "Phone number is required" : null;
        if (!isValidPhone(v)) return "Enter a valid phone number (7–15 digits)";
        return null;
      case "street":
        if (!v) return (el && el.required) ? "Street address is required" : null;
        if (v.length < 5) return "Street address must be at least 5 characters";
        if (v.length > 150) return "Street address must be 150 characters or less";
        return null;
      case "city":
        if (!v) return (el && el.required) ? "City is required" : null;
        if (v.length < 2) return "City must be at least 2 characters";
        if (v.length > 50) return "City must be 50 characters or less";
        if (!/^[A-Za-z\s\-'\.]+$/.test(v)) return "City can only contain letters";
        return null;
      case "district":
        if (!v) return (el && el.required) ? "District is required" : null;
        if (v.length < 2) return "District must be at least 2 characters";
        if (v.length > 50) return "District must be 50 characters or less";
        return null;
      case "state":
        if (!v) return (el && el.required) ? "State / Province is required" : null;
        if (v.length < 2) return "State must be at least 2 characters";
        if (v.length > 50) return "State must be 50 characters or less";
        return null;
      case "zip":
        if (!v) return (el && el.required) ? "Zip / Postal code is required" : null;
        if (v.length < 4) return "Zip / Postal code must be at least 4 characters";
        if (v.length > 10) return "Zip / Postal code must be 10 characters or less";
        if (!/^[A-Za-z0-9\s\-]+$/.test(v)) return "Enter a valid zip / postal code";
        return null;
      case "country":
        if (!v) return (el && el.required) ? "Please select a country" : null;
        return null;
      case "message":
        if (v.length > 500) return "Message must be 500 characters or less";
        return null;
      case "number": {
        if (!v) return el && el.required ? lbl + " is required" : null;
        const num = parseFloat(v);
        if (isNaN(num)) return "Enter a valid number";
        const fMin = (el && el.min !== "" && el.min != null) ? parseFloat(el.min) : null;
        const fMax = (el && el.max !== "" && el.max != null) ? parseFloat(el.max) : null;
        if (fMin !== null && !isNaN(fMin) && num < fMin) return lbl + " must be at least " + fMin;
        if (fMax !== null && !isNaN(fMax) && num > fMax) return lbl + " must be at most " + fMax;
        return null;
      }
      case "checkbox":
      case "paragraph":
      case "file":
        return null;
      default:
        if (el && el.required && !v) return lbl + " is required";
        return null;
    }
  };

  const handlePreviewSubmit = async () => {
    const allEls = [
      ...contactElements,
      ...shippingElements,
      ...extraInfoElements,
    ];
    const errors = {};
    allEls.forEach((el) => {
      const ft = (el.type || "").toLowerCase().trim();
      if (ft === "paragraph") return;
      const val = previewTestData[el.id] || "";
      const role = _previewDetectRole(el);
      if (ft === "checkbox" || role === "checkbox") {
        if (el.required && !val) errors[el.id] = (el.label || "This field") + " is required";
        return;
      }
      if (ft === "radio group" || ft === "radio") {
        if (el.required && !val) errors[el.id] = (el.label || "This field") + " is required";
        return;
      }
      if (role === "file") {
        if (el.required) {
          const files = previewFiles[el.id] || [];
          if (files.length === 0) {
            errors[el.id] = (el.label || "This file field") + " is required";
          }
        }
        return;
      }
      const err = _previewValidateField(role, val, el);
      if (err) errors[el.id] = err;
    });
    setPreviewErrors(errors);
    if (Object.keys(errors).length > 0) return;

    // ── Build the payload from test data ───────────────────────────────────────
    // Collect all field values as formFields
    const formFields = allEls
      .filter((el) => el.type !== "Paragraph")
      .map((el) => {
        const val = previewTestData[el.id] || "";
        if (val === "__files__") {
          const files = previewFiles[el.id] || [];
          return { label: el.label || el.type, value: files.map((f) => f.name).join(", ") };
        }
        return { label: el.label || el.type, value: val };
      })
      .filter((f) => f.value);

    // Detect common fields for top-level payload
    const findVal = (roleMatch) => {
      const el = allEls.find((e) => _previewDetectRole(e) === roleMatch);
      return el ? (previewTestData[el.id] || "").trim() : "";
    };
    const emailVal = findVal("email");
    const firstVal = findVal("firstname");
    const lastVal = findVal("lastname");
    const fullVal = findVal("fullname");
    const phoneVal = findVal("phone");
    const customerName = firstVal && lastVal ? `${firstVal} ${lastVal}`.trim() : (fullVal || firstVal || "Preview Merchant");
    const customerEmail = emailVal || `preview-test@${shop}`;

    const payload = {
      shop,
      shopCurrency,
      productTitle: "[TEST] Preview Form Submission",
      customerName,
      customerEmail,
      customerPhone: phoneVal || null,
      tags: "test-case",
      cartItems: previewProducts.map((p) => ({
        productTitle: p.title,
        quantity: p.qty,
        price: p.price,
        image: p.image,
      })),
      formFields,
    };

    setPreviewSending(true);
    try {
      // Submit through this route's own authenticated action (not the public
      // App Proxy endpoint, which now requires a real Shopify-signed request
      // and would reject this admin-initiated preview).
      const fd = new FormData();
      fd.append("intent", "sendTestQuote");
      fd.append("payload", JSON.stringify(payload));
      const res = await fetch(window.location.pathname + window.location.search, {
        method: "POST",
        body: fd,
      });
      const data = await res.json();
      if (data.success) {
        setPreviewSubmitted(true);
        setPreviewQuoteId(data.quoteId || null);
      } else {
        setPreviewErrors({ _api: data.error || "Submission failed. Please try again." });
      }
    } catch (err) {
      setPreviewErrors({ _api: "Network error. Could not reach the server." });
    } finally {
      setPreviewSending(false);
    }
  };

  const handleTabChange = useCallback((selectedTabIndex) => {
    setSelected(selectedTabIndex);
  }, []);

  return {
    isMobile, currSym, fetcher,
    errorColor, accentColor, successColor,
    selected, setSelected, handleTabChange,

    // Tab 1
    targetMode, setTargetMode,
    selectedProducts, setSelectedProducts,
    selectedCollections, setSelectedCollections,
    displayMode, setDisplayMode,
    showOnCollectionPage, setShowOnCollectionPage,
    showOnHomepage, setShowOnHomepage,
    messageType, setMessageType,
    successMessage, setSuccessMessage,
    buttonBorderRadius, buttonWidth,
    visibilityMode, setVisibilityMode,
    selectedTags, tagInputValue, setTagInputValue, filteredTagOptions, handleTagSelect, removeTag,
    buttonLabel, setButtonLabel,
    textColorHsb, setTextColorHsb,
    buttonColorHsb, setButtonColorHsb,
    fontSize, setFontSize,
    buttonPosition, setButtonPosition,

    // Widget
    widgetEnabled, setWidgetEnabled,
    widgetButtonText, setWidgetButtonText,
    widgetPosition, setWidgetPosition,
    widgetBgColorHsb, setWidgetBgColorHsb,
    widgetTxtColorHsb, setWidgetTxtColorHsb,

    // Toast
    toastEnabled, setToastEnabled,
    successToastEnabled, setSuccessToastEnabled,
    toastMessage, setToastMessage,
    toastBgColorHsb, setToastBgColorHsb,
    toastTxtColorHsb, setToastTxtColorHsb,
    toastBorderColorHsb, setToastBorderColorHsb,
    toastFontSize, setToastFontSize,
    toastBorderRadius, setToastBorderRadius,
    toastBorderWidth, setToastBorderWidth,
    toastPosition, setToastPosition,

    // Hide-price
    hidePriceTarget, setHidePriceTarget,
    hidePriceProducts, setHidePriceProducts,
    hidePriceCollections, setHidePriceCollections,
    hidePriceProductPage, setHidePriceProductPage,
    hidePriceCollectionPage, setHidePriceCollectionPage,
    hidePriceHomePage, setHidePriceHomePage,
    hidePriceCartPage, setHidePriceCartPage,
    hideAddToCart, setHideAddToCart,
    hideBuyItNow, setHideBuyItNow,
    hidePriceReplacement, setHidePriceReplacement,
    replacementText, setReplacementText,
    replacementTextColor,

    // Tab 2 — form content / submit button style
    formTitle, setFormTitle,
    submitButtonLabel, setSubmitButtonLabel,
    formBtnTextColorHsb, setFormBtnTextColorHsb,
    formBtnColorHsb, setFormBtnColorHsb,
    formBtnFontSize, setFormBtnFontSize,
    formBtnBorderRadius, setFormBtnBorderRadius,
    showVendor, setShowVendor,
    showSku, setShowSku,
    showOption,
    showPrice, setShowPrice,
    showQuotePrice, setShowQuotePrice,
    showNote, setShowNote,

    // Section collapse/picker toggles
    productInfoOpen, setProductInfoOpen,
    desktopPreviewOpen, setDesktopPreviewOpen,
    contactSectionOpen, setContactSectionOpen,
    showElementPicker, setShowElementPicker,
    shippingSectionOpen, setShippingSectionOpen,
    showShippingPicker, setShowShippingPicker,
    extraInfoSectionOpen, setExtraInfoSectionOpen,
    showExtraInfoPicker, setShowExtraInfoPicker,

    // Field-removal confirmation
    confirmRemove, setConfirmRemove, requestRemoveEl,

    // Form field lists
    contactElements, setContactElements,
    addContactElement, updateContactElement, removeContactElement,
    moveElement, addOption, updateOption, removeOption,

    shippingElements, setShippingElements,
    addShippingElement, updateShippingElement, removeShippingElement,
    moveShippingElement, addShippingOption, updateShippingOption, removeShippingOption,

    extraInfoElements, setExtraInfoElements,
    addExtraInfoElement, updateExtraInfoElement, removeExtraInfoElement,
    moveExtraInfoElement, addExtraInfoOption, updateExtraInfoOption, removeExtraInfoOption,

    // Save / discard
    handleSave, handleDiscard,

    // Live "quoted products" preview
    previewProducts, updatePreviewQty, removePreviewProduct, updatePreviewOfferPrice, togglePreviewNote, updatePreviewNote,

    // Interactive test form
    previewTestData, previewSubmitted, setPreviewSubmitted, previewErrors,
    previewMode, setPreviewMode, previewFiles, previewSending, previewQuoteId,
    updateTestField, updateFileField, removeFileFromField, clearTestData, handlePreviewSubmit,
  };
}

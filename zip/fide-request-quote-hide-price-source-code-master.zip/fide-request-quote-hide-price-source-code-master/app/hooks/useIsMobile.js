import { useState, useEffect } from "react";

/**
 * Reusable viewport-width breakpoint hook — tracks whether the window is
 * narrower than `breakpoint`, updating on resize. Used across many admin
 * pages/hooks (quote detail, quote list, settings pages, dashboard, etc.) to
 * switch between desktop and mobile-friendly Polaris layouts.
 *
 * @param {number} [breakpoint=768] - width in px below which `isMobile` is true
 * @returns {boolean} isMobile
 */
export function useIsMobile(breakpoint = 768) {
  const [isMobile, setIsMobile] = useState(false);
  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < breakpoint);
    check();
    window.addEventListener("resize", check);
    return () => window.removeEventListener("resize", check);
  }, [breakpoint]);
  return isMobile;
}

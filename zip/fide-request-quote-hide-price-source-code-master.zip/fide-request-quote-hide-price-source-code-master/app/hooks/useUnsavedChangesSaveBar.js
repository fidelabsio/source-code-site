import { useEffect } from "react";
import { useAppBridge } from "@shopify/app-bridge-react";

/**
 * Shows/hides Shopify's contextual App Bridge save bar based on dirty state.
 * Hides on unmount — the save bar is a singleton overlay that otherwise
 * outlives the route's element across client-side navigation.
 *
 * @param {boolean} isDirty
 * @param {string|null} saveBarId - id of the <ui-save-bar> element to control;
 *   pass null/undefined to skip the App Bridge save bar entirely (e.g. pages
 *   that render their own sticky save bar instead).
 */
export function useUnsavedChangesSaveBar(isDirty, saveBarId) {
  const shopify = useAppBridge();

  useEffect(() => {
    if (!saveBarId) return;
    if (isDirty) shopify.saveBar.show(saveBarId);
    else shopify.saveBar.hide(saveBarId);
    return () => shopify?.saveBar?.hide(saveBarId);
  }, [isDirty, saveBarId, shopify]);
}

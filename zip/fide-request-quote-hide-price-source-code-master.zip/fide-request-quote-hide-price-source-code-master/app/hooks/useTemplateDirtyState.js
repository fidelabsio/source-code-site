import { useCallback, useState } from "react";
import { useUnsavedChangesSaveBar } from "./useUnsavedChangesSaveBar";

/**
 * Shared "is this page dirty" bookkeeping: snapshots `currentValues` as the
 * clean baseline, derives `isDirty` by comparing against it, and (unless
 * `saveBarId` is omitted) wires the App Bridge save bar. Pages that render
 * their own sticky save bar instead (e.g. the quote detail page) can pass
 * `null` for `saveBarId` and just use `isDirty` directly.
 *
 * @param {object} currentValues - plain object of the page's current field values
 * @param {string|null} [saveBarId] - id of the <ui-save-bar> element to control
 * @returns {{ isDirty: boolean, markClean: () => void, getBaseline: () => object|null }}
 */
export function useTemplateDirtyState(currentValues, saveBarId = null) {
  const currentStr = JSON.stringify(currentValues);
  const [initialStr, setInitialStr] = useState(currentStr);
  const isDirty = currentStr !== initialStr;

  useUnsavedChangesSaveBar(isDirty, saveBarId);

  const markClean = useCallback(() => setInitialStr(currentStr), [currentStr]);
  const getBaseline = useCallback(() => {
    try {
      return JSON.parse(initialStr);
    } catch {
      return null;
    }
  }, [initialStr]);

  return { isDirty, markClean, getBaseline };
}

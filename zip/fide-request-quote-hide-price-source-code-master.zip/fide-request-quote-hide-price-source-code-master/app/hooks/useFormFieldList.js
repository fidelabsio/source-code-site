import { useCallback, useState } from "react";

/**
 * CRUD + reordering for one Form Builder field list (contact/shipping/extra-info
 * elements on the Quote Settings page). All three field-list sections use the
 * exact same shape — add/update/remove/move an element, add/update/remove one
 * of its options — so this hook is called once per section instead of each
 * section hand-rolling its own copy of these seven functions.
 *
 * @param {object[]|(() => object[])} initialElements - initial list, or a lazy initializer (as with useState)
 * @param {{ onAdd?: () => void }} [options] - onAdd fires after a new element is appended (e.g. to close the "add field" popover)
 */
export function useFormFieldList(initialElements, { onAdd } = {}) {
  const [elements, setElements] = useState(initialElements);

  const add = useCallback((type) => {
    setElements((prev) => [...prev, {
      id: Date.now(), type, open: true,
      label: "", placeholder: "", helpText: "", required: false,
      options: ["Option 1", "Option 2"],
      content: "", rows: 4, min: "", max: "", accept: "",
    }]);
    onAdd?.();
  }, [onAdd]);

  const update = useCallback((id, field, value) => {
    setElements((prev) => prev.map((el) => el.id === id ? { ...el, [field]: value } : el));
  }, []);

  const remove = useCallback((id) => {
    setElements((prev) => prev.filter((el) => el.id !== id));
  }, []);

  const move = useCallback((id, dir) => {
    setElements((prev) => {
      const idx = prev.findIndex((el) => el.id === id);
      const next = idx + dir;
      if (next < 0 || next >= prev.length) return prev;
      const arr = [...prev];
      [arr[idx], arr[next]] = [arr[next], arr[idx]];
      return arr;
    });
  }, []);

  const addOption = useCallback((id) => {
    setElements((prev) => prev.map((el) =>
      el.id === id ? { ...el, options: [...el.options, `Option ${el.options.length + 1}`] } : el
    ));
  }, []);

  const updateOption = useCallback((id, idx, value) => {
    setElements((prev) => prev.map((el) =>
      el.id === id ? { ...el, options: el.options.map((o, i) => i === idx ? value : o) } : el
    ));
  }, []);

  const removeOption = useCallback((id, idx) => {
    setElements((prev) => prev.map((el) =>
      el.id === id ? { ...el, options: el.options.filter((_, i) => i !== idx) } : el
    ));
  }, []);

  return { elements, setElements, add, update, remove, move, addOption, updateOption, removeOption };
}

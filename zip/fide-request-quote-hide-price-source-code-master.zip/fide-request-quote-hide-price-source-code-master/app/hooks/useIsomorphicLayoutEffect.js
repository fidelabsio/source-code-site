import { useEffect, useLayoutEffect } from "react";

/**
 * Reusable SSR-safe drop-in replacement for `useLayoutEffect`.
 * useLayoutEffect warns during SSR since there's no DOM to lay out — fall
 * back to useEffect on the server, use the real thing in the browser.
 *
 * @type {typeof useLayoutEffect}
 */
export const useIsomorphicLayoutEffect =
  typeof window !== "undefined" ? useLayoutEffect : useEffect;

const ESCAPE_MAP = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };

/**
 * Escape a string for safe interpolation into an HTML document (email
 * bodies, printed PDF/quote HTML). This app builds several HTML documents by
 * template-string interpolation rather than a templating engine, so every
 * value that originates from user/customer input (name, message, product
 * title, etc.) MUST be passed through this before being embedded — otherwise
 * a customer-submitted value containing markup executes in an authenticated
 * admin context (stored XSS) or breaks the outgoing email.
 * @param {*} str - value to escape (coerced to a string; null/undefined → "")
 * @returns {string}
 */
export function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, (c) => ESCAPE_MAP[c]);
}

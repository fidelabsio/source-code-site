/**
 * Trigger a browser download of an in-memory Blob (e.g. a generated CSV or
 * PDF) without navigating away — creates a throwaway object URL, clicks a
 * hidden anchor, then revokes the URL shortly after so the download has time
 * to start before the underlying memory is freed.
 * @param {Blob} blob
 * @param {string} filename - suggested filename for the download
 */
export function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

/**
 * Format a date as "Jan 5, 2026" — used for compact table/list rows
 * (quote list, dashboard recent-quotes).
 * @param {string|number|Date} d
 * @returns {string}
 */
export function formatShortDate(d) {
  return new Date(d).toLocaleDateString("en-US", {
    month: "short", day: "numeric", year: "numeric",
  });
}

/**
 * Format a date+time as "Jan 5, 2026, 03:45 PM". Returns an em dash for a
 * falsy input instead of "Invalid Date" (used where the timestamp is
 * optional, e.g. a not-yet-set expiry date).
 * @param {string|number|Date|null|undefined} d
 * @returns {string}
 */
export function formatDateTime(d) {
  return d ? new Date(d).toLocaleDateString("en-IN", {
    month: "short", day: "numeric", year: "numeric",
    hour: "2-digit", minute: "2-digit",
  }) : "—";
}

/**
 * Format just the time portion, e.g. "3:45pm" — used for timeline/activity
 * rows that already show the date separately via a day-group heading.
 * @param {string|number|Date|null|undefined} d
 * @returns {string}
 */
export function formatTimeOnly(d) {
  return d ? new Date(d).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", hour12: true }).toLowerCase() : "";
}

/**
 * Format a date as a full day label, e.g. "January 5, 2026" — used as the
 * heading for a group of same-day timeline entries.
 * @param {string|number|Date|null|undefined} d
 * @returns {string}
 */
export function formatDayLabel(d) {
  return d ? new Date(d).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" }) : "";
}

/**
 * Truncate a date to local midnight, returned as an epoch ms timestamp.
 * Used as a grouping key when bucketing timestamps into day groups (two
 * events on the same calendar day collapse to the same key regardless of
 * their time-of-day).
 * @param {string|number|Date} d
 * @returns {number}
 */
export function toMidnight(d) {
  return new Date(new Date(d).toDateString()).getTime();
}

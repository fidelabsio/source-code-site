// Symbol lookup for the currencies this app has been used with — reconciled
// from several near-duplicate maps that used to live inline in individual
// routes (dashboard, quote list, quote settings, quote detail). Extend this
// map rather than re-adding a local one in a route/domain file.
export const CURRENCY_SYMBOLS = {
  USD: "$", EUR: "€", GBP: "£", INR: "₹", AUD: "A$",
  CAD: "C$", SGD: "S$", AED: "AED", JPY: "¥", CNY: "¥",
  CHF: "Fr", MXN: "MX$", BRL: "R$", ZAR: "R", SEK: "kr",
  NOK: "kr", DKK: "kr", NZD: "NZ$", HKD: "HK$", KRW: "₩",
  PLN: "zł", CZK: "Kč", HUF: "Ft",
};

/**
 * Look up a currency's display symbol, falling back to the ISO code itself
 * (with a trailing space so it doesn't visually run into the amount) for any
 * currency not in {@link CURRENCY_SYMBOLS}.
 * @param {string} currency - ISO 4217 currency code, e.g. "USD"
 * @returns {string}
 */
export function getCurrencySymbol(currency) {
  return CURRENCY_SYMBOLS[currency] || (currency ? `${currency} ` : "");
}

/**
 * Format an amount with its currency symbol and two decimal places, e.g.
 * `formatMoney(19.9, "USD")` → `"$19.90"`.
 * @param {number|string} amount
 * @param {string} currency - ISO 4217 currency code
 * @returns {string}
 */
export function formatMoney(amount, currency) {
  const sym = getCurrencySymbol(currency);
  return `${sym}${parseFloat(amount || 0).toFixed(2)}`;
}

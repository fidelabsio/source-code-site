/**
 * Escape a single CSV cell value per RFC 4180: wrap in quotes (doubling any
 * embedded quotes) if the value contains a comma, quote, or newline.
 * @param {*} v - raw cell value (stringified if not already a string)
 * @returns {string}
 */
export function escapeCsvValue(v) {
  if (v == null) return "";
  const s = String(v);
  if (s.includes(",") || s.includes('"') || s.includes("\n")) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

/**
 * Build a full CSV document (header row + data rows) as a single string.
 * Uses CRLF row separators per RFC 4180 for maximum spreadsheet-app compatibility.
 * @param {string[]} headers - column header row
 * @param {Array<Array<*>>} rows - each row is an array of raw cell values
 * @returns {string} CSV text, ready to write to a Blob/file
 */
export function buildCsv(headers, rows) {
  return [headers, ...rows]
    .map((row) => row.map(escapeCsvValue).join(","))
    .join("\r\n");
}

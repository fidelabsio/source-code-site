/**
 * Open a new browser tab containing a fully-formed HTML document and
 * immediately trigger the browser's print dialog — used for "Print PDF"
 * actions that render a quote/invoice as printable HTML rather than a real
 * PDF file. Callers are responsible for HTML-escaping any interpolated
 * user/customer data before passing it in here (see {@link escapeHtml} in
 * ./html.js) — this function does no sanitization of its own.
 * @param {string} html - complete `<html>...</html>` document string
 */
export function printHtmlDocument(html) {
  const win = window.open("", "_blank");
  win.document.write(html);
  win.document.close();
  win.print();
}

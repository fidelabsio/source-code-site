// Polaris's <ColorPicker> works in HSB, but colors are stored/sent to the
// server as hex — these two convert at the state/DB boundary so the rest of
// the app can just use hex strings.

/**
 * Convert an HSB color (as Polaris's `<ColorPicker>` produces) to a hex string.
 * @param {{hue: number, saturation: number, brightness: number}} hsb - hue in degrees (0-360), saturation/brightness as 0-1 fractions
 * @returns {string} hex color, e.g. "#1a73e8"
 */
export function hsbToHex({ hue, saturation, brightness }) {
  const h = hue / 360, s = saturation, b = brightness;
  const i = Math.floor(h * 6);
  const f = h * 6 - i;
  const p = b * (1 - s), q = b * (1 - f * s), t = b * (1 - (1 - f) * s);
  const [r, g, bl] = [
    [b, t, p], [q, b, p], [p, b, t], [p, q, b], [t, p, b], [b, p, q],
  ][i % 6];
  const hex = (x) => Math.round(x * 255).toString(16).padStart(2, "0");
  return `#${hex(r)}${hex(g)}${hex(bl)}`;
}

/**
 * Convert a hex color string to the HSB shape Polaris's `<ColorPicker>` expects.
 * @param {string} hex - hex color, e.g. "#1a73e8"
 * @returns {{hue: number, saturation: number, brightness: number, alpha: number}}
 */
export function hexToHsb(hex) {
  const r = parseInt(hex.slice(1, 3), 16) / 255;
  const g = parseInt(hex.slice(3, 5), 16) / 255;
  const b = parseInt(hex.slice(5, 7), 16) / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min;
  let hue = 0;
  if (d) {
    if (max === r) hue = ((g - b) / d) % 6;
    else if (max === g) hue = (b - r) / d + 2;
    else hue = (r - g) / d + 4;
    hue = Math.round(hue * 60);
    if (hue < 0) hue += 360;
  }
  return { hue, saturation: max ? d / max : 0, brightness: max, alpha: 1 };
}

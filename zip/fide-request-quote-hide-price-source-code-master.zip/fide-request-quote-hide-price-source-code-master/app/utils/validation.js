/** Loose but practical email-shape check — not RFC 5322-exhaustive, just enough to catch obvious typos client-side. */
export const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
/** Matches 7-15 digits, with an optional leading `+` — applied AFTER stripping spaces/dashes/parens/dots (see {@link isValidPhone}). */
export const PHONE_REGEX = /^\+?[0-9]{7,15}$/;

/**
 * @param {string} value
 * @returns {boolean} true if `value` looks like a plausible email address
 */
export function isValidEmail(value) {
  return EMAIL_REGEX.test(value || "");
}

/**
 * Validate a phone number after stripping common formatting characters
 * (spaces, dashes, parens, dots) — so "(555) 123-4567" and "5551234567"
 * both validate the same way.
 * @param {string} value
 * @returns {boolean}
 */
export function isValidPhone(value) {
  const digits = String(value || "").replace(/[\s\-().]/g, "");
  return PHONE_REGEX.test(digits);
}

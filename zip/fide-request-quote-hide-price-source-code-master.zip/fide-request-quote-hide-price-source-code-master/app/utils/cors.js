/**
 * Build permissive CORS headers for a storefront-facing API route (App Proxy
 * requests are same-origin through Shopify, but the theme extension's own
 * fetch calls run from the storefront's origin, so these routes need CORS).
 * @param {string} [methods="GET, OPTIONS"] - value for Access-Control-Allow-Methods
 * @returns {Record<string, string>} headers to spread into a Response
 */
export function buildCorsHeaders(methods = "GET, OPTIONS") {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": methods,
    "Access-Control-Allow-Headers": "Content-Type",
  };
}

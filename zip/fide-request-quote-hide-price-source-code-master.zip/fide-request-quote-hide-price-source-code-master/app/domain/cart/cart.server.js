/**
 * Quote Cart Page
 * Served via App Proxy: mystore.myshopify.com/apps/{subpath}/cart
 * → APP_URL/cart (subpath comes from app/config/app-proxy.json)
 *
 * Returns raw HTML — no React wrapper.
 * Client-side JS reads the quote cart from localStorage and renders items.
 *
 * Gotcha: unlike upload.server.js, this route does NOT go through
 * `authenticate.public.appProxy`, so the `shop` used to look up branding
 * (button color/text/success message) is resolved from a client-supplied
 * header or URL query param and is never HMAC-verified. That's acceptable
 * here because `shop` only affects cosmetic theming of this static page —
 * it is never used to read/write quote or customer data (the cart itself
 * lives entirely in the browser's localStorage; nothing server-side is
 * read or written by this loader beyond the one branding-config lookup).
 */

import prisma from "../../db.server";
import { buildCorsHeaders } from "../../utils/cors";
import { APP_PROXY_SUBPATH } from "../../core/appProxy.server";

const CORS = buildCorsHeaders("GET, OPTIONS");

/**
 * Loader for `/cart` — renders the quote-cart page shell and injects the
 * shop's branding config (button color/text, success message) as inline
 * styles/data attributes. All actual cart state (items, quantities) is
 * managed client-side in the embedded `<script>` below, which reads/writes
 * `localStorage` and posts the final request to
 * `/apps/{APP_PROXY_SUBPATH}/api/quote` on submit — this loader never sees or
 * persists individual cart items.
 *
 * @param {Request} request - `X-Shopify-Shop-Domain` header or `?shop=`
 *   query param identifies the shop for branding lookup only (see gotcha
 *   above); missing/invalid shop just falls back to default branding.
 * @returns {Response} `text/html` document (200), or a 204 CORS preflight
 *   response for `OPTIONS`.
 */
export const loader = async ({ request }) => {
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS });
  }

  const shop =
    request.headers.get("X-Shopify-Shop-Domain") ||
    new URL(request.url).searchParams.get("shop") ||
    "";

  const config = shop
    ? await prisma.quoteConfig.findUnique({ where: { shop } }).catch(() => null)
    : null;

  const btnBg    = config?.buttonBgColor    ?? "#1a1a18";
  const btnTxt   = config?.buttonTextColor  ?? "#ffffff";
  const btnText  = config?.buttonText       ?? "Request a Quote";
  const successMsg = config?.successMessage ?? "Thank you! We will be in touch shortly.";

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Quote Cart</title>
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background: #f6f6f1;
      color: #1a1a18;
      min-height: 100vh;
    }

    /* ── Header ── */
    .qrc-header {
      background: #fff;
      border-bottom: 1px solid #e3e3db;
      padding: 0 24px;
      height: 60px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      position: sticky;
      top: 0;
      z-index: 10;
    }
    .qrc-header-back {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      font-size: 14px;
      color: #6b7280;
      text-decoration: none;
      transition: color .15s;
    }
    .qrc-header-back:hover { color: #1a1a18; }
    .qrc-header-title { font-size: 16px; font-weight: 700; }
    .qrc-header-count {
      font-size: 13px;
      color: #6b7280;
      background: #f6f6f1;
      border: 1px solid #e3e3db;
      padding: 3px 10px;
      border-radius: 20px;
    }

    /* ── Page wrapper ── */
    .qrc-page {
      max-width: 1080px;
      margin: 0 auto;
      padding: 32px 20px 80px;
    }

    /* ── Layout grid ── */
    .qrc-grid {
      display: grid;
      grid-template-columns: 1fr 380px;
      gap: 24px;
      align-items: start;
    }
    @media (max-width: 768px) {
      .qrc-grid { grid-template-columns: 1fr; }
    }

    /* ── Section card ── */
    .qrc-card {
      background: #fff;
      border: 1px solid #e3e3db;
      border-radius: 12px;
      overflow: hidden;
    }
    .qrc-card-header {
      padding: 16px 20px;
      border-bottom: 1px solid #f0f0eb;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .qrc-card-header h2 { font-size: 15px; font-weight: 700; }
    .qrc-card-header .qrc-clear-btn {
      font-size: 13px;
      color: #b91c1c;
      background: none;
      border: none;
      cursor: pointer;
      padding: 4px 8px;
      border-radius: 6px;
    }
    .qrc-card-header .qrc-clear-btn:hover { background: #fef2f2; }

    /* ── Product items ── */
    .qrc-items { padding: 8px 0; }
    .qrc-item {
      display: grid;
      grid-template-columns: 64px 1fr auto;
      gap: 14px;
      align-items: start;
      padding: 16px 20px;
      border-bottom: 1px solid #f0f0eb;
    }
    .qrc-item:last-child { border-bottom: none; }

    .qrc-item-img {
      width: 64px;
      height: 64px;
      border-radius: 8px;
      object-fit: cover;
      background: #f0f0eb;
      flex-shrink: 0;
      border: 1px solid #e3e3db;
    }
    .qrc-item-img-placeholder {
      width: 64px;
      height: 64px;
      border-radius: 8px;
      background: #f0f0eb;
      border: 1px solid #e3e3db;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #9ca3af;
      font-size: 22px;
      flex-shrink: 0;
    }

    .qrc-item-info { min-width: 0; }
    .qrc-item-title {
      font-size: 14px;
      font-weight: 600;
      line-height: 1.3;
      margin-bottom: 3px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .qrc-item-variant { font-size: 12px; color: #6b7280; margin-bottom: 8px; }
    .qrc-item-price { font-size: 13px; color: #374151; font-weight: 500; }

    /* Qty stepper */
    .qrc-qty {
      display: inline-flex;
      align-items: center;
      gap: 0;
      border: 1px solid #e3e3db;
      border-radius: 8px;
      overflow: hidden;
      margin-top: 10px;
    }
    .qrc-qty button {
      width: 30px;
      height: 30px;
      background: none;
      border: none;
      cursor: pointer;
      font-size: 16px;
      color: #374151;
      line-height: 1;
      transition: background .12s;
    }
    .qrc-qty button:hover { background: #f6f6f1; }
    .qrc-qty button:disabled { color: #d1d5db; cursor: default; }
    .qrc-qty span {
      min-width: 32px;
      text-align: center;
      font-size: 13px;
      font-weight: 600;
      border-left: 1px solid #e3e3db;
      border-right: 1px solid #e3e3db;
      height: 30px;
      line-height: 30px;
    }

    .qrc-item-actions { display: flex; flex-direction: column; align-items: flex-end; gap: 8px; padding-top: 2px; }
    .qrc-remove-btn {
      background: none;
      border: none;
      cursor: pointer;
      color: #9ca3af;
      padding: 4px;
      border-radius: 4px;
      font-size: 18px;
      line-height: 1;
      transition: color .12s;
    }
    .qrc-remove-btn:hover { color: #b91c1c; }

    /* ── Empty state ── */
    .qrc-empty {
      padding: 56px 20px;
      text-align: center;
    }
    .qrc-empty-icon { font-size: 40px; margin-bottom: 14px; }
    .qrc-empty h3 { font-size: 16px; font-weight: 700; margin-bottom: 8px; }
    .qrc-empty p { font-size: 14px; color: #6b7280; margin-bottom: 20px; }
    .qrc-empty a {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      font-size: 14px;
      font-weight: 600;
      color: #1a1a18;
      text-decoration: none;
      border: 1.5px solid #1a1a18;
      padding: 8px 18px;
      border-radius: 8px;
      transition: background .12s, color .12s;
    }
    .qrc-empty a:hover { background: #1a1a18; color: #fff; }

    /* ── Contact form card ── */
    .qrc-form { padding: 20px; }
    .qrc-form label {
      display: block;
      font-size: 13px;
      font-weight: 600;
      margin-bottom: 5px;
      color: #374151;
    }
    .qrc-form label .req { color: #b91c1c; margin-left: 2px; }
    .qrc-input {
      width: 100%;
      border: 1.5px solid #e3e3db;
      border-radius: 8px;
      padding: 9px 12px;
      font-size: 14px;
      font-family: inherit;
      color: #1a1a18;
      background: #fff;
      transition: border-color .15s, box-shadow .15s;
      outline: none;
      margin-bottom: 14px;
    }
    .qrc-input:focus { border-color: #1a1a18; box-shadow: 0 0 0 3px rgba(26,26,24,0.08); }
    .qrc-input--error { border-color: #b91c1c; }
    .qrc-error-msg { font-size: 12px; color: #b91c1c; margin-top: -10px; margin-bottom: 12px; }

    textarea.qrc-input { resize: vertical; min-height: 80px; }

    /* Submit button */
    .qrc-submit-btn {
      width: 100%;
      padding: 13px;
      background: ${btnBg};
      color: ${btnTxt};
      border: none;
      border-radius: 8px;
      font-size: 15px;
      font-weight: 700;
      cursor: pointer;
      transition: opacity .15s;
      margin-top: 4px;
      font-family: inherit;
    }
    .qrc-submit-btn:hover { opacity: 0.88; }
    .qrc-submit-btn:disabled { opacity: 0.55; cursor: not-allowed; }

    .qrc-form-note {
      text-align: center;
      font-size: 12px;
      color: #9ca3af;
      margin-top: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 5px;
    }

    /* ── Success state ── */
    #qrc-success {
      display: none;
      padding: 48px 28px;
      text-align: center;
    }
    .qrc-success-icon {
      width: 56px;
      height: 56px;
      background: #d1fae5;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 16px;
      font-size: 26px;
    }
    #qrc-success h3 { font-size: 18px; font-weight: 700; margin-bottom: 8px; }
    #qrc-success p { font-size: 14px; color: #6b7280; margin-bottom: 20px; line-height: 1.6; }
    #qrc-success a {
      font-size: 14px;
      font-weight: 600;
      color: ${btnBg};
      text-decoration: underline;
    }

    /* ── Summary strip ── */
    .qrc-summary {
      border-top: 1px solid #f0f0eb;
      padding: 14px 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 13px;
      color: #6b7280;
    }
    .qrc-summary strong { color: #1a1a18; font-size: 14px; }

    /* ── Error banner ── */
    #qrc-submit-error {
      display: none;
      background: #fef2f2;
      border: 1px solid #fecaca;
      border-radius: 8px;
      padding: 10px 14px;
      font-size: 13px;
      color: #b91c1c;
      margin-bottom: 12px;
    }

    /* ── Loading skeleton ── */
    .qrc-skeleton {
      background: linear-gradient(90deg, #f0f0eb 25%, #e8e8e0 50%, #f0f0eb 75%);
      background-size: 200% 100%;
      animation: qrc-shimmer 1.4s infinite;
      border-radius: 6px;
    }
    @keyframes qrc-shimmer { 0% { background-position: 200% 0; } 100% { background-position: -200% 0; } }
  </style>
</head>
<body data-shop="${shop}" data-success-msg="${successMsg.replace(/"/g, '&quot;')}">

  <!-- Header -->
  <header class="qrc-header">
    <a class="qrc-header-back" href="javascript:history.back()">
      ← Back
    </a>
    <span class="qrc-header-title">Quote Cart</span>
    <span class="qrc-header-count" id="qrc-header-count">0 items</span>
  </header>

  <main class="qrc-page">
    <div class="qrc-grid" id="qrc-main-grid">

      <!-- Left: Products -->
      <div>
        <div class="qrc-card" id="qrc-products-card">
          <div class="qrc-card-header">
            <h2>Products</h2>
            <button class="qrc-clear-btn" id="qrc-clear-btn" onclick="QRC.clearCart()">Remove all</button>
          </div>
          <div class="qrc-items" id="qrc-items-list">
            <!-- populated by JS -->
            <div class="qrc-item" style="opacity:.4">
              <div class="qrc-item-img-placeholder qrc-skeleton" style="width:64px;height:64px"></div>
              <div>
                <div class="qrc-skeleton" style="height:14px;width:160px;margin-bottom:8px"></div>
                <div class="qrc-skeleton" style="height:12px;width:80px"></div>
              </div>
            </div>
          </div>
          <div class="qrc-summary" id="qrc-summary">
            <span id="qrc-item-count">—</span>
          </div>
        </div>
      </div>

      <!-- Right: Contact form -->
      <div class="qrc-card" id="qrc-form-card">
        <div class="qrc-card-header">
          <h2>Your details</h2>
        </div>

        <div class="qrc-form" id="qrc-form-wrap">
          <div id="qrc-submit-error" style="display:none"></div>

          <label>Name <span class="req">*</span></label>
          <input class="qrc-input" id="qrc-name" type="text" placeholder="Your full name" autocomplete="name" />
          <div class="qrc-error-msg" id="qrc-name-error"></div>

          <label>Email <span class="req">*</span></label>
          <input class="qrc-input" id="qrc-email" type="email" placeholder="your@email.com" autocomplete="email" />
          <div class="qrc-error-msg" id="qrc-email-error"></div>

          <label>Phone</label>
          <div style="display:flex;gap:8px;margin-bottom:0;">
            <select id="qrc-phone-code" style="width:110px;flex-shrink:0;height:42px;padding:0 8px;border:1.5px solid #e3e3db;border-radius:8px;font-size:14px;font-family:inherit;background:#fff;cursor:pointer;"></select>
            <input class="qrc-input" id="qrc-phone" type="tel" placeholder="Phone number" autocomplete="tel" style="flex:1;min-width:0;margin-bottom:0;" />
          </div>
          <div class="qrc-error-msg" id="qrc-phone-error" style="margin-bottom:14px;"></div>

          <label>Company</label>
          <input class="qrc-input" id="qrc-company" type="text" placeholder="Company name (optional)" autocomplete="organization" />

          <label>Message</label>
          <textarea class="qrc-input" id="qrc-message" rows="4" placeholder="Any special requirements or questions…"></textarea>

          <button class="qrc-submit-btn" id="qrc-submit-btn" onclick="QRC.submit()">
            ${btnText}
          </button>

          <p class="qrc-form-note">
            🔒 Your information is kept private
          </p>
        </div>

        <!-- Success -->
        <div id="qrc-success">
          <div class="qrc-success-icon">✓</div>
          <h3>Quote request sent!</h3>
          <p id="qrc-success-msg">${successMsg}</p>
          <a href="/">Continue shopping</a>
        </div>
      </div>

    </div>
  </main>

  <script>
  (function () {
    "use strict";

    const STORAGE_KEY = "qr_cart";
    const shop = document.body.dataset.shop || "";

    // ── Dial code data ────────────────────────────────────────────────────────
    var DIAL = [
      {c:"US",n:"United States",d:"+1"},{c:"GB",n:"United Kingdom",d:"+44"},
      {c:"AU",n:"Australia",d:"+61"},{c:"CA",n:"Canada",d:"+1"},
      {c:"IN",n:"India",d:"+91"},{c:"DE",n:"Germany",d:"+49"},
      {c:"FR",n:"France",d:"+33"},{c:"AF",n:"Afghanistan",d:"+93"},
      {c:"AL",n:"Albania",d:"+355"},{c:"DZ",n:"Algeria",d:"+213"},
      {c:"AR",n:"Argentina",d:"+54"},{c:"AM",n:"Armenia",d:"+374"},
      {c:"AT",n:"Austria",d:"+43"},{c:"AZ",n:"Azerbaijan",d:"+994"},
      {c:"BH",n:"Bahrain",d:"+973"},{c:"BD",n:"Bangladesh",d:"+880"},
      {c:"BY",n:"Belarus",d:"+375"},{c:"BE",n:"Belgium",d:"+32"},
      {c:"BA",n:"Bosnia",d:"+387"},{c:"BR",n:"Brazil",d:"+55"},
      {c:"BG",n:"Bulgaria",d:"+359"},{c:"KH",n:"Cambodia",d:"+855"},
      {c:"CM",n:"Cameroon",d:"+237"},{c:"CL",n:"Chile",d:"+56"},
      {c:"CN",n:"China",d:"+86"},{c:"CO",n:"Colombia",d:"+57"},
      {c:"HR",n:"Croatia",d:"+385"},{c:"CY",n:"Cyprus",d:"+357"},
      {c:"CZ",n:"Czech Republic",d:"+420"},{c:"DK",n:"Denmark",d:"+45"},
      {c:"EG",n:"Egypt",d:"+20"},{c:"EE",n:"Estonia",d:"+372"},
      {c:"ET",n:"Ethiopia",d:"+251"},{c:"FI",n:"Finland",d:"+358"},
      {c:"GE",n:"Georgia",d:"+995"},{c:"GH",n:"Ghana",d:"+233"},
      {c:"GR",n:"Greece",d:"+30"},{c:"HK",n:"Hong Kong",d:"+852"},
      {c:"HU",n:"Hungary",d:"+36"},{c:"IS",n:"Iceland",d:"+354"},
      {c:"ID",n:"Indonesia",d:"+62"},{c:"IR",n:"Iran",d:"+98"},
      {c:"IQ",n:"Iraq",d:"+964"},{c:"IE",n:"Ireland",d:"+353"},
      {c:"IL",n:"Israel",d:"+972"},{c:"IT",n:"Italy",d:"+39"},
      {c:"JP",n:"Japan",d:"+81"},{c:"JO",n:"Jordan",d:"+962"},
      {c:"KZ",n:"Kazakhstan",d:"+7"},{c:"KE",n:"Kenya",d:"+254"},
      {c:"KW",n:"Kuwait",d:"+965"},{c:"LV",n:"Latvia",d:"+371"},
      {c:"LB",n:"Lebanon",d:"+961"},{c:"LY",n:"Libya",d:"+218"},
      {c:"LT",n:"Lithuania",d:"+370"},{c:"LU",n:"Luxembourg",d:"+352"},
      {c:"MY",n:"Malaysia",d:"+60"},{c:"MV",n:"Maldives",d:"+960"},
      {c:"MT",n:"Malta",d:"+356"},{c:"MX",n:"Mexico",d:"+52"},
      {c:"MD",n:"Moldova",d:"+373"},{c:"MA",n:"Morocco",d:"+212"},
      {c:"MM",n:"Myanmar",d:"+95"},{c:"NP",n:"Nepal",d:"+977"},
      {c:"NL",n:"Netherlands",d:"+31"},{c:"NZ",n:"New Zealand",d:"+64"},
      {c:"NG",n:"Nigeria",d:"+234"},{c:"NO",n:"Norway",d:"+47"},
      {c:"OM",n:"Oman",d:"+968"},{c:"PK",n:"Pakistan",d:"+92"},
      {c:"PS",n:"Palestine",d:"+970"},{c:"PY",n:"Paraguay",d:"+595"},
      {c:"PE",n:"Peru",d:"+51"},{c:"PH",n:"Philippines",d:"+63"},
      {c:"PL",n:"Poland",d:"+48"},{c:"PT",n:"Portugal",d:"+351"},
      {c:"QA",n:"Qatar",d:"+974"},{c:"RO",n:"Romania",d:"+40"},
      {c:"RU",n:"Russia",d:"+7"},{c:"SA",n:"Saudi Arabia",d:"+966"},
      {c:"RS",n:"Serbia",d:"+381"},{c:"SG",n:"Singapore",d:"+65"},
      {c:"SK",n:"Slovakia",d:"+421"},{c:"SI",n:"Slovenia",d:"+386"},
      {c:"ZA",n:"South Africa",d:"+27"},{c:"KR",n:"South Korea",d:"+82"},
      {c:"ES",n:"Spain",d:"+34"},{c:"LK",n:"Sri Lanka",d:"+94"},
      {c:"SE",n:"Sweden",d:"+46"},{c:"CH",n:"Switzerland",d:"+41"},
      {c:"SY",n:"Syria",d:"+963"},{c:"TW",n:"Taiwan",d:"+886"},
      {c:"TZ",n:"Tanzania",d:"+255"},{c:"TH",n:"Thailand",d:"+66"},
      {c:"TN",n:"Tunisia",d:"+216"},{c:"TR",n:"Turkey",d:"+90"},
      {c:"UA",n:"Ukraine",d:"+380"},{c:"AE",n:"UAE",d:"+971"},
      {c:"UY",n:"Uruguay",d:"+598"},{c:"UZ",n:"Uzbekistan",d:"+998"},
      {c:"VE",n:"Venezuela",d:"+58"},{c:"VN",n:"Vietnam",d:"+84"},
      {c:"YE",n:"Yemen",d:"+967"},{c:"ZM",n:"Zambia",d:"+260"},
      {c:"ZW",n:"Zimbabwe",d:"+263"},
    ];
    function flag(code) {
      try { return String.fromCodePoint(0x1F1E6+code.charCodeAt(0)-65, 0x1F1E6+code.charCodeAt(1)-65); } catch(e) { return ""; }
    }
    (function populateDial() {
      var sel = document.getElementById("qrc-phone-code");
      if (!sel) return;
      var popular = ["US","GB","AU","CA","IN","DE","FR"];
      var html = "";
      popular.forEach(function(c) {
        var e = DIAL.find(function(x){return x.c===c;});
        if (e) html += '<option value="' + e.d + '">' + flag(e.c) + " " + e.d + " " + e.n + "</option>";
      });
      html += '<option disabled>─────────────</option>';
      DIAL.slice().sort(function(a,b){return a.n.localeCompare(b.n);}).forEach(function(e) {
        html += '<option value="' + e.d + '">' + flag(e.c) + " " + e.d + " " + e.n + "</option>";
      });
      sel.innerHTML = html;
    })();

    // ── Cart helpers ──────────────────────────────────────────────────────────
    // localStorage is the ONLY source of truth for cart contents — nothing is
    // synced to the server until the buyer hits "Send Quote Request" below.
    function getCart() {
      try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); } catch { return []; }
    }
    function saveCart(items) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    }

    // ── Render ────────────────────────────────────────────────────────────────
    function render() {
      const items = getCart();
      const list  = document.getElementById("qrc-items-list");
      const count = document.getElementById("qrc-item-count");
      const hdrCount = document.getElementById("qrc-header-count");

      if (!list) return;

      hdrCount.textContent = items.length + " item" + (items.length !== 1 ? "s" : "");

      if (items.length === 0) {
        list.innerHTML = "";
        document.getElementById("qrc-products-card").innerHTML = \`
          <div class="qrc-empty">
            <div class="qrc-empty-icon">🛒</div>
            <h3>Your quote cart is empty</h3>
            <p>Browse products and click "Add to Quote" to get started.</p>
            <a href="/">← Continue shopping</a>
          </div>\`;
        if (count) count.textContent = "No items";
        const submitBtn = document.getElementById("qrc-submit-btn");
        if (submitBtn) submitBtn.disabled = true;
        return;
      }

      const submitBtn = document.getElementById("qrc-submit-btn");
      if (submitBtn) submitBtn.disabled = false;

      if (count) count.textContent = items.length + " product" + (items.length !== 1 ? "s" : "");

      list.innerHTML = items.map((item, idx) => \`
        <div class="qrc-item" data-idx="\${idx}">
          \${item.image
            ? \`<img class="qrc-item-img" src="\${item.image}" alt="\${esc(item.productTitle)}" />\`
            : \`<div class="qrc-item-img-placeholder">📦</div>\`
          }
          <div class="qrc-item-info">
            <div class="qrc-item-title">\${esc(item.productTitle)}</div>
            \${item.variantTitle ? \`<div class="qrc-item-variant">\${esc(item.variantTitle)}</div>\` : ""}
            \${item.price ? \`<div class="qrc-item-price">\${esc(item.price)}</div>\` : ""}
            <div class="qrc-qty">
              <button onclick="QRC.updateQty(\${idx}, -1)" \${item.quantity <= 1 ? "disabled" : ""}>−</button>
              <span>\${item.quantity}</span>
              <button onclick="QRC.updateQty(\${idx}, 1)">+</button>
            </div>
          </div>
          <div class="qrc-item-actions">
            <button class="qrc-remove-btn" onclick="QRC.removeItem(\${idx})" title="Remove">✕</button>
          </div>
        </div>\`).join("");
    }

    // HTML-escape before inlining into innerHTML above. item.productTitle /
    // variantTitle / price come from storefront product data written into
    // localStorage by the "Add to Quote" widget on the product page, so they
    // are untrusted as far as this page is concerned — without this, a
    // crafted product/variant title could inject markup.
    function esc(str) {
      return String(str || "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
    }

    // ── Cart actions ──────────────────────────────────────────────────────────
    window.QRC = {
      updateQty(idx, delta) {
        const items = getCart();
        if (!items[idx]) return;
        items[idx].quantity = Math.max(1, (items[idx].quantity || 1) + delta);
        saveCart(items);
        render();
      },
      removeItem(idx) {
        const items = getCart();
        items.splice(idx, 1);
        saveCart(items);
        render();
      },
      clearCart() {
        if (!confirm("Remove all items from your quote cart?")) return;
        saveCart([]);
        render();
      },
      async submit() {
        const items = getCart();
        if (!items.length) return;

        // Validate
        const name  = document.getElementById("qrc-name")?.value.trim();
        const email = document.getElementById("qrc-email")?.value.trim();
        const phoneNum = (document.getElementById("qrc-phone")?.value || "").trim();
        let ok = true;

        ["qrc-name-error","qrc-email-error","qrc-phone-error"].forEach(id => {
          const el = document.getElementById(id); if (el) el.textContent = "";
        });
        ["qrc-name","qrc-email","qrc-phone"].forEach(id => {
          document.getElementById(id)?.classList.remove("qrc-input--error");
        });

        if (!name || name.length < 2) {
          document.getElementById("qrc-name")?.classList.add("qrc-input--error");
          const el = document.getElementById("qrc-name-error"); if (el) el.textContent = !name ? "Please enter your name." : "Name must be at least 2 characters.";
          ok = false;
        } else if (name.length > 100) {
          document.getElementById("qrc-name")?.classList.add("qrc-input--error");
          const el = document.getElementById("qrc-name-error"); if (el) el.textContent = "Name must be 100 characters or less.";
          ok = false;
        }
        if (!email) {
          document.getElementById("qrc-email")?.classList.add("qrc-input--error");
          const el = document.getElementById("qrc-email-error"); if (el) el.textContent = "Email is required.";
          ok = false;
        } else if (email.length > 100 || !/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(email)) {
          document.getElementById("qrc-email")?.classList.add("qrc-input--error");
          const el = document.getElementById("qrc-email-error"); if (el) el.textContent = "Enter a valid email address (e.g. name@example.com).";
          ok = false;
        }
        if (phoneNum) {
          const phoneDigits = phoneNum.replace(/[\\s\\-\\(\\)\\.]/g, "");
          if (!/^\\+?[0-9]{7,15}$/.test(phoneDigits)) {
            document.getElementById("qrc-phone")?.classList.add("qrc-input--error");
            const el = document.getElementById("qrc-phone-error"); if (el) el.textContent = "Enter a valid phone number (7–15 digits, digits only).";
            ok = false;
          }
        }
        if (!ok) return;

        const btn = document.getElementById("qrc-submit-btn");
        const errBanner = document.getElementById("qrc-submit-error");
        // Cache the merchant-configured label so the error path below can
        // restore it exactly, instead of resetting to a hardcoded string.
        const originalBtnText = btn.textContent;
        btn.disabled = true;
        btn.textContent = "Sending…";
        if (errBanner) errBanner.style.display = "none";

        // The backend quote record is keyed to a single product/quantity, so
        // when the cart holds multiple items only the first becomes the
        // "primary" quote row — the full cart still rides along in the
        // cartItems field for the merchant to see everything that was requested.
        // The backend quote record is keyed to a single product/quantity, so
        // when the cart holds multiple items only the first becomes the
        // "primary" quote row — the full cart still rides along in the
        // cartItems field for the merchant to see everything that was requested.
        const first = items[0];
        const payload = {
          shop,
          productId:     first.productId    || null,
          productTitle:  first.productTitle  || "Untitled item",
          customerName:  name,
          customerEmail: email,
          customerPhone: (() => { var num = (document.getElementById("qrc-phone")?.value || "").trim(); var code = document.getElementById("qrc-phone-code")?.value || ""; return num ? (code ? code + " " + num : num) : null; })(),
          companyName:   document.getElementById("qrc-company")?.value.trim() || null,
          message:       document.getElementById("qrc-message")?.value.trim() || null,
          quantity:      String(first.quantity || 1),
          cartItems:     items,
        };

        try {
          const res = await fetch("/apps/${APP_PROXY_SUBPATH}/api/quote", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          });
          if (!res.ok) {
            const data = await res.json().catch(() => ({}));
            throw new Error(data.error || "Server error " + res.status);
          }

          // Clear cart + show success
          saveCart([]);
          document.getElementById("qrc-form-wrap").style.display = "none";
          document.getElementById("qrc-success").style.display = "block";
          const msgEl = document.getElementById("qrc-success-msg");
          if (msgEl) msgEl.textContent = document.body.dataset.successMsg || msgEl.textContent;
        } catch (err) {
          if (errBanner) { errBanner.textContent = err.message; errBanner.style.display = "block"; }
          btn.disabled = false;
          btn.textContent = originalBtnText;
        }
      },
    };

    // Clear inline errors when user fixes the value
    ["qrc-name", "qrc-email", "qrc-phone"].forEach(function (id) {
      var el = document.getElementById(id);
      if (!el) return;
      el.addEventListener("input", function () {
        if (!el.classList.contains("qrc-input--error")) return;
        var v = el.value.trim();
        var ok = id === "qrc-email"
          ? v && v.length <= 100 && /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(v)
          : id === "qrc-phone"
          ? !v || /^\\+?[0-9]{7,15}$/.test(v.replace(/[\\s\\-\\(\\)\\.]/g, ""))
          : !!v;
        if (ok) {
          el.classList.remove("qrc-input--error");
          var errEl = document.getElementById(id + "-error");
          if (errEl) errEl.textContent = "";
        }
      });
    });

    render();
  })();
  </script>
</body>
</html>`;

  return new Response(html, {
    status: 200,
    headers: { ...CORS, "Content-Type": "text/html; charset=utf-8" },
  });
};

/**
 * Maps Shopify's LoginErrorType enum to human-readable form errors for the
 * `/auth/login` page. Consumed by auth.server.js (loginLoader/loginAction).
 */
import { LoginErrorType } from "@shopify/shopify-app-react-router/server";

/**
 * Translate the raw error returned by the Shopify SDK's `login()` helper
 * into a field-keyed message the login form can render next to the shop
 * input.
 * @param {object} loginErrors - Error object returned by `login(request)`.
 * @returns {{shop?: string}} Empty object when there's no shop-field error.
 */
export function loginErrorMessage(loginErrors) {
  if (loginErrors?.shop === LoginErrorType.MissingShop) {
    return { shop: "Please enter your shop domain to log in" };
  } else if (loginErrors?.shop === LoginErrorType.InvalidShop) {
    return { shop: "Please enter a valid shop domain to log in" };
  }

  return {};
}

/**
 * Shopify OAuth entry points: the `/auth/*` callback that completes the
 * install/re-auth handshake, and the `/auth/login` form used for shops that
 * aren't embedded yet. Consumed by app/routes/auth.$.jsx (loader + headers)
 * and app/routes/auth.login/route.jsx (loader + action).
 *
 * Gotcha: `loginLoader` must redirect embedded-session requests back through
 * `/auth` instead of rendering the login form — see comment below.
 */
import { boundary } from "@shopify/shopify-app-react-router/server";
import { redirect } from "react-router";
import { authenticate, login } from "../../core/shopify/shopify.server";
import { loginErrorMessage } from "./authError.server";
import { APP_NAME } from "../../core/branding.server";

/**
 * Loader for `/auth/*` (auth.$.jsx) — completes the Shopify OAuth callback.
 * `authenticate.admin` validates the OAuth response, persists the session,
 * and throws its own redirect back into the embedded app; this loader never
 * needs to return a body itself.
 * @returns {null}
 */
export const authCallbackLoader = async ({ request }) => {
  await authenticate.admin(request);

  return null;
};

/**
 * Headers export for auth.$.jsx — delegates to the Shopify SDK's boundary
 * helper so OAuth responses carry the CSP/frame headers required for the
 * embedded iframe to load correctly.
 */
export const authHeaders = (headersArgs) => {
  return boundary.headers(headersArgs);
};

/**
 * Loader for `/auth/login` (auth.login/route.jsx) — renders the pre-install
 * login form, used by brand-new visitors with no store context.
 *
 * @returns {{errors: object, appName: string}} Field-level error messages
 * from `login()`, keyed for the login form (empty object when there's
 * nothing to report), plus this app's own display name
 * (app/config/branding.json) for the page copy.
 */
export const loginLoader = async ({ request }) => {
  const url = new URL(request.url);
  // A known/installed merchant — most importantly an embedded session that
  // expired or lost its params mid-action — lands here with a shop and/or host
  // param. Don't strand them on the App Store install copy (that's meant for
  // brand-new visitors with no store context). Route them through /auth so
  // authenticate.admin can re-establish the session and bounce them back into
  // the embedded app.
  if (url.searchParams.get("shop") || url.searchParams.get("host")) {
    throw redirect(`/auth?${url.searchParams.toString()}`);
  }

  const errors = loginErrorMessage(await login(request));

  return { errors, appName: APP_NAME };
};

/**
 * Action for `/auth/login` — handles the login form submission.
 * @returns {{errors: object}} Same shape as {@link loginLoader}.
 */
export const loginAction = async ({ request }) => {
  const errors = loginErrorMessage(await login(request));

  return { errors };
};

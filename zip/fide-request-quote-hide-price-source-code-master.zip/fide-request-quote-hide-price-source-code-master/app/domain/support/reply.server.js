/**
 * Reply endpoint — requires Shopify admin auth.
 * Called from the admin dashboard to send a reply email to the buyer.
 *
 * POST /api/reply
 * Body: { quoteId, replyText }
 * Auth: Shopify admin session (embedded app)
 */

import { authenticate } from "../../core/shopify/shopify.server";
import prisma from "../../db.server";
import { sendEmailForShop } from "../../lib/mailer.server";
import { merchantReplyEmail } from "../email/emailTemplates.server";

/** Loader always rejects — this endpoint is action-only (POST). */
export const loader = async () => {
  return Response.json({ error: "Method not allowed" }, { status: 405 });
};

/**
 * Action for `/api/reply` — sends the merchant's reply to the buyer's email
 * and records it on the quote.
 *
 * @param {Request} request - JSON body `{ quoteId, replyText }`.
 * @returns {Response} `{ success: true, customerEmail }` on success, or a
 *   4xx `{ error }` body for invalid input / missing quote. Note: the email
 *   send is fire-and-forget (errors are only logged) so a mail provider
 *   outage does not block the quote status from being updated.
 */
export const action = async ({ request }) => {
  if (request.method !== "POST") {
    return Response.json({ error: "Method not allowed" }, { status: 405 });
  }

  // Shopify auth — session identifies the merchant's shop
  const { session } = await authenticate.admin(request);
  const { shop } = session;

  let body;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const { quoteId, replyText } = body;

  if (!quoteId || !replyText?.trim()) {
    return Response.json(
      { error: "quoteId and replyText are required" },
      { status: 400 },
    );
  }

  // Verify this quote belongs to the authenticated shop
  const [quote, emailConfig] = await Promise.all([
    prisma.quote.findFirst({ where: { id: quoteId, shop } }),
    prisma.emailConfig.findUnique({ where: { shop } }).catch(() => null),
  ]);
  if (!quote) {
    return Response.json({ error: "Quote not found" }, { status: 404 });
  }

  const storeName = shop;

  // Send reply email (non-blocking, catch errors)
  const { subject, html } = merchantReplyEmail(quote, replyText.trim(), storeName);
  sendEmailForShop(emailConfig, { to: quote.customerEmail, subject, html }).catch((err) =>
    console.error("[Email] Reply send failed:", err.message),
  );

  // Update quote in DB
  await prisma.quote.update({
    where: { id: quoteId },
    data: { merchantReply: replyText.trim(), status: "replied" },
  });

  return Response.json({ success: true, customerEmail: quote.customerEmail });
};

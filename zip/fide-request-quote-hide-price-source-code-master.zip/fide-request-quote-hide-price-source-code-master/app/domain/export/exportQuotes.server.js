/**
 * Quote export endpoints for the admin dashboard: a full CSV download and a
 * "matching set" lookup used by the export dialog to preview/select rows
 * before exporting. Backs app/routes/api.export.jsx (csvExportLoader) and
 * app/routes/app.export-quotes.jsx (matchingQuotesLoader).
 */
import { authenticate } from "../../core/shopify/shopify.server";
import prisma from "../../db.server";
import { buildCsv } from "../../utils/csv";
import { tabWhere } from "../quotes/quoteFilters.server";

/**
 * Loader for `/api/export` — streams the full matching quote set as a CSV
 * attachment (not paginated; the export dialog is expected to have already
 * narrowed the set via `matchingQuotesLoader`).
 *
 * @param {Request} request - Reads `status`, `from`, and `to` query params;
 *   `from`/`to` are inclusive date bounds on `createdAt`.
 * @returns {Response} `text/csv` attachment named `quotes-<date>.csv`, with
 *   `Cache-Control: no-store` since exports must always be fresh.
 */
export const csvExportLoader = async ({ request }) => {
  const { session } = await authenticate.admin(request);
  const { shop } = session;

  const url = new URL(request.url);
  const status = url.searchParams.get("status");
  const from   = url.searchParams.get("from");
  const to     = url.searchParams.get("to");

  const where = { shop };
  if (status) where.status = status;
  if (from || to) {
    where.createdAt = {};
    if (from) where.createdAt.gte = new Date(from);
    if (to)   where.createdAt.lte = new Date(to);
  }

  const quotes = await prisma.quote.findMany({
    where,
    orderBy: { createdAt: "desc" },
    select: {
      id: true, status: true, customerName: true, customerEmail: true,
      customerPhone: true, companyName: true, productTitle: true,
      quantity: true, message: true,
      quotedPrice: true, quotedCurrency: true,
      createdAt: true, updatedAt: true,
    },
  });

  const headers = [
    "ID","Status","Customer Name","Email","Phone","Company",
    "Product","Quantity","Message","Quoted Price","Currency",
    "Created","Updated",
  ];

  const rows = quotes.map(q => [
    q.id, q.status,
    q.customerName, q.customerEmail, q.customerPhone || "",
    q.companyName || "", q.productTitle,
    q.quantity || "", q.message || "",
    q.quotedPrice != null ? q.quotedPrice : "",
    q.quotedCurrency || "",
    q.createdAt.toISOString(), q.updatedAt.toISOString(),
  ]);

  const csv = buildCsv(headers, rows);
  const filename = `quotes-${new Date().toISOString().slice(0, 10)}.csv`;

  return new Response(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${filename}"`,
      "Cache-Control": "no-store",
    },
  });
};

/**
 * Loader for `/app/export-quotes` — resolves the set of quotes the export
 * dialog will act on. Returns the FULL matching set (not paginated), since
 * the dialog needs to know exactly which rows will be exported/counted.
 *
 * @param {Request} request - Reads `ids` (comma-separated explicit selection
 *   — takes priority when present), or `tab` + `q` (search) to derive the
 *   filter via {@link tabWhere} otherwise.
 * @returns {{quotes: object[]}} Lightweight quote projections (no message/
 *   price fields) for list rendering.
 */
export const matchingQuotesLoader = async ({ request }) => {
  const { session } = await authenticate.admin(request);
  const { shop } = session;

  const url    = new URL(request.url);
  const tab    = url.searchParams.get("tab") || "all";
  const search = (url.searchParams.get("q") || "").trim();
  const ids    = (url.searchParams.get("ids") || "").split(",").filter(Boolean);

  const where = { shop };
  if (ids.length) {
    where.id = { in: ids };
  } else {
    Object.assign(where, tabWhere(tab));
    if (search) {
      where.OR = [
        { customerName:  { contains: search, mode: "insensitive" } },
        { customerEmail: { contains: search, mode: "insensitive" } },
        { productTitle:  { contains: search, mode: "insensitive" } },
        { companyName:   { contains: search, mode: "insensitive" } },
      ];
    }
  }

  const quotes = await prisma.quote.findMany({
    where,
    orderBy: { createdAt: "desc" },
    select: {
      id: true, quoteNumber: true, status: true,
      customerName: true, customerEmail: true, customerPhone: true, companyName: true,
      productTitle: true, quantity: true, createdAt: true,
    },
  });

  return { quotes };
};

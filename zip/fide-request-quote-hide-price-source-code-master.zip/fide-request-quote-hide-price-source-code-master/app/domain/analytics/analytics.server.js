/**
 * Aggregate quote-request stats for the admin analytics dashboard. Backs
 * app/routes/api.analytics.jsx. Read-only — all figures are derived from the
 * `Quote` table, scoped to the authenticated shop.
 */
import { authenticate } from "../../core/shopify/shopify.server";
import prisma from "../../db.server";

/**
 * Loader for `/api/analytics` — no query params; everything is scoped to the
 * requesting shop's session.
 *
 * @returns {Response} JSON body with:
 *   - total: all-time quote count
 *   - thisMonth: quotes created in the last 30 days
 *   - newCount / replied: counts by status
 *   - responseRate: replied/total as a rounded percentage
 *   - statusBreakdown: counts keyed by status
 *   - topProducts: top 10 products by quote count
 *   - dailyTrend: one entry per day for the last 30 days (zero-filled), so
 *     the chart always has a continuous x-axis even on days with no quotes
 * Response is cached for 60s (`Cache-Control: private, max-age=60`) since
 * this is a moderately expensive multi-query aggregation.
 */
export const loader = async ({ request }) => {
  const { session } = await authenticate.admin(request);
  const { shop } = session;

  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

  const [total, statuses, products, recent] = await Promise.all([
    prisma.quote.count({ where: { shop } }),
    prisma.quote.groupBy({ by: ["status"], where: { shop }, _count: { id: true } }),
    prisma.quote.groupBy({
      by: ["productTitle"],
      where: { shop },
      _count: { id: true },
      orderBy: { _count: { id: "desc" } },
      take: 10,
    }),
    prisma.quote.findMany({
      where: { shop, createdAt: { gte: thirtyDaysAgo } },
      select: { createdAt: true },
      orderBy: { createdAt: "asc" },
    }),
  ]);

  const dailyMap = {};
  for (let i = 29; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    dailyMap[d.toISOString().slice(0, 10)] = 0;
  }
  for (const q of recent) {
    const key = new Date(q.createdAt).toISOString().slice(0, 10);
    if (dailyMap[key] !== undefined) dailyMap[key]++;
  }

  const statusMap = Object.fromEntries(statuses.map(s => [s.status, s._count.id]));

  return Response.json({
    total,
    thisMonth: recent.length,
    newCount: statusMap["new"] || 0,
    replied: statusMap["replied"] || 0,
    responseRate: total > 0 ? Math.round(((statusMap["replied"] || 0) / total) * 100) : 0,
    statusBreakdown: statusMap,
    topProducts: products.map(p => ({ title: p.productTitle, count: p._count.id })),
    dailyTrend: Object.entries(dailyMap).map(([date, count]) => ({ date, count })),
  }, {
    headers: { "Cache-Control": "private, max-age=60" },
  });
};

/**
 * Editor backend for a single merchant-facing email template (notification,
 * auto-response, accept-quote, reject-quote). Backs app.email-edit.$id.jsx —
 * `params.id` is the templateType and selects which row is loaded/saved.
 *
 * The action doubles as a live "send test email" endpoint (intent=testEmail),
 * so it goes out over the shop's real SMTP/Gmail config — treat it as a side
 * effect, not a pure save, when reasoning about this file.
 */
import { authenticate } from "../../core/shopify/shopify.server";
import prisma from "../../db.server";
import { sendEmailForShop } from "../../lib/mailer.server";
import { isValidEmail as validateEmail } from "../../utils/validation";
import { EMAIL_EDITOR_LINK_COLOR, EMAIL_HEADER_COLOR, EMAIL_CTA_COLOR, EMAIL_ACCEPT_COLOR, EMAIL_REJECT_COLOR } from "../../core/email/theme.server";
import { EMAIL_LOGO_URL, EMAIL_SIGNATURE } from "../../core/branding.server";
import { readEmailText } from "../../core/email/text-labels.server";

// Maps a templateType (route param) to the EmailConfig boolean column that
// enables/disables sending that template. Templates with no entry here
// (e.g. any future type) are treated as always-off via isEnabled below.
const TOGGLE_FIELD = {
  "notification":  "notificationEnabled",
  "auto-response": "autoResponseEnabled",
  "accept-quote":  "acceptQuoteEnabled",
  "reject-quote":  "rejectQuoteEnabled",
};

// Header background color actually used when this templateType is sent — see
// renderCustomTemplate() in emailTemplates.server.js and its call sites in
// quotes.server.js/quotesList.server.js. Must stay in sync with those, or the
// editor's preview will show a color the real email doesn't use.
const HEADER_COLOR_FIELD = {
  "notification":  EMAIL_HEADER_COLOR,
  "auto-response": EMAIL_HEADER_COLOR,
  "accept-quote":  EMAIL_ACCEPT_COLOR,
  "reject-quote":  EMAIL_REJECT_COLOR,
};

// Fallback used only when EmailConfig has no row yet for the shop (i.e. the
// merchant hasn't touched email settings) — every known template defaults on.
const TOGGLE_DEFAULT = {
  "notification":  true,
  "auto-response": true,
  "accept-quote":  true,
  "reject-quote":  true,
};

/**
 * Loads the saved template (subject/body), its current enabled state, and
 * the exact colors/branding the real send will use — so the editor's live
 * preview never shows something the actual email won't.
 * @param {object} params - route params; `params.id` is the templateType.
 * @returns {Promise<{saved: object|null, isEnabled: boolean, headerColor: string, ctaColor: string, logoUrl: string, signature: string}>}
 *   `saved` is the EmailTemplate row (or null if never saved); `isEnabled`
 *   reflects the matching EmailConfig toggle column, falling back to
 *   TOGGLE_DEFAULT; `headerColor` is this templateType's actual send-time
 *   header color (accept/reject get their own distinct color, everything
 *   else gets the generic one).
 */
export const loader = async ({ request, params }) => {
  const { session } = await authenticate.admin(request);
  const { shop } = session;
  const templateType = params.id;

  const [saved, emailConfig] = await Promise.all([
    prisma.emailTemplate.findUnique({
      where: { shop_templateType: { shop, templateType } },
    }).catch(() => null),
    prisma.emailConfig.findUnique({ where: { shop } }).catch(() => null),
  ]);

  const enabledField = TOGGLE_FIELD[templateType];
  const isEnabled = enabledField
    ? (emailConfig?.[enabledField] ?? TOGGLE_DEFAULT[templateType] ?? false)
    : false;

  return {
    saved,
    isEnabled,
    linkColor: EMAIL_EDITOR_LINK_COLOR,
    headerColor: HEADER_COLOR_FIELD[templateType] ?? EMAIL_HEADER_COLOR,
    ctaColor: EMAIL_CTA_COLOR,
    logoUrl: EMAIL_LOGO_URL,
    signature: EMAIL_SIGNATURE,
    labels: readEmailText(),
  };
};

/**
 * Handles two form intents from the email-template editor UI:
 *  - `testEmail`: builds a throwaway preview email from the submitted fields
 *    and sends it immediately via the shop's mail config (no DB write).
 *  - (default/no intent): persists the template (subject + JSON-encoded body)
 *    and, if the templateType has a toggle, its enabled/disabled status.
 * @param {object} params - route params; `params.id` is the templateType.
 * @returns {Promise<object>} `{ success, error?, intent? }`; the intent field
 *   lets the route disambiguate which fetcher/form the response belongs to.
 */
export const action = async ({ request, params }) => {
  const { session } = await authenticate.admin(request);
  const { shop } = session;
  const templateType = params.id;
  const formData = await request.formData();
  const intent = formData.get("intent");

  if (intent === "testEmail") {
    const labels = readEmailText();
    const emailConfig = await prisma.emailConfig.findUnique({ where: { shop } }).catch(() => null);
    const toEmail = (formData.get("toEmail") || "").trim();
    const isValidEmail = validateEmail(toEmail);
    if (!isValidEmail) {
      return { success: false, error: labels.errors.invalidTestEmail, intent: "testEmail" };
    }
    if (!emailConfig?.smtpEnabled && !process.env.GMAIL_USER) {
      return { success: false, error: labels.errors.noMailServer, intent: "testEmail" };
    }
    const subject = String(formData.get("subject") || labels.testEmailHtml.editorFallbackSubject);
    const heading = String(formData.get("heading") || labels.testEmailHtml.editorFallbackHeading);
    const body    = String(formData.get("content") || labels.testEmailHtml.editorFallbackBody);
    const cta     = String(formData.get("action")  || "");
    const html = `
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
        <div style="background:#f6f6f7;padding:16px 40px;border-bottom:1px solid #e1e3e5;text-align:center">
          <strong style="font-size:14px;color:#6d7175">${labels.testEmailHtml.editorPreviewLabel}</strong>
        </div>
        <div style="padding:32px 40px 24px;text-align:center">
          <h2 style="font-size:22px;font-weight:700;margin:0 0 12px;color:#202223">${heading}</h2>
          <p style="font-size:14px;color:#6d7175;line-height:1.6;margin:0 0 24px">${body}</p>
          ${cta ? `<a href="#" style="display:inline-block;background:#202223;color:#fff;padding:10px 24px;border-radius:6px;font-size:14px;font-weight:600;text-decoration:none">${cta}</a>` : ""}
        </div>
      </div>`;
    try {
      await sendEmailForShop(emailConfig, { to: toEmail, subject: labels.testEmailHtml.editorSubjectPrefixTemplate.replace("{subject}", subject), html });
      return { success: true, intent: "testEmail" };
    } catch (err) {
      return { success: false, error: labels.errors.sendFailedTemplate.replace("{message}", err.message), intent: "testEmail" };
    }
  }

  const subject     = String(formData.get("subject")     || "");
  const heading     = String(formData.get("heading")     || "");
  const content     = String(formData.get("content")     || "");
  const action      = String(formData.get("action")      || "");
  const redirectUrl = String(formData.get("redirectUrl") || "");
  const status      = String(formData.get("status")      || "enabled");
  const isEnabled   = status === "enabled";

  // Despite the column name, `htmlBody` stores structured JSON (not rendered
  // HTML) — the actual HTML is assembled later by emailTemplates.server.js
  // when the template is actually sent.
  const htmlBody = JSON.stringify({ heading, content, action, redirectUrl, status });

  const enabledField = TOGGLE_FIELD[templateType];
  await Promise.all([
    prisma.emailTemplate.upsert({
      where:  { shop_templateType: { shop, templateType } },
      create: { shop, templateType, subject, htmlBody },
      update: { subject, htmlBody },
    }),
    enabledField
      ? prisma.emailConfig.upsert({
          where:  { shop },
          create: { shop, [enabledField]: isEnabled },
          update: { [enabledField]: isEnabled },
        })
      : Promise.resolve(),
  ]);

  return { success: true };
};

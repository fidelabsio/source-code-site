/**
 * Email template functions.
 * Each function returns { subject, html } ready to pass to sendEmailForShop().
 *
 * Consumed by quotes.server.js (merchant notification + buyer confirmation on
 * submit), quotesList.server.js (accept/reject quote actions), reply.server.js
 * (merchant reply), pdf.server.jsx (parseCartItems, for the PDF line-item
 * table), and customersDataRequest.server.js (GDPR data-access webhook).
 *
 * All user-supplied values (customer name, message, form-field values, etc.)
 * MUST be passed through `esc()` before being interpolated into the returned
 * HTML — this is the app's main HTML-injection boundary for quote data, since
 * quote records originate from unauthenticated storefront submissions.
 */

import { escapeHtml as esc } from "../../utils/html.js";
import { APP_NAME, EMAIL_LOGO_URL, EMAIL_SIGNATURE } from "../../core/branding.server.js";
import { EMAIL_HEADER_COLOR, EMAIL_CTA_COLOR, EMAIL_ACCEPT_COLOR, EMAIL_REJECT_COLOR } from "../../core/email/theme.server.js";

// ─── Shared styles ───────────────────────────────────────────────────────────
// Header/CTA colors read from app/config/email-theme.json — the file a buyer
// edits to restyle these; everything else here is neutral page chrome, not a
// brand color, so it stays a fixed constant.

const CARD = `font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif;max-width:600px;margin:0 auto;background:#f4f4f4;`;
const HEADER = `background:${EMAIL_HEADER_COLOR};padding:28px 32px;border-radius:8px 8px 0 0;`;
const BODY = `background:#fff;padding:32px;border:1px solid #e5e5e5;border-top:none;border-radius:0 0 8px 8px;`;
const FOOTER_MUTED = `margin:14px 0 0;font-size:12px;color:#aaa;text-align:center;line-height:1.6;`;
const DIVIDER = `<hr style="border:none;border-top:1px solid #e8e8e8;margin:24px 0;">`;
const SECTION_LABEL = `margin:0 0 10px;font-size:13px;font-weight:600;color:#1a1a18;`;
const META_LINE = `margin:12px 0 0;font-size:12px;color:#9a9a9a;`;

/** One label/value `<tr>` for the two-column detail tables used throughout. */
function row(label, value) {
  return `
    <tr>
      <td style="padding:10px 14px;font-size:11px;font-weight:600;color:#8a8a8a;text-transform:uppercase;letter-spacing:0.04em;width:132px;vertical-align:top;border-bottom:1px solid #eee;">${label}</td>
      <td style="padding:10px 14px;font-size:14px;color:#1a1a18;border-bottom:1px solid #eee;vertical-align:top;line-height:1.5;">${value}</td>
    </tr>`;
}

/** Wraps an array of `row()` HTML strings in the shared bordered table shell. */
function infoTable(rows) {
  return `<table role="presentation" width="100%" style="width:100%;border-collapse:collapse;background:#fafafa;border:1px solid #e8e8e8;border-radius:6px;overflow:hidden;">${rows.join("")}</table>`;
}

// ─── Customer-detail helpers ─────────────────────────────────────────────────

/** Normalise a field label for duplicate detection (lowercase, alnum only). */
function normLabel(s) {
  return String(s || "").toLowerCase().replace(/[^a-z0-9]/g, "");
}

/** True when a value carries real content (not null/empty/empty-array). */
function hasValue(v) {
  if (v == null) return false;
  return Array.isArray(v) ? v.length > 0 : String(v).trim() !== "";
}

/** Read the custom Form Builder fields a buyer submitted ([] when none). */
function parseFormFields(quote) {
  try {
    const fd = JSON.parse(quote?.formData || "null");
    const fields =
      !Array.isArray(fd) && fd?.__v === 2
        ? fd.formFields || []
        : Array.isArray(fd)
          ? fd
          : [];
    return Array.isArray(fields) ? fields.filter((f) => f && (f.label || f.key)) : [];
  } catch {
    return [];
  }
}

/** Render one field's value: file links for arrays, mailto for emails, else text. */
function renderFieldValue(label, value) {
  const IMAGE_EXT = /\.(jpe?g|png|gif|webp|bmp|svg)(\?.*)?$/i;
  if (Array.isArray(value)) {
    return value
      .map((url) => {
        const name = String(url).split("/").pop().split("?")[0] || "file";
        const icon = IMAGE_EXT.test(url) ? "" : "📎 ";
        return `<a href="${esc(url)}" style="color:#458fff;text-decoration:none;">${icon}${esc(name)}</a>`;
      })
      .join(", ");
  }
  const str = String(value);
  if (normLabel(label).includes("email") && /\S+@\S+\.\S+/.test(str)) {
    return `<a href="mailto:${esc(str)}" style="color:#458fff;text-decoration:none;">${esc(str)}</a>`;
  }
  return esc(str);
}

/**
 * Build the de-duplicated "Customer details" rows for the merchant email.
 *
 * When the buyer filled a custom form, those fields ARE the submission (they
 * already include name parts, email, phone and address) — so we render them
 * and skip the scalar columns that merely mirror them. This is what removes the
 * old duplicate block (Name + First/Last name, Email + Email address, …).
 * Falls back to the scalar columns for the default form. Empty values are
 * dropped so the table stays minimal.
 */
function buildCustomerRows(quote) {
  const fields = parseFormFields(quote);
  const rows = [];
  const seen = new Set();

  const add = (label, valueHtml) => {
    const key = normLabel(label);
    if (!key || seen.has(key)) return;
    seen.add(key);
    rows.push(row(esc(label), valueHtml));
  };

  if (fields.length > 0) {
    for (const f of fields) {
      const label = f.label || f.key;
      if (!hasValue(f.value)) continue;
      add(label, renderFieldValue(label, f.value));
    }
    // Append scalar extras only when the form didn't already capture them.
    if (hasValue(quote.companyName) && !seen.has("company")) {
      add("Company", esc(quote.companyName));
    }
    if (hasValue(quote.message) && !seen.has("message") && !seen.has("note")) {
      add("Message", `<em>${esc(quote.message)}</em>`);
    }
  } else {
    if (hasValue(quote.customerName)) add("Name", esc(quote.customerName));
    if (hasValue(quote.customerEmail)) add("Email", renderFieldValue("Email", quote.customerEmail));
    if (hasValue(quote.customerPhone)) add("Phone", esc(quote.customerPhone));
    if (hasValue(quote.companyName)) add("Company", esc(quote.companyName));
    if (hasValue(quote.message)) add("Message", `<em>${esc(quote.message)}</em>`);
  }

  return rows;
}

/** Renders a timestamp as "17 Jul 2026, 14:30" (en-GB, fixed across locales so emails look consistent regardless of recipient). */
function formatDate(date) {
  return new Date(date).toLocaleString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

/**
 * Formats a price using Intl.NumberFormat for the given currency, with a
 * plain-string fallback (`"USD 12.00"`) if the currency code is invalid/
 * unsupported by the runtime's Intl data. Returns "—" for null/empty/NaN.
 */
function formatMoney(value, currency) {
  if (value == null || value === "") return "—";
  const num = typeof value === "number" ? value : parseFloat(value);
  if (Number.isNaN(num)) return "—";
  try {
    return new Intl.NumberFormat("en", {
      style: "currency",
      currency: currency || "USD",
    }).format(num);
  } catch {
    return `${currency || ""} ${num.toFixed(2)}`.trim();
  }
}

// ─── Product list helpers ──────────────────────────────────────────────────────

/**
 * Read all submitted products from a quote.
 * Submissions persist them in formData as { __v: 2, cartItems: [...] }.
 * Falls back to a single synthetic item built from the scalar columns so
 * legacy records (and parse failures) still render at least one row.
 * @param {object} quote - Prisma Quote record
 * @returns {Array<object>} cart items (always length >= 1)
 */
export function parseCartItems(quote) {
  try {
    const fd = JSON.parse(quote?.formData || "null");
    const items =
      !Array.isArray(fd) && fd?.__v === 2
        ? fd.cartItems
        : Array.isArray(fd)
          ? fd
          : null;
    if (Array.isArray(items) && items.length > 0) return items;
  } catch {
    /* fall through to single-product fallback */
  }
  return [
    {
      productTitle: quote?.productTitle || "Product",
      quantity: quote?.quantity ?? "",
      offerPrice: quote?.quotedPrice ?? null,
    },
  ];
}

/**
 * Compute a line total (quantity × unit offer price).
 * Returns null when either value is missing/non-numeric.
 * @param {object} it - cart item
 * @returns {number|null}
 */
function lineTotal(it) {
  const qty = parseFloat(it?.quantity);
  const price = typeof it?.offerPrice === "number" ? it.offerPrice : parseFloat(it?.offerPrice);
  if (!Number.isFinite(qty) || !Number.isFinite(price)) return null;
  return qty * price;
}

/**
 * Render all submitted products as a responsive HTML table.
 * Columns: Product (title + variant), Qty, Offer (unit price), Total (qty × offer).
 * A grand-total row sums every line total.
 * @param {Array<object>} cartItems
 * @param {string} currency - ISO currency code for the offer price
 */
export function renderProductTable(cartItems, currency) {
  const items = Array.isArray(cartItems) ? cartItems : [];
  let grandTotal = null;

  const rows = items
    .map((it) => {
      const title = esc(it.productTitle || "Product");
      const variant =
        it.variantTitle && it.variantTitle !== "Default Title"
          ? `<div style="font-size:12px;color:#888;margin-top:2px;">${esc(it.variantTitle)}</div>`
          : "";
      const qty = esc(String(it.quantity ?? ""));
      const offer = formatMoney(it.offerPrice, currency);
      const total = lineTotal(it);
      if (total != null) grandTotal = (grandTotal ?? 0) + total;
      const totalCell = formatMoney(total, currency);
      return `
      <tr>
        <td class="qr-cell" style="padding:10px 12px;font-size:14px;color:#1a1a18;border-bottom:1px solid #f0f0f0;vertical-align:top;">
          ${title}${variant}
        </td>
        <td class="qr-cell" style="padding:10px 12px;font-size:14px;color:#1a1a18;border-bottom:1px solid #f0f0f0;text-align:center;white-space:nowrap;vertical-align:top;">${qty}</td>
        <td class="qr-cell" style="padding:10px 12px;font-size:14px;color:#1a1a18;border-bottom:1px solid #f0f0f0;text-align:right;white-space:nowrap;vertical-align:top;">${offer}</td>
        <td class="qr-cell" style="padding:10px 12px;font-size:14px;color:#1a1a18;border-bottom:1px solid #f0f0f0;text-align:right;white-space:nowrap;vertical-align:top;font-weight:600;">${totalCell}</td>
      </tr>`;
    })
    .join("");

  const grandTotalRow =
    grandTotal != null
      ? `
      <tr>
        <td class="qr-cell" colspan="3" style="padding:12px;font-size:13px;font-weight:600;color:#6d7175;text-transform:uppercase;letter-spacing:0.04em;text-align:right;background:#f0f0f0;">Total</td>
        <td class="qr-cell" style="padding:12px;font-size:15px;font-weight:700;color:#1a1a18;text-align:right;white-space:nowrap;background:#f0f0f0;">${formatMoney(grandTotal, currency)}</td>
      </tr>`
      : "";

  return `
  <table class="qr-products" role="presentation" width="100%" style="width:100%;border-collapse:collapse;background:#fafafa;border:1px solid #e8e8e8;border-radius:6px;overflow:hidden;">
    <thead>
      <tr>
        <th align="left" class="qr-cell" style="padding:10px 12px;font-size:12px;font-weight:600;color:#6d7175;text-transform:uppercase;letter-spacing:0.04em;background:#f0f0f0;text-align:left;">Product</th>
        <th class="qr-cell" style="padding:10px 12px;font-size:12px;font-weight:600;color:#6d7175;text-transform:uppercase;letter-spacing:0.04em;background:#f0f0f0;text-align:center;">Qty</th>
        <th class="qr-cell" style="padding:10px 12px;font-size:12px;font-weight:600;color:#6d7175;text-transform:uppercase;letter-spacing:0.04em;background:#f0f0f0;text-align:right;">Offer</th>
        <th class="qr-cell" style="padding:10px 12px;font-size:12px;font-weight:600;color:#6d7175;text-transform:uppercase;letter-spacing:0.04em;background:#f0f0f0;text-align:right;">Total</th>
      </tr>
    </thead>
    <tbody>${rows}</tbody>
    <tfoot>${grandTotalRow}</tfoot>
  </table>`;
}

/**
 * Wrap email body in a responsive HTML document so it renders consistently
 * on mobile and desktop (viewport meta, fluid card, mobile media query).
 */
function emailShell({ headerStyle, title, body, footer }) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="x-apple-disable-message-reformatting">
<style>
  body { margin:0; padding:0; background:#f4f4f4; -webkit-text-size-adjust:100%; }
  .qr-card { width:100%; max-width:600px; margin:0 auto; }
  @media only screen and (max-width:480px) {
    .qr-body { padding:20px !important; }
    .qr-products .qr-cell { padding:8px 8px !important; font-size:13px !important; }
  }
</style>
</head>
<body style="margin:0;padding:0;background:#f4f4f4;">
  <div class="qr-card" style="${CARD}">
    <div style="${headerStyle}">
      ${EMAIL_LOGO_URL ? `<img src="${esc(EMAIL_LOGO_URL)}" alt="${esc(APP_NAME)}" style="display:block;max-height:28px;margin:0 0 12px;">` : ""}
      <h1 style="margin:0;color:#fff;font-size:20px;font-weight:600;">${title}</h1>
    </div>
    <div class="qr-body" style="${BODY}">
      ${body}
    </div>
    ${footer ? `<p style="${FOOTER_MUTED}">${footer}</p>` : ""}
    ${EMAIL_SIGNATURE ? `<p style="${FOOTER_MUTED}">${esc(EMAIL_SIGNATURE)}</p>` : ""}
  </div>
</body>
</html>`;
}

/** A styled call-to-action button (table-based for email client support). */
function ctaButton(href, label) {
  return `
  <table role="presentation" cellpadding="0" cellspacing="0" style="margin:4px 0 4px;">
    <tr><td style="border-radius:6px;background:${EMAIL_CTA_COLOR};">
      <a href="${href}" style="display:inline-block;padding:12px 22px;font-size:14px;font-weight:600;color:#fff;text-decoration:none;border-radius:6px;">${label}</a>
    </td></tr>
  </table>`;
}

// Logo/signature markup for the few templates below that build their own
// header/footer HTML instead of going through emailShell() (accept/reject/
// reply) — kept as tiny standalone snippets rather than folding these
// templates into emailShell, since their header background color and body
// layout already differ per template.
const logoHeaderHtml = () =>
  EMAIL_LOGO_URL
    ? `<img src="${esc(EMAIL_LOGO_URL)}" alt="${esc(APP_NAME)}" style="display:block;max-height:28px;margin:0 0 12px;">`
    : "";
const signatureFooterHtml = () =>
  EMAIL_SIGNATURE ? `<p style="${FOOTER_MUTED}">${esc(EMAIL_SIGNATURE)}</p>` : "";

/**
 * Renders a merchant-customized EmailTemplate row (saved via the Email
 * Template Editor at app.email-edit.$id.jsx) into {subject, html}. This is
 * what makes the editor's fields actually take effect for the
 * "notification"/"auto-response"/"accept-quote"/"reject-quote" template
 * types — previously those four send paths ignored any saved row entirely
 * and always used the hardcoded functions below, so editing a template in
 * the UI had no effect on what was actually sent.
 *
 * Returns null when there's no saved row yet (or it fails to parse), so the
 * caller can fall back to its built-in default template — this keeps
 * behavior byte-identical for any shop that hasn't customized a template.
 *
 * @param {{subject: string, htmlBody: string}|null|undefined} saved - EmailTemplate row
 * @param {Record<string,string>} replacements - "{token}" -> value, matching
 *   the variable list shown for that template type in the editor UI
 * @param {{storeName: string, recipientEmail: string, extraHtml?: string}} context
 *   `extraHtml` is optional extra markup appended after the CTA (e.g. a PDF
 *   download prompt on the buyer-confirmation email).
 * @param {string} [headerColor=EMAIL_HEADER_COLOR] - header background color.
 *   Callers for "accept-quote"/"reject-quote" MUST pass EMAIL_ACCEPT_COLOR/
 *   EMAIL_REJECT_COLOR here — without it, a customized accept/reject template
 *   silently renders with the generic header color instead of its distinct
 *   brand color (the built-in acceptQuoteEmail()/rejectQuoteEmail() fallback
 *   functions use the distinct color; only a *saved* customization was losing it).
 * @returns {{subject: string, html: string}|null}
 */
export function renderCustomTemplate(saved, replacements, { storeName, recipientEmail, extraHtml = "" }, headerColor = EMAIL_HEADER_COLOR) {
  if (!saved) return null;
  let body;
  try {
    body = JSON.parse(saved.htmlBody);
  } catch {
    return null;
  }

  const replace = (str) =>
    Object.entries(replacements).reduce(
      (s, [token, value]) => s.replaceAll(token, esc(String(value ?? ""))),
      String(str || ""),
    );

  const ctaUrl = (body.redirectUrl || "").trim() || `https://${storeName}`;

  return {
    subject: replace(saved.subject),
    html: emailShell({
      headerStyle: `background:${headerColor};padding:28px 32px;border-radius:8px 8px 0 0;`,
      title: replace(body.heading),
      body: `
    <p style="margin:0;font-size:15px;color:#444;line-height:1.6;white-space:pre-line;">${replace(body.content)}</p>
    ${body.action ? `<div style="margin-top:24px;">${ctaButton(ctaUrl, replace(body.action))}</div>` : ""}
    ${extraHtml}`,
      footer: `Sent to ${esc(recipientEmail)} via <strong>${esc(storeName)}</strong>`,
    }),
  };
}

// ─── Merchant notification ───────────────────────────────────────────────────

/**
 * Sent to the merchant when a new quote is submitted.
 * @param {object} quote  - Prisma Quote record
 * @param {string} storeName - shop domain
 */
export function merchantNotificationEmail(quote, storeName) {
  const items = parseCartItems(quote);
  const customerRows = buildCustomerRows(quote);
  const productLabel = items.length > 1 ? `${items.length} products` : "1 product";

  return {
    subject: `New Quote Request — ${productLabel}`,
    html: emailShell({
      headerStyle: HEADER,
      title: "New Quote Request",
      body: `
    <p style="${SECTION_LABEL}">Requested products (${items.length})</p>
    ${renderProductTable(items, quote.quotedCurrency)}
    ${DIVIDER}
    <p style="${SECTION_LABEL}">Customer details</p>
    ${infoTable(customerRows)}
    <p style="${META_LINE}">Submitted ${formatDate(quote.createdAt)} &middot; ${esc(storeName)}</p>
    ${DIVIDER}
    <p style="margin:0;font-size:14px;color:#555;line-height:1.6;">
      Log in to your ${APP_NAME} dashboard to reply to this customer.
    </p>`,
      footer: `You received this because a quote was submitted on <strong>${esc(storeName)}</strong>`,
    }),
  };
}

// ─── Buyer confirmation ──────────────────────────────────────────────────────

/**
 * Sent to the buyer immediately after they submit a quote.
 * @param {object} quote
 * @param {string} storeName
 * @param {string} thankYouMessage - from block / db settings
 * @param {string} [pdfUrl] - tokenized PDF download link; when present a
 *   "Download PDF" CTA is included (see pdfToken.server.js for signing).
 */
export function buyerConfirmationEmail(quote, storeName, thankYouMessage, pdfUrl) {
  const items = parseCartItems(quote);
  const productPhrase =
    items.length > 1
      ? `your quote request for <strong>${items.length} products</strong>`
      : `your quote request for <strong>${esc(items[0]?.productTitle || quote.productTitle)}</strong>`;

  return {
    subject: `We received your quote request — ${storeName}`,
    html: emailShell({
      headerStyle: HEADER,
      title: "Quote Request Received",
      body: `
    <p style="margin:0 0 6px;font-size:16px;color:#1a1a18;">Hi ${esc(quote.customerName)},</p>
    <p style="margin:0 0 20px;font-size:15px;color:#444;line-height:1.6;">
      Thank you for your interest. We have received ${productPhrase} and will get back to you shortly.
    </p>
    <p style="${SECTION_LABEL}">Your request summary</p>
    ${renderProductTable(items, quote.quotedCurrency)}
    <p style="${META_LINE}">Submitted ${formatDate(quote.createdAt)}</p>
    ${pdfUrl ? `${DIVIDER}<p style="margin:0 0 10px;font-size:14px;color:#444;">Download a copy of your request:</p>${ctaButton(pdfUrl, "⬇ Download PDF")}` : ""}
    ${DIVIDER}
    <p style="margin:0;font-size:15px;color:#444;line-height:1.6;">
      ${esc(thankYouMessage)}
    </p>`,
      footer: `This is an automated confirmation from <strong>${esc(storeName)}</strong>`,
    }),
  };
}

// ─── Merchant reply to buyer ─────────────────────────────────────────────────

/**
 * Sent to the buyer when the merchant replies from the dashboard.
 * @param {object} quote
 * @param {string} replyText
 * @param {string} storeName
 */
export function merchantReplyEmail(quote, replyText, storeName) {
  const originalRows = [
    row("Product", esc(quote.productTitle)),
    quote.quantity && row("Quantity", esc(quote.quantity)),
    quote.message && row("Message", `<em>${esc(quote.message)}</em>`),
  ].filter(Boolean);

  return {
    subject: `Re: Your quote request for ${quote.productTitle} — ${storeName}`,
    html: `
<div style="${CARD}">
  <div style="${HEADER}">
    ${logoHeaderHtml()}
    <h1 style="margin:0;color:#fff;font-size:20px;font-weight:600;">Reply from ${esc(storeName)}</h1>
  </div>
  <div style="${BODY}">
    <p style="margin:0 0 20px;font-size:16px;color:#1a1a18;">Hi ${esc(quote.customerName)},</p>

    <div style="background:#f8f8f8;border-left:4px solid #1a1a18;padding:16px 20px;border-radius:0 6px 6px 0;margin-bottom:24px;">
      <p style="margin:0 0 6px;font-size:12px;font-weight:600;color:#888;text-transform:uppercase;letter-spacing:0.05em;">
        Reply from ${esc(storeName)}
      </p>
      <p style="margin:0;font-size:15px;color:#1a1a18;line-height:1.7;white-space:pre-line;">${esc(replyText)}</p>
    </div>

    ${DIVIDER}

    <p style="margin:0 0 10px;font-size:13px;font-weight:600;color:#888;">Your original request</p>
    ${infoTable(originalRows)}
  </div>
  <p style="${FOOTER_MUTED}">
    Reply sent via ${APP_NAME} on <strong>${storeName}</strong>
  </p>
  ${signatureFooterHtml()}
</div>`,
  };
}

// ─── Accept quote ────────────────────────────────────────────────────────────

/**
 * Sent to the buyer when the merchant accepts their quote.
 * @param {object} quote - Prisma Quote record
 * @param {string} storeName - shop domain
 */
export function acceptQuoteEmail(quote, storeName) {
  const summaryRows = [
    row("Product",  esc(quote.productTitle)),
    quote.quotedPrice != null && row("Quoted Price", `<strong>${quote.quotedCurrency || ""} ${Number(quote.quotedPrice).toFixed(2)}</strong>`),
    quote.quantity  && row("Quantity",  esc(quote.quantity)),
  ].filter(Boolean);

  return {
    subject: `Your quote has been accepted — ${storeName}`,
    html: `
<div style="${CARD}">
  <div style="background:${EMAIL_ACCEPT_COLOR};padding:28px 32px;border-radius:8px 8px 0 0;">
    ${logoHeaderHtml()}
    <h1 style="margin:0;color:#fff;font-size:20px;font-weight:600;">Quote Accepted &#10003;</h1>
  </div>
  <div style="${BODY}">
    <p style="margin:0 0 6px;font-size:16px;color:#1a1a18;">Hi ${esc(quote.customerName)},</p>
    <p style="margin:0 0 20px;font-size:15px;color:#444;line-height:1.6;">
      Great news! We have reviewed your quote request for
      <strong>${esc(quote.productTitle)}</strong> and are happy to move forward.
    </p>
    <p style="margin:0 0 10px;font-size:14px;font-weight:600;color:#333;">Quote summary</p>
    ${infoTable(summaryRows)}
    ${DIVIDER}
    <p style="margin:0;font-size:14px;color:#555;line-height:1.6;">
      We will be in touch shortly with next steps. If you have any questions please reply to this email.
    </p>
  </div>
  <p style="${FOOTER_MUTED}">Sent via ${APP_NAME} on <strong>${storeName}</strong></p>
  ${signatureFooterHtml()}
</div>`,
  };
}

// ─── Reject quote ────────────────────────────────────────────────────────────

/**
 * Sent to the buyer when the merchant rejects their quote.
 * @param {object} quote - Prisma Quote record
 * @param {string} storeName - shop domain
 */
export function rejectQuoteEmail(quote, storeName) {
  const summaryRows = [
    row("Product",  esc(quote.productTitle)),
    quote.quantity  && row("Quantity",  esc(quote.quantity)),
    quote.message   && row("Your note", `<em>${esc(quote.message)}</em>`),
  ].filter(Boolean);

  return {
    subject: `Update on your quote request — ${storeName}`,
    html: `
<div style="${CARD}">
  <div style="background:${EMAIL_REJECT_COLOR};padding:28px 32px;border-radius:8px 8px 0 0;">
    ${logoHeaderHtml()}
    <h1 style="margin:0;color:#fff;font-size:20px;font-weight:600;">Quote Update</h1>
  </div>
  <div style="${BODY}">
    <p style="margin:0 0 6px;font-size:16px;color:#1a1a18;">Hi ${esc(quote.customerName)},</p>
    <p style="margin:0 0 20px;font-size:15px;color:#444;line-height:1.6;">
      Thank you for submitting a quote request for
      <strong>${esc(quote.productTitle)}</strong>. After reviewing your request,
      we are unfortunately unable to proceed with this quote at this time.
    </p>
    <p style="margin:0 0 10px;font-size:14px;font-weight:600;color:#333;">Your original request</p>
    ${infoTable(summaryRows)}
    ${DIVIDER}
    <p style="margin:0;font-size:14px;color:#555;line-height:1.6;">
      We appreciate your interest and hope to work with you in the future.
      Please feel free to browse our store or reach out if you have any questions.
    </p>
  </div>
  <p style="${FOOTER_MUTED}">Sent via ${APP_NAME} on <strong>${storeName}</strong></p>
  ${signatureFooterHtml()}
</div>`,
  };
}

// ─── GDPR: customer data-access request ──────────────────────────────────────

/**
 * Sent to the merchant when Shopify forwards a customers/data_request.
 * Shopify's payload provides no callback URL, so the app fulfils the access
 * request by emailing the merchant (the data controller) everything it stores
 * about the customer, so they can pass it on.
 * @param {Array<object>} quotes - the customer's Quote records
 * @param {string} customerEmail - the requesting customer's email
 * @param {string} storeName - shop domain
 */
export function customerDataAccessEmail(quotes, customerEmail, storeName) {
  const cards = quotes
    .map((q) =>
      infoTable([
        row("Quote #", esc(String(q.quoteNumber ?? q.id))),
        row("Product", esc(q.productTitle || "—")),
        row("Name", esc(q.customerName || "—")),
        row("Email", esc(q.customerEmail || "—")),
        row("Phone", esc(q.customerPhone || "—")),
        row("Company", esc(q.companyName || "—")),
        row("Quantity", esc(String(q.quantity ?? "—"))),
        row("Message", q.message ? `<em>${esc(q.message)}</em>` : "—"),
        row("Status", esc(q.status || "—")),
        row("Submitted", formatDate(q.createdAt)),
      ]),
    )
    .join('<div style="height:16px;"></div>');

  return {
    subject: `Customer data request — ${customerEmail}`,
    html: emailShell({
      headerStyle: HEADER,
      title: "Customer Data Request",
      body: `
    <p style="margin:0 0 16px;font-size:15px;color:#444;line-height:1.6;">
      A customer (<strong>${esc(customerEmail)}</strong>) has asked, via Shopify, for a
      copy of the personal data stored about them. As the store owner and data
      controller for <strong>${esc(storeName)}</strong>, please forward the records below
      to the customer. This is everything the ${APP_NAME} app holds for them.
    </p>
    <p style="${SECTION_LABEL}">Stored quote requests (${quotes.length})</p>
    ${cards}`,
      footer: `Forwarded for GDPR compliance from <strong>${esc(storeName)}</strong>`,
    }),
  };
}

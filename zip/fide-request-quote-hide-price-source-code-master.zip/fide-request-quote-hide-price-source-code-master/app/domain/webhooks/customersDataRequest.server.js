/**
 * GDPR — customers/data_request
 *
 * Shopify fires this when a customer asks a merchant for a copy of the data the
 * app stores about them. Shopify's payload contains the customer (id/email/phone)
 * but NO callback URL — there is no automated delivery channel. The merchant is
 * the data controller, so the app fulfils the request by emailing the merchant
 * everything it holds about the customer; they then pass it on.
 *
 * We store customer data only in Quote records (name, email, phone, company,
 * message, etc.). We key on email, so we look up by shop + email.
 *
 * Always returns 200 to acknowledge receipt, per Shopify's requirements.
 */

import { authenticate } from "../../core/shopify/shopify.server";
import db from "../../db.server";
import { sendEmailForShop } from "../../lib/mailer.server";
import { customerDataAccessEmail } from "../email/emailTemplates.server";

/**
 * Backs app/routes/webhooks.customers.data_request.jsx.
 * @returns {Response} Empty 200 response in all cases — including when no
 *   customer email is present, no quotes match, no merchant email is
 *   configured, or an internal error occurs — since Shopify only needs
 *   acknowledgement of receipt, not a success/failure signal.
 */
export const action = async ({ request }) => {
  const { shop, payload } = await authenticate.webhook(request);

  const customerEmail = payload?.customer?.email;

  if (customerEmail) {
    try {
      const [quotes, config, emailConfig] = await Promise.all([
        db.quote.findMany({
          where: { shop, customerEmail },
          select: {
            id: true,
            quoteNumber: true,
            productTitle: true,
            customerName: true,
            customerEmail: true,
            customerPhone: true,
            companyName: true,
            quantity: true,
            message: true,
            status: true,
            createdAt: true,
          },
          orderBy: { createdAt: "desc" },
        }),
        db.quoteConfig.findUnique({ where: { shop } }).catch(() => null),
        db.emailConfig.findUnique({ where: { shop } }).catch(() => null),
      ]);

      if (quotes.length === 0) {
        return new Response();
      }

      // Deliver the data to the merchant (the controller) so they can pass it
      // to the customer. Falls back to the configured sender address.
      const to = config?.notifyEmail || emailConfig?.fromEmail;

      if (to) {
        const { subject, html } = customerDataAccessEmail(quotes, customerEmail, shop);
        await sendEmailForShop(emailConfig, { to, subject, html });
      } else {
        // No merchant email configured — the data is still available in the app
        // dashboard, which satisfies "provide the data to the store owner".
        console.warn(
          `[Webhook] customers/data_request — no merchant email set for ${shop}; ` +
            `${quotes.length} record(s) for ${customerEmail} remain available in the dashboard`,
        );
      }
    } catch (err) {
      console.error("[Webhook] customers/data_request error:", err.message);
    }
  }

  return new Response();
};

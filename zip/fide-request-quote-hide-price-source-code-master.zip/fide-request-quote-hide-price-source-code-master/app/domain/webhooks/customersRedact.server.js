/**
 * GDPR — customers/redact
 *
 * Shopify fires this when a customer requests deletion of their personal data.
 * We must delete all records that contain the customer's PII.
 *
 * The payload contains the customer's email and (optionally) their Shopify
 * customer ID. We key our data on email, so we delete by email + shop.
 */

import { authenticate } from "../../core/shopify/shopify.server";
import db from "../../db.server";

/**
 * Backs app/routes/webhooks.customers.redact.jsx.
 *
 * Non-obvious scope note: only fields that can identify or contact the
 * customer are treated as PII here (name, email, phone, company, free-text
 * message/notes/replies, and the checkout link, which can embed customer
 * identifiers). Operational fields — status, quantity, productTitle,
 * quoteNumber, timestamps — are left intact so aggregate analytics
 * (see analytics.server.js) don't lose historical counts.
 *
 * @returns {Response} Empty 200 response even on internal error (logged
 *   only) — Shopify requires the endpoint to acknowledge receipt.
 */
export const action = async ({ request }) => {
  const { shop, payload } = await authenticate.webhook(request);

  const customerEmail = payload?.customer?.email;

  if (customerEmail) {
    try {
      // Anonymise quotes rather than hard-delete so analytics aren't skewed.
      // We replace PII fields with redacted placeholders and null out the rest.
      await db.quote.updateMany({
        where: { shop, customerEmail },
        data: {
          customerName:  "[redacted]",
          customerEmail: "[redacted]",
          customerPhone: null,
          companyName:   null,
          message:       null,
          merchantReply: null,
          replyHistory:  null,
          internalNotes: null,
          notesHistory:  null,
          formData:      null,
          checkoutLink:  null,
        },
      });
    } catch (err) {
      console.error("[Webhook] customers/redact error:", err.message);
    }
  }

  return new Response();
};

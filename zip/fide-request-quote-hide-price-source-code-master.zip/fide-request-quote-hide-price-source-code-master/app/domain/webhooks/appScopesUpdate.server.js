/**
 * app_scopes/update — not a GDPR webhook, but a mandatory Shopify app
 * webhook: fires whenever the merchant approves a changed set of API scopes
 * (e.g. after we add/remove a permission in our TOML). We persist the new
 * scope list on the stored session so future `authenticate.admin` calls know
 * what's actually granted. Backs app/routes/webhooks.app.scopes_update.jsx.
 */
import { authenticate } from "../../core/shopify/shopify.server";
import db from "../../db.server";

/**
 * @returns {Response} Empty 200 response (Shopify only checks the status
 *   code for webhook delivery acknowledgement).
 */
export const action = async ({ request }) => {
  const { payload, session } = await authenticate.webhook(request);

  const current = payload.current;

  // `session` can be absent if the shop's session was already cleared
  // (e.g. mid-uninstall race) — nothing to update in that case.
  if (session) {
    await db.session.update({
      where: {
        id: session.id,
      },
      data: {
        scope: current.toString(),
      },
    });
  }

  return new Response();
};

/**
 * app/uninstalled
 *
 * Fires immediately when a merchant removes the app. We deliberately DO NOT
 * delete the merchant's business data here — we only clear the session (the
 * access token is already revoked by Shopify).
 *
 * Keeping the data gives merchants a ~48-hour grace period: if they reinstall
 * within two days, their quotes, settings and configuration are still intact.
 * Permanent deletion happens automatically ~48 hours later via the shop/redact
 * webhook, which only deletes if the shop is still inactive (not reinstalled).
 */

import { authenticate } from "../../core/shopify/shopify.server";
import db from "../../db.server";

/**
 * Backs app/routes/webhooks.app.uninstalled.jsx.
 * @returns {Response} Empty 200 response regardless of cleanup outcome —
 *   session-deletion errors are swallowed (logged only) so Shopify doesn't
 *   retry-storm a webhook whose side effect isn't critical to acknowledge.
 */
export const action = async ({ request }) => {
  const { shop } = await authenticate.webhook(request);

  // Clear auth only. Deleting the session is also what lets shop/redact detect
  // a reinstall later: a fresh OAuth session means the merchant came back.
  try {
    await db.session.deleteMany({ where: { shop } });
  } catch (err) {
    console.error("[Webhook] app/uninstalled session cleanup error:", err.message);
  }

  return new Response();
};

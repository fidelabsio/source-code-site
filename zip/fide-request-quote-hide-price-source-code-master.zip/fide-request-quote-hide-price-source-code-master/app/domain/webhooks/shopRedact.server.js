/**
 * GDPR — shop/redact
 *
 * Shopify fires this ~48 hours after a merchant uninstalls the app. This is our
 * automatic deletion trigger: by this point the 2-day grace period is over, so
 * we permanently delete all of the shop's data.
 *
 * Reinstall guard: if the shop has an active session again, the merchant
 * reinstalled within the grace window — so we KEEP their data instead of wiping
 * an active store. (app/uninstalled clears sessions, so a session existing here
 * means a fresh OAuth, i.e. a reinstall.)
 *
 * This is a mandatory GDPR webhook for the Shopify App Store listing.
 */

import { authenticate } from "../../core/shopify/shopify.server";
import db from "../../db.server";

/**
 * Backs app/routes/webhooks.shop.redact.jsx.
 *
 * Deletes ALL shop-scoped data — not just customer PII — including quote
 * targeting/hide-price rules, email + form configuration, and settings.
 * Uses `Promise.allSettled` (not `Promise.all`) deliberately: one table's
 * delete failing must not abort the others, since a partial purge is safer
 * than silently leaving the bulk of the data behind.
 *
 * @returns {Response} Empty 200 response. Individual delete failures are
 *   logged per-step, not surfaced to Shopify (see allSettled note above).
 */
export const action = async ({ request }) => {
  const { shop } = await authenticate.webhook(request);

  // Reinstall guard — skip deletion if the shop is active again.
  const activeSession = await db.session.findFirst({ where: { shop } }).catch(() => null);
  if (activeSession) {
    return new Response();
  }

  // Shop is still inactive after 48h — permanently delete everything.
  const results = await Promise.allSettled([
    db.quote.deleteMany({ where: { shop } }),
    db.quoteTargetProduct.deleteMany({ where: { shop } }),
    db.quoteTargetCondition.deleteMany({ where: { shop } }),
    db.hidePriceProduct.deleteMany({ where: { shop } }),
    db.hidePriceCondition.deleteMany({ where: { shop } }),
    db.quoteConfig.deleteMany({ where: { shop } }),
    db.emailConfig.deleteMany({ where: { shop } }),
    db.emailTemplate.deleteMany({ where: { shop } }),
    db.formSchema.deleteMany({ where: { shop } }),
    db.settings.deleteMany({ where: { shop } }),
    db.session.deleteMany({ where: { shop } }),
  ]);

  results.forEach((r, i) => {
    if (r.status === "rejected") {
      console.error(`[Webhook] shop/redact cleanup error on step ${i}:`, r.reason?.message);
    }
  });

  return new Response();
};

/**
 * Quote PDF rendering — orchestrates branding lookup + PDF generation for a
 * single quote. Used by api.quote.$id.pdf.jsx (the public, token-protected
 * PDF download route).
 */
/* eslint-disable react/prop-types -- server-only PDF document, not a UI component */
import {
  Document,
  Page,
  View,
  Text,
  Image,
  StyleSheet,
  renderToBuffer,
} from "@react-pdf/renderer";
import prisma from "../../db.server";
import { parseCartItems } from "../email/emailTemplates.server";
import { APP_NAME } from "../../core/branding.server";
import { PDF_HEADER_ACCENT_COLOR, PDF_PAGE_BACKGROUND_COLOR } from "../../core/pdf/theme.server";

/** Formats a price for the given currency; falls back to "USD 12.00"-style plain text on an invalid/unsupported currency code, "—" for null/empty/NaN. */
function formatMoney(value, currency) {
  if (value == null || value === "") return "—";
  const num = typeof value === "number" ? value : parseFloat(value);
  if (Number.isNaN(num)) return "—";
  try {
    return new Intl.NumberFormat("en", { style: "currency", currency: currency || "USD" }).format(num);
  } catch {
    return `${currency || ""} ${num.toFixed(2)}`.trim();
  }
}

/** Renders a timestamp as "17 Jul 2026, 14:30" (en-GB, fixed regardless of viewer locale). */
function formatDate(date) {
  return new Date(date).toLocaleString("en-GB", {
    day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit",
  });
}

// @react-pdf/renderer requires a StyleSheet (not plain inline objects) and
// only understands a subset of CSS; it's regenerated per render since the
// merchant's brand primaryColor varies the header/company-name color.
const makeStyles = (primary) =>
  StyleSheet.create({
    page: { padding: 40, fontSize: 10, color: "#1a1a18", fontFamily: "Helvetica", backgroundColor: PDF_PAGE_BACKGROUND_COLOR() },
    header: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 18, borderBottomWidth: 2, borderBottomColor: primary, paddingBottom: 12 },
    logo: { width: 120, maxHeight: 50, objectFit: "contain" },
    company: { textAlign: "right", maxWidth: 240 },
    companyName: { fontSize: 14, fontFamily: "Helvetica-Bold", color: primary },
    muted: { color: "#6d7175" },
    title: { fontSize: 18, fontFamily: "Helvetica-Bold", marginBottom: 2 },
    section: { marginTop: 14 },
    sectionLabel: { fontSize: 11, fontFamily: "Helvetica-Bold", marginBottom: 6, color: "#333" },
    row: { flexDirection: "row", marginBottom: 3 },
    rowLabel: { width: 90, color: "#6d7175" },
    tHead: { flexDirection: "row", backgroundColor: "#f0f0f0", paddingVertical: 6, paddingHorizontal: 8 },
    tRow: { flexDirection: "row", paddingVertical: 6, paddingHorizontal: 8, borderBottomWidth: 1, borderBottomColor: "#eee" },
    cProduct: { flex: 1 },
    cQty: { width: 50, textAlign: "center" },
    cOffer: { width: 90, textAlign: "right" },
    th: { fontSize: 9, fontFamily: "Helvetica-Bold", color: "#6d7175", textTransform: "uppercase" },
    variant: { fontSize: 8, color: "#888", marginTop: 1 },
    note: { marginTop: 20, paddingTop: 10, borderTopWidth: 1, borderTopColor: "#eee", color: "#555" },
  });

/**
 * The A4 quote PDF document tree, built from React-PDF primitives (Document/
 * Page/View/Text/Image — NOT DOM elements; @react-pdf/renderer walks this
 * tree to produce a PDF buffer, it is never mounted in a browser).
 * @param {object} props
 * @param {object} props.quote - Prisma Quote record
 * @param {Array<object>} props.items - cart items from parseCartItems()
 * @param {object} props.brand - merchant's saved "pdf-quote" branding (logo,
 *   colors, company info, header/footer notes); see renderQuotePdfBuffer.
 */
function QuotePdf({ quote, items, brand }) {
  const primary = brand.primaryColor || PDF_HEADER_ACCENT_COLOR();
  const s = makeStyles(primary);
  const currency = quote.quotedCurrency;
  // Only render <Image> for absolute http(s) URLs — react-pdf's image loader
  // can't resolve relative/data paths reliably, and a bad src throws mid-render.
  const logoOk = typeof brand.companyLogo === "string" && /^https?:\/\//.test(brand.companyLogo);

  return (
    <Document>
      <Page size="A4" style={s.page}>
        <View style={s.header}>
          <View>
            {logoOk ? <Image src={brand.companyLogo} style={s.logo} /> : null}
            <Text style={s.title}>{brand.documentTitle || APP_NAME}</Text>
            {quote.quoteNumber != null ? <Text style={s.muted}>#{quote.quoteNumber}</Text> : null}
          </View>
          <View style={s.company}>
            {brand.companyName ? <Text style={s.companyName}>{brand.companyName}</Text> : null}
            {brand.companyAddress ? <Text style={s.muted}>{brand.companyAddress}</Text> : null}
            {brand.companyPhone ? <Text style={s.muted}>{brand.companyPhone}</Text> : null}
            {brand.companyEmail ? <Text style={s.muted}>{brand.companyEmail}</Text> : null}
          </View>
        </View>

        {brand.headerNote ? <Text style={{ marginBottom: 10, color: "#555" }}>{brand.headerNote}</Text> : null}

        <View style={s.section}>
          <Text style={s.sectionLabel}>Customer</Text>
          <View style={s.row}><Text style={s.rowLabel}>Name</Text><Text>{quote.customerName}</Text></View>
          <View style={s.row}><Text style={s.rowLabel}>Email</Text><Text>{quote.customerEmail}</Text></View>
          {quote.customerPhone ? <View style={s.row}><Text style={s.rowLabel}>Phone</Text><Text>{quote.customerPhone}</Text></View> : null}
          {quote.companyName ? <View style={s.row}><Text style={s.rowLabel}>Company</Text><Text>{quote.companyName}</Text></View> : null}
          <View style={s.row}><Text style={s.rowLabel}>Submitted</Text><Text>{formatDate(quote.createdAt)}</Text></View>
          <View style={s.row}><Text style={s.rowLabel}>Site</Text><Text>{quote.shop}</Text></View>
        </View>

        <View style={s.section}>
          <Text style={s.sectionLabel}>Requested products ({items.length})</Text>
          <View style={s.tHead}>
            <Text style={[s.cProduct, s.th]}>Product</Text>
            <Text style={[s.cQty, s.th]}>Qty</Text>
            <Text style={[s.cOffer, s.th]}>Offer</Text>
          </View>
          {items.map((it, i) => (
            <View key={i} style={s.tRow}>
              <View style={s.cProduct}>
                <Text>{it.productTitle || "Product"}</Text>
                {it.variantTitle && it.variantTitle !== "Default Title" ? <Text style={s.variant}>{it.variantTitle}</Text> : null}
              </View>
              <Text style={s.cQty}>{String(it.quantity ?? "")}</Text>
              <Text style={s.cOffer}>{formatMoney(it.offerPrice, currency)}</Text>
            </View>
          ))}
        </View>

        {quote.message ? (
          <View style={s.section}>
            <Text style={s.sectionLabel}>Message</Text>
            <Text style={{ color: "#444" }}>{quote.message}</Text>
          </View>
        ) : null}

        {brand.footerNote ? <Text style={s.note}>{brand.footerNote}</Text> : null}
      </Page>
    </Document>
  );
}

/**
 * Renders the PDF buffer for a quote, looking up the merchant's saved
 * "pdf-quote" branding template (falls back to a plain header on any
 * lookup/parse failure).
 * @param {object} quote - Prisma Quote record
 * @returns {Promise<{ buffer: Buffer, filename: string }>}
 */
export async function renderQuotePdfBuffer(quote) {
  let brand = {};
  try {
    const tpl = await prisma.emailTemplate.findUnique({
      where: { shop_templateType: { shop: quote.shop, templateType: "pdf-quote" } },
    });
    if (tpl) {
      const body = tpl.htmlBody ? JSON.parse(tpl.htmlBody) : {};
      brand = { documentTitle: tpl.subject || null, ...body };
    }
  } catch {
    /* plain PDF on any branding lookup/parse failure */
  }

  const items = parseCartItems(quote);
  const buffer = await renderToBuffer(<QuotePdf quote={quote} items={items} brand={brand} />);
  const filename = `quote-${quote.quoteNumber ?? quote.id}.pdf`;

  return { buffer, filename };
}

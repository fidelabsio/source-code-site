/**
 * Editor backend for the merchant's PDF branding template (logo, company
 * info, colors, header/footer notes). Backs app.pdf-edit.$id.jsx.
 *
 * Reuses the EmailTemplate table (shop_templateType) rather than a dedicated
 * table — the templateType is prefixed with "pdf-" (e.g. "pdf-quote") to
 * avoid colliding with email templateTypes stored under the same key. The
 * saved row is read back by pdf.server.jsx's renderQuotePdfBuffer() when a
 * quote PDF is actually generated.
 */
import { authenticate } from "../../core/shopify/shopify.server";
import prisma from "../../db.server";
import { readPdfText } from "../../core/pdf/text-labels.server";

/**
 * Loads the merchant's saved PDF branding config for `params.id` (e.g. "quote").
 * @returns {Promise<{saved: object|null, labels: object}>} `saved` is the
 *   EmailTemplate row (its `htmlBody` is a JSON string of branding fields),
 *   or null if unset; `labels` is the page's buyer-editable UI copy.
 */
export const loader = async ({ request, params }) => {
  const { session } = await authenticate.admin(request);
  const { shop } = session;
  const templateType = `pdf-${params.id}`;

  const saved = await prisma.emailTemplate.findUnique({
    where: { shop_templateType: { shop, templateType } },
  }).catch(() => null);

  return { saved, labels: readPdfText() };
};

/**
 * Persists the submitted PDF branding fields as a JSON blob in the
 * EmailTemplate row's `htmlBody` column (subject stores the document title).
 * @returns {Promise<{success: boolean}>}
 */
export const action = async ({ request, params }) => {
  const { session } = await authenticate.admin(request);
  const { shop } = session;
  const templateType = `pdf-${params.id}`;
  const formData = await request.formData();

  const documentTitle  = String(formData.get("documentTitle")  || "");
  const companyName    = String(formData.get("companyName")    || "");
  const companyLogo    = String(formData.get("companyLogo")    || "");
  const companyAddress = String(formData.get("companyAddress") || "");
  const companyPhone   = String(formData.get("companyPhone")   || "");
  const companyEmail   = String(formData.get("companyEmail")   || "");
  const headerNote     = String(formData.get("headerNote")     || "");
  const footerNote     = String(formData.get("footerNote")     || "");
  const primaryColor   = String(formData.get("primaryColor")   || "#2c6ecb");
  const status         = String(formData.get("status")         || "enabled");

  const htmlBody = JSON.stringify({ companyName, companyLogo, companyAddress, companyPhone, companyEmail, headerNote, footerNote, primaryColor, status });

  await prisma.emailTemplate.upsert({
    where:  { shop_templateType: { shop, templateType } },
    create: { shop, templateType, subject: documentTitle, htmlBody },
    update: { subject: documentTitle, htmlBody },
  });

  return { success: true };
};

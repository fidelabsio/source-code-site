/**
 * Signs and verifies the tokenized download link used by the public PDF
 * route (api.quote.$id.pdf.jsx). The link is emailed to buyers (see
 * buyerConfirmationEmail's pdfUrl) so it must be safe to hand to an
 * unauthenticated party while still restricting access to that one quote.
 *
 * Stateless per-quote download token: HMAC-SHA256 over the quote id with a
 * server secret — no DB column needed. Only someone holding the link for a
 * specific quote can fetch its PDF.
 *
 * Production has no fallback secret — if both ENCRYPTION_KEY and
 * SHOPIFY_API_SECRET are unset, token signing fails hard instead of using a
 * known dev secret that would make every download token forgeable.
 */
import crypto from "crypto";

/** Derives the HMAC signing secret, or throws in production if none is configured (see file header for why there's no dev-secret fallback there). */
function getSecret() {
  const secret = process.env.ENCRYPTION_KEY || process.env.SHOPIFY_API_SECRET;
  if (!secret) {
    if (process.env.NODE_ENV === "production") {
      throw new Error(
        "[SECURITY] Neither ENCRYPTION_KEY nor SHOPIFY_API_SECRET is set — cannot sign PDF download tokens.",
      );
    }
    return "dev-insecure-pdf-token-secret";
  }
  return secret;
}

/**
 * Signs a quote id, producing the token that authorizes downloading its PDF.
 * @param {string|number} quoteId
 * @returns {string} hex-encoded HMAC-SHA256 digest
 */
export function signQuoteToken(quoteId) {
  return crypto
    .createHmac("sha256", getSecret())
    .update(String(quoteId))
    .digest("hex");
}

/**
 * Absolute, tokenized download URL for a quote's PDF, or null if the app's
 * public base URL is not configured.
 * @param {string|number} quoteId
 * @returns {string|null}
 */
export function quotePdfUrl(quoteId) {
  const base = (process.env.SHOPIFY_APP_URL || "").replace(/\/$/, "");
  if (!base) return null;
  return `${base}/api/quote/${quoteId}/pdf?token=${signQuoteToken(quoteId)}`;
}

/**
 * Checks a caller-supplied token against the expected signature for a quote.
 * Uses `crypto.timingSafeEqual` (after a length check) rather than `===` so
 * this comparison doesn't leak timing information that could help an
 * attacker guess a valid token byte-by-byte.
 * @param {string|number} quoteId
 * @param {string} token - the `?token=` query param from the request
 * @returns {boolean}
 */
export function verifyQuoteToken(quoteId, token) {
  if (!token) return false;
  const expected = signQuoteToken(quoteId);
  const a = Buffer.from(expected);
  const b = Buffer.from(String(token));
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

/**
 * Zod schemas for server-side validation of quote edits. Used by
 * quoteDetail.server.js's action ("updateQuote" intent, both create and
 * update paths) to re-validate customer info, shipping address, and line
 * items before writing to the database — this is the authoritative check;
 * any client-side validation in the route component can be bypassed.
 */
import { z } from "zod";

export const shippingAddrSchema = z.object({
  street:   z.string().min(1, "Street is required"),
  city:     z.string().min(1, "City is required"),
  state:    z.string().min(1, "State is required"),
  postal:   z.string().min(1, "Postal code is required"),
  country:  z.string().min(1, "Country is required"),
  district: z.string().min(1, "District is required"),
});

export const quoteFormSchema = z.object({
  customerName:  z.string().min(1, "Customer name is required"),
  customerEmail: z.string().min(1, "Email is required").email("Enter a valid email"),
  customerPhone: z.string().min(1, "Phone is required"),
  shippingAddr:  shippingAddrSchema,
  lineItems: z
    .array(
      z.object({
        price: z.union([z.string(), z.number()]),
      }),
    )
    .min(1, "Add at least one product")
    .refine(
      (items) => items.every((i) => parseFloat(i.price) > 0),
      { message: "All products need a price greater than 0" },
    ),
});

/**
 * Flattens a Zod `safeParse` result into a flat `{ "field.path": message }`
 * map (first error message wins per path) — the shape the quote detail
 * route's form expects for displaying per-field errors.
 * @param {import("zod").SafeParseReturnType<any, any>} result
 * @returns {Object<string, string>} empty object if `result.success` is true.
 */
export function flattenZodErrors(result) {
  if (result.success) return {};
  const errors = {};
  for (const issue of result.error.issues) {
    const key = issue.path.join(".");
    if (!errors[key]) errors[key] = issue.message;
  }
  return errors;
}

// Map a tab key to a Prisma `where` fragment. Shared by the quote list loader
// (quotesList.server.js, backing app/routes/app.quotes.jsx) and the CSV/export-dialog
// loader — the tab keys must stay in sync with the TABS list in
// app/routes/app.quotes.jsx.
/**
 * Translates an inbox tab key into the Prisma `where` fragment that filters
 * quotes for that tab.
 * @param {string} key - "unread" | "read" | "cancelled" | "accepted" | "done" | "all" (or any other value, treated as "all").
 * @returns {object} Prisma `where` fragment to merge into the query (empty object for "all"/unrecognized).
 */
export function tabWhere(key) {
  switch (key) {
    case "unread":    return { status: "new" };
    case "read":      return { status: "read" };
    case "cancelled": return { quoteStatus: "rejected" };
    case "accepted":  return { quoteStatus: "accepted" };
    case "done":      return { quoteStatus: "paid" };
    default:          return {};
  }
}

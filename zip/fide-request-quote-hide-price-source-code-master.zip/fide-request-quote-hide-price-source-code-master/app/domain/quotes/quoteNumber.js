// Client-safe display formatter (no server-only imports) — used by
// app.quote.$id.jsx, app.quotes.jsx, and app._index.jsx to render a quote's
// human-facing number. The actual sequential number is assigned server-side
// by assignQuoteNumber() in quoteNumber.server.js.

/**
 * Format a quoteNumber integer to display string, e.g. 1 → "#QR-0001".
 * Falls back to the last 6 characters of the quote's id (uppercased) when
 * quoteNumber hasn't been assigned yet (e.g. brand-new/unsaved quotes).
 * @param {{quoteNumber?: number, id?: string}} q
 * @returns {string}
 */
export function formatQuoteNumber(q) {
  if (q?.quoteNumber) return `#QR-${String(q.quoteNumber).padStart(4, "0")}`;
  return `#${q?.id?.slice(-6).toUpperCase() ?? "------"}`;
}

/**
 * Merchant-facing quote settings page: loader auto-provisions and returns the
 * shop's quote config, targeted products, hide-price product list, and Form
 * Builder schema (creating sane defaults on first load); action saves those
 * settings and also handles the "send test quote" preview. Backs
 * app/routes/app.quote-settings.jsx, which re-exports this file's
 * `loader`/`action` directly.
 *
 * Side effects on every load: may create/update `quoteConfig` and
 * `formSchema` rows (first-run defaults, currency sync, required-field
 * backfill) and fires a best-effort deletion of the legacy /pages/quote page.
 * All of these are guarded to be idempotent/safe to repeat.
 */
import { authenticate } from "../../core/shopify/shopify.server";
import prisma from "../../db.server";
import { removeQuotePage, createQuoteForShop } from "./quotes.server";
import { applyRequiredDefaults } from "./formSchemaDefaults.server";
import { defaultQuoteConfigData } from "../shop/defaultQuoteConfig.server";
import { QUOTE_SETTINGS_ERROR_COLOR, QUOTE_SETTINGS_ACCENT_COLOR, QUOTE_SETTINGS_SUCCESS_COLOR } from "../../core/quote-settings/theme.server";

/**
 * Loader for /app/quote-settings.
 *
 * Auto-initializes `quoteConfig` (with the shop's live currency) and
 * `formSchema` (a default contact/shipping/extra-info field set) on first
 * visit if either doesn't exist yet, and backfills legacy all-optional
 * schemas to the current required-by-default set (see
 * formSchemaDefaults.server.js). Also fire-and-forgets removal of the
 * deprecated /pages/quote storefront page.
 *
 * @returns {Promise<object>} `{ config, targetProducts, hidePriceProductsDb,
 *   formSchemaRow, shopCurrency, shop }` — flows directly into
 *   `useLoaderData()` in app.quote-settings.jsx.
 */
export const loader = async ({ request }) => {
  const { session, admin } = await authenticate.admin(request);
  const { shop } = session;
  let [config, targetProducts, hidePriceProductsDb, formSchemaRow] = await Promise.all([
    prisma.quoteConfig.findUnique({ where: { shop } }),
    prisma.quoteTargetProduct.findMany({ where: { shop } }),
    prisma.hidePriceProduct.findMany({ where: { shop } }),
    prisma.formSchema.findUnique({ where: { shop } }),
  ]);

  const shopData = await admin.graphql("query { shop { currencyCode } }").then((r) => r.json()).catch(() => null);
  const shopCurrency = shopData?.data?.shop?.currencyCode ?? "USD";

  // Auto-initialize default settings in database if they don't exist
  if (!config) {
    config = await prisma.quoteConfig.create({
      data: defaultQuoteConfigData(shop, shopCurrency),
    });
  } else if (!config.shopCurrency) {
    config = await prisma.quoteConfig.update({
      where: { shop },
      data: { shopCurrency }
    });
  }

  // Auto-initialize default form schema in database if it doesn't exist
  if (!formSchemaRow) {
    const defaultFields = JSON.stringify({
      contactElements: [
        { id: 1, type: "Text", open: false, label: "First name", placeholder: "Enter first name", helpText: "", required: true, options: ["Option 1", "Option 2"], content: "", rows: 4, min: "", max: "", accept: "" },
        { id: 2, type: "Text", open: false, label: "Last name", placeholder: "Enter last name", helpText: "", required: true, options: ["Option 1", "Option 2"], content: "", rows: 4, min: "", max: "", accept: "" },
        { id: 3, type: "Email", open: false, label: "Email address", placeholder: "Enter email address", helpText: "", required: true, options: ["Option 1", "Option 2"], content: "", rows: 4, min: "", max: "", accept: "" },
        { id: 4, type: "Phone", open: false, label: "Phone number", placeholder: "Enter phone number", helpText: "", required: true, options: ["Option 1", "Option 2"], content: "", rows: 4, min: "", max: "", accept: "" }
      ],
      shippingElements: [
        { id: 10, type: "Text", open: false, label: "Street address", placeholder: "Enter street address", helpText: "", required: true, options: ["Option 1", "Option 2"], content: "", rows: 4, min: "", max: "", accept: "" },
        { id: 11, type: "Text", open: false, label: "City", placeholder: "Enter city", helpText: "", required: true, options: ["Option 1", "Option 2"], content: "", rows: 4, min: "", max: "", accept: "" },
        { id: 15, type: "Text", open: false, label: "District", placeholder: "Enter district", helpText: "", required: true, options: ["Option 1", "Option 2"], content: "", rows: 4, min: "", max: "", accept: "" },
        { id: 12, type: "Text", open: false, label: "State / Province", placeholder: "Enter state or province", helpText: "", required: true, options: ["Option 1", "Option 2"], content: "", rows: 4, min: "", max: "", accept: "" },
        { id: 13, type: "Text", open: false, label: "Zip / Postal code", placeholder: "Enter zip or postal code", helpText: "", required: true, options: ["Option 1", "Option 2"], content: "", rows: 4, min: "", max: "", accept: "" },
        { id: 14, type: "Country", open: false, label: "Country", placeholder: "", helpText: "", required: true, options: ["Option 1", "Option 2"], content: "", rows: 4, min: "", max: "", accept: "" }
      ],
      extraInfoElements: [
        { id: 20, type: "Textarea", open: false, label: "Message", placeholder: "Enter your message", helpText: "", required: false, options: ["Option 1", "Option 2"], content: "", rows: 4, min: "", max: "", accept: "" }
      ]
    });
    formSchemaRow = await prisma.formSchema.create({
      data: {
        shop,
        fields: defaultFields
      }
    });
  }

  // Required-by-default backfill for existing stores whose schema still has the
  // legacy all-optional contact/shipping fields. Guarded/idempotent, so it runs
  // at most once per store and merchant toggles stick afterward.
  if (formSchemaRow?.fields) {
    try {
      const parsed = JSON.parse(formSchemaRow.fields);
      const { changed } = applyRequiredDefaults(parsed);
      if (changed) {
        const nextFields = JSON.stringify(parsed);
        formSchemaRow = await prisma.formSchema.update({
          where: { shop },
          data: { fields: nextFields },
        });
      }
    } catch (err) {
      console.error("[quote-settings] required-default backfill skipped:", err.message);
    }
  }

  // Remove the legacy /pages/quote page — the quote cart now lives in the
  // in-store modal. Fire-and-forget so it never blocks load time. Idempotent.
  removeQuotePage(admin).catch(() => { });

  return {
    config, targetProducts, hidePriceProductsDb, formSchemaRow, shopCurrency: config.shopCurrency, shop,
    errorColor: QUOTE_SETTINGS_ERROR_COLOR(), accentColor: QUOTE_SETTINGS_ACCENT_COLOR(), successColor: QUOTE_SETTINGS_SUCCESS_COLOR(),
  };
};

/**
 * Action for /app/quote-settings — a multi-intent handler switched on the
 * `intent` form field:
 *  - "sendTestQuote" — parses a JSON `payload` and runs it through
 *                       createQuoteForShop() using this route's own
 *                       authenticated admin session (shop already verified),
 *                       so a merchant can preview the submission/email flow
 *                       without a real storefront customer.
 *  - "saveTags"      — overwrite `quoteConfig.requiredTags` (stored as JSON).
 *  - "saveAll"       — the main settings save: rewrites `quoteConfig` (button/
 *                       widget/toast styling, targeting mode, hide-price
 *                       rules, etc.), replaces the shop's `quoteTargetProduct`
 *                       and `hidePriceProduct` rows wholesale, and upserts the
 *                       Form Builder `formSchema`. Also re-syncs shop currency
 *                       and best-effort removes the legacy /pages/quote page.
 *                       Errors are logged server-side only — the merchant
 *                       only ever sees a generic failure message.
 * Any other intent returns a generic error.
 *
 * @returns {Promise<object>} `{ success: true, intent }` or `{ error, intent? }`
 *   — consumed by the corresponding useFetcher() call in app.quote-settings.jsx.
 */
export const action = async ({ request }) => {
  const { session, admin } = await authenticate.admin(request);
  const { shop } = session;
  const formData = await request.formData();
  const intent = formData.get("intent");

  if (intent === "sendTestQuote") {
    // Preview "send test quote" from this settings page. Runs through this
    // route's own authenticate.admin session (not the public App Proxy
    // endpoint), so `shop` here is already verified above.
    let payload;
    try {
      payload = JSON.parse(formData.get("payload") || "{}");
    } catch {
      return { success: false, error: "Invalid payload", intent: "sendTestQuote" };
    }
    const result = await createQuoteForShop(shop, payload);
    return { ...result, intent: "sendTestQuote" };
  }

  if (intent === "saveTags") {
    const tags = JSON.parse(formData.get("tags") || "[]");
    await prisma.quoteConfig.upsert({
      where: { shop },
      create: { shop, requiredTags: JSON.stringify(tags) },
      update: { requiredTags: JSON.stringify(tags) },
    });
    return { success: true, intent: "saveTags" };
  }

  if (intent === "saveAll") {
    try {
      const targetMode = formData.get("targetMode") || "all";
      const targetProductsRaw = JSON.parse(formData.get("targetProducts") || "[]");
      const targetCollRaw = JSON.parse(formData.get("targetCollections") || "[]");
      const addToQuoteBehaviour = formData.get("addToQuoteBehaviour") || "popup_and_form";
      const hidePriceTarget = formData.get("hidePriceTarget") || "all";
      const hidePriceMode = hidePriceTarget === "specific" ? "specific_products"
        : hidePriceTarget === "collections" ? "specific_collections"
          : hidePriceTarget === "all" ? "all"
            : "none";
      const hpProductsRaw = JSON.parse(formData.get("hidePriceProducts") || "[]");
      const hpCollRaw = JSON.parse(formData.get("hidePriceCollections") || "[]");
      const visibilityMode = formData.get("visibilityMode") || "everyone";
      const tags = JSON.parse(formData.get("tags") || "[]");
      const formSchemaRaw = JSON.parse(formData.get("formSchema") || "{}");

      const bool = (k) => formData.get(k) === "true";
      const num = (k, d) => parseInt(formData.get(k) || String(d), 10);

      const cfg = {
        targetMode,
        showOnProductList: bool("showOnCollectionPage"),
        showOnHomepage: bool("showOnHomepage"),
        productPageDisplay: formData.get("displayMode") || "button_only",
        addToQuoteBehaviour,
        redirectAfterSubmit: "",
        successMessage: formData.get("successMessage") || "Thank you! We will be in touch shortly.",
        buttonText: formData.get("buttonLabel") || "Request a Quote",
        buttonBgColor: formData.get("buttonBgColor") || "#1a1a18",
        buttonTextColor: formData.get("buttonTextColor") || "#ffffff",
        buttonFontSize: num("buttonFontSize", 14),
        buttonBorderRadius: num("buttonBorderRadius", 6),
        buttonFullWidth: formData.get("buttonWidth") === "full",
        buttonPosition: formData.get("buttonPosition") || "below_atc",
        hidePriceMode,
        hidePriceOnProductPage: bool("hidePriceOnProductPage"),
        hidePriceOnCollectionPage: bool("hidePriceOnCollectionPage"),
        hidePriceOnHomePage: bool("hidePriceOnHomePage"),
        hidePriceOnCartPage: bool("hidePriceOnCartPage"),
        hidePriceOnly: bool("hidePriceOnly"),
        hideAddToCart: bool("hideAddToCart"),
        hideBuyNow: bool("hideBuyItNow"),
        hidePriceReplacement: formData.get("hidePriceReplacement") || "text",
        replacementText: formData.get("replacementText") || "Price available on request",
        replacementTextColor: formData.get("replacementTextColor") || "#b4b2a9",
        requireLogin: visibilityMode !== "everyone",
        requiredTags: tags.length > 0 ? JSON.stringify(tags) : null,
        targetCollections: targetCollRaw.length > 0 ? JSON.stringify(targetCollRaw) : null,
        hidePriceCollections: hpCollRaw.length > 0 ? JSON.stringify(hpCollRaw) : null,
        modalTitle: formData.get("formTitle") || "Request a Quote",
        submitButtonText: formData.get("submitButtonLabel") || "Request a Quote",
        formBtnBgColor: formData.get("formBtnBgColor") || "#1a1a18",
        formBtnTextColor: formData.get("formBtnTextColor") || "#ffffff",
        formBtnFontSize: num("formBtnFontSize", 14),
        formBtnBorderRadius: num("formBtnBorderRadius", 6),
        showVendorInForm: bool("showVendor"),
        showSkuInForm: bool("showSku"),
        showOptionInForm: bool("showOption"),
        showPriceInForm: bool("showPrice"),
        showQuotePriceInForm: bool("showQuotePrice"),
        showNoteInForm: bool("showNote"),
        widgetEnabled: bool("widgetEnabled"),
        widgetButtonText: formData.get("widgetButtonText") || "Request a Quote",
        widgetAction: formData.get("widgetAction") || "popup",
        widgetPosition: formData.get("widgetPosition") || "bottom_right",
        widgetBgColor: formData.get("widgetBgColor") || "#1a1a18",
        widgetTextColor: formData.get("widgetTextColor") || "#ffffff",
        toastEnabled: bool("toastEnabled"),
        successToastEnabled: bool("successToastEnabled"),
        toastMessage: formData.get("toastMessage") || "Product added to quote cart.",
        toastBgColor: formData.get("toastBgColor") || "#0f172a",
        toastTextColor: formData.get("toastTextColor") || "#ffffff",
        toastFontSize: num("toastFontSize", 14),
        toastBorderRadius: num("toastBorderRadius", 40),
        toastBorderWidth: num("toastBorderWidth", 0),
        toastBorderColor: formData.get("toastBorderColor") || "#0f172a",
        toastPosition: formData.get("toastPosition") || "bottom_center",
      };

      // Fetch & persist store currency
      const shopData = await admin.graphql("query { shop { currencyCode } }").then((r) => r.json()).catch(() => null);
      const shopCurrency = shopData?.data?.shop?.currencyCode ?? "USD";
      cfg.shopCurrency = shopCurrency;

      await Promise.all([
        prisma.quoteConfig.upsert({ where: { shop }, create: { shop, ...cfg }, update: cfg }),

        (async () => {
          await prisma.quoteTargetProduct.deleteMany({ where: { shop } });
          if (targetMode === "products" && targetProductsRaw.length > 0)
            await prisma.quoteTargetProduct.createMany({
              data: targetProductsRaw.map((p) => ({
                shop, productId: String(p.id), productTitle: p.title || "",
                productHandle: p.handle || "", productImage: p.image || "",
              })),
            });
        })(),

        (async () => {
          await prisma.hidePriceProduct.deleteMany({ where: { shop } });
          if (hidePriceMode === "specific_products" && hpProductsRaw.length > 0)
            await prisma.hidePriceProduct.createMany({
              data: hpProductsRaw.map((p) => ({
                shop, productId: String(p.id), productTitle: p.title || "",
                productHandle: p.handle || "",
              })),
            });
        })(),

        prisma.formSchema.upsert({
          where: { shop },
          create: { shop, fields: JSON.stringify(formSchemaRaw) },
          update: { fields: JSON.stringify(formSchemaRaw) },
        }),
      ]);

      // Remove the legacy /pages/quote page whenever merchant saves (best-effort, non-blocking)
      removeQuotePage(admin).catch(() => { });

      // Note: Config metafields are removed in favor of direct API calls and local storage/session storage cache.


      return { success: true, intent: "saveAll" };
    } catch (err) {
      // Log full details server-side only — never leak internals to the merchant.
      console.error("[saveAll] Error:", err);
      return { error: "We couldn't save your settings. Please try again.", intent: "saveAll" };
    }
  }

  return { error: "Something went wrong. Please try again." };
};

/**
 * Storefront Theme App Extension endpoint, reached only via Shopify's App
 * Proxy:
 *   GET  /apps/{subpath}/api/quote  → current settings
 *   POST /apps/{subpath}/api/quote  → save a new quote + send emails
 *
 * authenticate.public.appProxy verifies Shopify's HMAC `signature` query
 * param before either handler runs, so `shop` below is always the
 * Shopify-verified domain from the session — never a client-supplied value.
 */

import prisma from "../../db.server";
import { authenticate } from "../../core/shopify/shopify.server";
import { createQuoteForShop } from "./quotes.server";
import { buildCorsHeaders } from "../../utils/cors";

const CORS = buildCorsHeaders("GET, POST, OPTIONS");

// ─── GET — settings for the storefront block ──────────────────────────────────

/**
 * Loader — returns the storefront hide-price/request-quote display settings
 * for the theme app extension block to render (button text/colors, which
 * optional fields to show, thank-you message). Responds 401 if the App Proxy
 * request doesn't resolve to an installed shop.
 *
 * @returns {Promise<Response>} JSON response (with CORS headers) shaped
 *   `{ isEnabled, hideForGuestsOnly, buttonText, buttonColor,
 *   buttonTextColor, showPhone, showCompany, showQuantity, showMessage,
 *   thankYouMessage }`.
 */
export const loader = async ({ request }) => {
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS });
  }

  const { session } = await authenticate.public.appProxy(request);
  const shop = session?.shop;

  if (!shop) {
    return Response.json({ error: "Shop not installed" }, { status: 401, headers: CORS });
  }

  const settings = await prisma.settings.findUnique({ where: { shop } });

  return Response.json(
    {
      isEnabled: settings?.hidePriceEnabled ?? false,
      hideForGuestsOnly: settings?.hideForGuestsOnly ?? false,
      buttonText: settings?.buttonText ?? "Request a Quote",
      buttonColor: settings?.buttonColor ?? "#222222",
      buttonTextColor: settings?.buttonTextColor ?? "#ffffff",
      showPhone: settings?.showPhone ?? true,
      showCompany: settings?.showCompany ?? true,
      showQuantity: settings?.showQuantity ?? true,
      showMessage: settings?.showMessage ?? true,
      thankYouMessage:
        settings?.thankYouMessage ?? "Thank you! We will be in touch shortly.",
    },
    { headers: CORS },
  );
};

// ─── POST — submit a new quote ────────────────────────────────────────────────

/**
 * Action — accepts a JSON body from the storefront quote form/cart and
 * delegates to createQuoteForShop() to persist it and send emails. Rejects
 * non-POST methods (405) and unparseable JSON (400); 401s if the App Proxy
 * request doesn't resolve to an installed shop.
 *
 * @returns {Promise<Response>} JSON response (with CORS headers) mirroring
 *   createQuoteForShop()'s result — `{ success, quoteId }` or `{ error }` —
 *   with the HTTP status taken from `result.status` (default 200).
 */
export const action = async ({ request }) => {
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS });
  }

  if (request.method !== "POST") {
    return Response.json({ error: "Method not allowed" }, { status: 405, headers: CORS });
  }

  const { session } = await authenticate.public.appProxy(request);
  const shop = session?.shop;

  if (!shop) {
    return Response.json({ success: false, error: "Shop not installed" }, { status: 401, headers: CORS });
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Invalid JSON" }, { status: 400, headers: CORS });
  }

  const result = await createQuoteForShop(shop, body);
  const { status = 200, ...payload } = result;
  return Response.json(payload, { status, headers: CORS });
};

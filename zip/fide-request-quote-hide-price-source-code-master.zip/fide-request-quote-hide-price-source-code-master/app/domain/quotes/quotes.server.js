/**
 * Shared quote-creation logic: not a route module itself, but consumed by
 * two callers that each verify `shop` in their own way before delegating
 * here — the public storefront endpoint (storefrontQuote.server.js, backing
 * app/routes/api.quote.jsx and apps.$proxySubpath.api.quote.jsx, where shop
 * is verified via the Shopify App Proxy HMAC signature) and the admin
 * "send test quote" preview (quoteSettings.server.js, backing
 * app/routes/app.quote-settings.jsx, where shop comes from the authenticated
 * admin session). This module trusts `shop` completely — it is the caller's
 * job to have already verified it.
 */
import prisma from "../../db.server";
import { applyRequiredDefaults } from "./formSchemaDefaults.server";
import { sendEmailForShop } from "../../lib/mailer.server";
import {
  merchantNotificationEmail,
  buyerConfirmationEmail,
  renderCustomTemplate,
} from "../email/emailTemplates.server";
import { assignQuoteNumber } from "./quoteNumber.server";
import { quotePdfUrl } from "../pdf/pdfToken.server";

// Shared by the public storefront endpoint (api.quote.jsx, shop verified via
// App Proxy signature) and the admin "send test quote" preview
// (app.quote-settings.jsx, shop verified via the authenticated admin session) —
// `shop` must already be verified by the caller before this runs.
/**
 * Creates a quote record for a shop and fires off the merchant-notification
 * and buyer-confirmation emails. Used both for real customer submissions and
 * for the admin-side "send test quote" preview.
 *
 * Re-validates required fields server-side against the shop's saved Form
 * Builder schema (see formSchemaDefaults.server.js) even though the
 * storefront also validates client-side — the client check can be bypassed
 * (JS disabled, direct API call, client bug), so this is the authoritative
 * gate. On an unexpected validation error it fails OPEN (allows the quote
 * through) so a schema bug can never block all submissions.
 *
 * @param {string} shop - already-verified shop domain (see file header).
 * @param {object} body - raw submission payload (cartItems, formFields, customer info, etc).
 * @returns {Promise<{success: boolean, quoteId?: string, error?: string, status?: number}>}
 *   `status` is only present on failure and is meant to be forwarded as the
 *   HTTP response status by the caller.
 */
export async function createQuoteForShop(shop, body) {
  const {
    shopCurrency,
    productId,
    productTitle,
    variantId,
    variantTitle,
    customerName,
    customerEmail,
    customerPhone,
    companyName,
    quantity,
    message,
    offerPrice,
    cartItems,
    formFields,
    tags,
  } = body;

  if (!customerName?.trim() || !customerEmail?.trim()) {
    return { success: false, error: "Name and email are required", status: 400 };
  }

  // ── Authoritative required-field validation ──────────────────────────────────
  // The storefront validates too, but that can be bypassed (JS disabled, direct
  // API calls, or a client bug). Enforce the merchant's required fields here
  // against the stored Form Builder schema so incomplete quotes are always
  // rejected — independent of the client. Fails open only on unexpected errors
  // so a validation bug can never block all quote submissions.
  try {
    const schemaRow = await prisma.formSchema.findUnique({ where: { shop } });
    if (schemaRow?.fields) {
      const parsed = JSON.parse(schemaRow.fields);
      // Normalize legacy all-optional schemas in-memory so required enforcement
      // is correct even if no backfill write has landed for this store yet.
      applyRequiredDefaults(parsed);
      const allFields = [
        ...(parsed.contactElements || []),
        ...(parsed.shippingElements || []),
        ...(parsed.extraInfoElements || []),
      ];
      const requiredFields = allFields.filter(
        (f) =>
          f &&
          f.required &&
          String(f.label || "").trim() &&
          String(f.type || "").toLowerCase().trim() !== "paragraph",
      );
      if (requiredFields.length) {
        const norm = (s) => String(s || "").trim().toLowerCase();
        const submitted = Array.isArray(formFields) ? formFields : [];
        const hasValue = (label) =>
          submitted.some((ff) => {
            if (norm(ff.label) !== norm(label)) return false;
            const val = ff.value;
            if (Array.isArray(val)) return val.length > 0;
            return String(val ?? "").trim().length > 0;
          });
        const missing = requiredFields.filter((f) => !hasValue(f.label));
        if (missing.length) {
          return {
            success: false,
            error: `Please fill in all required fields: ${missing.map((f) => f.label).join(", ")}`,
            status: 400,
          };
        }
      }
    }
  } catch (err) {
    console.error("[createQuote] required-field validation skipped:", err.message);
  }

  // Resolve primary product — use cartItems[0] if present
  const primaryItem = Array.isArray(cartItems) && cartItems.length ? cartItems[0] : null;
  const resolvedProductId    = primaryItem?.productId ? String(primaryItem.productId) : (productId ? String(productId) : null);
  const baseTitle            = primaryItem?.productTitle ?? (productTitle || "Unknown Product");
  const resolvedProductTitle = variantTitle && variantTitle !== "Default Title"
    ? `${baseTitle} — ${variantTitle}`
    : baseTitle;
  const resolvedQuantity     = primaryItem?.quantity     ? String(primaryItem.quantity) : (quantity?.trim() || null);
  // offerPrice may come as top-level field (modal) or inside cartItems[0] (cart page)
  const rawOfferPrice = offerPrice ?? primaryItem?.offerPrice ?? null;
  const resolvedOfferPrice   = rawOfferPrice != null ? parseFloat(rawOfferPrice) || null : null;

  // ── 1. Save quote first — always ────────────────────────────────────────────
  let quote;
  try {
    quote = await prisma.quote.create({
      data: {
        shop,
        productId:     resolvedProductId,
        productTitle:  resolvedProductTitle,
        customerName:  customerName.trim(),
        customerEmail: customerEmail.trim(),
        customerPhone: customerPhone?.trim() || null,
        companyName:   companyName?.trim()   || null,
        quantity:      resolvedQuantity,
        quotedPrice:    resolvedOfferPrice,
        quotedCurrency: shopCurrency || "USD",
        message:       message?.trim()       || null,
        status: "new",
        tags: tags || null,
        formData: Array.isArray(cartItems) && cartItems.length > 0
          ? JSON.stringify({
              __v: 2,
              cartItems: cartItems.map((item) => ({
                productId:    item.productId    || null,
                variantId:    item.variantId    || null,
                productTitle: item.productTitle || "",
                variantTitle: item.variantTitle || "",
                vendor:       item.vendor       || "",
                sku:          item.sku          || "",
                quantity:     item.quantity     || 1,
                price:        item.price        || "",
                offerPrice:   item.offerPrice   != null ? parseFloat(item.offerPrice) || null : null,
                note:         item.note         || "",
                image:        item.image        || item.productImage || "",
              })),
              formFields: Array.isArray(formFields) ? formFields : [],
            })
          : JSON.stringify({
              __v: 2,
              cartItems: [{
                productId:    productId    || null,
                variantId:    variantId    || null,
                productTitle: productTitle || "",
                variantTitle: variantTitle || "",
                quantity:     quantity     || 1,
                price:        offerPrice   != null ? String(offerPrice) : "",
                offerPrice:   offerPrice   != null ? parseFloat(offerPrice) || null : null,
                image:        body.productImage || "",
              }],
              formFields: Array.isArray(formFields) ? formFields : [],
            }),
      },
    });
  } catch (err) {
    console.error("[createQuote] DB error:", err.message);
    return { success: false, error: "Something went wrong. Please try again.", status: 500 };
  }

  // ── 2. Assign sequential quote number ──────────────────────────────────────
  assignQuoteNumber(shop, quote.id).catch((err) =>
    console.error("[createQuote] quoteNumber assign failed:", err.message),
  );

  // ── 3. Fetch config for email (non-blocking) ────────────────────────────────
  const [config, emailConfig, notificationTemplate, autoResponseTemplate] = await Promise.all([
    prisma.quoteConfig.findUnique({ where: { shop } }).catch(() => null),
    prisma.emailConfig.findUnique({ where: { shop } }).catch(() => null),
    prisma.emailTemplate.findUnique({ where: { shop_templateType: { shop, templateType: "notification" } } }).catch(() => null),
    prisma.emailTemplate.findUnique({ where: { shop_templateType: { shop, templateType: "auto-response" } } }).catch(() => null),
  ]);

  const storeName = shop;
  const thankYouMessage =
    config?.successMessage ?? "Thank you! We will be in touch shortly.";

  // ── 4. Send emails — each catches its own errors ─────────────────────────────
  // Notification to admin (only if toggle is on AND notify email is set).
  // Uses the merchant's saved template (Email Template Editor) when one
  // exists, falling back to the built-in default otherwise.
  if (emailConfig?.notificationEnabled !== false && config?.notifyEmail) {
    const { subject, html } = renderCustomTemplate(
      notificationTemplate,
      {
        "{customer_name}": quote.customerName,
        "{customer_email}": quote.customerEmail,
        "{product_title}": quote.productTitle,
        "{quote_message}": quote.message || "",
        "{store_name}": storeName,
      },
      { storeName, recipientEmail: config.notifyEmail },
    ) || merchantNotificationEmail(quote, storeName);
    sendEmailForShop(emailConfig, { to: config.notifyEmail, subject, html }).catch((err) =>
      console.error("[Email] Merchant notification failed:", err.message),
    );
  }

  // Auto-response to customer — on by default, like the admin notification
  // above; only suppressed when the merchant explicitly disables it. Same
  // saved-template-first fallback as above; the PDF download prompt (when
  // available) is appended regardless of customization.
  if (emailConfig?.autoResponseEnabled !== false) {
    const pdfUrl = quotePdfUrl(quote.id);
    const pdfPromptHtml = pdfUrl
      ? `<p style="margin:16px 0 0;font-size:14px;color:#444;">Download a copy of your request: <a href="${pdfUrl}">Download PDF</a></p>`
      : "";
    const buyerEmail = renderCustomTemplate(
      autoResponseTemplate,
      {
        "{customer_name}": quote.customerName,
        "{product_title}": quote.productTitle,
        "{store_name}": storeName,
      },
      { storeName, recipientEmail: quote.customerEmail, extraHtml: pdfPromptHtml },
    ) || buyerConfirmationEmail(quote, storeName, thankYouMessage, pdfUrl);
    sendEmailForShop(emailConfig, { to: quote.customerEmail, ...buyerEmail }).catch((err) =>
      console.error("[Email] Buyer confirmation failed:", err.message),
    );
  }

  // ── 5. Return success even if emails fail ────────────────────────────────────
  return { success: true, quoteId: quote.id };
}

/**
 * Removes the /pages/quote page from the merchant's store if it exists.
 * The app no longer uses a separate quote page — the quote cart is shown in the
 * in-store modal instead. Safe to call repeatedly — idempotent.
 */
export async function removeQuotePage(admin) {
  try {
    const checkRes  = await admin.graphql(
      `query { pages(first: 1, query: "handle:quote") { edges { node { id handle } } } }`
    );
    const checkData = await checkRes.json();
    const existing  = checkData?.data?.pages?.edges?.[0]?.node;
    if (!existing) return; // nothing to remove

    await admin.graphql(
      `mutation pageDelete($id: ID!) {
        pageDelete(id: $id) {
          deletedPageId
          userErrors { field message }
        }
      }`,
      { variables: { id: existing.id } }
    );
  } catch (err) {
    console.error("[removeQuotePage]", err.message);
  }
}

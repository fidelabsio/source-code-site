// ─── Draft order address helpers (server-side only) ───────────────────────────
// Shared by quotesList.server.js and quoteDetail.server.js — both convert a
// quote + a client-submitted shipping address blob into a Shopify draft order
// address input. No route re-exports this file directly; it is a pure helper
// module consumed by the two quote-mutation modules above (their "convertToDraft"
// / "accept" style intents).

/**
 * Splits a full display name into first/last for Shopify address input,
 * on the first whitespace run — everything after the first token becomes
 * the last name.
 * @param {string} fullName
 * @returns {{firstName: string, lastName: string}}
 */
export function splitName(fullName) {
  const parts = (fullName || "").trim().split(/\s+/);
  return { firstName: parts[0] || "", lastName: parts.slice(1).join(" ") || "" };
}

// Known country display names (as stored by the storefront form) mapped to
// their ISO 3166-1 alpha-2 code, which is what Shopify's address input expects.
export const COUNTRY_CODE_MAP = {
  "United States": "US", "United States of America": "US",
  "United Kingdom": "GB", "Great Britain": "GB",
  "Canada": "CA", "Australia": "AU", "India": "IN",
  "Singapore": "SG", "New Zealand": "NZ", "Germany": "DE",
  "France": "FR", "Japan": "JP", "China": "CN", "Brazil": "BR",
  "Mexico": "MX", "South Africa": "ZA", "Netherlands": "NL",
  "Sweden": "SE", "Norway": "NO", "Denmark": "DK",
  "Switzerland": "CH", "South Korea": "KR", "Hong Kong": "HK",
  "United Arab Emirates": "AE", "Saudi Arabia": "SA",
};

/**
 * Normalizes a country value to an ISO alpha-2 code. Already-2-letter values
 * pass through uppercased (assumed to already be a code); otherwise looked
 * up in COUNTRY_CODE_MAP by display name.
 * @param {string} value
 * @returns {string|null} 2-letter country code, or null if unrecognized.
 */
export function toCountryCode(value) {
  if (!value) return null;
  const trimmed = value.trim();
  return trimmed.length === 2 ? trimmed.toUpperCase() : (COUNTRY_CODE_MAP[trimmed] || null);
}

/**
 * Builds a Shopify draft order address input from a quote row and a parsed
 * shipping-address blob. Fields are only included when present/truthy —
 * Shopify's address input tolerates partial addresses, so this avoids
 * sending empty-string overwrites for fields the customer never filled in.
 * @param {object} quote - Prisma quote row (used for name, company, phone).
 * @param {object} addrData - parsed shipping address (see extractShippingAddr).
 * @returns {object} draft order `billingAddress`/`shippingAddress` input.
 */
export function buildAddress(quote, addrData) {
  const { firstName, lastName } = splitName(quote.customerName);
  const countryCode = toCountryCode(addrData?.country || "");
  return {
    firstName,
    lastName,
    ...(quote.companyName   ? { company:  quote.companyName }  : {}),
    ...(addrData?.street    ? { address1: addrData.street }     : {}),
    ...(addrData?.district  ? { address2: addrData.district }   : {}),
    ...(addrData?.city      ? { city:     addrData.city }       : {}),
    ...(addrData?.state     ? { province: addrData.state }      : {}),
    ...(addrData?.postal    ? { zip:      addrData.postal }     : {}),
    ...(countryCode         ? { countryCode }                    : {}),
    ...(quote.customerPhone ? { phone:    quote.customerPhone } : {}),
  };
}

/**
 * Pulls the customer-submitted shipping address out of a quote's serialized
 * `formData` JSON, if present. formData may be a legacy plain array of line
 * items (no address) or the newer `{ __v: 2, cartItems, __shippingAddr }`
 * shape — this only cares about the latter's `__shippingAddr` key.
 * @param {string} formDataStr - raw `quote.formData` column value.
 * @returns {object} the shipping address object, or `{}` if absent/invalid/empty.
 */
export function extractShippingAddr(formDataStr) {
  try {
    const raw = JSON.parse(formDataStr || "{}");
    if (raw.__shippingAddr && Object.values(raw.__shippingAddr).some(Boolean)) {
      return raw.__shippingAddr;
    }
  } catch {}
  return {};
}

/**
 * Required-by-default backfill for the Form Builder schema.
 *
 * Contact + shipping fields ship as required by default (see the seed in
 * app.quote-settings.jsx). Stores created BEFORE that change have those fields
 * stored as required:false. This helper upgrades them at read time so the
 * change takes effect on ALL stores — without a Prisma schema migration.
 *
 * It is intentionally conservative: it only upgrades when NONE of the seeded
 * contact/shipping fields are required yet (i.e. the legacy all-optional
 * default). The moment any of them is required — because we upgraded it, the
 * new seed set it, or a merchant toggled it — this becomes a no-op, so a
 * merchant can still freely make those fields optional afterward and it will
 * stick. The free-form Message field is never touched (stays optional).
 *
 * Not a route module — pure helper consumed by quoteSettings.server.js (the
 * loader that seeds/backfills the schema for app.quote-settings.jsx) and by
 * quotes.server.js's createQuoteForShop() (to know which fields to enforce
 * as required at submission time).
 */

const REQUIRED_BY_DEFAULT = new Set([
  // Contact
  "first name",
  "last name",
  "email address",
  "phone number",
  // Shipping
  "street address",
  "city",
  "district",
  "state / province",
  "zip / postal code",
  "country",
]);

const norm = (s) => String(s || "").trim().toLowerCase();

/**
 * Mutates `fields` in place, upgrading seeded contact/shipping fields to
 * required when the schema is still on the legacy all-optional default.
 * @returns {{ changed: boolean, fields: any }}
 */
export function applyRequiredDefaults(fields) {
  if (!fields || typeof fields !== "object") return { changed: false, fields };

  const seeded = [];
  ["contactElements", "shippingElements"].forEach((section) => {
    if (!Array.isArray(fields[section])) return;
    fields[section].forEach((f) => {
      if (f && REQUIRED_BY_DEFAULT.has(norm(f.label))) seeded.push(f);
    });
  });

  if (!seeded.length) return { changed: false, fields };
  // Already upgraded / seeded-new / merchant-customized → leave it alone.
  if (seeded.some((f) => f.required === true)) return { changed: false, fields };

  seeded.forEach((f) => { f.required = true; });
  return { changed: true, fields };
}

/**
 * Quotes list/inbox page: loader returns a paginated, filtered, sorted page
 * of quotes plus per-tab badge counts; action handles bulk/per-row mutations
 * (delete, duplicate, convert to draft order, accept/reject with email).
 * Backs app/routes/app.quotes.jsx, which re-exports this file's
 * `loader`/`action` directly.
 *
 * Side effect: the loader also opportunistically (fire-and-forget, once per
 * shop per server process) writes the app's URL into a shop metafield so the
 * storefront extension can discover it without an authenticated call.
 */
import { authenticate } from "../../core/shopify/shopify.server";
import { assignQuoteNumber } from "./quoteNumber.server";
import { setCachedCurrency } from "../shop/shopCache.server";
import prisma from "../../db.server";
import { sendEmailForShop } from "../../lib/mailer.server";
import { acceptQuoteEmail, rejectQuoteEmail, renderCustomTemplate } from "../email/emailTemplates.server";
import { EMAIL_ACCEPT_COLOR, EMAIL_REJECT_COLOR } from "../../core/email/theme.server";
import { buildAddress as buildDraftAddress, extractShippingAddr } from "./draftOrderAddress.server";
import { tabWhere } from "./quoteFilters.server";
import { APP_NAME } from "../../core/branding.server";
import { QUOTES_LIST_COLOR, QUOTES_LIST_SUCCESS_COLOR, QUOTES_LIST_WARNING_COLOR, QUOTES_LIST_CARD_BACKGROUND_COLOR } from "../../core/quotes/theme.server";
import { readQuotesText } from "../../core/quotes/text-labels.server";
import { formatMoney } from "../../utils/currency";

// ─── Loader ───────────────────────────────────────────────────────────────────

const PAGE_SIZE = 8;

// Per-tab badge counts — independent of search, computed across the whole shop
/**
 * Computes the badge count for each inbox tab, independent of the current
 * search/sort/pagination — always counted across the whole shop.
 * @param {string} shop
 * @returns {Promise<{all:number, unread:number, read:number, cancelled:number, accepted:number, done:number}>}
 */
async function countTabs(shop) {
  const [all, unread, read, cancelled, accepted, done] = await Promise.all([
    prisma.quote.count({ where: { shop } }),
    prisma.quote.count({ where: { shop, status: "new" } }),
    prisma.quote.count({ where: { shop, status: "read" } }),
    prisma.quote.count({ where: { shop, quoteStatus: "rejected" } }),
    prisma.quote.count({ where: { shop, quoteStatus: "accepted" } }),
    prisma.quote.count({ where: { shop, quoteStatus: "paid" } }),
  ]);
  return { all, unread, read, cancelled, accepted, done };
}

// Cache: only write the metafield once per shop per server process
const _metafieldWritten = new Set();

/**
 * Loader for /app/quotes.
 *
 * Reads pagination/filter/sort state from URL search params:
 *  - `page` (1-based, default 1)
 *  - `tab`  (one of tabWhere()'s keys — "all", "unread", "read", "cancelled",
 *            "accepted", "done" — default "all")
 *  - `q`    (free-text search across customer name/email, product title, company)
 *  - `sort` ("date_desc" default, "date_asc", "name_asc", "name_desc")
 *
 * @returns {Promise<object>} `{ quotes, shopCurrency, tabCounts, page,
 *   pageSize, totalCount, totalPages, tab, search, sortKey }` — flows
 *   directly into `useLoaderData()` in app.quotes.jsx.
 */
export const loader = async ({ request }) => {
  const { session, admin } = await authenticate.admin(request);
  const { shop } = session;

  // ── Server-side pagination / filter / sort params (read from the URL) ──
  const url     = new URL(request.url);
  const page    = Math.max(1, parseInt(url.searchParams.get("page"), 10) || 1);
  const tab     = url.searchParams.get("tab")  || "all";
  const search  = (url.searchParams.get("q")   || "").trim();
  const sortKey = url.searchParams.get("sort") || "date_desc";

  const appUrl = process.env.SHOPIFY_APP_URL;
  if (appUrl && !_metafieldWritten.has(shop)) {
    _metafieldWritten.add(shop);
    (async () => {
      try {
        const shopRes = await admin.graphql(`#graphql
          query { shop { id } }
        `);
        const { data } = await shopRes.json();
        await admin.graphql(
          `#graphql
          mutation metafieldsSet($metafields: [MetafieldsSetInput!]!) {
            metafieldsSet(metafields: $metafields) {
              userErrors { field message }
            }
          }`,
          {
            variables: {
              metafields: [
                {
                  ownerId: data.shop.id,
                  namespace: "quote_request",
                  key: "app_url",
                  type: "single_line_text_field",
                  value: appUrl,
                },
              ],
            },
          },
        );
      } catch (e) {
        _metafieldWritten.delete(shop);
        console.warn("Could not write app URL metafield:", e.message);
      }
    })();
  }

  // Build the filtered query: tab filter + free-text search
  const where = { shop, ...tabWhere(tab) };
  if (search) {
    where.OR = [
      { customerName:  { contains: search, mode: "insensitive" } },
      { customerEmail: { contains: search, mode: "insensitive" } },
      { productTitle:  { contains: search, mode: "insensitive" } },
      { companyName:   { contains: search, mode: "insensitive" } },
    ];
  }

  const orderBy =
    sortKey === "date_asc"  ? { createdAt: "asc" }    :
    sortKey === "name_asc"  ? { customerName: "asc" }  :
    sortKey === "name_desc" ? { customerName: "desc" } :
                              { createdAt: "desc" };

  const [quotes, totalCount, tabCounts, quoteConfig] = await Promise.all([
    prisma.quote.findMany({
      where,
      orderBy,
      skip: (page - 1) * PAGE_SIZE,
      take: PAGE_SIZE,
      select: {
        id: true, quoteNumber: true, status: true, quoteStatus: true,
        customerName: true, customerEmail: true, customerPhone: true, companyName: true,
        productTitle: true, quotedPrice: true, quotedCurrency: true, quantity: true, message: true,
        createdAt: true, merchantReply: true, formData: true, tags: true,
      },
    }),
    prisma.quote.count({ where }),
    countTabs(shop),
    prisma.quoteConfig.findUnique({ where: { shop }, select: { shopCurrency: true } }).catch(() => null),
  ]);

  const shopCurrency = quoteConfig?.shopCurrency || "INR";
  setCachedCurrency(shop, shopCurrency);

  const totalPages = Math.max(1, Math.ceil(totalCount / PAGE_SIZE));

  return {
    quotes, shopCurrency, tabCounts,
    page, pageSize: PAGE_SIZE, totalCount, totalPages,
    tab, search, sortKey,
    appName: APP_NAME,
    primaryColor: QUOTES_LIST_COLOR(),
    successColor: QUOTES_LIST_SUCCESS_COLOR(),
    warningColor: QUOTES_LIST_WARNING_COLOR(),
    cardBackgroundColor: QUOTES_LIST_CARD_BACKGROUND_COLOR(),
    labels: readQuotesText().quotesList,
  };
};

// ─── Action ───────────────────────────────────────────────────────────────────

/**
 * Action for /app/quotes — a multi-intent handler switched on the `intent`
 * form field:
 *  - "bulkDelete"     — delete all quotes whose id is in the comma-separated
 *                        `ids` field (scoped to this shop).
 *  - "markAsRead"     — set a single quote's status to "read".
 *  - "convertToDraft" — create a Shopify draft order from the quote's stored
 *                        line items (or a single fallback line item), storing
 *                        the resulting draft order name + invoice link.
 *  - "duplicate"      — create a fresh "new"-status quote copying customer/product fields.
 *  - "delete"         — delete a single quote.
 *  - "acceptQuote"    — mark accepted + read; optionally emails the customer
 *                        if the shop's accept-quote email toggle is on.
 *  - "rejectQuote"    — mark rejected + read; optionally emails the customer
 *                        if the shop's reject-quote email toggle is on.
 * All intents except "bulkDelete" require a `quoteId` field identifying an
 * existing quote for this shop; missing/not-found returns an `error`.
 *
 * @returns {Promise<object>} `{ success: true, intent, ... }` or `{ error }`
 *   — consumed by the corresponding useFetcher() call in app.quotes.jsx.
 */
export const action = async ({ request }) => {
  const { session, admin } = await authenticate.admin(request);
  const { shop } = session;
  const formData = await request.formData();
  const intent   = formData.get("intent");
  const quoteId  = formData.get("quoteId");

  if (intent === "bulkDelete") {
    const ids = String(formData.get("ids") || "").split(",").filter(Boolean);
    if (!ids.length) return { error: "No quotes selected" };
    await prisma.quote.deleteMany({ where: { id: { in: ids }, shop } });
    return { success: true, intent: "bulkDelete", ids };
  }

  if (!quoteId) return { error: "Missing quoteId" };
  const quote = await prisma.quote.findFirst({ where: { id: quoteId, shop } });

  if (intent === "markAsRead") {
    if (!quote) return { error: "Quote not found" };
    await prisma.quote.update({ where: { id: quoteId }, data: { status: "read" } });
    return { success: true, intent: "markAsRead" };
  }

  if (intent === "convertToDraft") {
    if (!quote) return { error: "Quote not found" };
    try {
      const res = await admin.graphql(
        `#graphql
        mutation draftOrderCreate($input: DraftOrderInput!) {
          draftOrderCreate(input: $input) {
            draftOrder { id name invoiceUrl }
            userErrors { field message }
          }
        }`,
        {
          variables: {
            input: (() => {
              const addrData = extractShippingAddr(quote.formData);
              const address  = buildDraftAddress(quote, addrData);
              return {
              note: `Converted from quote #${quote.quoteNumber ?? quote.id}`,
              email: quote.customerEmail || undefined,
              billingAddress:  address,
              shippingAddress: address,
              lineItems: (() => {
                try {
                  const items = JSON.parse(quote.formData || "[]");
                  if (Array.isArray(items) && items.length && (items[0].productTitle || items[0].title)) {
                    return items.map((item) => {
                      const price   = String(parseFloat(item.offerPrice ?? item.price ?? quote.quotedPrice ?? 0).toFixed(2));
                      const qty     = parseInt(item.quantity ?? item.qty) || 1;
                      const varId   = item.variantId;
                      if (varId) {
                        const gid = String(varId).startsWith("gid://") ? varId : `gid://shopify/ProductVariant/${varId}`;
                        return { variantId: gid, quantity: qty, originalUnitPrice: price };
                      }
                      return { title: item.productTitle || item.title || "Product", quantity: qty, originalUnitPrice: price };
                    });
                  }
                } catch {}
                return [{ title: quote.productTitle, quantity: parseInt(quote.quantity) || 1, originalUnitPrice: String(parseFloat(quote.quotedPrice || 0).toFixed(2)) }];
              })(),
              };
            })(),
          },
        },
      );
      const resJson     = await res.json();
      const draftResult = resJson?.data?.draftOrderCreate;
      if (!draftResult) return { error: resJson?.errors?.[0]?.message || "Draft order creation failed" };
      if (draftResult.userErrors?.length) return { error: draftResult.userErrors[0].message };
      await prisma.quote.update({
        where: { id: quoteId },
        data: {
          draftOrderName: draftResult.draftOrder.name,
          checkoutLink:   draftResult.draftOrder.invoiceUrl || null,
        },
      });
      return { success: true, intent: "convertToDraft", draftOrderName: draftResult.draftOrder.name };
    } catch (e) {
      return { error: `Failed to create draft order: ${e.message}` };
    }
  }

  if (intent === "duplicate") {
    if (!quote) return { error: "Quote not found" };
    const dup = await prisma.quote.create({
      data: {
        shop,
        customerName:  quote.customerName,
        customerEmail: quote.customerEmail,
        customerPhone: quote.customerPhone,
        companyName:   quote.companyName,
        productTitle:  quote.productTitle,
        quantity:      quote.quantity,
        message:       quote.message,
        status:        "new",
      },
    });
    assignQuoteNumber(shop, dup.id).catch(() => {});
    return { success: true, intent: "duplicate" };
  }

  if (intent === "delete") {
    if (!quote) return { error: "Quote not found" };
    await prisma.quote.delete({ where: { id: quoteId } });
    return { success: true, intent: "delete", quoteId };
  }

  if (intent === "acceptQuote") {
    if (!quote) return { error: "Quote not found" };
    const updated = await prisma.quote.update({
      where: { id: quoteId },
      data:  { quoteStatus: "accepted", status: "read" },
    });
    const emailConfig = await prisma.emailConfig.findUnique({ where: { shop } }).catch(() => null);
    if (emailConfig?.acceptQuoteEnabled) {
      // Saved template (Email Template Editor) first, built-in default otherwise.
      const savedTemplate = await prisma.emailTemplate.findUnique({
        where: { shop_templateType: { shop, templateType: "accept-quote" } },
      }).catch(() => null);
      const { subject, html } = renderCustomTemplate(
        savedTemplate,
        {
          "{customer_name}": updated.customerName,
          "{product_title}": updated.productTitle,
          "{quote_price}": updated.quotedPrice != null ? formatMoney(updated.quotedPrice, updated.quotedCurrency) : "—",
          "{store_name}": shop,
        },
        { storeName: shop, recipientEmail: updated.customerEmail },
        EMAIL_ACCEPT_COLOR,
      ) || acceptQuoteEmail(updated, shop);
      sendEmailForShop(emailConfig, { to: updated.customerEmail, subject, html }).catch((err) =>
        console.error("[Email] Accept quote email failed:", err.message),
      );
    }
    return { success: true, intent: "acceptQuote", quoteId };
  }

  if (intent === "rejectQuote") {
    if (!quote) return { error: "Quote not found" };
    const updated = await prisma.quote.update({
      where: { id: quoteId },
      data:  { quoteStatus: "rejected", status: "read" },
    });
    const emailConfig = await prisma.emailConfig.findUnique({ where: { shop } }).catch(() => null);
    if (emailConfig?.rejectQuoteEnabled) {
      // Saved template (Email Template Editor) first, built-in default otherwise.
      const savedTemplate = await prisma.emailTemplate.findUnique({
        where: { shop_templateType: { shop, templateType: "reject-quote" } },
      }).catch(() => null);
      const { subject, html } = renderCustomTemplate(
        savedTemplate,
        {
          "{customer_name}": updated.customerName,
          "{product_title}": updated.productTitle,
          "{store_name}": shop,
        },
        { storeName: shop, recipientEmail: updated.customerEmail },
        EMAIL_REJECT_COLOR,
      ) || rejectQuoteEmail(updated, shop);
      sendEmailForShop(emailConfig, { to: updated.customerEmail, subject, html }).catch((err) =>
        console.error("[Email] Reject quote email failed:", err.message),
      );
    }
    return { success: true, intent: "rejectQuote", quoteId };
  }

  if (!quote) return { error: "Quote not found" };
  return { error: "Unknown action" };
};

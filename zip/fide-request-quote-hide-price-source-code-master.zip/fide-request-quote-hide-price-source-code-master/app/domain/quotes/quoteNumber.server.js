// Server-only quote-number assignment. Not a route module — called from
// quotes.server.js (createQuoteForShop), quoteDetail.server.js ("new" quote
// create), and quotesList.server.js ("duplicate" intent) right after a new
// quote row is inserted. For the read-side display formatter, see the
// client-safe quoteNumber.js.
import prisma from "../../db.server";

/**
 * Atomically assigns the next sequential quoteNumber for a shop.
 * Uses SERIALIZABLE isolation to prevent two concurrent submissions from
 * getting the same number under PostgreSQL — without this, two quotes
 * created at the same instant could both read the same current max and be
 * assigned identical numbers.
 * @param {string} shop
 * @param {string} quoteId - id of the already-created quote row to stamp.
 * @returns {Promise<number>} the newly assigned quote number.
 */
export async function assignQuoteNumber(shop, quoteId) {
  return prisma.$transaction(
    async (tx) => {
      const agg = await tx.quote.aggregate({
        where: { shop },
        _max: { quoteNumber: true },
      });
      const next = (agg._max.quoteNumber ?? 0) + 1;
      await tx.quote.update({ where: { id: quoteId }, data: { quoteNumber: next } });
      return next;
    },
    { isolationLevel: "Serializable" },
  );
}

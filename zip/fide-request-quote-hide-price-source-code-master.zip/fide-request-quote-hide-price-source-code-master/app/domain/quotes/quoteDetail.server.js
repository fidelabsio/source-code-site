/**
 * Single-quote detail page: loader fetches one quote (or scaffolds a blank
 * "new" quote) plus its product/customer context, and action handles every
 * mutation on that quote (save, accept/reject with email, convert to draft
 * order, notes, tags, status changes). Backs app/routes/app.quote.$id.jsx,
 * which re-exports this file's `loader`/`action` directly.
 *
 * Gotcha: the accept/acceptWithEmail flow builds a real Shopify checkout link
 * (via draft order, falling back to a cart permalink) and — per Shopify App
 * Store policy 1.1.2 — never trusts a merchant-supplied "custom checkout URL"
 * unless it resolves to a Shopify-owned or the shop's own domain (see
 * sanitizeCheckoutUrl below). Also note: opening an unread quote via the
 * loader has the side effect of marking it read/viewed in the DB.
 */
import { authenticate } from "../../core/shopify/shopify.server";
import { redirect } from "react-router";
import { sendEmailForShop } from "../../lib/mailer.server";
import { assignQuoteNumber } from "./quoteNumber.server";
import prisma from "../../db.server";
import { quoteFormSchema, flattenZodErrors } from "./quoteSchema";
import { CURRENCY_SYMBOLS } from "../../utils/currency";
import { buildAddress, extractShippingAddr } from "./draftOrderAddress.server";
import { PDF_HEADER_ACCENT_COLOR } from "../../core/pdf/theme.server";
import { QUOTE_DETAIL_ACCENT_COLOR, QUOTE_DETAIL_LINK_COLOR, QUOTE_DETAIL_CARD_BACKGROUND_COLOR } from "../../core/quotes/theme.server";
import { readQuotesText } from "../../core/quotes/text-labels.server";

// ─── Loader ───────────────────────────────────────────────────────────────────

/**
 * Loader for /app/quote/:id.
 *
 * When `params.id === "new"`, returns an in-memory scaffold quote (no DB row
 * created yet) pre-filled with the shop's current currency, so the create
 * form has something to render before the merchant hits Save.
 *
 * Otherwise fetches the quote row, the full list of the shop's quote ids (to
 * derive prev/next for in-page navigation), how many quotes this same
 * customer email has submitted, the linked product's live data from Shopify
 * (via Admin GraphQL), and the shop's saved accept/reject/PDF email
 * templates used by this page's modals.
 *
 * Side effect: opening a quote that is still "new" flips it to
 * quoteStatus "viewed" / status "read" as a side effect of this GET.
 *
 * @returns {Promise<object>} `{ isNew, quote, prevId, nextId,
 *   customerQuoteCount, productData, shopCurrency, quoteConfigAccentColor,
 *   acceptTemplate, rejectTemplate, pdfTemplate, labels }` — flows directly
 *   into `useLoaderData()` in app.quote.$id.jsx. `labels` is the buyer-editable
 *   UI copy for this page (app/config/quotes/text-labels.json's "quoteDetail" key).
 */
export const loader = async ({ request, params }) => {
  const { session, admin } = await authenticate.admin(request);
  const { shop } = session;

  // ── New quote ────────────────────────────────────────────────────────────
  if (params.id === "new") {
    const [config, shopData] = await Promise.all([
      prisma.quoteConfig.findUnique({ where: { shop }, select: { shopCurrency: true } }).catch(() => null),
      admin.graphql("query { shop { currencyCode } }").then((r) => r.json()).catch(() => null),
    ]);
    const shopCurrency = shopData?.data?.shop?.currencyCode ?? config?.shopCurrency ?? "USD";
    if (config && shopCurrency !== config.shopCurrency) {
      prisma.quoteConfig.update({ where: { shop }, data: { shopCurrency } }).catch(() => null);
    }
    const now = new Date().toISOString();
    return {
      isNew: true,
      quote: {
        id: "new", shop,
        customerName: "", customerEmail: "", customerPhone: "", companyName: "",
        productTitle: "", productId: null, quantity: "1", message: "",
        formData: null, status: "new", quoteStatus: "new",
        quotedPrice: null, quotedCurrency: shopCurrency,
        discount: 0, shipping: 0, tax: 0,
        merchantReply: null, replyHistory: null, tags: "[]",
        internalNotes: "", notesHistory: "[]",
        followUpSentAt: null, merchantAlerted: null, expiresAt: null,
        checkoutLink: null, quoteNumber: null,
        createdAt: now, updatedAt: now,
      },
      prevId: null, nextId: null, customerQuoteCount: 0,
      productData: null, shopCurrency,
      quoteConfigAccentColor: PDF_HEADER_ACCENT_COLOR(),
      secondaryColor: QUOTE_DETAIL_ACCENT_COLOR(),
      linkColor: QUOTE_DETAIL_LINK_COLOR(),
      cardBackgroundColor: QUOTE_DETAIL_CARD_BACKGROUND_COLOR(),
      acceptTemplate: {}, rejectTemplate: {}, pdfTemplate: {},
      labels: readQuotesText().quoteDetail,
    };
  }

  // ── Existing quote ────────────────────────────────────────────────────────
  const quote = await prisma.quote.findFirst({
    where: { id: params.id, shop },
  });
  if (!quote) throw new Response("Not found", { status: 404 });

  const [allQuotes, customerQuoteCount] = await Promise.all([
    prisma.quote.findMany({
      where: { shop },
      orderBy: { createdAt: "desc" },
      select: { id: true },
    }),
    prisma.quote.count({
      where: { shop, customerEmail: quote.customerEmail },
    }),
  ]);

  const idx    = allQuotes.findIndex((q) => q.id === params.id);
  const prevId = allQuotes[idx - 1]?.id ?? null;
  const nextId = allQuotes[idx + 1]?.id ?? null;

  // Auto-mark as read + viewed on open
  const needsUpdate = quote.quoteStatus === "new" || quote.status === "new";
  if (needsUpdate) {
    await prisma.quote.update({
      where: { id: params.id },
      data: {
        ...(quote.quoteStatus === "new" ? { quoteStatus: "viewed" } : {}),
        ...(quote.status === "new" ? { status: "read" } : {}),
      },
    });
  }

  // Fetch product details from Shopify
  // Normalize numeric IDs to GID format (liquid gives plain numbers, GraphQL needs gid://)
  const toGid = (id) => {
    if (!id) return null;
    const s = String(id);
    return s.startsWith("gid://") ? s : `gid://shopify/Product/${s}`;
  };

  let productData = null;
  if (quote.productId) {
    try {
      const res = await admin.graphql(
        `#graphql
        query getProduct($id: ID!) {
          product(id: $id) {
            id title vendor
            media(first: 1) { edges { node { ... on MediaImage { image { url altText } } } } }
            variants(first: 20) {
              edges { node { id title price sku selectedOptions { name value } } }
            }
          }
        }`,
        { variables: { id: toGid(quote.productId) } },
      );
      const { data } = await res.json();
      productData = data?.product ?? null;
    } catch {}
  }

  // Fetch saved email templates for accept + reject modals
  const [acceptTpl, rejectTpl, quoteConfig, shopData, pdfTpl] = await Promise.all([
    prisma.emailTemplate.findUnique({ where: { shop_templateType: { shop, templateType: "accept-quote" } } }).catch(() => null),
    prisma.emailTemplate.findUnique({ where: { shop_templateType: { shop, templateType: "reject-quote" } } }).catch(() => null),
    prisma.quoteConfig.findUnique({ where: { shop } }).catch(() => null),
    admin.graphql("query { shop { currencyCode } }").then((r) => r.json()).catch(() => null),
    prisma.emailTemplate.findUnique({ where: { shop_templateType: { shop, templateType: "pdf-quote" } } }).catch(() => null),
  ]);

  const shopCurrency = shopData?.data?.shop?.currencyCode ?? quoteConfig?.shopCurrency ?? "USD";

  // Persist currency to config so api.config can return it without admin auth
  if (quoteConfig && shopCurrency !== quoteConfig.shopCurrency) {
    prisma.quoteConfig.update({ where: { shop }, data: { shopCurrency } }).catch(() => null);
  }

  const parseBody = (tpl) => { try { return tpl ? JSON.parse(tpl.htmlBody) : null; } catch { return null; } };

  const parsePdfBody = (tpl) => { try { return tpl ? JSON.parse(tpl.htmlBody) : null; } catch { return null; } };

  return {
    isNew: false,
    quote, prevId, nextId, customerQuoteCount, productData, shopCurrency,
    quoteConfigAccentColor: quoteConfig?.buttonBgColor ?? PDF_HEADER_ACCENT_COLOR(),
    secondaryColor: QUOTE_DETAIL_ACCENT_COLOR(),
    linkColor: QUOTE_DETAIL_LINK_COLOR(),
    cardBackgroundColor: QUOTE_DETAIL_CARD_BACKGROUND_COLOR(),
    acceptTemplate: { subject: acceptTpl?.subject ?? null, ...(parseBody(acceptTpl) ?? {}) },
    rejectTemplate: { subject: rejectTpl?.subject ?? null, ...(parseBody(rejectTpl) ?? {}) },
    pdfTemplate: {
      documentTitle: pdfTpl?.subject ?? null,
      ...(parsePdfBody(pdfTpl) ?? {}),
    },
    labels: readQuotesText().quoteDetail,
  };
};

// ─── Checkout URL safety ─────────────────────────────────────────────────────

// Shopify App Store policy 1.1.2: buyers must always be sent to Shopify checkout.
// The accept-email "Checkout link" field is merchant-editable, so we never trust
// an arbitrary URL — we only honour it when it resolves to a Shopify-controlled
// host (or the shop's own storefront domain, which also hosts Shopify checkout).
const SHOPIFY_HOST_SUFFIXES = [".myshopify.com", ".shopify.com", ".shopifypreview.com", ".shop.app"];

/**
 * Extracts the lowercased hostname from a URL, but only if it is https.
 * @param {string} url
 * @returns {string|null} hostname, or null if unparseable / not https.
 */
function checkoutUrlHost(url) {
  try {
    const u = new URL(String(url));
    return u.protocol === "https:" ? u.hostname.toLowerCase() : null;
  } catch {
    return null;
  }
}

/**
 * True if `host` is a Shopify-controlled domain (myshopify.com, shopify.com,
 * shopifypreview.com, shop.app or its bare apex). Used as the first, cheap
 * check before falling back to a live lookup of the shop's own domains.
 * @param {string|null} host
 * @returns {boolean}
 */
function hostIsShopifyOwned(host) {
  if (!host) return false;
  if (host === "shop.app") return true;
  return SHOPIFY_HOST_SUFFIXES.some((s) => host.endsWith(s));
}

// Returns the merchant's custom checkout URL only if it is safe (points to a
// Shopify-owned domain or the shop's own primary/myshopify domain). Otherwise
// returns "" so the caller falls back to the auto-generated draft order link.
/**
 * Security gate for the merchant-editable "Checkout link" email field.
 * @param {object} admin - authenticated Admin GraphQL client (used only when
 *   the host isn't already recognized as Shopify-owned, to look up the
 *   shop's real myshopify/primary domain).
 * @param {string} shop - the verified shop domain from the session.
 * @param {string} rawUrl - merchant-supplied URL, untrusted.
 * @returns {Promise<string>} the URL if safe, otherwise "" (caller falls
 *   back to the auto-generated draft order / cart link).
 */
async function sanitizeCheckoutUrl(admin, shop, rawUrl) {
  const url = String(rawUrl || "").trim();
  if (!url) return "";
  const host = checkoutUrlHost(url);
  if (!host) return ""; // not https or unparseable

  if (hostIsShopifyOwned(host)) return url;

  // Could be the shop's custom storefront domain (still Shopify checkout). Look
  // up the shop's real domains before deciding to drop the link.
  try {
    const res = await admin.graphql(`#graphql
      query checkoutDomains { shop { myshopifyDomain primaryDomain { host } } }`);
    const s = (await res.json())?.data?.shop;
    const allowed = [shop, s?.myshopifyDomain, s?.primaryDomain?.host]
      .filter(Boolean)
      .map((h) => String(h).toLowerCase());
    if (allowed.includes(host)) return url;
  } catch {
    /* fall through to reject */
  }

  console.warn("[Accept] Ignoring non-Shopify checkout URL, using auto-generated link instead:", url);
  return "";
}

// ─── Draft order / checkout link helper ──────────────────────────────────────

// lineItemsJson: serialized current UI line items (title, qty, price, variantId)
// discountAmt / shippingAmt: current UI adjustment values
/**
 * Builds a checkout link for a quote by creating a Shopify draft order
 * (preferred) or, if that fails, a cart permalink built from variant ids.
 *
 * Line item prices are resolved from — in priority order — the live UI
 * state passed in via `lineItemsJson` (so the merchant's on-screen edits
 * win), then the quote's stored `formData`, then the quote's own
 * quotedPrice/quantity as a last-resort single line item.
 *
 * @param {object} admin - authenticated Admin GraphQL client.
 * @param {string} shop - verified shop domain.
 * @param {object} quote - the Prisma quote row.
 * @param {string|null} lineItemsJson - serialized current UI line items
 *   (title, qty, price, variantId), or null/empty to use stored formData.
 * @param {number} [discountAmt=0] - fixed-amount discount to apply to the draft order.
 * @param {number} [shippingAmt=0] - shipping line amount to apply to the draft order.
 * @returns {Promise<string>} invoice URL, cart permalink fallback, or "" if
 *   both the draft order and the permalink could not be built.
 */
async function buildCheckoutLink(admin, shop, quote, lineItemsJson, discountAmt = 0, shippingAmt = 0) {
  // 1. Prefer live items passed from the UI so we use the merchant's current prices,
  //    not whatever was stored in the DB at submission time.
  let rawItems = [];
  if (lineItemsJson) {
    try { rawItems = JSON.parse(lineItemsJson); } catch {}
  }
  // Fall back to DB formData if caller didn't pass live items
  if (!Array.isArray(rawItems) || !rawItems.length) {
    try {
      const fd = JSON.parse(quote.formData || "[]");
      rawItems = (!Array.isArray(fd) && fd?.__v === 2) ? (fd.cartItems || []) : (Array.isArray(fd) ? fd : []);
    } catch {}
  }
  if (!Array.isArray(rawItems) || !rawItems.length) rawItems = [];

  const first = rawItems[0] || {};
  const isCartFormat     = "productTitle" in first;
  const isMerchantFormat = !isCartFormat && "title" in first && "qty" in first;
  const validItems       = (isCartFormat || isMerchantFormat) ? rawItems : [];

  const normItems = validItems.map((item) => {
    const title     = item.productTitle || item.title || quote.productTitle || "Product";
    const variantId = item.variantId || null;
    const qty       = parseInt(item.quantity || item.qty) || 1;
    let rawPrice;
    if (isCartFormat) {
      // Cart-format (from DB): offerPrice = customer's quoted price — prefer it over catalog price
      rawPrice =
        item.offerPrice != null && parseFloat(item.offerPrice) > 0 ? parseFloat(item.offerPrice) :
        item.price      != null && parseFloat(item.price)      > 0 ? parseFloat(item.price)      :
        parseFloat(quote.quotedPrice) || 0;
    } else {
      // Merchant-format (from UI): price field already holds the merchant's final quoted price
      rawPrice =
        item.price != null && parseFloat(item.price) > 0 ? parseFloat(item.price) :
        parseFloat(quote.quotedPrice) || 0;
    }
    return { title, variantId, qty, unitPrice: rawPrice.toFixed(2) };
  });

  const lineItemSources = normItems.length > 0
    ? normItems
    : [{
        title:     quote.productTitle || "Product",
        variantId: null,
        qty:       parseInt(quote.quantity) || 1,
        unitPrice: parseFloat(quote.quotedPrice || 0).toFixed(2),
      }];

  // Cart permalink — used as fallback only if the draft order fails
  let checkoutLink = "";
  const withVariant = lineItemSources.filter((i) => i.variantId);
  if (withVariant.length > 0) {
    const parts = withVariant.map((i) => {
      const numId = String(i.variantId).replace(/^gid:\/\/shopify\/ProductVariant\//, "");
      return `${numId}:${i.qty}`;
    });
    checkoutLink = `https://${shop}/cart/${parts.join(",")}`;
  }

  // Draft order — always use title-based line items (same as convertToDraft which works reliably).
  // variantId-based items can fail at customer checkout if the variant is unavailable or deleted.
  try {
    const lineItems = lineItemSources.map((item) => ({
      title:             item.title,
      quantity:          item.qty,
      originalUnitPrice: item.unitPrice,
    }));

    const draftInput = {
      note:      `Quote #${quote.quoteNumber ?? quote.id} — ${quote.productTitle}`,
      lineItems,
      // email omitted intentionally — avoids "protected customer data" gate
    };

    // Apply discount to draft order so customer pays the exact quoted total
    const discount = parseFloat(discountAmt) || 0;
    if (discount > 0) {
      draftInput.appliedDiscount = {
        value:     discount.toFixed(2),
        valueType: "FIXED_AMOUNT",
        title:     "Quote discount",
      };
    }

    // Apply shipping line
    const shipping = parseFloat(shippingAmt) || 0;
    if (shipping > 0) {
      draftInput.shippingLine = {
        price: shipping.toFixed(2),
        title: "Quoted shipping",
      };
    }

    const draftRes = await admin.graphql(
      `#graphql
      mutation draftOrderCreate($input: DraftOrderInput!) {
        draftOrderCreate(input: $input) {
          draftOrder { id name invoiceUrl }
          userErrors { field message }
        }
      }`,
      { variables: { input: draftInput } },
    );
    const draftJson   = await draftRes.json();
    const draftResult = draftJson?.data?.draftOrderCreate;
    if (draftResult?.draftOrder?.invoiceUrl && !draftResult.userErrors?.length) {
      checkoutLink = draftResult.draftOrder.invoiceUrl;
    } else {
      if (draftResult?.userErrors?.length) console.error("[Accept] Draft order user errors:", JSON.stringify(draftResult.userErrors));
      if (draftJson?.errors)               console.error("[Accept] Draft order GraphQL errors:", JSON.stringify(draftJson.errors));
      console.error("[Accept] Draft order failed — falling back to cart permalink:", checkoutLink || "(none)");
    }
  } catch (e) {
    console.error("[Accept] Draft order exception:", e.message);
  }

  return checkoutLink;  // empty string if draft order failed and no variant IDs
}

/**
 * Action for /app/quote/:id — a single multi-intent handler switched on the
 * `intent` form field:
 *  - "updateQuote"     — create the quote (when params.id === "new", then
 *                         redirects to the new quote's page) or update its
 *                         editable fields on an existing quote. Validates
 *                         customer info + line items via quoteFormSchema
 *                         first; returns `{ error, fieldErrors }` on failure.
 *  - "updateStatus"    — set quoteStatus to the submitted value verbatim.
 *  - "accept"          — mark accepted and generate a checkout link (draft
 *                         order, falling back to a cart permalink).
 *  - "acceptWithEmail" — same as "accept" plus sends a merchant-templated
 *                         accept email to the customer; honors a merchant
 *                         custom checkout URL only if sanitizeCheckoutUrl()
 *                         approves it (see file header).
 *  - "reject" / "rejectWithEmail" — mark rejected, optionally emailing the customer.
 *  - "paymentReceived" — mark quoteStatus "paid".
 *  - "reopen"          — revert quoteStatus to "viewed".
 *  - "duplicate"       — create a fresh "new" quote copying customer/product fields.
 *  - "convertToDraft"  — create a Shopify draft order from the current line
 *                         items and shipping address, storing its name + invoice link.
 *  - "addNote"         — append a note to notesHistory (stored as a JSON array).
 *  - "updateTags"      — overwrite the quote's tags (stored as a JSON array).
 * Any other/missing intent returns `{ error: "Unknown action" }`.
 *
 * @returns {Promise<object>} shape varies by intent but always includes
 *   `intent`, plus either `success: true` (with intent-specific fields such
 *   as `checkoutLink` or `draftOrderName`) or `error` — consumed by the
 *   matching useFetcher() call in app.quote.$id.jsx.
 */
export const action = async ({ request, params }) => {
  const { session, admin } = await authenticate.admin(request);
  const { shop } = session;
  const formData = await request.formData();
  const intent   = formData.get("intent");

  // ── Resolve shop currency once for the whole action ─────────────────────
  const shopConfig = await prisma.quoteConfig.findUnique({ where: { shop }, select: { shopCurrency: true } }).catch(() => null);
  const shopCurrency = shopConfig?.shopCurrency || "USD";

  // ── Create new quote on first Save ───────────────────────────────────────
  if (params.id === "new" && intent === "updateQuote") {
    const lineItemsJson    = String(formData.get("lineItemsJson")    || "");
    const shippingAddrJson = String(formData.get("shippingAddrJson") || "");

    // Server-side Zod validation
    const parsedLineItems = (() => { try { return JSON.parse(lineItemsJson); } catch { return []; } })();
    const parsedAddr      = (() => { try { return JSON.parse(shippingAddrJson); } catch { return {}; } })();
    const serverValidation = quoteFormSchema.safeParse({
      customerName:  String(formData.get("customerName")  || "").trim(),
      customerEmail: String(formData.get("customerEmail") || "").trim(),
      customerPhone: String(formData.get("customerPhone") || "").trim(),
      shippingAddr:  parsedAddr,
      lineItems:     Array.isArray(parsedLineItems) ? parsedLineItems : [],
    });
    if (!serverValidation.success) {
      return { error: "Validation failed", fieldErrors: flattenZodErrors(serverValidation) };
    }
    const expRaw = formData.get("expiresAt");

    let mergedFormData = lineItemsJson || null;
    if (shippingAddrJson) {
      try {
        const addr = JSON.parse(shippingAddrJson);
        if (Object.values(addr).some(Boolean)) {
          const base = lineItemsJson ? JSON.parse(lineItemsJson) : [];
          mergedFormData = JSON.stringify(
            Array.isArray(base)
              ? { __v: 2, cartItems: base, __shippingAddr: addr }
              : { ...base, __shippingAddr: addr }
          );
        }
      } catch {}
    }

    let productTitle = String(formData.get("productTitle") || "").trim();
    if (!productTitle && lineItemsJson) {
      try { productTitle = JSON.parse(lineItemsJson)[0]?.title || ""; } catch {}
    }

    const newQ = await prisma.quote.create({
      data: {
        shop,
        customerName:   String(formData.get("customerName")   || "").trim(),
        customerEmail:  String(formData.get("customerEmail")  || "").trim(),
        customerPhone:  String(formData.get("customerPhone")  || "").trim() || null,
        companyName:    String(formData.get("companyName")    || "").trim() || null,
        message:        String(formData.get("message")        || "").trim() || null,
        productTitle:   productTitle || "Untitled",
        quantity:       String(formData.get("quantity")       || "1"),
        internalNotes:  String(formData.get("internalNotes")  || ""),
        quotedPrice:    parseFloat(formData.get("quotedPrice")) || null,
        quotedCurrency: shopCurrency,
        discount:       parseFloat(formData.get("discount"))    || 0,
        shipping:       parseFloat(formData.get("shipping"))    || 0,
        tax:            parseFloat(formData.get("tax"))         || 0,
        expiresAt:      expRaw ? new Date(expRaw) : null,
        status:         "new",
        quoteStatus:    "new",
        ...(mergedFormData ? { formData: mergedFormData } : {}),
      },
    });
    assignQuoteNumber(shop, newQ.id).catch(() => {});
    return redirect(`/app/quote/${newQ.id}`);
  }

  if (params.id === "new") return { error: "Save the quote first" };

  const quote = await prisma.quote.findFirst({ where: { id: params.id, shop } });
  if (!quote) return { error: "Quote not found" };

  if (intent === "updateStatus") {
    await prisma.quote.update({
      where: { id: params.id },
      data: { quoteStatus: String(formData.get("quoteStatus")) },
    });
    return { success: true, intent };
  }

  if (intent === "updateQuote") {
    const lineItemsJson    = String(formData.get("lineItemsJson")    || "");
    const shippingAddrJson = String(formData.get("shippingAddrJson") || "");
    const cName  = String(formData.get("customerName")  || "").trim();
    const cEmail = String(formData.get("customerEmail") || "").trim();
    const expRaw = formData.get("expiresAt");

    // Server-side Zod validation
    const parsedLineItems = (() => { try { return JSON.parse(lineItemsJson); } catch { return []; } })();
    const parsedAddr      = (() => { try { return JSON.parse(shippingAddrJson); } catch { return {}; } })();
    const serverValidation = quoteFormSchema.safeParse({
      customerName:  cName,
      customerEmail: cEmail,
      customerPhone: String(formData.get("customerPhone") || "").trim(),
      shippingAddr:  parsedAddr,
      lineItems:     Array.isArray(parsedLineItems) ? parsedLineItems : [],
    });
    if (!serverValidation.success) {
      return { error: "Validation failed", fieldErrors: flattenZodErrors(serverValidation) };
    }

    // Merge shipping address into existing formData JSON
    let mergedFormData = lineItemsJson || null;
    if (shippingAddrJson) {
      try {
        const addr = JSON.parse(shippingAddrJson);
        const hasAddr = Object.values(addr).some(Boolean);
        if (hasAddr) {
          const base = lineItemsJson ? JSON.parse(lineItemsJson) : [];
          // Store as array if it was array, inject __shippingAddr into object form
          const wrapped = Array.isArray(base)
            ? { __v: 2, cartItems: base, __shippingAddr: addr }
            : { ...base, __shippingAddr: addr };
          mergedFormData = JSON.stringify(wrapped);
        }
      } catch {}
    }

    await prisma.quote.update({
      where: { id: params.id },
      data: {
        ...(cName  ? { customerName:  cName  } : {}),
        ...(cEmail ? { customerEmail: cEmail } : {}),
        customerPhone:  String(formData.get("customerPhone") || "").trim() || null,
        companyName:    String(formData.get("companyName")   || "").trim() || null,
        message:        String(formData.get("message")       || "").trim() || null,
        quotedCurrency: shopCurrency,
        expiresAt:      expRaw ? new Date(expRaw) : null,
        quotedPrice:    parseFloat(formData.get("quotedPrice")) || null,
        quantity:       String(formData.get("quantity") || "1"),
        internalNotes:  String(formData.get("internalNotes") || ""),
        discount:       parseFloat(formData.get("discount")) || 0,
        shipping:       parseFloat(formData.get("shipping")) || 0,
        tax:            parseFloat(formData.get("tax")) || 0,
        ...(mergedFormData ? { formData: mergedFormData } : {}),
      },
    });
    return { success: true, intent };
  }

  if (intent === "accept") {
    const lineItemsJson = formData.get("lineItemsJson") || null;
    const discountAmt   = parseFloat(formData.get("discount") || "0");
    const shippingAmt   = parseFloat(formData.get("shipping") || "0");
    const checkoutLink  = await buildCheckoutLink(admin, shop, quote, lineItemsJson, discountAmt, shippingAmt);
    await prisma.quote.update({
      where: { id: params.id },
      data: { quoteStatus: "accepted", checkoutLink: checkoutLink || null },
    });
    return { success: true, intent, checkoutLink: checkoutLink || null };
  }

  if (intent === "acceptWithEmail") {
    const subject           = String(formData.get("emailSubject")     || "").trim();
    const heading           = String(formData.get("emailHeading")     || "").trim();
    const body              = String(formData.get("emailContent")     || "").trim();
    const cta               = String(formData.get("emailAction")      || "").trim();
    const showCta           = formData.get("emailShowCta") !== "false";
    const customCheckoutUrl = String(formData.get("emailCheckoutUrl") || "").trim();
    const lineItemsJson     = formData.get("lineItemsJson") || null;
    const discountAmt       = parseFloat(formData.get("discount") || "0");
    const shippingAmt       = parseFloat(formData.get("shipping") || "0");
    const quoteTotalRaw     = formData.get("quoteTotal");

    // Only honour a merchant-supplied checkout URL when it points to Shopify
    // checkout (policy 1.1.2); otherwise fall back to the auto-generated link.
    const safeCustomUrl = await sanitizeCheckoutUrl(admin, shop, customCheckoutUrl);
    const checkoutLink = safeCustomUrl || await buildCheckoutLink(admin, shop, quote, lineItemsJson, discountAmt, shippingAmt);

    // ── Mark accepted + save checkout link ──────────────────────────────────
    await prisma.quote.update({
      where: { id: params.id },
      data: {
        quoteStatus:  "accepted",
        checkoutLink: checkoutLink || null,
      },
    });

    // ── Build and send email ─────────────────────────────────────────────────
    const sym = CURRENCY_SYMBOLS[quote.quotedCurrency] || quote.quotedCurrency || "";
    // Use the UI-computed total (passed from the merchant's screen) if available
    const quotePriceDisplay = quoteTotalRaw != null && quoteTotalRaw !== ""
      ? `${sym}${parseFloat(quoteTotalRaw).toFixed(2)}`
      : quote.quotedPrice != null ? `${sym}${parseFloat(quote.quotedPrice).toFixed(2)}` : "—";
    const replacements = {
      "{customer_name}":  quote.customerName  || "",
      "{product_title}":  quote.productTitle  || "",
      "{quote_price}":    quotePriceDisplay,
      "{checkout_link}":  checkoutLink        || "#",
      "{store_name}":     shop,
    };
    const replace = (str) => Object.entries(replacements).reduce((s, [k, v]) => s.replaceAll(k, v), str);

    const btnStyle = "display:inline-block;background:#202223;color:#fff;padding:12px 28px;border-radius:6px;font-size:15px;font-weight:600;text-decoration:none;letter-spacing:0.01em";
    const ctaLabel = cta || "Complete Purchase";
    const ctaHtml  = showCta
      ? (checkoutLink
          ? `<a href="${checkoutLink}" style="${btnStyle}" target="_blank">${replace(ctaLabel)}</a>`
          : `<span style="${btnStyle};opacity:0.5;cursor:default">${replace(ctaLabel)}</span>`)
      : "";
    const linkBoxHtml = showCta && checkoutLink
      ? `<div style="margin:0 40px 32px;background:#f6f6f7;border:1px solid #e1e3e5;border-radius:6px;padding:14px 18px">
          <p style="font-size:11px;color:#6d7175;margin:0 0 5px;font-weight:600;text-transform:uppercase;letter-spacing:0.05em">Or copy this link</p>
          <a href="${checkoutLink}" style="font-size:13px;color:#005bd3;word-break:break-all;text-decoration:none" target="_blank">${checkoutLink}</a>
        </div>`
      : "";

    const html = `
      <div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif;max-width:600px;margin:0 auto;background:#fff;border:1px solid #e1e3e5;border-radius:8px;overflow:hidden">
        <div style="background:#f6f6f7;padding:16px 32px;border-bottom:1px solid #e1e3e5;text-align:center">
          <span style="font-size:14px;font-weight:700;color:#202223">${shop}</span>
        </div>
        <div style="padding:40px 40px 32px;text-align:center">
          <div style="width:48px;height:48px;background:#e3f5eb;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 20px">
            <span style="font-size:22px">✓</span>
          </div>
          <h2 style="font-size:22px;font-weight:700;margin:0 0 12px;color:#202223">${replace(heading)}</h2>
          <p style="font-size:15px;color:#6d7175;line-height:1.6;margin:0 0 28px">${replace(body)}</p>
          ${ctaHtml}
        </div>
        ${linkBoxHtml}
        <div style="border-top:1px solid #e1e3e5;padding:16px 40px;text-align:center">
          <p style="font-size:12px;color:#8c9196;margin:0">This email was sent to ${quote.customerEmail}.</p>
        </div>
      </div>`;

    const emailConfig = await prisma.emailConfig.findUnique({ where: { shop } }).catch(() => null);
    sendEmailForShop(emailConfig, {
      to:      quote.customerEmail,
      subject: replace(subject),
      html,
    }).catch((err) => console.error("[Email] Accept email failed:", err.message));

    return { success: true, intent, checkoutLink: checkoutLink || null };
  }

  if (intent === "reject") {
    await prisma.quote.update({
      where: { id: params.id },
      data: { quoteStatus: "rejected" },
    });
    return { success: true, intent };
  }

  if (intent === "rejectWithEmail") {
    await prisma.quote.update({
      where: { id: params.id },
      data: { quoteStatus: "rejected" },
    });

    const subject = String(formData.get("emailSubject") || "").trim();
    const heading = String(formData.get("emailHeading") || "").trim();
    const body    = String(formData.get("emailContent") || "").trim();
    const cta     = String(formData.get("emailAction")  || "").trim();
    const showCta = formData.get("emailShowCta") !== "false";

    const replacements = {
      "{customer_name}": quote.customerName || "",
      "{product_title}": quote.productTitle || "",
      "{store_name}":    shop,
    };
    const replace = (str) => Object.entries(replacements).reduce((s, [k, v]) => s.replaceAll(k, v), str);

    const html = `
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
        <div style="background:#f6f6f7;height:56px;border-bottom:1px solid #e1e3e5;display:flex;align-items:center;justify-content:center">
          <div style="width:80px;height:20px;border-radius:4px;background:#d2d5d8"></div>
        </div>
        <div style="padding:32px 40px 24px;text-align:center">
          <h2 style="font-size:22px;font-weight:700;margin:0 0 12px;color:#202223">${replace(heading)}</h2>
          <p style="font-size:14px;color:#6d7175;line-height:1.6;margin:0 0 24px">${replace(body)}</p>
          ${showCta && cta ? `<a href="#" style="display:inline-block;background:#202223;color:#fff;padding:10px 24px;border-radius:6px;font-size:14px;font-weight:600;text-decoration:none">${replace(cta)}</a>` : ""}
        </div>
        <div style="border-top:1px solid #e1e3e5;padding:16px 40px;text-align:center">
          <p style="font-size:12px;color:#8c9196;margin:0">This email was sent to ${quote.customerEmail}.</p>
        </div>
      </div>`;

    const emailConfig = await prisma.emailConfig.findUnique({ where: { shop } }).catch(() => null);
    sendEmailForShop(emailConfig, {
      to:      quote.customerEmail,
      subject: replace(subject),
      html,
    }).catch((err) => console.error("[Email] Reject email failed:", err.message));

    return { success: true, intent };
  }

  if (intent === "paymentReceived") {
    await prisma.quote.update({
      where: { id: params.id },
      data: { quoteStatus: "paid" },
    });
    return { success: true, intent };
  }

  if (intent === "reopen") {
    await prisma.quote.update({
      where: { id: params.id },
      data: { quoteStatus: "viewed" },
    });
    return { success: true, intent };
  }

  if (intent === "duplicate") {
    await prisma.quote.create({
      data: {
        shop,
        customerName:  quote.customerName,
        customerEmail: quote.customerEmail,
        customerPhone: quote.customerPhone,
        companyName:   quote.companyName,
        productTitle:  quote.productTitle,
        productId:     quote.productId,
        quantity:      quote.quantity,
        message:       quote.message,
        formData:      quote.formData,
        quoteStatus:   "new",
      },
    });
    return { success: true, intent };
  }

  if (intent === "convertToDraft") {
    try {
      // Build line items from current UI state (all products), fall back to single quote row
      let draftLineItems = [];
      try {
        const uiItems = JSON.parse(formData.get("lineItemsJson") || "[]");
        if (Array.isArray(uiItems) && uiItems.length > 0) {
          draftLineItems = uiItems
            .filter((item) => item.title || item.productTitle)
            .map((item) => ({
              title:             String(item.title || item.productTitle || "Product"),
              quantity:          parseInt(item.qty || item.quantity) || 1,
              originalUnitPrice: String(parseFloat(item.price) > 0 ? parseFloat(item.price).toFixed(2) : parseFloat(quote.quotedPrice || 0).toFixed(2)),
            }));
        }
      } catch {}
      if (!draftLineItems.length) {
        draftLineItems = [{
          title:             quote.productTitle || "Product",
          quantity:          parseInt(quote.quantity) || 1,
          originalUnitPrice: String(parseFloat(quote.quotedPrice || 0).toFixed(2)),
        }];
      }

      const addrData = extractShippingAddr(quote.formData);
      const address  = buildAddress(quote, addrData);

      const res = await admin.graphql(
        `#graphql
        mutation draftOrderCreate($input: DraftOrderInput!) {
          draftOrderCreate(input: $input) {
            draftOrder { id name invoiceUrl }
            userErrors { field message }
          }
        }`,
        {
          variables: {
            input: {
              note:            `Converted from Quote #${quote.quoteNumber ?? params.id}`,
              email:           quote.customerEmail || undefined,
              lineItems:       draftLineItems,
              billingAddress:  address,
              shippingAddress: address,
            },
          },
        },
      );
      const { data } = await res.json();
      if (data.draftOrderCreate.userErrors.length) {
        return { error: data.draftOrderCreate.userErrors[0].message };
      }
      const draftOrder = data.draftOrderCreate.draftOrder;
      await prisma.quote.update({
        where: { id: params.id },
        data: {
          quoteStatus:   "quoted",
          draftOrderName: draftOrder.name,
          checkoutLink:   draftOrder.invoiceUrl || null,
        },
      });
      return {
        success:           true,
        intent,
        draftOrderName:    draftOrder.name,
        draftOrderInvoice: draftOrder.invoiceUrl,
      };
    } catch (e) {
      return { error: `Draft order failed: ${e.message}` };
    }
  }


  if (intent === "addNote") {
    const text = String(formData.get("noteText") || "").trim();
    if (!text) return { error: "Note cannot be empty", intent };
    let notes = [];
    try { notes = JSON.parse(quote.notesHistory || "[]"); } catch {}
    notes.push({ text, postedAt: new Date().toISOString() });
    await prisma.quote.update({
      where: { id: params.id },
      data:  { notesHistory: JSON.stringify(notes) },
    });
    return { success: true, intent };
  }

  if (intent === "updateTags") {
    const tagsJson = String(formData.get("tagsJson") || "[]");
    await prisma.quote.update({
      where: { id: params.id },
      data:  { tags: tagsJson },
    });
    return { success: true, intent };
  }

  return { error: "Unknown action" };
};

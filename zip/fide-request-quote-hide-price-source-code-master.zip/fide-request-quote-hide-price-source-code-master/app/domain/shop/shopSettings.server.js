/**
 * Backs app.settings.jsx — the merchant's SMTP/mail-provider configuration
 * page (provider choice, credentials, per-template toggles, test send, and
 * the notification recipient email, which actually lives on QuoteConfig).
 *
 * Security-sensitive: SMTP passwords and provider API keys are encrypted at
 * rest via `encrypt()` (lib/encrypt.server.js) before being persisted, and
 * the loader never sends the decrypted secret back to the client — the form
 * re-submits the literal placeholder "••••••••" for an unchanged secret, and
 * the action treats that exact sentinel as "leave the stored value alone"
 * rather than encrypting the dots themselves.
 */
import { authenticate } from "../../core/shopify/shopify.server";
import prisma from "../../db.server";
import { sendEmailForShop } from "../../lib/mailer.server";
import { encrypt } from "../../lib/encrypt.server";
import { isValidEmail as validateEmail } from "../../utils/validation";
import { APP_NAME } from "../../core/branding.server";
import { readEmailText } from "../../core/email/text-labels.server";
import { readPdfText } from "../../core/pdf/text-labels.server";

/**
 * Loads the shop's mail config and its notification recipient email.
 * @returns {Promise<{config: object|null, notifyEmail: string, shop: string, appName: string, emailLabels: object, pdfLabels: object}>}
 *   `config` is the EmailConfig row (encrypted secrets included — the route
 *   component must never render `smtpPassEnc`/`apiKeyEnc` back into a field
 *   value, only the "••••••••" placeholder when a secret is set). `appName`
 *   is this app's own display name (app/config/branding.json), used by the
 *   route's Settings sidebar label.
 */
export const loader = async ({ request }) => {
  const { session } = await authenticate.admin(request);
  const { shop } = session;
  const [config, quoteConfig] = await Promise.all([
    prisma.emailConfig.findUnique({ where: { shop } }),
    prisma.quoteConfig.findUnique({ where: { shop }, select: { notifyEmail: true } }),
  ]);
  return {
    config,
    notifyEmail: quoteConfig?.notifyEmail ?? "",
    shop,
    appName: APP_NAME,
    emailLabels: readEmailText(),
    pdfLabels: readPdfText(),
  };
};

/**
 * Handles three form intents from the mail-settings page:
 *  - `saveSmtp`: persists provider/host/credentials to EmailConfig (encrypting
 *    password/apiKey unless the field still holds the "••••••••" placeholder,
 *    meaning the merchant didn't change it) and the notification recipient to
 *    QuoteConfig.notifyEmail.
 *  - `toggleEmail`: flips a single EmailConfig boolean column; `field` is
 *    validated against an allow-list so this can't be used to write arbitrary
 *    columns.
 *  - `testSmtp`: sends a live test email via the shop's configured mail
 *    server (no DB write).
 * @returns {Promise<object>} `{ success, error?, intent? }` (or `{error}` for
 *   an unrecognized intent); `intent` echoes back which action ran.
 */
export const action = async ({ request }) => {
  const { session } = await authenticate.admin(request);
  const { shop } = session;
  const formData = await request.formData();
  const intent = formData.get("intent");

  if (intent === "saveSmtp") {
    const provider   = formData.get("provider") || "app_default";
    const rawPass    = formData.get("password") || null;
    const rawApiKey  = formData.get("apiKey")   || null;
    const encPass   = rawPass   && rawPass   !== "••••••••" ? encrypt(rawPass)   : undefined;
    const encApiKey = rawApiKey && rawApiKey !== "••••••••" ? encrypt(rawApiKey) : undefined;

    const smtpData = {
      provider,
      smtpEnabled: provider !== "app_default",
      smtpHost:    formData.get("host")      || null,
      smtpPort:    parseInt(formData.get("port") || "587", 10),
      smtpUser:    formData.get("username")  || null,
      fromName:    formData.get("fromName")  || null,
      fromEmail:   formData.get("fromEmail") || null,
      apiRegion:   formData.get("region")    || null,
      ...(encPass   !== undefined ? { smtpPassEnc: encPass }   : {}),
      ...(encApiKey !== undefined ? { apiKeyEnc:   encApiKey } : {}),
    };

    await prisma.emailConfig.upsert({
      where:  { shop },
      create: { shop, ...smtpData },
      update: smtpData,
    });

    // Save notification recipient email to QuoteConfig
    const notifyEmail = formData.get("notifyEmail") || null;
    if (notifyEmail !== null) {
      await prisma.quoteConfig.upsert({
        where:  { shop },
        create: { shop, notifyEmail },
        update: { notifyEmail },
      });
    }

    return { success: true, intent: "saveSmtp" };
  }

  if (intent === "toggleEmail") {
    const labels = readEmailText();
    const field = formData.get("field");
    const value = formData.get("value") === "true";
    const allowed = ["notificationEnabled","autoResponseEnabled","acceptQuoteEnabled","rejectQuoteEnabled"];
    if (!allowed.includes(field)) return { error: labels.errors.invalidToggleField };
    await prisma.emailConfig.upsert({
      where:  { shop },
      create: { shop, [field]: value },
      update: { [field]: value },
    });
    return { success: true, intent: "toggleEmail" };
  }

  if (intent === "testSmtp") {
    const labels = readEmailText();
    const emailConfig = await prisma.emailConfig.findUnique({ where: { shop } }).catch(() => null);
    const toEmail = (formData.get("toEmail") || "").trim();
    const isValidEmail = validateEmail(toEmail);
    if (!isValidEmail) {
      return { success: false, error: labels.errors.invalidTestEmail, intent: "testSmtp" };
    }
    if (!emailConfig?.smtpEnabled && !process.env.GMAIL_USER) {
      return { success: false, error: labels.errors.noMailServer, intent: "testSmtp" };
    }
    try {
      await sendEmailForShop(emailConfig, {
        to:      toEmail,
        subject: labels.testEmailHtml.settingsSubjectTemplate.replace("{appName}", APP_NAME),
        html:    `<div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:32px">
          <h2 style="color:#1a1a18">${labels.testEmailHtml.settingsHeading}</h2>
          <p style="color:#555">${labels.testEmailHtml.settingsBody}</p>
          <p style="color:#888;font-size:12px">${labels.testEmailHtml.settingsSentViaTemplate.replace("{appName}", APP_NAME)}</p>
        </div>`,
      });
      return { success: true, intent: "testSmtp" };
    } catch (err) {
      return { success: false, error: labels.errors.sendFailedTemplate.replace("{message}", err.message), intent: "testSmtp" };
    }
  }

  return { error: readEmailText().errors.unknownIntent };
};

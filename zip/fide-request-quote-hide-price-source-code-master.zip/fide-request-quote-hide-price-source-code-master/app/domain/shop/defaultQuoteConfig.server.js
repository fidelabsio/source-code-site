/**
 * Default QuoteConfig row, seeded the first time a shop is seen — either from
 * the Quote Settings page (quoteSettings.server.js) or the dashboard
 * (dashboard.server.js), whichever the merchant opens first. Not itself a
 * route loader/action — a plain data factory called by both.
 *
 * Keep this in sync with the Prisma QuoteConfig model: every field a merchant
 * can configure needs a sane default here, otherwise the first-ever page load
 * for a new shop will persist `undefined`/missing values for that field.
 */
// Fixed storefront default, independent of the merchant admin's theme.json
// (that file only styles the admin dashboard, never the storefront widget).
const DEFAULT_BUTTON_COLOR = "#1a1a18";

export function defaultQuoteConfigData(shop, shopCurrency) {
  return {
    shop,
    shopCurrency,
    targetMode: "all",
    showOnProductList: false,
    showOnHomepage: false,
    productPageDisplay: "button_only",
    addToQuoteBehaviour: "popup_and_form",
    redirectAfterSubmit: "",
    successMessage: "Thank you! We will be in touch shortly.",
    buttonText: "Request a Quote",
    buttonBgColor: DEFAULT_BUTTON_COLOR,
    buttonTextColor: "#ffffff",
    buttonFontSize: 14,
    buttonBorderRadius: 6,
    buttonFullWidth: true,
    buttonPosition: "below_atc",
    hidePriceMode: "all",
    hidePriceOnProductPage: false,
    hidePriceOnCollectionPage: false,
    hidePriceOnHomePage: false,
    hidePriceOnCartPage: false,
    hidePriceOnly: false,
    hideAddToCart: false,
    hideBuyNow: false,
    hidePriceReplacement: "text",
    replacementText: "Price available on request",
    replacementTextColor: "#b4b2a9",
    requireLogin: false,
    modalTitle: "Request a Quote",
    submitButtonText: "Request a Quote",
    formBtnBgColor: DEFAULT_BUTTON_COLOR,
    formBtnTextColor: "#ffffff",
    formBtnFontSize: 14,
    formBtnBorderRadius: 6,
    showVendorInForm: true,
    showSkuInForm: true,
    showPriceInForm: false,
    showQuotePriceInForm: true,
    showNoteInForm: true,
    widgetEnabled: true,
    widgetButtonText: "Request a Quote",
    widgetAction: "popup",
    widgetPosition: "bottom_right",
    widgetBgColor: "#1a1a18",
    widgetTextColor: "#ffffff",
    toastMessage: "Product added to quote cart.",
    toastBgColor: "#0f172a",
    toastTextColor: "#ffffff",
    toastFontSize: 14,
    toastBorderRadius: 40,
    toastBorderWidth: 0,
    toastBorderColor: "#0f172a",
    toastPosition: "bottom_center",
  };
}

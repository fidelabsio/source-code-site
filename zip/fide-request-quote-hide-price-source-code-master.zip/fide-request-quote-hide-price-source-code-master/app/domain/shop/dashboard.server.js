/**
 * Loader for the app's home dashboard (app._index.jsx) — aggregates quote
 * stats/recent activity for the merchant and lazily auto-provisions
 * per-shop config on first visit.
 *
 * Side effect: on each process's first load per shop, fire-and-forget writes
 * an `app_url` shop metafield (used by the theme-app-extension embed to find
 * the app's public base URL) — failures are swallowed/retried, never surfaced
 * to the merchant.
 */
import { authenticate } from "../../core/shopify/shopify.server";
import prisma from "../../db.server";
import { defaultQuoteConfigData } from "./defaultQuoteConfig.server";
import { APP_NAME } from "../../core/branding.server";
import {
  DASHBOARD_CHECKLIST_COLOR,
  DASHBOARD_STAT_TEXT_COLOR,
  DASHBOARD_STAT_CARD_BACKGROUND_COLOR,
  DASHBOARD_CARD_BACKGROUND_COLOR,
} from "../../core/dashboard/theme.server";
import { readDashboardText } from "../../core/dashboard/text-labels.server";

// In-memory guard so the metafield write is attempted at most once per shop
// per running server process (avoids 2 extra GraphQL calls on every page
// load). Not persisted — resets on redeploy/restart, which is fine since the
// write itself is idempotent.
const _metafieldWritten = new Set();

/**
 * Builds the dashboard's stats, recent quotes and top products for a shop,
 * seeding a default QuoteConfig row if this is the shop's first visit.
 * @returns {Promise<object>} `{ shop, embedEditorUrl, recent, stats, topProducts, shopCurrency, appName, primaryColor, statTextColor, statCardBackgroundColor, cardBackgroundColor, labels }`
 *   — `recent` is the 5 newest Quote records, `stats` totals/rates for the
 *   dashboard cards, `topProducts` the top 5 by request count,
 *   `embedEditorUrl` a deep link into the theme editor for the app embed,
 *   and `appName` this app's own display name (app/config/branding.json),
 *   used by the onboarding checklist copy.
 */
export const loader = async ({ request }) => {
  const { session, admin } = await authenticate.admin(request);
  const { shop } = session;

  const appUrl = process.env.SHOPIFY_APP_URL;
  if (appUrl && !_metafieldWritten.has(shop)) {
    _metafieldWritten.add(shop); // optimistic — prevent retry on next load
    // Fire-and-forget: don't block the page load waiting for this write
    (async () => {
      try {
        const shopRes = await admin.graphql(`#graphql
          query { shop { id } }
        `);
        const { data } = await shopRes.json();
        await admin.graphql(
          `#graphql
          mutation metafieldsSet($metafields: [MetafieldsSetInput!]!) {
            metafieldsSet(metafields: $metafields) { userErrors { field message } }
          }`,
          {
            variables: {
              metafields: [{ ownerId: data.shop.id, namespace: "quote_request", key: "app_url", type: "single_line_text_field", value: appUrl }],
            },
          },
        );
      } catch (e) {
        _metafieldWritten.delete(shop); // allow retry on next load if it failed
        console.warn("Could not write app URL metafield:", e.message);
      }
    })();
  }

  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

  let [allQuotes, topProductsDb, config, shopData] = await Promise.all([
    prisma.quote.findMany({
      where: { shop },
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        quoteNumber: true,
        status: true,
        quoteStatus: true,
        customerName: true,
        customerEmail: true,
        productTitle: true,
        quotedPrice: true,
        merchantReply: true,
        createdAt: true,
      },
    }),
    prisma.quote.groupBy({
      by: ["productTitle"],
      where: { shop },
      _count: { id: true },
      orderBy: { _count: { id: "desc" } },
      take: 5,
    }),
    prisma.quoteConfig.findUnique({ where: { shop } }).catch(() => null),
    admin.graphql("query { shop { currencyCode } }").then((r) => r.json()).catch(() => null),
  ]);

  if (!config) {
    // Also auto-initialize on the dashboard so the app embed works immediately
    config = await prisma.quoteConfig.create({
      data: defaultQuoteConfigData(shop, shopData?.data?.shop?.currencyCode ?? "USD"),
    }).catch(() => null);
  }

  const shopCurrency = shopData?.data?.shop?.currencyCode ?? config?.shopCurrency ?? "USD";
  const total      = allQuotes.length;
  const unread     = allQuotes.filter((q) => q.status === "new").length;
  const replied    = allQuotes.filter((q) => q.status === "replied").length;
  const accepted   = allQuotes.filter((q) => q.quoteStatus === "accepted" || q.quoteStatus === "paid").length;
  const thisMonth  = allQuotes.filter((q) => new Date(q.createdAt) >= startOfMonth).length;
  const revenue    = allQuotes
    .filter((q) => q.quoteStatus === "accepted" || q.quoteStatus === "paid")
    .reduce((sum, q) => sum + (q.quotedPrice || 0), 0);
  const conversionRate = total > 0 ? Math.round((accepted / total) * 100) : 0;

  // Deep-link URL that opens the theme editor directly on our app embed
  // activateAppId = {client_id}/{extension_handle} scrolls to and highlights our embed block
  const CLIENT_ID      = process.env.SHOPIFY_API_KEY;
  const EXT_HANDLE     = "quote-request";
  const embedEditorUrl = `https://${shop}/admin/themes/current/editor?context=apps&activateAppId=${CLIENT_ID}/${EXT_HANDLE}`;

  return {
    shop,
    embedEditorUrl,
    recent: allQuotes.slice(0, 5),
    stats: { total, unread, replied, accepted, thisMonth, revenue, conversionRate },
    topProducts: topProductsDb.map((p) => ({ title: p.productTitle, count: p._count.id })),
    shopCurrency,
    appName: APP_NAME,
    primaryColor: DASHBOARD_CHECKLIST_COLOR(),
    statTextColor: DASHBOARD_STAT_TEXT_COLOR(),
    statCardBackgroundColor: DASHBOARD_STAT_CARD_BACKGROUND_COLOR(),
    cardBackgroundColor: DASHBOARD_CARD_BACKGROUND_COLOR(),
    labels: readDashboardText(),
  };
};

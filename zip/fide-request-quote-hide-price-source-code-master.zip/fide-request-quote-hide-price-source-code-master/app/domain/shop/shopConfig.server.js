/**
 * Storefront embed block config endpoint, reached only via Shopify's App
 * Proxy: GET /apps/{subpath}/api/config
 *
 * authenticate.public.appProxy verifies Shopify's HMAC `signature` query
 * param before the loader runs, so `shop` is always the Shopify-verified
 * domain from the session — never a client-supplied value.
 */

import prisma from "../../db.server";
import { authenticate } from "../../core/shopify/shopify.server";
import { applyRequiredDefaults } from "../quotes/formSchemaDefaults.server";
import { buildCorsHeaders } from "../../utils/cors";

// Fixed storefront defaults, independent of the admin's own theme configs
// (dashboard/quotes/quote-settings theme.json files only style admin pages,
// never the storefront widget — these are plain hardcoded constants, not
// buyer-configurable via JSON).
const DEFAULT_BUTTON_COLOR = "#1a1a18";
const WIDGET_ACCENT_COLOR = "#3b82f6";
const WIDGET_SUCCESS_COLOR = "#1a7f4b";
const WIDGET_WARNING_COLOR = "#f59e0b";
const WIDGET_ERROR_COLOR = "#dc2626";

const CORS = buildCorsHeaders("GET, OPTIONS");

const tryJson = (str, fallback = []) => {
  try { return str ? JSON.parse(str) : fallback; } catch { return fallback; }
};

/**
 * Serves the full storefront widget/behavior config for the calling shop:
 * targeting rules, price-hiding rules, button/modal styling, form schema,
 * etc. Consumed by the theme-app-extension embed via App Proxy, so the
 * response is plain, unauthenticated JSON — access control is entirely
 * `authenticate.public.appProxy`'s HMAC signature check below, not a session.
 * @returns {Promise<Response>} JSON body is a large flat config object (see
 *   the sectioned literal below); 401 with `{error}` if the shop can't be
 *   resolved from the verified App Proxy request.
 */
export const loader = async ({ request }) => {
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS });
  }

  const { session } = await authenticate.public.appProxy(request);
  const shop = session?.shop;

  if (!shop) {
    return Response.json({ error: "Shop not installed" }, { status: 401, headers: CORS });
  }

  const [config, targetProducts, targetConditions, hidePriceProducts, formSchemaRow] =
    await Promise.all([
      prisma.quoteConfig.findUnique({ where: { shop } }),
      prisma.quoteTargetProduct.findMany({ where: { shop } }),
      prisma.quoteTargetCondition.findMany({ where: { shop } }),
      prisma.hidePriceProduct.findMany({ where: { shop } }),
      prisma.formSchema.findUnique({ where: { shop } }),
    ]);

  // Required-by-default backfill: upgrade legacy all-optional schemas so the
  // change reaches existing stores. Persist once (guarded, so it writes at most
  // one time per store), then serve the normalized schema.
  let formSchemaFields = null;
  if (formSchemaRow?.fields) {
    try { formSchemaFields = JSON.parse(formSchemaRow.fields); } catch { formSchemaFields = null; }
  }
  if (formSchemaFields) {
    const { changed } = applyRequiredDefaults(formSchemaFields);
    if (changed) {
      prisma.formSchema
        .update({ where: { shop }, data: { fields: JSON.stringify(formSchemaFields) } })
        .catch((err) => console.error("[shopConfig] required-default backfill failed:", err.message));
    }
  }

  return Response.json(
    {
      // ── Targeting ─────────────────────────────────────────────────────────
      targetMode:       config?.targetMode      ?? "all",
      conditionMatch:   config?.conditionMatch  ?? "all",
      targetProducts:   targetProducts.map((p) => ({
        productId:     p.productId,
        productTitle:  p.productTitle,
        productHandle: p.productHandle,
        productImage:  p.productImage,
      })),
      targetConditions: targetConditions.map((c) => ({
        field:    c.field,
        operator: c.operator,
        value:    c.value,
      })),
      targetCollections: tryJson(config?.targetCollections, []),

      // ── Price hiding ───────────────────────────────────────────────────────
      hidePriceMode:    config?.hidePriceMode  ?? "none",
      hideForGuestsOnly: config?.hideForGuestsOnly ?? false,
      hideAddToCart:    config?.hideAddToCart  ?? false,
      hideBuyNow:       config?.hideBuyNow     ?? false,
      hidePriceOnly:    config?.hidePriceOnly  ?? false,
      // Per-product hide list (for hidePriceMode === "specific_products")
      hidePriceCollections: tryJson(config?.hidePriceCollections, []),
      hidePriceProducts: hidePriceProducts.map((p) => ({
        productId:    p.productId,
        productHandle: p.productHandle,
      })),
      // Per-page scope
      hidePriceOnProductPage:    config?.hidePriceOnProductPage    ?? false,
      hidePriceOnCollectionPage: config?.hidePriceOnCollectionPage ?? false,
      hidePriceOnHomePage:       config?.hidePriceOnHomePage       ?? false,
      hidePriceOnCartPage:       config?.hidePriceOnCartPage       ?? false,
      // Replacement text
      hidePriceReplacement: config?.hidePriceReplacement ?? "text",
      replacementText:      config?.replacementText      ?? "Price available on request",
      replacementTextColor: config?.replacementTextColor ?? "#b4b2a9",

      // ── Display ────────────────────────────────────────────────────────────
      isEnabled:           config != null,
      showOnProductPage:   config?.showOnProductPage  ?? true,
      showOnProductList:   config?.showOnProductList  ?? false,
      showOnHomepage:      config?.showOnHomepage     ?? false,
      productPageDisplay:  config?.productPageDisplay ?? "button_only",
      showVariantsSelector: config?.showVariantsSelector ?? false,

      // ── Behaviour ──────────────────────────────────────────────────────────
      addToQuoteBehaviour:  config?.addToQuoteBehaviour  ?? "popup_and_form",
      requireLogin:         config?.requireLogin          ?? false,
      requiredTags:         tryJson(config?.requiredTags, []),
      allowPriceEdit:       config?.allowPriceEdit        ?? false,
      addCartToQuote:       config?.addCartToQuote        ?? false,
      buttonPosition:       config?.buttonPosition        ?? "below_atc",
      buttonFullWidth:      config?.buttonFullWidth       ?? true,

      // ── Post-submit ────────────────────────────────────────────────────────
      // Empty = show the success message inside the modal (no navigation).
      redirectAfterSubmit:      config?.redirectAfterSubmit      ?? "",

      // ── Quote button style ─────────────────────────────────────────────────
      buttonText:         config?.buttonText         ?? "Request a Quote",
      buttonColor:        config?.buttonBgColor       ?? DEFAULT_BUTTON_COLOR,
      buttonBgColor:      config?.buttonBgColor       ?? DEFAULT_BUTTON_COLOR,
      buttonTextColor:    config?.buttonTextColor     ?? "#ffffff",
      buttonFontSize:     config?.buttonFontSize      ?? 14,
      buttonBorderRadius: config?.buttonBorderRadius  ?? 6,

      // ── Fixed semantic state colors (buyer-themed, not merchant-configurable) ─
      accentColor:  WIDGET_ACCENT_COLOR,
      successColor: WIDGET_SUCCESS_COLOR,
      warningColor: WIDGET_WARNING_COLOR,
      errorColor:   WIDGET_ERROR_COLOR,

      // ── Modal ──────────────────────────────────────────────────────────────
      modalTitle:              config?.modalTitle              ?? "Request a Quote",
      submitButtonText:        config?.submitButtonText        ?? "Send Quote Request",
      thankYouMessage:         config?.successMessage ?? "Thank you! We will be in touch shortly.",
      successMessage:          config?.successMessage ?? "Thank you! We will be in touch shortly.",
      showProductImageInModal: config?.showProductImageInModal ?? true,
      showStepIndicator:       config?.showStepIndicator       ?? true,
      showTrustSignals:        config?.showTrustSignals        ?? true,

      // ── Form submit button style (separate from the quote button) ──────────
      formBtnBgColor:      config?.formBtnBgColor    ?? DEFAULT_BUTTON_COLOR,
      formBtnTextColor:    config?.formBtnTextColor   ?? "#ffffff",
      formBtnFontSize:     config?.formBtnFontSize    ?? 14,
      formBtnBorderRadius: config?.formBtnBorderRadius ?? 6,

      // ── Product info shown inside modal ────────────────────────────────────
      showVendorInForm:      config?.showVendorInForm      ?? false,
      showSkuInForm:         config?.showSkuInForm         ?? false,
      showOptionInForm:      config?.showOptionInForm      ?? false,
      showPriceInForm:       config?.showPriceInForm       ?? false,
      showQuotePriceInForm:  config?.showQuotePriceInForm  ?? false,
      showNoteInForm:        config?.showNoteInForm        ?? false,

      // ── Default form fields (when no Form Builder schema) ──────────────────
      showPhone:    true,
      showCompany:  true,
      showQuantity: true,
      showMessage:  true,

      // ── Currency ───────────────────────────────────────────────────────────
      shopCurrency: config?.shopCurrency ?? "USD",

      // ── Quote widget ───────────────────────────────────────────────────────
      widgetEnabled:     config?.widgetEnabled     ?? false,
      widgetButtonText:  config?.widgetButtonText  ?? "Request a Quote",
      widgetAction:      config?.widgetAction      ?? "popup",
      widgetPosition:    config?.widgetPosition    ?? "bottom_right",
      widgetBgColor:     config?.widgetBgColor     ?? "#1a1a18",
      widgetTextColor:   config?.widgetTextColor   ?? "#ffffff",

      // ── Notification toast ─────────────────────────────────────────────────
      toastEnabled:      config?.toastEnabled      ?? true,
      successToastEnabled: config?.successToastEnabled ?? true,
      toastMessage:      config?.toastMessage      ?? "Product added to quote cart.",
      toastBgColor:      config?.toastBgColor      ?? "#0f172a",
      toastTextColor:    config?.toastTextColor    ?? "#ffffff",
      toastFontSize:     config?.toastFontSize     ?? 14,
      toastBorderRadius: config?.toastBorderRadius ?? 40,
      toastBorderWidth:  config?.toastBorderWidth  ?? 0,
      toastBorderColor:  config?.toastBorderColor  ?? "#0f172a",
      toastPosition:     config?.toastPosition     ?? "bottom_center",

      // ── Custom form schema from Form Builder ───────────────────────────────
      formSchema: formSchemaFields,
    },
    {
      headers: {
        ...CORS,
        "Cache-Control": "public, max-age=5",
      },
    },
  );
};

/** This endpoint is read-only; any non-GET/OPTIONS verb is rejected outright. */
export const action = async () => {
  return Response.json({ error: "Method not allowed" }, { status: 405, headers: CORS });
};

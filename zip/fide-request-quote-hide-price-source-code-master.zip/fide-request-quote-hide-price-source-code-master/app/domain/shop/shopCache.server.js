/**
 * Per-shop in-memory cache for data that changes rarely (currently just the
 * shop's currency code). Populated by heavy loaders (e.g. quotesList.server.js,
 * which already fetches it via the Admin API) so lighter loaders/actions can
 * read it back without an extra GraphQL round-trip.
 *
 * Process-local and unbounded: it lives only as long as this server instance,
 * is never invalidated/expired, and is never read anywhere in this codebase —
 * only written. Treat it as a write-side cache warmer for future readers, not
 * a currently load-bearing dependency.
 */
const _currency = new Map();

/** Records a shop's currency code for later (fire-and-forget; no-op if `currency` is falsy). */
export const setCachedCurrency = (shop, currency) => { if (currency) _currency.set(shop, currency); };

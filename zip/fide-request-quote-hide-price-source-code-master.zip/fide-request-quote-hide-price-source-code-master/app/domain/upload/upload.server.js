/**
 * Storefront upload endpoint, reached only via Shopify's App Proxy:
 *   POST /apps/{subpath}/api/upload  (multipart/form-data, field name: files[])
 * Returns: { urls: string[] }
 *
 * authenticate.public.appProxy verifies Shopify's HMAC `signature` query
 * param before the action runs, so `shop` is always the Shopify-verified
 * domain from the session — never a client-supplied header.
 */
import { authenticate } from "../../core/shopify/shopify.server";
import { uploadFile } from "../../lib/cloudinary.server";
import { buildCorsHeaders } from "../../utils/cors";

const CORS = buildCorsHeaders("POST, OPTIONS");

const MAX_FILES = 5;
const MAX_BYTES = 10 * 1024 * 1024; // 10 MB

/**
 * Loader — only handles the CORS preflight (`OPTIONS`); any other method is
 * rejected since uploads only ever happen via `action`/POST.
 * @returns {Response} 204 for OPTIONS, 405 otherwise.
 */
export const loader = async ({ request }) => {
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS });
  }
  return Response.json({ error: "Method not allowed" }, { status: 405, headers: CORS });
};

/**
 * Action — accepts up to {@link MAX_FILES} multipart files (`files[]`, each
 * under {@link MAX_BYTES}) from the storefront quote-request widget and
 * uploads them to Cloudinary under a per-shop folder.
 *
 * @param {Request} request - Must be `multipart/form-data` with a `files[]`
 *   field; validated via Shopify's app-proxy signature (see file header).
 * @returns {Response} `{ urls: string[] }` — one secure Cloudinary URL per
 *   uploaded file, in the same order as submitted.
 */
export const action = async ({ request }) => {
  if (request.method !== "POST") {
    return Response.json({ error: "Method not allowed" }, { status: 405, headers: CORS });
  }

  const { session } = await authenticate.public.appProxy(request);
  if (!session?.shop) {
    return Response.json({ error: "Shop not installed" }, { status: 401, headers: CORS });
  }
  const shop = session.shop
    .replace(".myshopify.com", "")
    .replace(/[^a-z0-9-]/gi, "-");

  let formData;
  try {
    formData = await request.formData();
  } catch {
    return Response.json({ error: "Invalid multipart data" }, { status: 400, headers: CORS });
  }

  const entries = formData.getAll("files[]");
  const files   = entries.filter((f) => f instanceof File && f.size > 0);

  if (files.length === 0) {
    return Response.json({ error: "No files provided" }, { status: 400, headers: CORS });
  }
  if (files.length > MAX_FILES) {
    return Response.json(
      { error: `Too many files. Maximum ${MAX_FILES} allowed.` },
      { status: 400, headers: CORS }
    );
  }
  const oversized = files.find((f) => f.size > MAX_BYTES);
  if (oversized) {
    return Response.json(
      { error: `"${oversized.name}" exceeds the 10 MB limit.` },
      { status: 400, headers: CORS }
    );
  }

  try {
    const urls = await Promise.all(
      files.map(async (file) => {
        const buffer = Buffer.from(await file.arrayBuffer());
        const { secure_url } = await uploadFile(buffer, {
          folder: `quote-requests/${shop}`,
          resource_type: "auto",
        });
        return secure_url;
      })
    );
    return Response.json({ urls }, { headers: CORS });
  } catch (err) {
    console.error("[upload] Cloudinary error:", err.message);
    return Response.json(
      { error: "Upload failed. Please try again." },
      { status: 500, headers: CORS }
    );
  }
};

import { Button, InlineStack } from "@shopify/polaris";
import { useIsMobile } from "../../hooks/useIsMobile";

/**
 * Primary action pinned to the top of the page content so it stays visible
 * while a long form scrolls. The Polaris Page header action scrolls out of
 * view on both desktop and mobile, which forces the merchant to scroll back
 * up to save — this bar keeps Save/Create reachable at all times.
 *
 * Full-width button on mobile, right-aligned on desktop. Used on the quote
 * detail page (app/routes/app.quote.$id.jsx), which renders its own save bar
 * here instead of the App Bridge one (see useQuoteDetail.js for why).
 *
 * @param {object} props
 * @param {string} [props.label="Save"] - Button text.
 * @param {() => void} props.onAction - Click handler for the button.
 * @param {boolean} [props.loading=false] - Shows the button's loading spinner and disables interaction while true.
 */
export function StickySaveBar({ label = "Save", onAction, loading = false }) {
  const isMobile = useIsMobile();
  return (
    <div
      style={{
        position: "sticky",
        top: 0,
        zIndex: 20,
        padding: "10px 12px",
        background: "var(--p-color-bg-surface)",
        border: "1px solid var(--p-color-border)",
        borderRadius: "var(--p-border-radius-300)",
        boxShadow: "var(--p-shadow-200)",
      }}
    >
      <InlineStack align={isMobile ? "center" : "end"} blockAlign="center">
        <div style={{ width: isMobile ? "100%" : "auto" }}>
          <Button
            variant="primary"
            fullWidth={isMobile}
            size={isMobile ? "large" : "medium"}
            onClick={onAction}
            loading={loading}
          >
            {label}
          </Button>
        </div>
      </InlineStack>
    </div>
  );
}

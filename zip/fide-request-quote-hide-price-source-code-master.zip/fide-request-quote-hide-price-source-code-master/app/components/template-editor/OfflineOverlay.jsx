import { useEffect, useState } from "react";

// Friendly full-page "you're offline" screen.
//
// Deliberately plain HTML + inline CSS — NO Polaris components and NO remote
// assets:
//   - Offline means CDN assets (images, fonts) fail to load, so a remote
//     illustration would render broken.
//   - The route ErrorBoundary renders OUTSIDE the Polaris/App Bridge providers,
//     so Polaris components would throw there. Plain markup works everywhere.
/**
 * Takes no props. Rendered by OfflineOverlay (below) for proactive detection,
 * and also rendered directly by the root ErrorBoundary in app/routes/app.jsx
 * as a fallback when a render error looks like a lost connection.
 */
export function OfflineScreen() {
  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 600, // above Polaris modals/toasts (~519)
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "#f1f1f1",
        padding: "2rem",
        fontFamily:
          "Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
        color: "#303030",
        textAlign: "center",
      }}
    >
      <div style={{ maxWidth: 420 }}>
        <div
          aria-hidden="true"
          style={{ fontSize: 48, lineHeight: 1, marginBottom: 16 }}
        >
          📡
        </div>
        <h1 style={{ fontSize: 20, fontWeight: 650, margin: "0 0 8px" }}>
          You&rsquo;re offline
        </h1>
        <p
          style={{
            fontSize: 14,
            lineHeight: 1.5,
            margin: "0 0 20px",
            color: "#616161",
          }}
        >
          Your internet connection was lost. Check your network &mdash; this
          page reconnects automatically once you&rsquo;re back online.
        </p>
        <button
          type="button"
          onClick={() => window.location.reload()}
          style={{
            appearance: "none",
            border: "1px solid #898f94",
            borderRadius: 8,
            background: "#fff",
            color: "#303030",
            fontSize: 14,
            fontWeight: 600,
            padding: "8px 16px",
            cursor: "pointer",
          }}
        >
          Try again
        </button>
      </div>
    </div>
  );
}

// Proactive offline detection. Renders OfflineScreen while the browser reports
// it is offline, and removes itself automatically when the connection returns.
/**
 * Mounted once near the root of the authenticated app shell (app/routes/app.jsx)
 * so every page shows the offline screen immediately on a lost connection,
 * without waiting for a network request to fail first. Takes no props.
 */
export function OfflineOverlay() {
  const [online, setOnline] = useState(true);

  useEffect(() => {
    // navigator.onLine is only meaningful on the client.
    setOnline(navigator.onLine);

    const goOnline = () => setOnline(true);
    const goOffline = () => setOnline(false);
    window.addEventListener("online", goOnline);
    window.addEventListener("offline", goOffline);
    return () => {
      window.removeEventListener("online", goOnline);
      window.removeEventListener("offline", goOffline);
    };
  }, []);

  if (online) return null;
  return <OfflineScreen />;
}

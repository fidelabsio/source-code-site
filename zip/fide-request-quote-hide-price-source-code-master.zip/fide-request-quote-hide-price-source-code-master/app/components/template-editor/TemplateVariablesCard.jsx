import { Card, BlockStack, Text, InlineStack } from "@shopify/polaris";

// Shared by the email and PDF template editors — both list the merge-field
// tokens ({customer_name}, {product_title}, ...) a template can use.
/**
 * Used by app/routes/app.email-edit.$id.jsx and app/routes/app.pdf-edit.$id.jsx.
 *
 * @param {object} props
 * @param {Array<{key: string, desc: string}>} props.variables - Token/description pairs to render, in the order given.
 */
export function TemplateVariablesCard({ variables }) {
  return (
    <Card>
      <BlockStack gap="300">
        <Text variant="headingSm" as="h3" fontWeight="semibold">
          Available template variables
        </Text>
        <BlockStack gap="300">
          {variables.map((v) => (
            <InlineStack key={v.key} gap="200" blockAlign="start" wrap={false}>
              <div style={{ marginTop: 2, flexShrink: 0, color: "#8c9196" }}>
                <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M10 2a1 1 0 0 1 1 1v1.07A7.002 7.002 0 0 1 17 11a7 7 0 1 1-14 0 7.002 7.002 0 0 1 6-6.93V3a1 1 0 0 1 1-1Zm0 4a5 5 0 1 0 0 10A5 5 0 0 0 10 6Zm0 2a1 1 0 0 1 .993.883L11 9v2.586l1.707 1.707a1 1 0 0 1-1.32 1.497l-.094-.083-2-2A1 1 0 0 1 9 12V9a1 1 0 0 1 1-1Z" />
                </svg>
              </div>
              <Text variant="bodySm" as="p">
                <span style={{ fontWeight: 600 }}>{v.key}</span>{": "}{v.desc}
              </Text>
            </InlineStack>
          ))}
        </BlockStack>
      </BlockStack>
    </Card>
  );
}

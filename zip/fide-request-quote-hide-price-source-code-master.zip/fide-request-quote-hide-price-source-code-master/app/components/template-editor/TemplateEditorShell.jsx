import { Page, Box, InlineGrid, BlockStack } from "@shopify/polaris";

// Shared page shell for the email and PDF template editors: title/back
// action, App Bridge save bar, an optional success banner, and a two-column
// layout with a sticky preview on the right. The two editors differ in
// everything inside `leftPanel`/`preview` (different fields, different
// preview rendering) — that's genuine, not duplication, so it stays local to
// each route.
/**
 * Used by app/routes/app.email-edit.$id.jsx and app/routes/app.pdf-edit.$id.jsx.
 *
 * @param {object} props
 * @param {string} props.title - Page title.
 * @param {string} [props.subtitle] - Page subtitle.
 * @param {() => void} props.onBack - Back action handler (navigates back to Settings).
 * @param {string} props.saveBarId - Id used for the App Bridge `<ui-save-bar>` element and its child Save/Discard buttons.
 * @param {boolean} props.isSaving - Disables the Save/Discard buttons and shows the Save button's loading state.
 * @param {() => void} props.onSave - Save button click handler.
 * @param {() => void} props.onDiscard - Discard button click handler.
 * @param {React.ReactNode} [props.successBanner] - Optional banner rendered above the two-column layout (e.g. after a successful save).
 * @param {boolean} props.isMobile - Collapses the two-column layout to a single stacked column.
 * @param {number} [props.previewStickyTop=20] - `top` offset (px) for the sticky preview column.
 * @param {boolean} [props.wrapInBlockStack=false] - Wraps the whole body in a BlockStack instead of rendering it as a bare fragment.
 * @param {React.ReactNode} props.leftPanel - Editor form content rendered in the left column.
 * @param {React.ReactNode} props.preview - Live preview content rendered in the sticky right column.
 */
export function TemplateEditorShell({
  title,
  subtitle,
  onBack,
  saveBarId,
  isSaving,
  onSave,
  onDiscard,
  successBanner,
  isMobile,
  previewStickyTop = 20,
  wrapInBlockStack = false,
  leftPanel,
  preview,
}) {
  const body = (
    <>
      <ui-save-bar id={saveBarId}>
        <button
          variant="primary"
          id={`${saveBarId}-save`}
          onClick={onSave}
          disabled={isSaving}
          loading={isSaving ? "" : undefined}
        >
          Save
        </button>
        <button id={`${saveBarId}-discard`} onClick={onDiscard} disabled={isSaving}>
          Discard
        </button>
      </ui-save-bar>

      {successBanner}

      <InlineGrid columns={isMobile ? 1 : ["oneThird", "twoThirds"]} gap="500" alignItems="start">
        <BlockStack gap="400">{leftPanel}</BlockStack>
        <div style={{ position: "sticky", top: previewStickyTop }}>{preview}</div>
      </InlineGrid>

      <Box paddingBlockEnd="600" />
    </>
  );

  return (
    <Page title={title} subtitle={subtitle} backAction={{ content: "Settings", onAction: onBack }}>
      {wrapInBlockStack ? <BlockStack gap="400">{body}</BlockStack> : body}
    </Page>
  );
}

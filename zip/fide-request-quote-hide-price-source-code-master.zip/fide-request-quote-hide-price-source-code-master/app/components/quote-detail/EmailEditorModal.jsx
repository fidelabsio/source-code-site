import { Modal, BlockStack, Text, TextField, Checkbox, Divider } from "@shopify/polaris";

/**
 * Two-pane "edit + live preview" modal shared by the Accept and Reject quote
 * actions: subject/heading/message/button-text fields plus a checkbox on the
 * left, a rendered email preview on the right. The two callers differ in
 * which variables are available, whether there's an extra field (Accept's
 * checkout-link override), and how the preview header/message are built —
 * those are passed in rather than hard-coded, so this stays one component
 * instead of two near-identical modals.
 */
export function EmailEditorModal({
  open, // Modal visibility.
  onClose, // Called on Cancel, backdrop dismiss, and after the primary/secondary action fires.
  title, // Modal title (e.g. "Accept quote", "Reject quote").
  isMobile, // Switches the two-pane layout to a single stacked column.
  toEmail, // Recipient shown in "Email to" and the preview footer.
  subject, onSubjectChange, // Subject line field + its setter.
  heading, onHeadingChange, // Preview heading field + its setter.
  content, onContentChange, // Message body field + its setter.
  ctaText, onCtaTextChange, // Button-text field + its setter; field is disabled when showCta is false.
  showCta, onShowCtaChange, // Whether the CTA button appears in the email + the checkbox's setter.
  ctaCheckboxLabel = "Show button in email", // Label text for the showCta checkbox.
  extraFields = null, // Extra form content rendered below the checkbox (e.g. Accept's checkout-link override); caller-supplied so this one component serves both Accept and Reject.
  variables, // [key, value] pairs rendered under "Available variables".
  variablesTruncate = false, // Truncate long variable values instead of wrapping them.
  previewHeader, // Content rendered in the preview pane's header strip.
  previewHeaderStyle = { padding: "12px 20px" }, // Inline style override merged into the preview header strip.
  previewMessage, // Message text shown in the preview pane (may differ from `content`, e.g. with variables substituted in).
  previewExtra = null, // Extra content rendered in the preview between the message and the "Sent to" footer.
  ctaPadding = "8px 20px", // Inline padding for the rendered CTA button in the preview.
  primaryActionLabel, // Label for the modal's primary action button.
  onPrimaryAction, // Called (then onClose) when the primary action is clicked.
  secondaryActionLabel, // Label for the modal's secondary action button.
  onSecondaryAction, // Called (then onClose) when the secondary action is clicked.
  destructive = false, // Styles the primary action as destructive (used by Reject).
  isBusy = false, // Shows a loading spinner on the primary action button.
}) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      title={title}
      size="large"
      primaryAction={{
        content: primaryActionLabel,
        destructive,
        loading: isBusy,
        onAction: () => {
          onPrimaryAction();
          onClose();
        },
      }}
      secondaryActions={[
        {
          content: secondaryActionLabel,
          onAction: () => {
            onSecondaryAction();
            onClose();
          },
        },
        { content: "Cancel", onAction: onClose },
      ]}
    >
      <Modal.Section flush>
        <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "1fr 1fr", minHeight: isMobile ? "auto" : 480 }}>

          {/* Left — editable fields */}
          <div style={{ padding: "20px 24px", borderRight: isMobile ? "none" : "1px solid #e1e3e5", borderBottom: isMobile ? "1px solid #e1e3e5" : "none", overflowY: "auto" }}>
            <BlockStack gap="400">

              <BlockStack gap="100">
                <Text variant="headingSm" fontWeight="semibold" as="h3">Email to</Text>
                <div style={{ background: "#f6f6f7", border: "1px solid #e1e3e5", borderRadius: 8, padding: "8px 12px" }}>
                  <Text variant="bodySm" tone="subdued">{toEmail}</Text>
                </div>
              </BlockStack>

              <TextField label="Subject" value={subject} onChange={onSubjectChange} autoComplete="off" />

              <Divider />

              <Text variant="headingSm" fontWeight="semibold" as="h3">Email body</Text>

              <TextField label="Heading" value={heading} onChange={onHeadingChange} autoComplete="off" />

              <TextField label="Message" value={content} onChange={onContentChange} multiline={4} autoComplete="off" />

              <TextField label="Button text" value={ctaText} onChange={onCtaTextChange} autoComplete="off" disabled={!showCta} />

              <Checkbox label={ctaCheckboxLabel} checked={showCta} onChange={onShowCtaChange} />

              {extraFields && (
                <>
                  <Divider />
                  {extraFields}
                </>
              )}

              <Divider />

              <BlockStack gap="200">
                <Text variant="bodySm" fontWeight="semibold" tone="subdued">Available variables</Text>
                {variables.map(([key, val]) => (
                  <div key={key} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8 }}>
                    <Text variant="bodySm" as="span">
                      <span style={{ fontFamily: "monospace", background: "#f6f6f7", padding: "1px 6px", borderRadius: 4, fontSize: 12 }}>{key}</span>
                    </Text>
                    <Text variant="bodySm" tone="subdued" as="span" truncate={variablesTruncate}>{val}</Text>
                  </div>
                ))}
              </BlockStack>

            </BlockStack>
          </div>

          {/* Right — live preview */}
          <div style={{ padding: "20px 24px", background: "#f6f6f7", overflowY: "auto" }}>
            <BlockStack gap="300">
              <Text variant="headingSm" fontWeight="semibold" as="h3">Preview</Text>

              <div style={{ background: "#fff", border: "1px solid #e1e3e5", borderRadius: 8, padding: "10px 14px" }}>
                <Text variant="bodySm" as="p">
                  <span style={{ fontWeight: 600 }}>Subject: </span>
                  {subject || <span style={{ color: "#8c9196" }}>No subject</span>}
                </Text>
              </div>

              <div style={{ background: "#fff", border: "1px solid #e1e3e5", borderRadius: 8, overflow: "hidden" }}>
                <div style={{ background: "#f6f6f7", borderBottom: "1px solid #e1e3e5", display: "flex", alignItems: "center", justifyContent: "center", ...previewHeaderStyle }}>
                  {previewHeader}
                </div>
                <div style={{ padding: "24px 28px 18px", textAlign: "center" }}>
                  <p style={{ fontSize: 17, fontWeight: 700, margin: "0 0 10px", color: "#202223" }}>
                    {heading || <span style={{ color: "#8c9196" }}>Heading</span>}
                  </p>
                  <p style={{ fontSize: 13, color: "#6d7175", lineHeight: 1.6, margin: "0 0 18px", whiteSpace: "pre-wrap" }}>
                    {previewMessage || <span style={{ color: "#c9cccf" }}>Message</span>}
                  </p>
                  {showCta && ctaText && (
                    <span style={{ display: "inline-block", background: "#202223", color: "#fff", padding: ctaPadding, borderRadius: 6, fontSize: 13, fontWeight: 600, cursor: "default" }}>
                      {ctaText}
                    </span>
                  )}
                </div>
                {previewExtra}
                <div style={{ borderTop: "1px solid #e1e3e5", padding: "12px 28px", textAlign: "center" }}>
                  <p style={{ fontSize: 11, color: "#8c9196", margin: 0 }}>
                    Sent to {toEmail}
                  </p>
                </div>
              </div>

            </BlockStack>
          </div>

        </div>
      </Modal.Section>
    </Modal>
  );
}

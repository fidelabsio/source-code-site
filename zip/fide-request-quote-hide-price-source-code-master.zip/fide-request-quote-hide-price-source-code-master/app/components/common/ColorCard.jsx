import { Box } from "@shopify/polaris";

/**
 * Same visual shell as Polaris <Card> (ShadowBevel + Box: boxShadow "100",
 * borderRadius "300"), but with an arbitrary buyer-configured hex background —
 * Polaris's own Card/Box `background` prop only accepts fixed design tokens,
 * not raw hex, so it can't take a value read from a theme.json config file.
 */
// eslint-disable-next-line react/prop-types -- presentational wrapper, not worth a PropTypes dependency
export function ColorCard({ background, padding, children }) {
  return (
    <div style={{ borderRadius: "var(--p-border-radius-300)", boxShadow: "var(--p-shadow-100)", overflow: "hidden", background }}>
      {padding ? <Box padding={padding}>{children}</Box> : children}
    </div>
  );
}

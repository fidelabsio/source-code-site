import { useState } from "react";
import { Popover, Box, ColorPicker, TextField } from "@shopify/polaris";
import { hsbToHex, hexToHsb } from "../../utils/color";

const HEX_RE = /^#[0-9a-fA-F]{6}$/;

// A labeled swatch that opens a Popover <ColorPicker> (HSB) plus a synced hex
// <TextField>. Owns its own popover-open state and the HSB<->hex conversion —
// callers just pass/receive a hex string.
/**
 * Used throughout app/routes/app.quote-settings.jsx for every color field
 * (text/button/widget/toast/form-button colors).
 *
 * @param {object} props
 * @param {string} props.value - Current color as a 6-digit hex string (e.g. "#ffffff").
 * @param {(hex: string) => void} props.onChange - Called with the new hex string when the popover's ColorPicker changes, or when a valid hex is typed into the text field.
 * @param {boolean} [props.disabled=false] - Disables both the swatch popover and the hex text field.
 */
export function ColorSwatchPicker({ value, onChange, disabled = false }) {
  const [popoverActive, setPopoverActive] = useState(false);
  const hsb = hexToHsb(value);

  return (
    <>
      <Popover
        active={popoverActive}
        activator={
          <div
            onClick={() => !disabled && setPopoverActive(true)}
            style={{
              width: 36,
              height: 36,
              borderRadius: 6,
              background: value,
              border: "1px solid #ccc",
              cursor: disabled ? "default" : "pointer",
              opacity: disabled ? 0.5 : 1,
            }}
          />
        }
        onClose={() => setPopoverActive(false)}
      >
        <Box padding="400">
          <ColorPicker onChange={(next) => onChange(hsbToHex(next))} color={hsb} />
        </Box>
      </Popover>
      <TextField
        label=""
        labelHidden
        value={value}
        onChange={(v) => HEX_RE.test(v) && onChange(v)}
        autoComplete="off"
        maxLength={7}
        disabled={disabled}
      />
    </>
  );
}

import { useCallback } from "react";
import { useAppBridge } from "@shopify/app-bridge-react";
import { TextField, Button, Box, BlockStack, InlineGrid, InlineStack, Text, Divider, Icon } from "@shopify/polaris";
import { SearchIcon, XSmallIcon } from "@shopify/polaris-icons";

const GID_PREFIX = { product: "gid://shopify/Product/", collection: "gid://shopify/Collection/" };

// Search box + Browse button that opens Shopify's resourcePicker, plus a list
// of the selected resources with a remove (x) button per row. Used for both
// product and collection selection across the settings page.
/**
 * Used in app/routes/app.quote-settings.jsx for the product/collection
 * allow-list and deny-list pickers.
 *
 * @param {object} props
 * @param {"product"|"collection"} props.type - Which Shopify resource type the picker searches/selects; also determines the GID prefix used when talking to `shopify.resourcePicker`.
 * @param {Array<{id: string, title: string, handle?: string, image?: string}>} props.selected - Currently selected resources, keyed by bare (non-GID) id.
 * @param {(next: Array<object>) => void} props.onChange - Called with the full updated `selected` array after picking new resources or removing one via its (x) button.
 * @param {string} [props.placeholder] - Placeholder text for the read-only search field that opens the picker.
 */
export function ResourcePickerList({ type, selected, onChange, placeholder }) {
  const shopify = useAppBridge();
  const prefix = GID_PREFIX[type];

  const openPicker = useCallback(async () => {
    const picked = await shopify.resourcePicker({
      type,
      multiple: true,
      selectionIds: selected.map((r) => ({ id: `${prefix}${r.id}` })),
    });
    if (!picked) return;
    onChange(
      picked.map((r) => ({
        id: r.id.replace(prefix, ""),
        title: r.title,
        handle: r.handle || "",
        image: type === "product" ? (r.images?.[0]?.originalSrc || "") : (r.image?.originalSrc || ""),
      }))
    );
  }, [shopify, type, prefix, selected, onChange]);

  return (
    <BlockStack gap="200">
      <InlineGrid columns="1fr auto" gap="200" alignItems="center">
        <TextField
          label=""
          labelHidden
          placeholder={placeholder}
          autoComplete="off"
          readOnly
          onFocus={openPicker}
          prefix={<Icon source={SearchIcon} />}
        />
        <Button onClick={openPicker}>Browse</Button>
      </InlineGrid>

      {selected.length > 0 && (
        <Box borderWidth="025" borderColor="border" borderRadius="200">
          {selected.map((r, idx) => (
            <div key={r.id}>
              {idx > 0 && <Divider />}
              <Box paddingInlineStart="300" paddingInlineEnd="300" paddingBlockStart="200" paddingBlockEnd="200">
                <InlineStack blockAlign="center">
                  <div style={{ flex: 1 }}>
                    <Text variant="bodySm" fontWeight="semibold">{r.title}</Text>
                  </div>
                  <Button
                    variant="plain"
                    icon={XSmallIcon}
                    accessibilityLabel={`Remove ${r.title}`}
                    onClick={() => onChange(selected.filter((x) => x.id !== r.id))}
                  />
                </InlineStack>
              </Box>
            </div>
          ))}
        </Box>
      )}
    </BlockStack>
  );
}

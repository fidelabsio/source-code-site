/**
 * Reads app/config/pdf/theme.json — colors for the generated quote PDF.
 *
 * Each color is exported as a function, re-reading the file on every call
 * rather than caching it at module load — Vite's dev server only watches
 * `import`ed files for HMR, not raw fs.readFileSync targets, so a cached
 * read would otherwise require a full server restart on every edit.
 *
 * Each entry in the JSON is `{ value, usedIn }` rather than a bare hex
 * string — `usedIn` documents exactly which UI element that color reaches,
 * for whoever is editing the file without reading this codebase.
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const themePath = join(dirname(fileURLToPath(import.meta.url)), "../../config/pdf/theme.json");

function readTheme() {
  try {
    return JSON.parse(readFileSync(themePath, "utf-8"));
  } catch {
    return {};
  }
}

export const PDF_HEADER_ACCENT_COLOR = () => readTheme().PDF_HEADER_ACCENT_COLOR?.value || "#2c6ecb";
export const PDF_PAGE_BACKGROUND_COLOR = () => readTheme().PDF_PAGE_BACKGROUND_COLOR?.value || "#ffffff";

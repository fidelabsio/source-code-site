/**
 * Reads app/config/pdf/text-labels.json — buyer-editable UI copy for the
 * PDF/Invoice Editor page (app.pdf-edit.$id.jsx): both templates' default
 * seed content (title, description, document-title/header/footer defaults,
 * merge-variable descriptions) and the editor page's own chrome (field
 * labels, help text, headings, the live-preview mock's static text).
 *
 * Merges per-section against DEFAULTS (recursively) so a partial edit or a
 * missing/malformed file can't blank out the rest of the page — every field
 * this page reads always resolves to a value. `variables` arrays replace
 * wholesale rather than merging (a buyer editing them is replacing the
 * whole list, not patching one entry).
 *
 * Re-read on every call rather than cached at module load — Vite's dev
 * server only watches `import`ed files for HMR, not raw fs.readFileSync
 * targets, so a cached read would otherwise require a full server restart
 * on every edit.
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const textPath = join(dirname(fileURLToPath(import.meta.url)), "../../config/pdf/text-labels.json");

const DEFAULTS = {
  quoteTemplate: {
    title: "Quote PDF",
    description: "Template used to convert quote to PDF file",
    documentTitleDefault: "Quote #{quote_number}",
    headerNoteDefault: "Thank you for your interest! Please review your quote below.",
    footerNoteDefault: "This quote is valid for 30 days. Contact us for any questions.",
    variables: [
      { key: "{quote_number}", desc: "Unique quote reference number" },
      { key: "{quote_date}", desc: "Date the quote was created" },
      { key: "{customer_name}", desc: "Full name of the customer" },
      { key: "{customer_email}", desc: "Email address of the customer" },
      { key: "{product_title}", desc: "Product requested for quote" },
      { key: "{quantity}", desc: "Requested quantity" },
      { key: "{offer_price}", desc: "Quoted price offered" },
      { key: "{quote_message}", desc: "Message submitted by the customer" },
      { key: "{store_name}", desc: "Your store name" },
      { key: "{store_address}", desc: "Your store address" },
    ],
  },
  invoiceTemplate: {
    title: "Invoice PDF",
    description: "Template used to convert a draft order to PDF file",
    documentTitleDefault: "Invoice #{invoice_number}",
    headerNoteDefault: "Thank you for your order! Please find your invoice details below.",
    footerNoteDefault: "Payment is due within 14 days. Thank you for your business.",
    variables: [
      { key: "{invoice_number}", desc: "Unique invoice reference number" },
      { key: "{invoice_date}", desc: "Date the invoice was issued" },
      { key: "{due_date}", desc: "Payment due date" },
      { key: "{customer_name}", desc: "Full name of the customer" },
      { key: "{customer_email}", desc: "Email address of the customer" },
      { key: "{customer_address}", desc: "Billing address of the customer" },
      { key: "{order_number}", desc: "Draft order number" },
      { key: "{line_items}", desc: "List of ordered products" },
      { key: "{subtotal}", desc: "Order subtotal before tax" },
      { key: "{tax}", desc: "Tax amount applied" },
      { key: "{total}", desc: "Total amount due" },
      { key: "{store_name}", desc: "Your store name" },
      { key: "{store_address}", desc: "Your store address" },
    ],
  },
  page: {
    statusHeading: "Status",
    enabledLabel: "Enabled",
    disabledLabel: "Disabled",
    documentSettingsHeading: "Document Settings",
    documentTitleLabel: "Document Title",
    documentTitleHelpText: "Use {quote_number} or {invoice_number} for auto-numbering",
    accentColorLabel: "Accent Color",
    accentColorPlaceholder: "#2c6ecb",
    companyInfoHeading: "Company Info",
    companyNameLabel: "Company Name",
    companyNamePlaceholder: "Your Store",
    logoUrlLabel: "Logo URL",
    logoUrlPlaceholder: "https://yourstore.com/logo.png",
    logoUrlHelpText: "Publicly accessible image URL",
    addressLabel: "Address",
    addressPlaceholder: "123 Store St, City, Country",
    phoneLabel: "Phone",
    phonePlaceholder: "+1 555 000 0000",
    emailLabel: "Email",
    emailPlaceholder: "hello@yourstore.com",
    contentHeading: "Content",
    headerNoteLabel: "Header Note",
    headerNoteHelpText: "Shown at the top of the document body",
    footerNoteLabel: "Footer Note",
    footerNoteHelpText: "Shown at the bottom of the document",
    previewHeading: "Preview",
    savedToast: "PDF template saved",
    savedBanner: "PDF template saved successfully.",
  },
  preview: {
    companyNameFallback: "Your Company Name",
    companyAddressFallback: "123 Store Street, City, Country",
    documentTitleFallbackQuote: "Quote #001",
    documentTitleFallbackInvoice: "Invoice #001",
    datePrefix: "Date:",
    duePrefix: "Due:",
    billToLabel: "BILL TO",
    columnDescription: "Description",
    columnQty: "Qty",
    columnPrice: "Price",
    subtotalPrefix: "Subtotal:",
    taxPrefix: "Tax:",
    totalPrefix: "Total:",
  },
  settingsPage: {
    heading: "PDF Templates",
    descriptionIntro: "These are two separate, independent templates — editing one never changes the other.",
    descriptionQuoteBold: "Quote PDF",
    descriptionQuoteRest: "is used when a quote is exported, and",
    descriptionInvoiceBold: "Invoice PDF",
    descriptionInvoiceRest: "is used when a draft order is exported. Each keeps its own layout, document title, and merge variables.",
    independentTemplateBadge: "Independent template",
    editAction: "Edit",
    items: {
      quote: {
        title: "Quote PDF",
        description: "Generated when a customer's quote is exported to PDF. Has its own layout and variables — independent from the Invoice PDF.",
      },
      invoice: {
        title: "Invoice PDF",
        description: "Generated when a draft order is exported to PDF. Has its own layout and variables — independent from the Quote PDF.",
      },
    },
  },
};

function isPlainObject(val) {
  return Boolean(val) && typeof val === "object" && !Array.isArray(val);
}

function mergeDeep(base, custom) {
  if (!custom) return base;
  const out = { ...base };
  for (const key of Object.keys(base)) {
    const customVal = custom[key];
    if (isPlainObject(customVal) && isPlainObject(base[key])) {
      out[key] = mergeDeep(base[key], customVal);
    } else if (customVal !== undefined) {
      out[key] = customVal;
    }
  }
  return out;
}

export function readPdfText() {
  let custom = {};
  try {
    custom = JSON.parse(readFileSync(textPath, "utf-8"));
  } catch {
    custom = {};
  }
  return {
    quoteTemplate: mergeDeep(DEFAULTS.quoteTemplate, custom.quoteTemplate),
    invoiceTemplate: mergeDeep(DEFAULTS.invoiceTemplate, custom.invoiceTemplate),
    page: mergeDeep(DEFAULTS.page, custom.page),
    preview: mergeDeep(DEFAULTS.preview, custom.preview),
    settingsPage: mergeDeep(DEFAULTS.settingsPage, custom.settingsPage),
  };
}

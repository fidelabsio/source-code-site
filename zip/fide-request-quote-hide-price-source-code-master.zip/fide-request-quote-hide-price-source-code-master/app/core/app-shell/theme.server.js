/**
 * Reads app/config/app-shell/theme.json — colors for the root admin layout
 * (app/routes/app.jsx), which every admin page nests inside. Kept separate
 * from dashboard/theme.json since this isn't Dashboard-specific — it's
 * global chrome (e.g. the Polaris brand button color) that reaches every
 * page, not just the Dashboard.
 *
 * Each color is exported as a function, re-reading the file on every call
 * rather than caching it at module load — Vite's dev server only watches
 * `import`ed files for HMR, not raw fs.readFileSync targets, so a cached
 * read would otherwise require a full server restart on every edit.
 *
 * Each entry in the JSON is `{ value, usedIn }` rather than a bare hex
 * string — `usedIn` documents exactly which UI element that color reaches,
 * for whoever is editing the file without reading this codebase.
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const themePath = join(dirname(fileURLToPath(import.meta.url)), "../../config/app-shell/theme.json");

function readTheme() {
  try {
    return JSON.parse(readFileSync(themePath, "utf-8"));
  } catch {
    return {};
  }
}

export const ADMIN_BUTTON_BRAND_COLOR = () => readTheme().ADMIN_BUTTON_BRAND_COLOR?.value || "#1a1a18";

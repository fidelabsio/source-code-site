/**
 * Reads app/config/quote-settings/theme.json — colors scoped only to the
 * Quote Settings page's live preview. Kept separate from quotes/theme.json
 * (Quotes list + Quote Detail) and the storefront widget's own colors so
 * each can be themed independently without side effects on the others.
 *
 * Each color is exported as a function, re-reading the file on every call
 * rather than caching it at module load — Vite's dev server only watches
 * `import`ed files for HMR, not raw fs.readFileSync targets, so a cached
 * read would otherwise require a full server restart on every edit.
 *
 * Each entry in the JSON is `{ value, usedIn }` rather than a bare hex
 * string — `usedIn` documents exactly which UI element that color reaches,
 * for whoever is editing the file without reading this codebase.
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const themePath = join(dirname(fileURLToPath(import.meta.url)), "../../config/quote-settings/theme.json");

function readTheme() {
  try {
    return JSON.parse(readFileSync(themePath, "utf-8"));
  } catch {
    return {};
  }
}

export const QUOTE_SETTINGS_ACCENT_COLOR = () => readTheme().QUOTE_SETTINGS_ACCENT_COLOR?.value || "#3b82f6";
export const QUOTE_SETTINGS_SUCCESS_COLOR = () => readTheme().QUOTE_SETTINGS_SUCCESS_COLOR?.value || "#1a7f4b";
export const QUOTE_SETTINGS_ERROR_COLOR = () => readTheme().QUOTE_SETTINGS_ERROR_COLOR?.value || "#dc2626";

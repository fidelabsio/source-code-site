/**
 * Reads app/config/branding.json — the ONLY file a buyer needs to edit to
 * rebrand this product's name, transactional-email logo, and email
 * signature across transactional emails, the pre-install login/landing
 * pages, and admin onboarding copy. This module is just plumbing that
 * re-exports those values as named constants; nothing here should need
 * editing — change app/config/branding.json instead.
 *
 * Does NOT cover the Shopify Partner app name
 * (`shopify.app.toml`'s `name` field) or the theme app extension's display
 * name (`extensions/quote-request/shopify.extension.toml`) — those are
 * static manifests evaluated by Shopify CLI at setup time, not at runtime,
 * so a JSON config file can't drive them. See README's "Rebranding a new
 * instance" section for the full list of what to edit by hand.
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

// Plain readFileSync + JSON.parse rather than a JSON import attribute
// (`import ... with { type: "json" }`) — this project's ESLint parser
// doesn't yet support that syntax, and this reads identically under plain
// Node (unit tests) and Vite's SSR bundle.
const brandingPath = join(dirname(fileURLToPath(import.meta.url)), "../config/branding.json");
const branding = JSON.parse(readFileSync(brandingPath, "utf-8"));

export const APP_NAME = branding.APP_NAME || "Quote Request";

// Both optional and blank by default — when unset, transactional emails
// render exactly as before (colored header + title, no signature line).
export const EMAIL_LOGO_URL = branding.EMAIL_LOGO_URL || "";
export const EMAIL_SIGNATURE = branding.EMAIL_SIGNATURE || "";

/**
 * Reads app/config/app-proxy.json, a generated copy of `[app_proxy].subpath`
 * from shopify.app.toml — the ONLY file to edit when the App Proxy subpath
 * changes. scripts/sync-app-proxy-subpath.js copies that toml value into this
 * JSON (so Node doesn't need a TOML parser) and into the browser-side theme
 * extension JS (extensions/quote-request/assets/quote-request-utils.js — see
 * app.PROXY_SUBPATH there) on predev/prebuild/predeploy — the extension is a
 * static bundle deployed separately from this app, so it cannot import
 * either file at runtime. Do not hand-edit app-proxy.json; it gets
 * overwritten from the toml on the next sync.
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const appProxyPath = join(dirname(fileURLToPath(import.meta.url)), "../config/app-proxy.json");
const appProxy = JSON.parse(readFileSync(appProxyPath, "utf-8"));

export const APP_PROXY_SUBPATH = appProxy.subpath || "quote-request";

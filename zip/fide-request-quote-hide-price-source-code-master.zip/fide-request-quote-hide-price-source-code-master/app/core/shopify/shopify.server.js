// The Shopify SDK singleton — OAuth config, session storage, and the
// authenticate/login/registerWebhooks helpers every route and domain module
// imports. This is framework wiring with no business logic of its own;
// nothing outside this file should need to know HOW it's configured, only
// import the named exports below. See app/domain/auth/auth.server.js for the
// OAuth login flow built on top of this.
import "@shopify/shopify-app-react-router/adapters/node";
import {
  ApiVersion,
  AppDistribution,
  shopifyApp,
} from "@shopify/shopify-app-react-router/server";
import { PrismaSessionStorage } from "@shopify/shopify-app-session-storage-prisma";
import prisma from "../../db.server";

const shopify = shopifyApp({
  apiKey: process.env.SHOPIFY_API_KEY,
  apiSecretKey: process.env.SHOPIFY_API_SECRET || "",
  apiVersion: ApiVersion.October25,
  scopes: process.env.SCOPES?.split(","),
  appUrl: process.env.SHOPIFY_APP_URL || "",
  authPathPrefix: "/auth",
  sessionStorage: new PrismaSessionStorage(prisma),
  distribution: AppDistribution.AppStore,
  future: {
    expiringOfflineAccessTokens: true,
  },
  ...(process.env.SHOP_CUSTOM_DOMAIN
    ? { customShopDomains: [process.env.SHOP_CUSTOM_DOMAIN] }
    : {}),
});

export default shopify;
export const apiVersion = ApiVersion.October25;
/** Adds Shopify's required embedded-app response headers (CSP frame-ancestors, etc.) — used by route `headers()` exports via `boundary.headers`. */
export const addDocumentResponseHeaders = shopify.addDocumentResponseHeaders;
/** `authenticate.admin(request)` / `authenticate.public(...)` — verifies the session and returns `{ session, admin, redirect, ... }` for admin routes and App Proxy/webhook routes respectively. */
export const authenticate = shopify.authenticate;
/** Authenticate a request that isn't tied to an active embedded-admin session (e.g. background/offline access). */
export const unauthenticated = shopify.unauthenticated;
/** Kicks off the OAuth install/login redirect — used by `app/domain/auth/auth.server.js`. */
export const login = shopify.login;
/** Registers this app's webhook subscriptions with Shopify for a given shop (called after install/auth). */
export const registerWebhooks = shopify.registerWebhooks;
/** The Prisma-backed session storage instance — mostly needed only by SDK internals, rarely imported directly elsewhere. */
export const sessionStorage = shopify.sessionStorage;

/**
 * Reads app/config/quotes/text-labels.json — buyer-editable UI copy for the
 * Quotes list and Quote Detail admin pages. Merges per-field against
 * DEFAULTS recursively (to arbitrary depth) so a partial edit or a
 * missing/malformed file can't blank out the rest of either page — every
 * label these pages read always resolves to a string.
 *
 * Re-read on every call rather than cached at module load — Vite's dev
 * server only watches `import`ed files for HMR, not raw fs.readFileSync
 * targets, so a cached read would otherwise require a full server restart
 * on every edit.
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const textPath = join(dirname(fileURLToPath(import.meta.url)), "../../config/quotes/text-labels.json");

const DEFAULTS = {
  quotesList: {
    pageTitle: "Quote Lists",
    createQuoteAction: "Create quote",
    exportCsvAction: "Export CSV",
    tabs: {
      all: "All quotes",
      unread: "Unread",
      read: "Read",
      cancelled: "Cancelled",
      accepted: "Accepted",
      done: "Done",
    },
    statusBadges: {
      new: "Unread",
      read: "Read",
      accepted: "Accepted",
      rejected: "Rejected",
      paid: "Paid",
      quoted: "Quoted",
    },
    sortOptions: {
      dateDesc: "Newest first",
      dateAsc: "Oldest first",
      nameAsc: "Name A → Z",
      nameDesc: "Name Z → A",
    },
    searchPlaceholder: "Search quotes…",
    searchFilterTitle: "Search & filter",
    sortTitlePrefix: "Sort:",
    emptyFilteredHeading: "No quotes found",
    emptyFilteredBody: "Try adjusting your search or filter to find what you're looking for.",
    emptyHeading: "You have no quote requests yet",
    emptyBody: "Once customers submit quote requests from your storefront, they will appear here. Make sure your app embed is active in your theme settings.",
    emptyViewSetupGuideAction: "View setup guide",
    emptyGoToSettingsAction: "Go to settings",
    columnQuoteId: "Quote ID",
    columnStatus: "Status",
    columnCustomer: "Customer",
    columnDate: "Date",
    columnActions: "Actions",
    paginationSummaryTemplate: "{from}–{to} of {total}",
    selectedCountSuffix: "selected",
    deleteButtonLabel: "Delete",
    testBadgeText: "🧪 TEST",
    tooltipViewEdit: "View / Edit",
    tooltipConvertToDraft: "Convert to draft order",
    tooltipPrintPdf: "Print PDF",
    tooltipDuplicate: "Duplicate",
    tooltipDelete: "Delete",
    printWindow: {
      titleTemplate: "Quote — {name}",
      generatedOnPrefix: "Generated on",
      rowCustomer: "Customer",
      rowEmail: "Email",
      rowPhone: "Phone",
      rowCompany: "Company",
      rowProduct: "Product",
      rowQuantity: "Quantity",
      rowMessage: "Message",
      rowStatus: "Status",
      rowSubmitted: "Submitted",
    },
    quoteDetailModal: {
      titleTemplate: "Quote — {name}",
      titleFallback: "Quote Details",
      closeAction: "Close",
      markAsReadAction: "Mark as Read",
      acceptQuoteAction: "Accept Quote",
      rejectQuoteAction: "Reject Quote",
      printPdfAction: "Print PDF",
      termProduct: "Product",
      termCustomer: "Customer",
      termEmail: "Email",
      termPhone: "Phone",
      termCompany: "Company",
      termQty: "Qty",
      termOfferedPrice: "Customer's Offered Price",
      termItems: "Items",
      termMessage: "Message",
      termStatus: "Status",
      termSubmitted: "Submitted",
      termPreviousReply: "Previous Reply",
      itemQtyPrefix: "Qty:",
      itemPricePrefix: "Price:",
      itemOfferedPrefix: "Offered:",
      itemSkuPrefix: "SKU:",
      itemVendorPrefix: "Vendor:",
      itemNotePrefix: "Note:",
    },
    deleteModal: {
      title: "Delete quote?",
      confirmAction: "Delete",
      cancelAction: "Cancel",
      bodyTemplate: "This will permanently delete the quote from {name}. This cannot be undone.",
    },
    bulkDeleteModal: {
      titleTemplate: "Delete {count} quote{plural}?",
      confirmActionTemplate: "Delete {count} quote{plural}",
      cancelAction: "Cancel",
      bodyTemplate: "This will permanently delete {count} selected quote{plural}. This cannot be undone.",
    },
    convertModal: {
      title: "Convert to draft order?",
      confirmAction: "Convert",
      cancelAction: "Cancel",
      bodyTemplate: "A Shopify draft order will be created for {name} with product {product}.",
      note: "You can set the price and send the invoice from Shopify Admin after conversion.",
    },
  },
  quoteDetail: {
    page: {
      newTitle: "New Quote",
      newSubtitle: "Fill in the details and save to create this quote",
      subtitleTemplate: "Updated {date}",
      backAction: "Quotes",
      tooltipPreviousQuote: "Previous quote",
      tooltipNextQuote: "Next quote",
    },
    saveBar: {
      createAction: "Create Quote",
      saveAction: "Save",
    },
    headerActions: {
      accept: "Accept",
      reject: "Reject",
      paymentReceived: "Payment received",
      reopen: "Reopen",
      moreActionsTitle: "More actions",
      convertToDraft: "Convert to draft order",
      duplicate: "Duplicate",
      printPdf: "Print / Save PDF",
    },
    statusBadges: {
      new: "New",
      viewed: "Viewed",
      quoted: "Quoted",
      accepted: "Accepted",
      rejected: "Rejected",
      paid: "Payment received",
    },
    banners: {
      unsavedChanges: "You have unsaved changes. Click the ‘Save’ button to apply and save your changes.",
      acceptedTitle: "Quote accepted — waiting for payment",
      acceptedRecordAction: "Record payment received",
      checkoutLinkSentLabel: "Checkout link sent to customer:",
      paidTitle: "Payment received — quote complete",
      rejectedTitle: "Quote rejected by merchant",
      rejectedReopenAction: "Reopen quote",
      draftOrderTitleTemplate: "Draft order{name} created in Shopify Admin",
      draftOrderInvoiceLabel: "Invoice link:",
    },
    productsCard: {
      heading: "Products",
      searchPlaceholder: "Search products to add…",
      columnProduct: "Product",
      columnQty: "Qty",
      columnQuotePrice: "Quote price",
      columnTotal: "Total",
      qtyFieldLabel: "Qty",
      priceFieldLabel: "Price",
      vendorPrefix: "Vendor:",
      skuPrefix: "SKU:",
      customerOfferPrefix: "Customer quote:",
      notePrefix: "Note:",
      lineTotalLabel: "Line total",
      removeProductAction: "Remove product",
      alreadyAddedToast: "Already added",
      productsAddedToastTemplate: "{count} product{plural} added",
    },
    paymentCard: {
      heading: "Payment",
      subtotalLabel: "Subtotal",
      discountLabel: "Discount",
      shippingLabel: "Shipping",
      taxLabel: "Tax",
      totalLabel: "Total",
      discountExceedsSubtotalTemplate: "Cannot exceed subtotal ({amount})",
      discountExceedsSubtotalToast: "Discount can't be more than the subtotal",
    },
    timelineCard: {
      heading: "Timeline",
      composePlaceholder: "Leave a comment...",
      postAction: "Post",
      visibilityNote: "Only you and your staff can see comments",
      eventQuoteSubmitted: "Quote submitted",
      eventViewedByMerchant: "Viewed by merchant",
      eventQuoteAccepted: "Quote accepted",
      eventPaymentReceived: "Payment received",
      eventQuoteRejected: "Quote rejected",
    },
    customerCard: {
      heading: "Customer",
      quoteCountTooltipTemplate: "{count} quote{plural} from this customer",
      quoteCountBadgeTemplate: "{count} quote{plural}",
      editAction: "Edit",
      doneAction: "Done",
      fieldName: "Name",
      fieldEmail: "Email",
      fieldPhone: "Phone",
      fieldMessage: "Message",
      shippingHeading: "Shipping address",
      fieldStreet: "Street",
      fieldCity: "City",
      fieldDistrict: "District",
      fieldState: "State",
      fieldCountry: "Country",
      fieldPostal: "Postal code",
      noShippingAddress: "No shipping address provided",
      additionalInfoHeading: "Additional info",
    },
    tagsCard: {
      heading: "Tags",
      searchPlaceholder: "Search or add a tag",
      addTagActionTemplate: 'Add "{tag}"',
    },
    acceptModal: {
      title: "Accept quote & notify customer",
      ctaCheckboxLabel: "Show checkout button in email",
      checkoutLinkFieldLabel: "Checkout link (optional)",
      checkoutLinkPlaceholder: "Leave blank to auto-generate from quote",
      checkoutLinkHelpText: "A Shopify draft order checkout link is created automatically. Any override must be a link to your Shopify store — non-Shopify URLs are ignored and the auto-generated link is used instead.",
      variableQuotePriceFallback: "— (set a quoted price first)",
      variableCheckoutLinkPlaceholder: "Auto-generated checkout URL",
      previewStoreFallback: "Your Store",
      previewCheckoutPlaceholder: "[auto-generated]",
      checkoutLinkPreviewLabel: "Checkout Link",
      checkoutLinkAutoGenNote: "Auto-generated when you send",
      primaryActionLabel: "Accept & Send Email",
      secondaryActionLabel: "Accept without email",
      defaultEmailSubjectTemplate: "Your quote for {productTitle} has been accepted!",
      defaultEmailHeading: "Your quote has been accepted!",
      defaultEmailContent: "Great news, {customer_name}! Your quote for {product_title} has been accepted at {quote_price}. Click the button below to complete your purchase.",
      defaultEmailAction: "Complete Purchase →",
    },
    rejectModal: {
      title: "Reject quote & notify customer",
      primaryActionLabel: "Reject & Send Email",
      secondaryActionLabel: "Reject without email",
      defaultEmailSubjectTemplate: "Update on your quote request for {productTitle}",
      defaultEmailHeading: "Quote Update",
      defaultEmailContentTemplate: "We're sorry, {customerName}. Unfortunately we are unable to fulfill your quote request for {productTitle} at this time.",
      defaultEmailAction: "Shop Now",
    },
    draftOrderModal: {
      title: "Draft order created",
      doneAction: "Done",
      bodyTemplate: "Draft order {name} has been created in Shopify Admin.",
      viewInvoiceAction: "View invoice link",
    },
    attachments: {
      downloadTooltip: "Download",
      downloadAllTemplate: "↓ Download all ({count})",
      lightboxDownload: "↓ Download",
      lightboxDownloadAll: "↓ Download all",
    },
    pdfPrint: {
      docTitleTemplate: "Quote {number}",
      customerHeading: "Customer",
      nameLabel: "Name",
      companyLabel: "Company",
      emailLabel: "Email",
      phoneLabel: "Phone",
      productsHeading: "Products",
      columnProduct: "Product",
      columnQty: "Qty",
      columnUnitPrice: "Unit Price",
      columnTotal: "Total",
      summaryHeading: "Summary",
      subtotalLabel: "Subtotal",
      discountLabel: "Discount",
      shippingLabel: "Shipping",
      taxLabel: "Tax",
      totalLabel: "Total",
      notesHeading: "Notes from customer",
    },
    toasts: {
      statusUpdated: "Status updated",
      quoteSaved: "Quote saved",
      accepted: "Quote accepted",
      acceptedWithEmail: "Quote accepted — email sent to customer",
      rejected: "Quote rejected",
      rejectedWithEmail: "Quote rejected — email sent to customer",
      paymentReceived: "Payment received recorded",
      reopened: "Quote reopened",
      duplicated: "Quote duplicated",
      draftOrderCreatedTemplate: "Draft order {name} created",
      noteAdded: "Note added",
      tagsSaved: "Tags saved",
      genericDone: "Done",
      fixHighlightedFields: "Please fix the highlighted fields",
    },
    validation: {
      priceRequired: "Price required",
    },
  },
};

// Recursive merge — handles arbitrarily nested sections (both quotesList's one
// level and quoteDetail's section->field shape) without needing per-field
// special-casing. Arrays and other non-plain-object values are replaced
// wholesale rather than merged.
function isPlainObject(val) {
  return Boolean(val) && typeof val === "object" && !Array.isArray(val);
}

function mergeDeep(base, custom) {
  if (!custom) return base;
  const out = { ...base };
  for (const key of Object.keys(base)) {
    const customVal = custom[key];
    if (isPlainObject(customVal) && isPlainObject(base[key])) {
      out[key] = mergeDeep(base[key], customVal);
    } else if (customVal !== undefined) {
      out[key] = customVal;
    }
  }
  return out;
}

export function readQuotesText() {
  let custom = {};
  try {
    custom = JSON.parse(readFileSync(textPath, "utf-8"));
  } catch {
    custom = {};
  }
  return {
    quotesList: mergeDeep(DEFAULTS.quotesList, custom.quotesList),
    quoteDetail: mergeDeep(DEFAULTS.quoteDetail, custom.quoteDetail),
  };
}

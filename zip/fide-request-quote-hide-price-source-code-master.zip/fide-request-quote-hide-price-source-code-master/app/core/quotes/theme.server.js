/**
 * Reads app/config/quotes/theme.json — colors scoped only to the Quotes
 * list and Quote Detail admin pages. The storefront widget's own colors
 * live separately in widget-theme.server.js, and Quote Settings' preview
 * colors in quote-settings-theme.server.js, so all three can be edited
 * independently of each other.
 *
 * Each color is exported as a function, re-reading the file on every call
 * rather than caching it at module load — Vite's dev server only watches
 * `import`ed files for HMR, not raw fs.readFileSync targets, so a cached
 * read would otherwise require a full server restart on every edit.
 *
 * Each entry in the JSON is `{ value, usedIn }` rather than a bare hex
 * string — `usedIn` documents exactly which UI element that color reaches,
 * for whoever is editing the file without reading this codebase.
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const themePath = join(dirname(fileURLToPath(import.meta.url)), "../../config/quotes/theme.json");

function readTheme() {
  try {
    return JSON.parse(readFileSync(themePath, "utf-8"));
  } catch {
    return {};
  }
}

export const QUOTES_LIST_COLOR = () => readTheme().QUOTES_LIST_COLOR?.value || "#1a1a18";
export const QUOTES_LIST_SUCCESS_COLOR = () => readTheme().QUOTES_LIST_SUCCESS_COLOR?.value || "#1a7f4b";
export const QUOTES_LIST_WARNING_COLOR = () => readTheme().QUOTES_LIST_WARNING_COLOR?.value || "#f59e0b";
export const QUOTE_DETAIL_ACCENT_COLOR = () => readTheme().QUOTE_DETAIL_ACCENT_COLOR?.value || "#5c6ac4";
export const QUOTE_DETAIL_LINK_COLOR = () => readTheme().QUOTE_DETAIL_LINK_COLOR?.value || "#2c6ecb";
export const QUOTES_LIST_CARD_BACKGROUND_COLOR = () => readTheme().QUOTES_LIST_CARD_BACKGROUND_COLOR?.value || "#ffffff";
export const QUOTE_DETAIL_CARD_BACKGROUND_COLOR = () => readTheme().QUOTE_DETAIL_CARD_BACKGROUND_COLOR?.value || "#ffffff";

/**
 * Reads app/config/dashboard/theme.json — colors scoped only to the admin
 * Dashboard page. The app-wide Polaris button brand color lives separately
 * in app-shell-theme.server.js, since it isn't Dashboard-specific.
 *
 * Each color is exported as a function, re-reading the file on every call
 * rather than caching it at module load — Vite's dev server only watches
 * `import`ed files for HMR, not raw fs.readFileSync targets, so a cached
 * read would otherwise require a full server restart on every edit.
 *
 * Each entry in the JSON is `{ value, usedIn }` rather than a bare hex
 * string — `usedIn` documents exactly which UI element that color reaches,
 * for whoever is editing the file without reading this codebase.
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const themePath = join(dirname(fileURLToPath(import.meta.url)), "../../config/dashboard/theme.json");

function readTheme() {
  try {
    return JSON.parse(readFileSync(themePath, "utf-8"));
  } catch {
    return {};
  }
}

export const DASHBOARD_CHECKLIST_COLOR = () => readTheme().DASHBOARD_CHECKLIST_COLOR?.value || "#1a1a18";
export const DASHBOARD_STAT_TEXT_COLOR = () => readTheme().DASHBOARD_STAT_TEXT_COLOR?.value || "#1a1a18";
export const DASHBOARD_STAT_CARD_BACKGROUND_COLOR = () => readTheme().DASHBOARD_STAT_CARD_BACKGROUND_COLOR?.value || "#ffffff";
export const DASHBOARD_CARD_BACKGROUND_COLOR = () => readTheme().DASHBOARD_CARD_BACKGROUND_COLOR?.value || "#ffffff";

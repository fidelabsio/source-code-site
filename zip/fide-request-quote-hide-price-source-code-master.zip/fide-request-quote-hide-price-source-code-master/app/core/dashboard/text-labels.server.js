/**
 * Reads app/config/dashboard/text-labels.json — buyer-editable UI copy for
 * the admin Dashboard page (headings, button labels, empty states, column
 * headers, status badge text). Merges per-section against DEFAULTS so a
 * partial edit (or a missing/malformed file) can't blank out the rest of
 * the page — every field the Dashboard reads always resolves to a string.
 *
 * Re-read on every call rather than cached at module load — Vite's dev
 * server only watches `import`ed files for HMR, not raw fs.readFileSync
 * targets, so a cached read would otherwise require a full server restart
 * on every edit.
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const textPath = join(dirname(fileURLToPath(import.meta.url)), "../../config/dashboard/text-labels.json");

const DEFAULTS = {
  pageTitle: "Overview",
  setupGuide: {
    heading: "Setup guide",
    descriptionIntro: "Follow these steps to start using the {appName} app. For help getting started, check out our",
    videoTutorialLinkText: "Video Tutorial",
    descriptionJoiner: "and",
    helpDocsLinkText: "Help Docs.",
    stepsCompletedSuffix: "steps completed",
    dismissLabel: "Dismiss",
    expandLabel: "Expand",
    collapseLabel: "Collapse",
    steps: [
      {
        title: "Activate app embed in Shopify",
        description: "Turn on the {appName} embed in your theme's App Embeds, then click Save — your quote button will appear on the storefront. Requires an Online Store 2.0 theme (all current free and most premium themes); older “vintage” themes don't support app embeds.",
        primaryLabel: "Open App Embeds",
        doneLabel: "I've done it",
      },
      {
        title: "Configure your quote request form",
        description: "Set up your button text, colors, and the fields shown on your quote request form.",
        primaryLabel: "Go to settings",
        doneLabel: "I've done it",
      },
      {
        title: "Confirm your quote form is working",
        description: "Visit your storefront and submit a test quote to confirm everything is set up correctly.",
        primaryLabel: "View your store",
        doneLabel: "I've done it",
      },
    ],
  },
  statCards: {
    totalQuotes: "Total Quotes",
    thisMonth: "This Month",
    accepted: "Accepted",
    revenue: "Revenue",
  },
  recentQuotes: {
    heading: "Recent Quotes",
    totalSuffix: "total",
    viewAllLabel: "View all",
    emptyTitle: "No quotes yet",
    emptyDescription: "Quote requests from your storefront will appear here.",
    columnCustomer: "Customer",
    columnProduct: "Product",
    columnStatus: "Status",
    columnDate: "Date",
    statusUnread: "Unread",
    statusRead: "Read",
    statusReplied: "Sent mail",
    missingValuePlaceholder: "—",
  },
  topProducts: {
    heading: "Top Requested Products",
    emptyText: "No quote data yet.",
  },
  summary: {
    heading: "Summary",
    unread: "Unread",
    replied: "Replied",
    conversionRate: "Conversion rate",
    acceptedRevenue: "Accepted revenue",
  },
};

const mergeSection = (base, custom) => ({ ...base, ...(custom || {}) });

export function readDashboardText() {
  let custom = {};
  try {
    custom = JSON.parse(readFileSync(textPath, "utf-8"));
  } catch {
    custom = {};
  }

  const customSteps = custom.setupGuide?.steps;
  const steps = Array.isArray(customSteps)
    ? DEFAULTS.setupGuide.steps.map((step, i) => ({ ...step, ...(customSteps[i] || {}) }))
    : DEFAULTS.setupGuide.steps;

  return {
    pageTitle: custom.pageTitle || DEFAULTS.pageTitle,
    setupGuide: { ...mergeSection(DEFAULTS.setupGuide, custom.setupGuide), steps },
    statCards: mergeSection(DEFAULTS.statCards, custom.statCards),
    recentQuotes: mergeSection(DEFAULTS.recentQuotes, custom.recentQuotes),
    topProducts: mergeSection(DEFAULTS.topProducts, custom.topProducts),
    summary: mergeSection(DEFAULTS.summary, custom.summary),
  };
}

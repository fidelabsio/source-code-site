/**
 * Reads app/config/email/theme.json — the file a buyer edits to restyle the
 * fixed visual accents in transactional emails (as opposed to per-shop
 * merchant color settings, which already live in Quote Settings and are
 * unaffected by this file). This module is just plumbing; nothing here
 * should need editing.
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const emailThemePath = join(dirname(fileURLToPath(import.meta.url)), "../../config/email/theme.json");
const emailTheme = JSON.parse(readFileSync(emailThemePath, "utf-8"));

export const EMAIL_HEADER_COLOR = emailTheme.EMAIL_HEADER_COLOR || "#1a1a18";
export const EMAIL_CTA_COLOR = emailTheme.EMAIL_CTA_COLOR || "#1a1a18";
export const EMAIL_ACCEPT_COLOR = emailTheme.EMAIL_ACCEPT_COLOR || "#1a7f4b";
export const EMAIL_REJECT_COLOR = emailTheme.EMAIL_REJECT_COLOR || "#4a4a48";
export const EMAIL_EDITOR_LINK_COLOR = emailTheme.EMAIL_EDITOR_LINK_COLOR || "#2c6ecb";

/**
 * Reads app/config/email/text-labels.json — buyer-editable UI copy shared by
 * the Settings page's Email tab (app.settings.jsx) and the Email Template
 * Editor (app.email-edit.$id.jsx). `templates` is the single source of truth
 * for each template's title/description/default content — both pages read
 * from it rather than keeping their own separate hardcoded copies.
 *
 * Merges per-section against DEFAULTS (recursively) so a partial edit or a
 * missing/malformed file can't blank out the rest of either page — every
 * field these pages read always resolves to a value.
 *
 * Re-read on every call rather than cached at module load — Vite's dev
 * server only watches `import`ed files for HMR, not raw fs.readFileSync
 * targets, so a cached read would otherwise require a full server restart
 * on every edit.
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const textPath = join(dirname(fileURLToPath(import.meta.url)), "../../config/email/text-labels.json");

const DEFAULTS = {
  templates: {
    notification: {
      title: "Email Notification",
      description: "Sent to admin when a new quote request is submitted",
      subjectDefault: "New quote request from {customer_name}",
      headingDefault: "New Quote Request!",
      contentDefault: "You have a new quote request from {customer_name} for {product_title}. {quote_message}",
      actionDefault: "View Quote",
      variables: [
        { key: "{customer_name}", desc: "Full name of the customer" },
        { key: "{customer_email}", desc: "Email address of the customer" },
        { key: "{product_title}", desc: "Product requested for quote" },
        { key: "{quote_message}", desc: "Message submitted by the customer" },
        { key: "{store_name}", desc: "Your store name" },
      ],
    },
    "auto-response": {
      title: "Auto Response Email",
      description: "Automatically sent to the customer after submitting a quote",
      subjectDefault: "We received your quote request, {customer_name}!",
      headingDefault: "Thanks for your request, {customer_name}!",
      contentDefault: "We have received your quote request for {product_title} and will get back to you shortly.",
      actionDefault: "Visit Store",
      variables: [
        { key: "{customer_name}", desc: "Full name of the customer" },
        { key: "{product_title}", desc: "Product requested for quote" },
        { key: "{store_name}", desc: "Your store name" },
      ],
    },
    "accept-quote": {
      title: "Email Accept Quote",
      description: "Sent to the customer when their quote is accepted",
      subjectDefault: "Your quote for {product_title} has been accepted!",
      headingDefault: "Your quote has been accepted!",
      contentDefault: "Great news, {customer_name}! Your quote for {product_title} has been accepted at {quote_price}. Complete your purchase now.",
      actionDefault: "Complete Purchase",
      variables: [
        { key: "{customer_name}", desc: "Full name of the customer" },
        { key: "{product_title}", desc: "Product requested for quote" },
        { key: "{quote_price}", desc: "The accepted quote price" },
        { key: "{store_name}", desc: "Your store name" },
      ],
    },
    "reject-quote": {
      title: "Email Reject Quote",
      description: "Sent to the customer when their quote is rejected",
      subjectDefault: "Update on your quote request for {product_title}",
      headingDefault: "Quote Update",
      contentDefault: "We're sorry, {customer_name}. Unfortunately we are unable to fulfill your quote request for {product_title} at this time. Feel free to browse our store.",
      actionDefault: "Shop Now",
      variables: [
        { key: "{customer_name}", desc: "Full name of the customer" },
        { key: "{product_title}", desc: "Product requested for quote" },
        { key: "{store_name}", desc: "Your store name" },
      ],
    },
  },
  settingsPage: {
    pageTitle: "Settings",
    navEmailLabel: "Email Settings",
    navPdfLabel: "PDF Template",
    turnOffAction: "Turn off",
    turnOnAction: "Turn on",
    editAction: "Edit",
    saveAction: "Save",
    discardAction: "Discard",
    smtp: {
      heading: "SMTP",
      description: "Use the app's default email service or your own. The sender address will be used for all quote notifications.",
      activeBadge: "Active",
      providerLabel: "Email Provider",
      providerAppDefault: "Use the app's default email",
      providerGmail: "Google",
      providerElasticEmail: "Elastic Email",
      notifyEmailLabel: "Admin Notification Email",
      notifyEmailPlaceholder: "admin@yourstore.com",
      notifyEmailHelpText: "Receives an email notification when a new quote is submitted",
      gmailUsernameLabel: "Gmail Address",
      gmailUsernamePlaceholder: "you@gmail.com",
      gmailUsernameHelpText: "Your Google account email address",
      gmailPasswordLabel: "App Password",
      gmailPasswordHelpText: "Generate at myaccount.google.com/apppasswords (not your Gmail password)",
      elasticUsernameLabel: "SMTP Username",
      elasticUsernamePlaceholder: "you@example.com",
      elasticUsernameHelpText: "Your Elastic Email account email",
      elasticPasswordLabel: "SMTP Password",
      elasticPasswordHelpText: "Found in Elastic Email → Settings → SMTP",
      passwordPlaceholder: "••••••••",
      fromNameLabel: "From Name",
      fromNamePlaceholder: "Your Store",
      fromEmailLabel: "From Email",
      fromEmailPlaceholder: "noreply@yourstore.com",
      sendTestToLabel: "Send test to",
      sendTestToPlaceholder: "you@example.com",
      sendTestToHelpText: "Enter an address to receive a test email",
      sendTestButton: "Send test email",
    },
  },
  editorPage: {
    statusHeading: "Status",
    enabledLabel: "Enabled",
    disabledLabel: "Disabled",
    subjectLabel: "Subject",
    contentHeading: "Content",
    headingLabel: "Heading",
    contentLabel: "Content",
    actionLabel: "Action",
    redirectUrlLabel: "Redirect url",
    redirectUrlPlaceholder: "https://yourstore.com",
    redirectUrlHelpText: "Redirects to your store when left blank",
    sendTestHeading: "Send test email",
    recipientPlaceholder: "you@example.com",
    sendTestButton: "Send test",
    sendTestHelpText: "Sends the current template content to the address above.",
    previewHeading: "Preview",
    savedBanner: "Template saved — new quotes will use this content.",
    preview: {
      subjectLabel: "Subject:",
      noSubjectFallback: "No subject",
      headingFallback: "Heading",
      contentFallback: "Email content",
      footerTemplate: "Sent to {email} via {store_name}",
    },
  },
  toasts: {
    testEmailSent: "Test email sent",
    testEmailSentFull: "Test email sent successfully",
    testEmailFailed: "Test email failed",
    templateSaved: "Template saved",
    settingsSaved: "Settings saved",
  },
  errors: {
    invalidTestEmail: "Please enter a valid recipient email address to send the test to.",
    noMailServer: "No mail server configured. Enable custom SMTP or set GMAIL_USER in your environment.",
    invalidToggleField: "Invalid field",
    unknownIntent: "Unknown intent",
    sendFailedTemplate: "Send failed: {message}",
  },
  testEmailHtml: {
    editorPreviewLabel: "Test Email Preview",
    settingsHeading: "Your SMTP is working ✓",
    settingsBody: "This test confirms that your mail server is configured correctly and emails will be delivered.",
    settingsSentViaTemplate: "Sent via {appName}",
    settingsSubjectTemplate: "Test email — {appName}",
    editorSubjectPrefixTemplate: "[Test] {subject}",
    editorFallbackSubject: "Test email",
    editorFallbackHeading: "Test Email",
    editorFallbackBody: "This is a test email.",
  },
};

function isPlainObject(val) {
  return Boolean(val) && typeof val === "object" && !Array.isArray(val);
}

function mergeDeep(base, custom) {
  if (!custom) return base;
  const out = { ...base };
  for (const key of Object.keys(base)) {
    const customVal = custom[key];
    if (isPlainObject(customVal) && isPlainObject(base[key])) {
      out[key] = mergeDeep(base[key], customVal);
    } else if (customVal !== undefined) {
      out[key] = customVal;
    }
  }
  return out;
}

export function readEmailText() {
  let custom = {};
  try {
    custom = JSON.parse(readFileSync(textPath, "utf-8"));
  } catch {
    custom = {};
  }
  return {
    templates: mergeDeep(DEFAULTS.templates, custom.templates),
    settingsPage: mergeDeep(DEFAULTS.settingsPage, custom.settingsPage),
    editorPage: mergeDeep(DEFAULTS.editorPage, custom.editorPage),
    toasts: mergeDeep(DEFAULTS.toasts, custom.toasts),
    errors: mergeDeep(DEFAULTS.errors, custom.errors),
    testEmailHtml: mergeDeep(DEFAULTS.testEmailHtml, custom.testEmailHtml),
  };
}

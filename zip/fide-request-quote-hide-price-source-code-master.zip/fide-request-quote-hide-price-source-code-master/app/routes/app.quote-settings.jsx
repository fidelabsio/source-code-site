import { useQuoteSettingsPage, TABS, FIELD_META, ELEMENT_TYPES } from "../hooks/quotes/useQuoteSettingsPage";
import { ColorSwatchPicker } from "../components/common/ColorSwatchPicker";
import { ResourcePickerList } from "../components/common/ResourcePickerList";
import {
  Tabs,
  Page,
  Card,
  Text,
  BlockStack,
  InlineStack,
  Button,
  Box,
  RadioButton,
  TextField,
  Icon, InlineGrid,
  Checkbox,
  RangeSlider,
  Popover, Divider,
  Collapsible,
  ActionList,
  Select,
  Modal,
  Combobox,
  Listbox,
  Tag,
  AutoSelection,
  Badge,
  Banner,
} from "@shopify/polaris";
import { ChevronUpIcon, ChevronDownIcon, DeleteIcon, NoteIcon, DesktopIcon } from "@shopify/polaris-icons";
import { useRouteError } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";

export { loader, action } from "../domain/quotes/quoteSettings.server";

/**
 * The merchant-facing configuration page for the whole app: where the quote
 * button/widget shows, its styling, price-hiding rules, and the Form Builder
 * (Tab 2) that defines what fields customers fill in. Everything here saves
 * through a single `saveAll` action into one `QuoteConfig` row per shop.
 *
 * All state, derived values, and handlers live in useQuoteSettingsPage() —
 * this component just wires that state into JSX. The three
 * render-a-field-section/preview helpers below build JSX (Polaris components,
 * raw `<div>`s) directly from that state, so they stay here rather than in
 * the (plain .js, non-JSX) hook file.
 */

export default function DesignPage() {
  const {
    isMobile, currSym, fetcher,
    errorColor, accentColor, successColor,
    selected, setSelected, handleTabChange,

    // Tab 1
    targetMode, setTargetMode,
    selectedProducts, setSelectedProducts,
    selectedCollections, setSelectedCollections,
    displayMode, setDisplayMode,
    showOnCollectionPage, setShowOnCollectionPage,
    showOnHomepage, setShowOnHomepage,
    messageType, setMessageType,
    successMessage, setSuccessMessage,
    buttonBorderRadius, buttonWidth,
    visibilityMode, setVisibilityMode,
    selectedTags, tagInputValue, setTagInputValue, filteredTagOptions, handleTagSelect, removeTag,
    buttonLabel, setButtonLabel,
    textColorHsb, setTextColorHsb,
    buttonColorHsb, setButtonColorHsb,
    fontSize, setFontSize,
    buttonPosition, setButtonPosition,

    // Widget
    widgetEnabled, setWidgetEnabled,
    widgetButtonText, setWidgetButtonText,
    widgetPosition, setWidgetPosition,
    widgetBgColorHsb, setWidgetBgColorHsb,
    widgetTxtColorHsb, setWidgetTxtColorHsb,

    // Toast
    toastEnabled, setToastEnabled,
    successToastEnabled, setSuccessToastEnabled,
    toastMessage, setToastMessage,
    toastBgColorHsb, setToastBgColorHsb,
    toastTxtColorHsb, setToastTxtColorHsb,
    toastBorderColorHsb, setToastBorderColorHsb,
    toastFontSize, setToastFontSize,
    toastBorderRadius, setToastBorderRadius,
    toastBorderWidth, setToastBorderWidth,
    toastPosition, setToastPosition,

    // Hide-price
    hidePriceTarget, setHidePriceTarget,
    hidePriceProducts, setHidePriceProducts,
    hidePriceCollections, setHidePriceCollections,
    hidePriceProductPage, setHidePriceProductPage,
    hidePriceCollectionPage, setHidePriceCollectionPage,
    hidePriceHomePage, setHidePriceHomePage,
    hidePriceCartPage, setHidePriceCartPage,
    hideAddToCart, setHideAddToCart,
    hideBuyItNow, setHideBuyItNow,
    hidePriceReplacement, setHidePriceReplacement,
    replacementText, setReplacementText,
    replacementTextColor,

    // Tab 2 — form content / submit button style
    formTitle, setFormTitle,
    submitButtonLabel, setSubmitButtonLabel,
    formBtnTextColorHsb, setFormBtnTextColorHsb,
    formBtnColorHsb, setFormBtnColorHsb,
    formBtnFontSize, setFormBtnFontSize,
    formBtnBorderRadius, setFormBtnBorderRadius,
    showVendor, setShowVendor,
    showSku, setShowSku,
    showOption,
    showPrice, setShowPrice,
    showQuotePrice, setShowQuotePrice,
    showNote, setShowNote,

    // Section collapse/picker toggles
    productInfoOpen, setProductInfoOpen,
    desktopPreviewOpen, setDesktopPreviewOpen,
    contactSectionOpen, setContactSectionOpen,
    showElementPicker, setShowElementPicker,
    shippingSectionOpen, setShippingSectionOpen,
    showShippingPicker, setShowShippingPicker,
    extraInfoSectionOpen, setExtraInfoSectionOpen,
    showExtraInfoPicker, setShowExtraInfoPicker,

    // Field-removal confirmation
    confirmRemove, setConfirmRemove, requestRemoveEl,

    // Form field lists
    contactElements, updateContactElement, removeContactElement,
    moveElement, addOption, updateOption, removeOption, addContactElement,

    shippingElements, updateShippingElement, removeShippingElement,
    moveShippingElement, addShippingOption, updateShippingOption, removeShippingOption, addShippingElement,

    extraInfoElements, updateExtraInfoElement, removeExtraInfoElement,
    moveExtraInfoElement, addExtraInfoOption, updateExtraInfoOption, removeExtraInfoOption, addExtraInfoElement,

    // Save / discard
    handleSave, handleDiscard,

    // Live "quoted products" preview
    previewProducts, updatePreviewQty, removePreviewProduct, updatePreviewOfferPrice, togglePreviewNote, updatePreviewNote,

    // Interactive test form
    previewTestData, previewSubmitted, setPreviewSubmitted, previewErrors,
    previewMode, setPreviewMode, previewFiles, previewSending, previewQuoteId,
    updateTestField, updateFileField, removeFileFromField, clearTestData, handlePreviewSubmit,
  } = useQuoteSettingsPage();

  const renderFieldSection = (elements, updateEl, removeEl, moveEl, addOpt, updateOpt, removeOpt, pickerActive, setPickerActive, addEl) => (
    <BlockStack gap="300">
      {elements.map((el, idx) => {
        const meta = FIELD_META[el.type] || {};
        return (
          <Box key={el.id} borderWidth="025" borderColor="border" borderRadius="200" padding="300" background="bg-surface-secondary">
            <BlockStack gap="300">
              <InlineStack align="space-between" blockAlign="center">
                <InlineStack gap="200" blockAlign="center">
                  <Button variant="plain" icon={el.open ? ChevronUpIcon : ChevronDownIcon} onClick={() => updateEl(el.id, "open", !el.open)} accessibilityLabel={el.open ? "Collapse" : "Expand"} />
                  <Text variant="bodySm" fontWeight="semibold">{el.label || el.type}</Text>
                </InlineStack>
                <InlineStack gap="100" blockAlign="center">
                  <Button variant="plain" size="slim" icon={ChevronUpIcon} disabled={idx === 0} onClick={() => moveEl(el.id, -1)} accessibilityLabel="Move up" />
                  <Button variant="plain" size="slim" icon={ChevronDownIcon} disabled={idx === elements.length - 1} onClick={() => moveEl(el.id, 1)} accessibilityLabel="Move down" />
                  <Button variant="plain" tone="critical" size="slim" onClick={() => requestRemoveEl(removeEl, el.id, el.label || el.type)}>Remove</Button>
                </InlineStack>
              </InlineStack>
              <Collapsible open={el.open} id={`el-${el.id}`} transition={{ duration: "150ms", timingFunction: "ease-in-out" }}>
                <Box paddingBlockStart="200">
                  <BlockStack gap="300">
                    {meta.hasContent ? (
                      <TextField label="Paragraph content" value={el.content} onChange={(v) => updateEl(el.id, "content", v)} multiline={3} autoComplete="off" />
                    ) : (
                      <>
                        <TextField label="Label" value={el.label} onChange={(v) => updateEl(el.id, "label", v)} autoComplete="off" />
                        {meta.hasPlaceholder && <TextField label="Placeholder" value={el.placeholder} onChange={(v) => updateEl(el.id, "placeholder", v)} autoComplete="off" />}
                        {meta.hasHelpText && <TextField label="Help text" value={el.helpText} onChange={(v) => updateEl(el.id, "helpText", v)} autoComplete="off" />}
                        {meta.hasRows && <TextField label="Rows" type="number" value={String(el.rows)} onChange={(v) => updateEl(el.id, "rows", Number(v))} autoComplete="off" />}
                        {meta.hasMinMax && (
                          <InlineGrid columns="1fr 1fr" gap="200">
                            <TextField label="Min" type="number" value={el.min} onChange={(v) => updateEl(el.id, "min", v)} autoComplete="off" />
                            <TextField label="Max" type="number" value={el.max} onChange={(v) => updateEl(el.id, "max", v)} autoComplete="off" />
                          </InlineGrid>
                        )}
                        {meta.hasAccept && <TextField label="Accepted file types" placeholder=".pdf, .jpg" value={el.accept} onChange={(v) => updateEl(el.id, "accept", v)} autoComplete="off" />}
                        {meta.hasMultiple && (
                          <InlineStack gap="300" blockAlign="center">
                            <Text variant="bodySm" as="span">Allow multiple files?</Text>
                            <Select
                              label=""
                              labelHidden
                              options={[
                                { label: "Single file only", value: "single" },
                                { label: "Multiple files (up to 5)", value: "multiple" },
                              ]}
                              value={el.multiple ? "multiple" : "single"}
                              onChange={(v) => updateEl(el.id, "multiple", v === "multiple")}
                            />
                          </InlineStack>
                        )}
                        {meta.hasOptions && (
                          <BlockStack gap="200">
                            <Text variant="bodySm" fontWeight="medium">Options</Text>
                            {el.options.map((opt, oi) => (
                              <InlineGrid key={oi} columns="1fr auto" gap="200" alignItems="center">
                                <TextField label="" labelHidden value={opt} onChange={(v) => updateOpt(el.id, oi, v)} autoComplete="off" />
                                <Button variant="plain" tone="critical" size="slim" onClick={() => removeOpt(el.id, oi)} disabled={el.options.length <= 1}>Remove</Button>
                              </InlineGrid>
                            ))}
                            <Button variant="plain" onClick={() => addOpt(el.id)}>+ Add option</Button>
                          </BlockStack>
                        )}
                        <Checkbox label="Required" checked={el.required} onChange={(v) => updateEl(el.id, "required", v)} />
                      </>
                    )}
                  </BlockStack>
                </Box>
              </Collapsible>
            </BlockStack>
          </Box>
        );
      })}
      <Popover
        active={pickerActive}
        activator={<Button fullWidth onClick={() => setPickerActive((o) => !o)}>+ Add Field</Button>}
        onClose={() => setPickerActive(false)}
        fullWidth
      >
        <ActionList items={ELEMENT_TYPES.map((type) => ({ content: type, onAction: () => addEl(type) }))} />
      </Popover>
    </BlockStack>
  );

  const renderVisualFieldPreview = (el, isMobile) => {
    const label = el.label || el.type;
    const req = el.required;
    const placeholder = el.placeholder || "";
    const helpText = el.helpText;
    const marginVal = isMobile ? 10 : 14;
    const labelSize = isMobile ? 11 : 13;
    const inputHeight = isMobile ? 36 : 44;
    const inputFontSize = isMobile ? 12 : 14;

    switch (el.type) {
      case "Paragraph":
        return (
          <div key={el.id} style={{ marginBottom: marginVal }}>
            <p style={{ fontSize: inputFontSize, color: "#374151", lineHeight: 1.5, margin: "0 0 4px", whiteSpace: "pre-wrap" }}>
              {el.content || "Paragraph text…"}
            </p>
          </div>
        );
      case "Checkbox":
        return (
          <div key={el.id} style={{ marginBottom: marginVal }}>
            <label style={{ display: "flex", alignItems: "center", gap: 10, cursor: "pointer", fontSize: inputFontSize, fontWeight: 400 }}>
              <input type="checkbox" style={{ width: 16, height: 16, flexShrink: 0 }} disabled />
              <span>
                {label}{req && <span style={{ color: errorColor }}> *</span>}
              </span>
            </label>
            {helpText && <div style={{ fontSize: isMobile ? 10 : 12, color: "#6b7280", marginTop: 4, paddingLeft: 26 }}>{helpText}</div>}
          </div>
        );
      case "Radio Group":
        return (
          <div key={el.id} style={{ marginBottom: marginVal }}>
            <div style={{ fontSize: labelSize, fontWeight: 400, color: "#6d7175", marginBottom: isMobile ? 4 : 6 }}>
              {label}{req && <span style={{ color: errorColor }}> *</span>}
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: isMobile ? 6 : 8 }}>
              {(el.options || []).map((o, idx) => (
                <label key={idx} style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: inputFontSize, fontWeight: 400 }}>
                  <input type="radio" name={`prev-${el.id}`} style={{ width: 16, height: 16 }} disabled />
                  <span>{o}</span>
                </label>
              ))}
            </div>
            {helpText && <div style={{ fontSize: isMobile ? 10 : 12, color: "#6b7280", marginTop: 4 }}>{helpText}</div>}
          </div>
        );
      case "Dropdown":
      case "Country":
        return (
          <div key={el.id} style={{ marginBottom: marginVal }}>
            <div style={{ fontSize: labelSize, fontWeight: 400, color: "#6d7175", marginBottom: isMobile ? 4 : 6 }}>
              {label}{req && <span style={{ color: errorColor }}> *</span>}
            </div>
            <div style={{
              height: inputHeight,
              border: "1px solid #c9cccf",
              borderRadius: 4,
              background: "#fff",
              padding: "0 10px",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              boxSizing: "border-box"
            }}>
              <span style={{ fontSize: inputFontSize, color: "#a3a3a3" }}>{placeholder || (el.type === "Country" ? "Select country…" : "Select option…")}</span>
              <svg style={{ width: 16, height: 16, color: "#6b7280" }} fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
              </svg>
            </div>
            {helpText && <div style={{ fontSize: isMobile ? 10 : 12, color: "#6b7280", marginTop: 4 }}>{helpText}</div>}
          </div>
        );
      case "Textarea":
        return (
          <div key={el.id} style={{ marginBottom: marginVal }}>
            <div style={{ fontSize: labelSize, fontWeight: 400, color: "#6d7175", marginBottom: isMobile ? 4 : 6 }}>
              {label}{req && <span style={{ color: errorColor }}> *</span>}
            </div>
            <div style={{
              height: isMobile ? 60 : 80,
              border: "1px solid #c9cccf",
              borderRadius: 4,
              background: "#fff",
              padding: "8px 10px",
              display: "flex",
              alignItems: "flex-start",
              boxSizing: "border-box"
            }}>
              <span style={{ fontSize: inputFontSize, color: "#ccc" }}>{placeholder}</span>
            </div>
            {helpText && <div style={{ fontSize: isMobile ? 10 : 12, color: "#6b7280", marginTop: 4 }}>{helpText}</div>}
          </div>
        );
      case "File Upload":
        return (
          <div key={el.id} style={{ marginBottom: marginVal }}>
            <div style={{ fontSize: labelSize, fontWeight: 400, color: "#6d7175", marginBottom: isMobile ? 4 : 6 }}>
              {label}{req && <span style={{ color: errorColor }}> *</span>}
            </div>
            <div style={{
              position: "relative",
              border: "2px dashed #cbd5e1",
              borderRadius: "8px",
              padding: isMobile ? "16px 12px" : "24px 16px",
              textAlign: "center",
              backgroundColor: "#f8fafc",
              cursor: "pointer",
              marginBottom: "4px",
              boxSizing: "border-box"
            }}>
              <div style={{ pointerEvents: "none" }}>
                <svg style={{
                  margin: "0 auto 8px",
                  width: isMobile ? "28px" : "36px",
                  height: isMobile ? "28px" : "36px",
                  color: "#9ca3af",
                  display: "block"
                }} fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                </svg>
                <p style={{ margin: 0, fontSize: isMobile ? "12px" : "14px", fontWeight: 500, color: "#374151" }}>Click to upload or drag & drop</p>
                <p style={{ margin: "4px 0 0", fontSize: isMobile ? "10px" : "12px", color: "#6b7280" }}>
                  {el.accept ? `${el.accept} files` : "Images & Documents"} &middot; {el.multiple ? "Max 5 files" : "Single file only"}
                </p>
              </div>
            </div>
            {helpText && <div style={{ fontSize: isMobile ? 10 : 12, color: "#6b7280", marginTop: 4 }}>{helpText}</div>}
          </div>
        );
      default:
        return (
          <div key={el.id} style={{ marginBottom: marginVal }}>
            <div style={{ fontSize: labelSize, fontWeight: 400, color: "#6d7175", marginBottom: isMobile ? 4 : 6 }}>
              {label}{req && <span style={{ color: errorColor }}> *</span>}
            </div>
            <div style={{
              height: inputHeight,
              border: "1px solid #c9cccf",
              borderRadius: 4,
              background: "#fff",
              padding: "0 10px",
              boxSizing: "border-box"
            }}>
              <span style={{ fontSize: inputFontSize, color: "#ccc" }}>{placeholder}</span>
            </div>
            {helpText && <div style={{ fontSize: isMobile ? 10 : 12, color: "#6b7280", marginTop: 4 }}>{helpText}</div>}
          </div>
        );
    }
  };

  // ── Interactive Field Preview (editable test form) ──────────────────────────
  const renderInteractiveFieldPreview = (el, isMobile) => {
    const label = el.label || el.type;
    const req = el.required;
    const placeholder = el.placeholder || "";
    const helpText = el.helpText;
    const marginVal = isMobile ? 10 : 14;
    const labelSize = isMobile ? 11 : 13;
    const inputHeight = isMobile ? 36 : 44;
    const inputFontSize = isMobile ? 12 : 14;
    const val = previewTestData[el.id];
    const errMsg = previewErrors[el.id];
    const borderColor = errMsg ? errorColor : "#c9cccf";
    const inputStyle = {
      width: "100%",
      height: inputHeight,
      border: `1px solid ${borderColor}`,
      borderRadius: 4,
      background: "#fff",
      padding: "0 10px",
      fontSize: inputFontSize,
      fontFamily: "inherit",
      outline: "none",
      boxSizing: "border-box",
      color: "#374151",
      transition: "border-color 0.15s",
    };

    switch (el.type) {
      case "Paragraph":
        return (
          <div key={el.id} style={{ marginBottom: marginVal }}>
            <p style={{ fontSize: inputFontSize, color: "#374151", lineHeight: 1.5, margin: "0 0 4px", whiteSpace: "pre-wrap" }}>
              {el.content || "Paragraph text…"}
            </p>
          </div>
        );

      case "Checkbox":
        return (
          <div key={el.id} style={{ marginBottom: marginVal }}>
            <label style={{ display: "flex", alignItems: "center", gap: 10, cursor: "pointer", fontSize: inputFontSize, fontWeight: 400 }}>
              <input
                type="checkbox"
                checked={!!val}
                onChange={(e) => updateTestField(el.id, e.target.checked ? "yes" : "")}
                style={{ width: 16, height: 16, flexShrink: 0, cursor: "pointer", accentColor }}
              />
              <span>{label}{req && <span style={{ color: errorColor }}> *</span>}</span>
            </label>
            {errMsg && <div style={{ fontSize: isMobile ? 10 : 12, color: errorColor, marginTop: 4, paddingLeft: 26 }}>{errMsg}</div>}
            {helpText && <div style={{ fontSize: isMobile ? 10 : 12, color: "#6b7280", marginTop: 4, paddingLeft: 26 }}>{helpText}</div>}
          </div>
        );

      case "Radio Group":
        return (
          <div key={el.id} style={{ marginBottom: marginVal }}>
            <div style={{ fontSize: labelSize, fontWeight: 400, color: "#6d7175", marginBottom: isMobile ? 4 : 6 }}>
              {label}{req && <span style={{ color: errorColor }}> *</span>}
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: isMobile ? 6 : 8 }}>
              {(el.options || []).map((o, idx) => (
                <label key={idx} style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: inputFontSize, fontWeight: 400 }}>
                  <input
                    type="radio"
                    name={`test-${el.id}`}
                    value={o}
                    checked={val === o}
                    onChange={() => updateTestField(el.id, o)}
                    style={{ width: 16, height: 16, cursor: "pointer", accentColor }}
                  />
                  <span>{o}</span>
                </label>
              ))}
            </div>
            {errMsg && <div style={{ fontSize: isMobile ? 10 : 12, color: errorColor, marginTop: 4 }}>{errMsg}</div>}
            {helpText && <div style={{ fontSize: isMobile ? 10 : 12, color: "#6b7280", marginTop: 4 }}>{helpText}</div>}
          </div>
        );

      case "Dropdown":
        return (
          <div key={el.id} style={{ marginBottom: marginVal }}>
            <div style={{ fontSize: labelSize, fontWeight: 400, color: "#6d7175", marginBottom: isMobile ? 4 : 6 }}>
              {label}{req && <span style={{ color: errorColor }}> *</span>}
            </div>
            <select
              value={val || ""}
              onChange={(e) => updateTestField(el.id, e.target.value)}
              style={{ ...inputStyle, appearance: "none", backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' stroke='%236b7280' stroke-width='2' viewBox='0 0 24 24'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' d='M19 9l-7 7-7-7'/%3E%3C/svg%3E\")", backgroundRepeat: "no-repeat", backgroundPosition: "right 10px center", backgroundSize: "16px", paddingRight: 32, cursor: "pointer" }}
            >
              <option value="">Select option…</option>
              {(el.options || []).map((o, i) => <option key={i} value={o}>{o}</option>)}
            </select>
            {errMsg && <div style={{ fontSize: isMobile ? 10 : 12, color: errorColor, marginTop: 4 }}>{errMsg}</div>}
            {helpText && <div style={{ fontSize: isMobile ? 10 : 12, color: "#6b7280", marginTop: 4 }}>{helpText}</div>}
          </div>
        );

      case "Country":
        return (
          <div key={el.id} style={{ marginBottom: marginVal }}>
            <div style={{ fontSize: labelSize, fontWeight: 400, color: "#6d7175", marginBottom: isMobile ? 4 : 6 }}>
              {label}{req && <span style={{ color: errorColor }}> *</span>}
            </div>
            <select
              value={val || ""}
              onChange={(e) => updateTestField(el.id, e.target.value)}
              style={{ ...inputStyle, appearance: "none", backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' stroke='%236b7280' stroke-width='2' viewBox='0 0 24 24'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' d='M19 9l-7 7-7-7'/%3E%3C/svg%3E\")", backgroundRepeat: "no-repeat", backgroundPosition: "right 10px center", backgroundSize: "16px", paddingRight: 32, cursor: "pointer" }}
            >
              <option value="">Select country…</option>
              <option value="US">United States</option>
              <option value="GB">United Kingdom</option>
              <option value="CA">Canada</option>
              <option value="AU">Australia</option>
              <option value="IN">India</option>
              <option value="DE">Germany</option>
              <option value="FR">France</option>
              <option value="SG">Singapore</option>
              <option value="AE">UAE</option>
            </select>
            {errMsg && <div style={{ fontSize: isMobile ? 10 : 12, color: errorColor, marginTop: 4 }}>{errMsg}</div>}
            {helpText && <div style={{ fontSize: isMobile ? 10 : 12, color: "#6b7280", marginTop: 4 }}>{helpText}</div>}
          </div>
        );

      case "Textarea":
        return (
          <div key={el.id} style={{ marginBottom: marginVal }}>
            <div style={{ fontSize: labelSize, fontWeight: 400, color: "#6d7175", marginBottom: isMobile ? 4 : 6 }}>
              {label}{req && <span style={{ color: errorColor }}> *</span>}
            </div>
            <textarea
              value={val || ""}
              onChange={(e) => updateTestField(el.id, e.target.value)}
              placeholder={placeholder}
              rows={el.rows || (isMobile ? 3 : 4)}
              style={{ ...inputStyle, height: "auto", padding: "8px 10px", resize: "vertical", lineHeight: 1.5 }}
            />
            {errMsg && <div style={{ fontSize: isMobile ? 10 : 12, color: errorColor, marginTop: 4 }}>{errMsg}</div>}
            {helpText && <div style={{ fontSize: isMobile ? 10 : 12, color: "#6b7280", marginTop: 4 }}>{helpText}</div>}
          </div>
        );

      case "File Upload": {
        const fieldFiles = previewFiles[el.id] || [];
        const hasFiles = fieldFiles.length > 0;
        const maxFiles = el.multiple ? 5 : 1;
        return (
          <div key={el.id} style={{ marginBottom: marginVal }}>
            <div style={{ fontSize: labelSize, fontWeight: 400, color: "#6d7175", marginBottom: isMobile ? 4 : 6 }}>
              {label}{req && <span style={{ color: errorColor }}> *</span>}
            </div>

            {/* Drop zone — always visible so more files can be added */}
            <label style={{
              display: "block",
              position: "relative",
              border: `2px dashed ${hasFiles ? accentColor : "#cbd5e1"}`,
              borderRadius: "8px",
              padding: isMobile ? "12px 10px" : "16px",
              textAlign: "center",
              backgroundColor: hasFiles ? "#eff6ff" : "#f8fafc",
              cursor: "pointer",
              marginBottom: "4px",
              transition: "all 0.2s",
            }}>
              <input
                type="file"
                multiple={!!el.multiple}
                accept={el.accept || undefined}
                onChange={(e) => {
                  const files = Array.from(e.target.files || []);
                  if (files.length > 0) updateFileField(el.id, files, !!el.multiple);
                  e.target.value = ""; // reset so same file can be re-added after remove
                }}
                style={{ position: "absolute", inset: 0, opacity: 0, cursor: "pointer", width: "100%", height: "100%" }}
              />
              <svg style={{ margin: "0 auto 5px", width: isMobile ? "22px" : "28px", height: isMobile ? "22px" : "28px", color: hasFiles ? accentColor : "#9ca3af", display: "block" }} fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
              </svg>
              <p style={{ margin: 0, fontSize: isMobile ? "11px" : "13px", fontWeight: 500, color: hasFiles ? accentColor : "#374151" }}>
                {hasFiles ? `${fieldFiles.length}/${maxFiles} file${fieldFiles.length > 1 ? "s" : ""} selected — click to add more` : "Click to upload or drag & drop"}
              </p>
              {!hasFiles && (
                <p style={{ margin: "3px 0 0", fontSize: isMobile ? "10px" : "12px", color: "#6b7280" }}>
                  {el.accept ? `${el.accept} files` : "Images & Documents"} · {el.multiple ? `Max ${maxFiles} files` : "Single file only"}
                </p>
              )}
            </label>

            {/* Thumbnail previews — just like storefront */}
            {hasFiles && (
              <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginTop: 8, marginBottom: 4 }}>
                {fieldFiles.map((file, idx) => {
                  const isImg = file.type && file.type.startsWith("image/");
                  const objUrl = isImg ? URL.createObjectURL(file) : null;
                  return (
                    <div key={idx} style={{
                      position: "relative",
                      width: isMobile ? 64 : 80,
                      height: isMobile ? 64 : 80,
                      borderRadius: 6,
                      border: "1px solid #e5e7eb",
                      overflow: "hidden",
                      background: "#f3f4f6",
                      boxShadow: "0 1px 3px rgba(0,0,0,0.05)",
                      flexShrink: 0,
                    }}>
                      {isImg
                        ? <img src={objUrl} alt={file.name} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
                        : <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 4, textAlign: "center" }}>
                          <svg style={{ width: 22, height: 22, color: "#9ca3af", marginBottom: 2 }} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                          </svg>
                          <span style={{ fontSize: 8, fontWeight: 600, color: "#4b5563", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", width: "100%", display: "block" }}>
                            {file.name}
                          </span>
                        </div>
                      }
                      {/* Remove button */}
                      <button
                        type="button"
                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); removeFileFromField(el.id, idx); }}
                        style={{
                          position: "absolute", top: 3, right: 3,
                          width: 18, height: 18,
                          background: "rgba(239,68,68,0.9)",
                          color: "#fff",
                          border: "none",
                          borderRadius: "50%",
                          cursor: "pointer",
                          display: "flex", alignItems: "center", justifyContent: "center",
                          fontSize: 10, fontWeight: "bold", lineHeight: 1,
                          padding: 0, zIndex: 10,
                        }}
                        title="Remove file"
                      >×</button>
                    </div>
                  );
                })}
              </div>
            )}

            {errMsg && <div style={{ fontSize: isMobile ? 10 : 12, color: errorColor, marginTop: 4 }}>{errMsg}</div>}
            {helpText && <div style={{ fontSize: isMobile ? 10 : 12, color: "#6b7280", marginTop: 4 }}>{helpText}</div>}
          </div>
        );
      }

      case "Date field":
        return (
          <div key={el.id} style={{ marginBottom: marginVal }}>
            <div style={{ fontSize: labelSize, fontWeight: 400, color: "#6d7175", marginBottom: isMobile ? 4 : 6 }}>
              {label}{req && <span style={{ color: errorColor }}> *</span>}
            </div>
            <input
              type="date"
              value={val || ""}
              onChange={(e) => updateTestField(el.id, e.target.value)}
              style={inputStyle}
            />
            {errMsg && <div style={{ fontSize: isMobile ? 10 : 12, color: errorColor, marginTop: 4 }}>{errMsg}</div>}
            {helpText && <div style={{ fontSize: isMobile ? 10 : 12, color: "#6b7280", marginTop: 4 }}>{helpText}</div>}
          </div>
        );

      case "Number":
        return (
          <div key={el.id} style={{ marginBottom: marginVal }}>
            <div style={{ fontSize: labelSize, fontWeight: 400, color: "#6d7175", marginBottom: isMobile ? 4 : 6 }}>
              {label}{req && <span style={{ color: errorColor }}> *</span>}
            </div>
            <input
              type="number"
              value={val || ""}
              onChange={(e) => updateTestField(el.id, e.target.value)}
              placeholder={placeholder}
              min={el.min !== "" && el.min != null ? el.min : undefined}
              max={el.max !== "" && el.max != null ? el.max : undefined}
              style={inputStyle}
            />
            {errMsg && <div style={{ fontSize: isMobile ? 10 : 12, color: errorColor, marginTop: 4 }}>{errMsg}</div>}
            {helpText && <div style={{ fontSize: isMobile ? 10 : 12, color: "#6b7280", marginTop: 4 }}>{helpText}</div>}
          </div>
        );

      default: {
        // Text, Email, Phone and all other inputs
        const inputType = el.type === "Email" ? "email" : el.type === "Phone" ? "tel" : "text";
        return (
          <div key={el.id} style={{ marginBottom: marginVal }}>
            <div style={{ fontSize: labelSize, fontWeight: 400, color: "#6d7175", marginBottom: isMobile ? 4 : 6 }}>
              {label}{req && <span style={{ color: errorColor }}> *</span>}
            </div>
            <input
              type={inputType}
              value={val || ""}
              onChange={(e) => updateTestField(el.id, e.target.value)}
              placeholder={placeholder}
              style={inputStyle}
            />
            {errMsg && <div style={{ fontSize: isMobile ? 10 : 12, color: errorColor, marginTop: 4 }}>{errMsg}</div>}
            {helpText && <div style={{ fontSize: isMobile ? 10 : 12, color: "#6b7280", marginTop: 4 }}>{helpText}</div>}
          </div>
        );
      }
    }
  };

  return (
    <Page title="General">
      <ui-save-bar id="my-save-bar">
        <button variant="primary" id="save-bar-save" onClick={handleSave} disabled={fetcher.state !== "idle"}>Save</button>
        {/* Discard reverts every field to the last-saved values in place (see
            handleDiscard) — no window.location.reload(), no browser popup. */}
        <button id="save-bar-discard" onClick={handleDiscard}>Discard</button>
      </ui-save-bar>

      {/* Confirm before removing a form field */}
      <Modal
        open={!!confirmRemove}
        onClose={() => setConfirmRemove(null)}
        title="Remove field?"
        primaryAction={{
          content: "Remove",
          destructive: true,
          onAction: () => {
            if (confirmRemove) confirmRemove.remove(confirmRemove.id);
            setConfirmRemove(null);
          },
        }}
        secondaryActions={[{ content: "Cancel", onAction: () => setConfirmRemove(null) }]}
      >
        <Modal.Section>
          <Text as="p" variant="bodyMd">
            {confirmRemove?.label
              ? `“${confirmRemove.label}” will be removed from the form. This can't be undone.`
              : "This field will be removed from the form. This can't be undone."}
          </Text>
        </Modal.Section>
      </Modal>
      <Box paddingBlockStart="400">
        <div style={{ maxWidth: "1200px", margin: "0 auto", paddingLeft: "20px", paddingRight: "20px" }}>
          <BlockStack gap="500">
            <Tabs tabs={TABS} selected={selected} onSelect={handleTabChange} />

            {/* ════ TAB 1 ════ */}
            {selected === 0 && (
              <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "43% 57%", gap: "20px", alignItems: "start" }}>

                {/* LEFT */}
                <BlockStack gap="400">
                  <Card>
                    <BlockStack gap="300">
                      <Text as="h2" variant="headingMd">Where to show the quote button</Text>

                      <BlockStack gap="300">
                        {/* All products */}
                        <RadioButton
                          label="All products"
                          id="target-all"
                          name="targetMode"
                          checked={targetMode === "all"}
                          onChange={() => {
                            setTargetMode("all");
                            setSelectedProducts([]);
                            setSelectedCollections([]);
                          }}
                        />

                        {/* Specific collections */}
                        <RadioButton
                          label="Specific collections only"
                          id="target-Collections"
                          name="targetMode"
                          checked={targetMode === "Collections"}
                          onChange={() => {
                            setTargetMode("Collections");
                            setSelectedProducts([]);
                          }}
                        />

                        {targetMode === "Collections" && (
                          <ResourcePickerList
                            type="collection"
                            selected={selectedCollections}
                            onChange={setSelectedCollections}
                            placeholder="Search collections…"
                          />
                        )}

                        {/* Hand-picked products */}
                        <RadioButton
                          label="Hand-picked products only"
                          id="target-specific"
                          name="targetMode"
                          checked={targetMode === "specific"}
                          onChange={() => {
                            setTargetMode("specific");
                            setSelectedCollections([]);
                          }}
                        />

                        {targetMode === "specific" && (
                          <ResourcePickerList
                            type="product"
                            selected={selectedProducts}
                            onChange={setSelectedProducts}
                            placeholder="Search products…"
                          />
                        )}
                      </BlockStack>

                      <Divider />

                      <Text as="h3" variant="headingSm" fontWeight="semibold">How the button behaves</Text>
                      <BlockStack gap="300">
                        <RadioButton label="Button only" id="display-button" name="displayMode" checked={displayMode === "button_only"} onChange={() => setDisplayMode("button_only")} />
                        <RadioButton label="Don't show" id="display-hide" name="displayMode" checked={displayMode === "hide"} onChange={() => setDisplayMode("hide")} />
                      </BlockStack>

                      <Divider />

                      <Text as="h3" variant="headingSm" fontWeight="semibold">Also show on</Text>
                      <BlockStack gap="300">
                        <Checkbox label="Collection page" checked={showOnCollectionPage} onChange={setShowOnCollectionPage} />
                        <Checkbox label="Homepage" checked={showOnHomepage} onChange={setShowOnHomepage} />
                      </BlockStack>

                    </BlockStack>
                  </Card>

                  {/* ── NEW: Visibility ── */}
                  <Card>
                    <BlockStack gap="300">
                      <Text as="h2" variant="headingMd">Who sees the button</Text>
                      <BlockStack gap="300">
                        <RadioButton label="All visitors" id="vis-everyone" name="visibilityMode" checked={visibilityMode === "everyone"} onChange={() => setVisibilityMode("everyone")} />
                        <RadioButton label="Logged-in customers only" id="vis-loggedin" name="visibilityMode" checked={visibilityMode === "loggedin"} onChange={() => setVisibilityMode("loggedin")} />
                        <RadioButton label="Tagged customers" id="vis-tagged" name="visibilityMode" checked={visibilityMode === "tagged"} onChange={() => setVisibilityMode("tagged")} />
                        {visibilityMode === "tagged" && (
                          <BlockStack gap="200">
                            <div onKeyDown={(e) => {
                              if (e.key === "Enter" && tagInputValue.trim()) {
                                e.preventDefault();
                                handleTagSelect(tagInputValue.trim());
                              }
                            }}>
                              <Combobox
                                allowMultiple
                                activator={
                                  <Combobox.TextField
                                    label="Tags"
                                    value={tagInputValue}
                                    onChange={setTagInputValue}
                                    placeholder=""
                                    autoComplete="off"
                                  />
                                }
                              >
                                {filteredTagOptions.length > 0 ? (
                                  <Listbox autoSelection={AutoSelection.None} onSelect={handleTagSelect}>
                                    {filteredTagOptions.map((tag) => (
                                      <Listbox.Option
                                        key={tag}
                                        value={tag}
                                        selected={selectedTags.includes(tag)}
                                      >
                                        {tag}
                                      </Listbox.Option>
                                    ))}
                                  </Listbox>
                                ) : tagInputValue.trim() ? (
                                  <Listbox autoSelection={AutoSelection.None} onSelect={handleTagSelect}>
                                    <Listbox.Action value={tagInputValue.trim()}>
                                      {`Add "${tagInputValue.trim()}"`}
                                    </Listbox.Action>
                                  </Listbox>
                                ) : null}
                              </Combobox>
                            </div>
                            {selectedTags.length > 0 && (
                              <InlineStack gap="200" wrap>
                                {selectedTags.map((tag) => (
                                  <Tag key={tag} onRemove={() => removeTag(tag)}>
                                    {tag}
                                  </Tag>
                                ))}
                              </InlineStack>
                            )}
                          </BlockStack>
                        )}
                      </BlockStack>
                    </BlockStack>
                  </Card>

                  {!widgetEnabled && (
                    <Card>
                      <BlockStack gap="300">
                        <Text as="h2" variant="headingMd">What happens when customer clicks</Text>
                        <BlockStack gap="300">
                          <RadioButton label="Quick confirm popup" id="msg-popup" name="messageType" checked={messageType === "popup"} onChange={() => setMessageType("popup")} />
                          <RadioButton label="Popup with full form" id="msg-popup-form" name="messageType" checked={messageType === "popup_and_form"} onChange={() => setMessageType("popup_and_form")} />
                        </BlockStack>
                      </BlockStack>
                    </Card>
                  )}

                  <Card>
                    <BlockStack gap="300">
                      <Text as="h2" variant="headingMd">Hide price settings</Text>

                      <Banner tone="info">
                        <Text as="p" variant="bodySm">
                          These settings apply to storefront pages only (product, collection, home, and cart pages). They do <strong>not</strong> affect the quote form.
                        </Text>
                        <Text as="p" variant="bodySm">
                          To show or hide price on the quote form, go to the <strong>Form Builder</strong> tab in Quote Settings. Price on the quote form is controlled separately because it supports negotiable pricing.
                        </Text>
                      </Banner>

                      {/* Target scope */}
                      <BlockStack gap="300">
                        {/* All products */}
                        <RadioButton
                          label="All products"
                          id="hp-all"
                          name="hidePriceTarget"
                          checked={hidePriceTarget === "all"}
                          onChange={() => {
                            setHidePriceTarget("all");
                            setHidePriceProducts([]);
                            setHidePriceCollections([]);
                          }}
                        />

                        {/* Specific collections */}
                        <RadioButton
                          label="Specific collections only"
                          id="hp-col"
                          name="hidePriceTarget"
                          checked={hidePriceTarget === "collections"}
                          onChange={() => {
                            setHidePriceTarget("collections");
                            setHidePriceProducts([]);
                          }}
                        />

                        {hidePriceTarget === "collections" && (
                          <ResourcePickerList
                            type="collection"
                            selected={hidePriceCollections}
                            onChange={setHidePriceCollections}
                            placeholder="Search collections…"
                          />
                        )}

                        {/* Hand-picked products */}
                        <RadioButton
                          label="Hand-picked products only"
                          id="hp-specific"
                          name="hidePriceTarget"
                          checked={hidePriceTarget === "specific"}
                          onChange={() => {
                            setHidePriceTarget("specific");
                            setHidePriceCollections([]);
                          }}
                        />

                        {hidePriceTarget === "specific" && (
                          <ResourcePickerList
                            type="product"
                            selected={hidePriceProducts}
                            onChange={setHidePriceProducts}
                            placeholder="Search products…"
                          />
                        )}
                      </BlockStack>

                      <Divider />

                      {/* Pages */}
                      <Text variant="headingSm" as="h3">Hide on pages</Text>
                      <BlockStack gap="300">
                        <Checkbox label="Product page" checked={hidePriceProductPage} onChange={setHidePriceProductPage} />
                        <Checkbox label="Collection page" checked={hidePriceCollectionPage} onChange={setHidePriceCollectionPage} />
                        <Checkbox label="Home page" checked={hidePriceHomePage} onChange={setHidePriceHomePage} />
                        <Checkbox label="Cart page" checked={hidePriceCartPage} onChange={setHidePriceCartPage} />
                      </BlockStack>

                      <Divider />

                      <Text variant="headingSm" as="h3">Also hide these buttons</Text>
                      <BlockStack gap="300">
                        <Checkbox label="Hide Add to Cart button" checked={hideAddToCart} onChange={setHideAddToCart} />
                        <Checkbox label="Hide Buy Now button" checked={hideBuyItNow} onChange={setHideBuyItNow} />
                      </BlockStack>

                      <Divider />

                      <Text variant="headingSm" as="h3">When price is hidden, show</Text>
                      <BlockStack gap="300">
                        <RadioButton
                          label="Nothing"
                          id="hidePriceReplace_nothing"
                          name="hidePriceReplace_radio"
                          checked={hidePriceReplacement === "nothing"}
                          onChange={() => setHidePriceReplacement("nothing")}
                        />
                        <RadioButton
                          label="Replacement text"
                          id="hidePriceReplace_text"
                          name="hidePriceReplace_radio"
                          checked={hidePriceReplacement === "text"}
                          onChange={() => setHidePriceReplacement("text")}
                        />
                        {hidePriceReplacement === "text" && (
                          <TextField
                            value={replacementText}
                            onChange={setReplacementText}
                            autoComplete="off"
                          />
                        )}
                      </BlockStack>

                      <Divider />

                      <Text variant="headingSm" as="h3">Where the button appears</Text>
                      <BlockStack gap="300">
                        <RadioButton label="Above Add to Cart" id="pos-above" name="buttonPosition" checked={buttonPosition === "above_atc"} onChange={() => setButtonPosition("above_atc")} />
                        <RadioButton label="Below Add to Cart" id="pos-below" name="buttonPosition" checked={buttonPosition === "below_atc"} onChange={() => setButtonPosition("below_atc")} />
                      </BlockStack>
                    </BlockStack>
                  </Card>

                  <Card>
                    <BlockStack gap="400">
                      <Text as="h2" variant="headingMd">Styles</Text>

                      <BlockStack gap="100">
                        <TextField label="Button text" value={buttonLabel} onChange={setButtonLabel} autoComplete="off" />
                      </BlockStack>

                      <BlockStack gap="150">
                        <Text variant="bodyMd" as="p" fontWeight="medium">Button text color</Text>
                        <InlineGrid columns="auto 1fr" gap="200" alignItems="center">
                          <ColorSwatchPicker value={textColorHsb} onChange={setTextColorHsb} />
                        </InlineGrid>
                      </BlockStack>

                      <BlockStack gap="150">
                        <Text variant="bodyMd" as="p" fontWeight="medium">Button background color</Text>
                        <InlineGrid columns="auto 1fr" gap="200" alignItems="center">
                          <ColorSwatchPicker value={buttonColorHsb} onChange={setButtonColorHsb} />
                        </InlineGrid>
                      </BlockStack>

                      <BlockStack gap="150">
                        <Text variant="bodyMd" as="p" fontWeight="medium">Text size</Text>
                        <RangeSlider label="" labelHidden min={10} max={32} step={1} value={fontSize} onChange={(v) => setFontSize(Number(v))} output suffix={<Text variant="bodySm">{fontSize}px</Text>} />
                      </BlockStack>

                    </BlockStack>
                  </Card>

                  <Card>
                    <BlockStack gap="400">
                      <InlineStack align="space-between" blockAlign="center">
                        <Text as="h2" variant="headingMd">Quote Widget</Text>
                        <Badge tone={widgetEnabled ? "success" : undefined}>
                          {widgetEnabled ? "Active" : "Inactive"}
                        </Badge>
                      </InlineStack>

                      <Checkbox
                        label="Enable floating quote widget"
                        helpText="Shows a fixed button on every storefront page"
                        checked={widgetEnabled}
                        onChange={setWidgetEnabled}
                      />

                      <TextField
                        label="Button label"
                        value={widgetButtonText}
                        onChange={setWidgetButtonText}
                        autoComplete="off"
                        disabled={!widgetEnabled}
                      />

                      <Divider />

                      <Text variant="headingSm" as="h3">Widget position</Text>
                      <BlockStack gap="200">
                        {[
                          { label: "Bottom right", value: "bottom_right" },
                          { label: "Half bottom right", value: "half_bottom_right" },
                          { label: "Half top right", value: "half_top_right" },
                          { label: "Bottom left", value: "bottom_left" },
                          { label: "Half bottom left", value: "half_bottom_left" },
                          { label: "Half top left", value: "half_top_left" },
                        ].map(({ label, value }) => (
                          <RadioButton
                            key={value}
                            label={label}
                            id={`widget-pos-${value}`}
                            name="widgetPosition"
                            checked={widgetPosition === value}
                            onChange={() => setWidgetPosition(value)}
                            disabled={!widgetEnabled}
                          />
                        ))}
                      </BlockStack>

                      <Divider />

                      <Text variant="headingSm" as="h3">Color</Text>
                      <BlockStack gap="300">
                        <BlockStack gap="150">
                          <Text variant="bodyMd" as="p" fontWeight="medium">Text color</Text>
                          <InlineGrid columns="auto 1fr" gap="200" alignItems="center">
                            <ColorSwatchPicker value={widgetTxtColorHsb} onChange={setWidgetTxtColorHsb} disabled={!widgetEnabled} />
                          </InlineGrid>
                        </BlockStack>

                        <BlockStack gap="150">
                          <Text variant="bodyMd" as="p" fontWeight="medium">Background color</Text>
                          <InlineGrid columns="auto 1fr" gap="200" alignItems="center">
                            <ColorSwatchPicker value={widgetBgColorHsb} onChange={setWidgetBgColorHsb} disabled={!widgetEnabled} />
                          </InlineGrid>
                        </BlockStack>
                      </BlockStack>
                    </BlockStack>
                  </Card>

                  <Card>
                    <BlockStack gap="300">
                      <InlineStack align="space-between" blockAlign="center">
                        <Text as="h2" variant="headingMd">Notification (toast)</Text>
                        <Badge tone={toastEnabled ? "success" : undefined}>
                          {toastEnabled ? "Active" : "Inactive"}
                        </Badge>
                      </InlineStack>

                      <Text as="p" variant="bodySm" tone="subdued">
                        Setup the messages for the toast notifications
                      </Text>

                      <Checkbox
                        label="Enable 'Add to quote cart' notification"
                        checked={toastEnabled}
                        onChange={setToastEnabled}
                      />

                      <TextField
                        label="Add to quote cart message"
                        value={toastMessage}
                        onChange={setToastMessage}
                        autoComplete="off"
                        maxLength={120}
                        disabled={!toastEnabled}
                      />

                      <Divider />

                      <Checkbox
                        label="Enable 'Quote submit success' notification"
                        checked={successToastEnabled}
                        onChange={setSuccessToastEnabled}
                      />

                      <TextField
                        label="Quote submit success message"
                        helpText="Shown to the customer after the quote is submitted"
                        value={successMessage}
                        onChange={setSuccessMessage}
                        autoComplete="off"
                        disabled={!successToastEnabled}
                      />

                      <Divider />

                      <Text variant="headingSm" as="h3">Size &amp; shape</Text>
                      <InlineGrid columns={{ xs: 1, sm: 3 }} gap="300" alignItems="end">
                        <TextField label="Font size" suffix="px" type="number" min={8} max={32} value={String(toastFontSize)} onChange={(v) => setToastFontSize(parseInt(v || "0", 10) || 0)} autoComplete="off" />
                        <TextField label="Corner radius" suffix="px" type="number" min={0} max={60} value={String(toastBorderRadius)} onChange={(v) => setToastBorderRadius(parseInt(v || "0", 10) || 0)} autoComplete="off" />
                        <TextField label="Border width" suffix="px" type="number" min={0} max={10} value={String(toastBorderWidth)} onChange={(v) => setToastBorderWidth(parseInt(v || "0", 10) || 0)} autoComplete="off" />
                      </InlineGrid>

                      <Divider />

                      <Text variant="headingSm" as="h3">Colors</Text>
                      <BlockStack gap="300">
                        <BlockStack gap="150">
                          <Text variant="bodyMd" as="p" fontWeight="medium">Text color</Text>
                          <InlineGrid columns="auto 1fr" gap="200" alignItems="center">
                            <ColorSwatchPicker value={toastTxtColorHsb} onChange={setToastTxtColorHsb} />
                          </InlineGrid>
                        </BlockStack>

                        <BlockStack gap="150">
                          <Text variant="bodyMd" as="p" fontWeight="medium">Background color</Text>
                          <InlineGrid columns="auto 1fr" gap="200" alignItems="center">
                            <ColorSwatchPicker value={toastBgColorHsb} onChange={setToastBgColorHsb} />
                          </InlineGrid>
                        </BlockStack>

                        <BlockStack gap="150">
                          <Text variant="bodyMd" as="p" fontWeight="medium">Border color</Text>
                          <InlineGrid columns="auto 1fr" gap="200" alignItems="center">
                            <ColorSwatchPicker value={toastBorderColorHsb} onChange={setToastBorderColorHsb} />
                          </InlineGrid>
                        </BlockStack>
                      </BlockStack>

                      <Divider />

                      <Select
                        label="Position"
                        options={[
                          { label: "Top left", value: "top_left" },
                          { label: "Top center", value: "top_center" },
                          { label: "Top right", value: "top_right" },
                          { label: "Bottom left", value: "bottom_left" },
                          { label: "Bottom center", value: "bottom_center" },
                          { label: "Bottom right", value: "bottom_right" },
                        ]}
                        value={toastPosition}
                        onChange={setToastPosition}
                      />
                    </BlockStack>
                  </Card>

                  <Button variant="secondary" fullWidth onClick={() => setSelected(1)}>
                    Next: set up the form →
                  </Button>
                  <Box paddingBlockEnd="600" />
                </BlockStack>

                {/* RIGHT — Tab 1 Live Preview (identical to original) */}
                {(() => {
                  const btnBg = buttonColorHsb;
                  const btnTxt = textColorHsb;
                  const quoteBtn = displayMode !== "hide" && (
                    <button style={{ width: buttonWidth === "full" ? "100%" : "auto", background: btnBg, color: btnTxt, fontSize, border: "none", borderRadius: buttonBorderRadius, padding: "10px 16px", cursor: "pointer", fontWeight: 600, letterSpacing: 0.2 }}>
                      {buttonLabel || "Request a Quote"}
                    </button>
                  );
                  const atcBtn = !hideAddToCart && (
                    <button style={{ width: "100%", background: "#1a1a18", color: "#fff", fontSize: 14, border: "none", borderRadius: 6, padding: "10px 16px", cursor: "pointer", fontWeight: 600 }}>Add to Cart</button>
                  );
                  const buyNowBtn = !hideBuyItNow && (
                    <button style={{ width: "100%", background: "#fff", color: "#1a1a18", fontSize: 14, border: "1px solid #1a1a18", borderRadius: 6, padding: "10px 16px", cursor: "pointer", fontWeight: 600 }}>Buy it Now</button>
                  );
                  const renderButtons = () => {
                    if (buttonPosition === "replace_atc") return <>{quoteBtn}{buyNowBtn}</>;
                    if (buttonPosition === "above_atc") return <>{quoteBtn}{atcBtn}{buyNowBtn}</>;
                    return <>{atcBtn}{buyNowBtn}{quoteBtn}</>;
                  };
                  const renderProductPage = (compact) => (
                    <div style={{ padding: compact ? "14px 12px 16px" : "20px 24px 24px" }}>
                      <img
                        src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&h=450&fit=crop&auto=format"
                        alt="Sample product"
                        style={{ width: "100%", aspectRatio: compact ? "4/3" : "16/9", objectFit: "cover", borderRadius: compact ? 8 : 10, display: "block", marginBottom: compact ? 10 : 14 }}
                      />
                      <Text variant="bodySm" tone="subdued" as="p">Vendor Name</Text>
                      <Text variant={compact ? "headingSm" : "headingMd"} as="h2">Sample Product Title</Text>
                      <div style={{ marginTop: compact ? 4 : 6 }}>
                        {hidePriceProductPage
                          ? hidePriceReplacement === "nothing"
                            ? null
                            : <Text variant="bodySm" tone="subdued" as="p" style={{ fontStyle: "italic", color: replacementTextColor }}>{replacementText || "Price available on request"}</Text>
                          : <Text variant={compact ? "bodyMd" : "headingSm"} fontWeight="semibold" as="p">{currSym}1,299.00</Text>
                        }
                      </div>
                      <div style={{ marginTop: compact ? 8 : 12 }}>
                        <Text variant="bodySm" fontWeight="semibold" as="p">Size</Text>
                        <div style={{ display: "flex", gap: 6, marginTop: 5, flexWrap: "wrap" }}>
                          {["S", "M", "L", "XL"].map((s, i) => (
                            <div key={s} style={{ border: `1px solid ${i === 1 ? "#1a1a18" : "#d8d8d0"}`, borderRadius: 4, padding: compact ? "3px 8px" : "4px 12px", fontSize: compact ? 11 : 13, background: i === 1 ? "#1a1a18" : "#fff", color: i === 1 ? "#fff" : "#333", cursor: "pointer" }}>{s}</div>
                          ))}
                        </div>
                      </div>
                      <div style={{ marginTop: compact ? 10 : 14, display: "flex", flexDirection: "column", gap: compact ? 6 : 8 }}>
                        {renderButtons()}
                      </div>
                      {displayMode !== "hide" && (
                        <div style={{ marginTop: compact ? 8 : 10 }}>
                          <Text variant="bodySm" tone="subdued" as="span">
                            {widgetEnabled
                              ? "↗ Adds product to quote cart"
                              : messageType === "popup"
                                ? "↗ Opens popup on click"
                                : "↗ Opens popup with form"}
                          </Text>
                        </div>
                      )}
                      {displayMode !== "hide" && successMessage && (
                        <div style={{ marginTop: 4, padding: "4px 8px", background: "#f0f8ee", borderRadius: 4, border: "1px dashed #b5d9af" }}>
                          <Text variant="bodySm" tone="subdued" as="span">✓ {successMessage}</Text>
                        </div>
                      )}
                    </div>
                  );
                  const wBg = widgetBgColorHsb;
                  const wTxt = widgetTxtColorHsb;
                  const wLabel = widgetButtonText || "Request a Quote";
                  const widgetStyle = (() => {
                    const base = {
                      position: "absolute", zIndex: 10,
                      background: wBg, color: wTxt,
                      border: "none", borderRadius: 6,
                      fontWeight: 600, fontSize: 11,
                      cursor: "pointer", whiteSpace: "nowrap",
                      padding: "6px 12px", boxShadow: "0 2px 8px rgba(0,0,0,0.18)",
                    };
                    switch (widgetPosition) {
                      case "bottom_right": return { ...base, bottom: 12, right: 12 };
                      case "bottom_left": return { ...base, bottom: 12, left: 12 };
                      case "half_bottom_right": return { ...base, bottom: "30%", right: 0, borderRadius: "6px 0 0 6px", writingMode: "vertical-rl", transform: "rotate(180deg)", padding: "12px 6px" };
                      case "half_top_right": return { ...base, top: "30%", right: 0, borderRadius: "6px 0 0 6px", writingMode: "vertical-rl", transform: "rotate(180deg)", padding: "12px 6px" };
                      case "half_bottom_left": return { ...base, bottom: "30%", left: 0, borderRadius: "0 6px 6px 0", writingMode: "vertical-lr", padding: "12px 6px" };
                      case "half_top_left": return { ...base, top: "30%", left: 0, borderRadius: "0 6px 6px 0", writingMode: "vertical-lr", padding: "12px 6px" };
                      default: return { ...base, bottom: 12, right: 12 };
                    }
                  })();
                  return (
                    <div style={{ position: "sticky", top: 20, paddingBottom: 48 }}>
                      <Card padding="0">
                        <div style={{ border: "1px solid #e3e3db", borderRadius: 8, overflow: "hidden" }}>
                          <div style={{ padding: "10px 14px", background: "#f6f6f1", borderBottom: "1px solid #e3e3db", display: "flex", alignItems: "center", gap: 6 }}>
                            <div style={{ width: 10, height: 10, borderRadius: "50%", background: "#ff5f57" }} />
                            <div style={{ width: 10, height: 10, borderRadius: "50%", background: "#ffbd2e" }} />
                            <div style={{ width: 10, height: 10, borderRadius: "50%", background: "#28c840" }} />
                            <Text variant="bodySm" fontWeight="semibold" tone="subdued" as="span">&nbsp;&nbsp;STOREFRONT PREVIEW</Text>
                          </div>
                          <div style={{ background: "#f0f0eb", padding: "16px 20px 20px" }}>
                            <div style={{ maxWidth: 340, margin: "0 auto", background: "#fff", borderRadius: 12, border: "1px solid #d8d8d0", overflow: "hidden", boxShadow: "0 2px 12px rgba(0,0,0,0.08)", position: "relative" }}>
                              <div style={{ background: "#f6f6f1", borderBottom: "1px solid #e3e3db", padding: "8px 12px", display: "flex", alignItems: "center", gap: 8 }}>
                                <div style={{ display: "flex", gap: 5 }}>
                                  {["#e0e0d8", "#e0e0d8", "#e0e0d8"].map((c, i) => <div key={i} style={{ width: 8, height: 8, borderRadius: "50%", background: c }} />)}
                                </div>
                                <div style={{ flex: 1, background: "#ebebeb", borderRadius: 4, padding: "3px 8px" }}>
                                  <Text variant="bodySm" tone="subdued" as="span">yourstore.com/products/sample</Text>
                                </div>
                              </div>
                              <div style={{ maxHeight: 500, overflowY: "auto" }}>
                                {renderProductPage(true)}
                              </div>
                              {widgetEnabled && (
                                <button style={widgetStyle}>{wLabel}</button>
                              )}
                              {toastEnabled && (
                                <div style={{
                                  position: "absolute", zIndex: 20,
                                  background: toastBgColorHsb, color: toastTxtColorHsb,
                                  border: `${toastBorderWidth}px solid ${toastBorderColorHsb}`,
                                  borderRadius: toastBorderRadius,
                                  fontWeight: 500, fontSize: toastFontSize,
                                  whiteSpace: "nowrap", padding: "8px 14px",
                                  boxShadow: "0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -1px rgba(0,0,0,0.06)",
                                  ...(() => {
                                    switch (toastPosition) {
                                      case "top_left": return { top: 12, left: 12 };
                                      case "top_center": return { top: 12, left: "50%", transform: "translateX(-50%)" };
                                      case "top_right": return { top: 12, right: 12 };
                                      case "bottom_left": return { bottom: 12, left: 12 };
                                      case "bottom_center": return { bottom: 12, left: "50%", transform: "translateX(-50%)" };
                                      case "bottom_right": return { bottom: 12, right: 12 };
                                      default: return { bottom: 12, left: "50%", transform: "translateX(-50%)" };
                                    }
                                  })()
                                }}>{toastMessage || "Product added to quote cart."}</div>
                              )}
                            </div>
                          </div>
                        </div>
                      </Card>
                    </div>
                  );
                })()}
              </div>
            )}

            {/* ════ TAB 2 ════ */}
            {selected === 1 && (
              <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "43% 57%", gap: "20px", alignItems: "start" }}>

                {/* LEFT */}
                <BlockStack gap="400">

                  {/* ── Form content + Submit button style (merged) ── */}
                  <Card>
                    <BlockStack gap="400">
                      <Text as="h2" variant="headingMd">Form content</Text>
                      <TextField label="Form heading" value={formTitle} onChange={setFormTitle} autoComplete="off" />

                      <Divider />

                      <Text as="h3" variant="headingSm" fontWeight="semibold">Submit button style</Text>

                      <TextField label="Submit button text" value={submitButtonLabel} onChange={setSubmitButtonLabel} autoComplete="off" />

                      <BlockStack gap="150">
                        <Text variant="bodyMd" as="p" fontWeight="medium">Button text color</Text>
                        <InlineGrid columns="auto 1fr" gap="200" alignItems="center">
                          <ColorSwatchPicker value={formBtnTextColorHsb} onChange={setFormBtnTextColorHsb} />
                        </InlineGrid>
                      </BlockStack>

                      <BlockStack gap="150">
                        <Text variant="bodyMd" as="p" fontWeight="medium">Button background color</Text>
                        <InlineGrid columns="auto 1fr" gap="200" alignItems="center">
                          <ColorSwatchPicker value={formBtnColorHsb} onChange={setFormBtnColorHsb} />
                        </InlineGrid>
                      </BlockStack>

                      <BlockStack gap="150">
                        <Text variant="bodyMd" as="p" fontWeight="medium">Text size</Text>
                        <RangeSlider label="" labelHidden min={10} max={32} step={1} value={formBtnFontSize} onChange={(v) => setFormBtnFontSize(Number(v))} output suffix={<Text variant="bodySm">{formBtnFontSize}px</Text>} />
                      </BlockStack>

                      <BlockStack gap="150">
                        <Text variant="bodyMd" as="p" fontWeight="medium">Button corner roundness</Text>
                        <RangeSlider label="" labelHidden min={0} max={24} step={1} value={formBtnBorderRadius} onChange={(v) => setFormBtnBorderRadius(Number(v))} output suffix={<Text variant="bodySm">{formBtnBorderRadius}px</Text>} />
                      </BlockStack>
                    </BlockStack>
                  </Card>

                  <Card>
                    <BlockStack gap="300">
                      {/* ── FIXED: was raw button, now Polaris Button ── */}
                      <InlineStack align="space-between" blockAlign="center">
                        <Text as="h2" variant="headingMd">Show product details in form</Text>
                        <Button variant="plain" icon={productInfoOpen ? ChevronUpIcon : ChevronDownIcon} onClick={() => setProductInfoOpen((o) => !o)} accessibilityLabel={productInfoOpen ? "Collapse" : "Expand"} />
                      </InlineStack>
                      <Collapsible open={productInfoOpen} id="product-info-collapsible">
                        <BlockStack gap="300">
                          <Checkbox label="Vendor" checked={showVendor} onChange={setShowVendor} />
                          <Checkbox label="SKU" checked={showSku} onChange={setShowSku} />
                          <Checkbox label="Price" checked={showPrice} onChange={setShowPrice} />
                          <Checkbox label="Quote Price" checked={showQuotePrice} onChange={setShowQuotePrice} />
                          <Checkbox label="Note" checked={showNote} onChange={setShowNote} />
                        </BlockStack>
                      </Collapsible>
                    </BlockStack>
                  </Card>

                  <Card>
                    <BlockStack gap="400">
                      <Box paddingBlockEnd="200" borderBlockEndWidth="025" borderColor="border">
                        <InlineStack align="space-between" blockAlign="center">
                          <BlockStack gap="050">
                            <Text as="h2" variant="headingMd">Contact fields</Text>
                            <Text variant="bodySm" tone="subdued">Collected from the customer</Text>
                          </BlockStack>
                          <Button variant="plain" icon={contactSectionOpen ? ChevronUpIcon : ChevronDownIcon} onClick={() => setContactSectionOpen((o) => !o)} accessibilityLabel={contactSectionOpen ? "Collapse" : "Expand"} />
                        </InlineStack>
                      </Box>
                      <Collapsible open={contactSectionOpen} id="contact-section-collapsible" transition={{ duration: "200ms", timingFunction: "ease-in-out" }}>
                        {renderFieldSection(contactElements, updateContactElement, removeContactElement, moveElement, addOption, updateOption, removeOption, showElementPicker, setShowElementPicker, addContactElement)}
                      </Collapsible>
                    </BlockStack>
                  </Card>

                  <Card>
                    <BlockStack gap="400">
                      <Box paddingBlockEnd="200" borderBlockEndWidth="025" borderColor="border">
                        <InlineStack align="space-between" blockAlign="center">
                          <BlockStack gap="050">
                            <Text as="h2" variant="headingMd">Shipping fields</Text>
                            <Text variant="bodySm" tone="subdued">Where to send the order</Text>
                          </BlockStack>
                          <Button variant="plain" icon={shippingSectionOpen ? ChevronUpIcon : ChevronDownIcon} onClick={() => setShippingSectionOpen((o) => !o)} accessibilityLabel={shippingSectionOpen ? "Collapse" : "Expand"} />
                        </InlineStack>
                      </Box>
                      <Collapsible open={shippingSectionOpen} id="shipping-section-collapsible" transition={{ duration: "200ms", timingFunction: "ease-in-out" }}>
                        {renderFieldSection(shippingElements, updateShippingElement, removeShippingElement, moveShippingElement, addShippingOption, updateShippingOption, removeShippingOption, showShippingPicker, setShowShippingPicker, addShippingElement)}
                      </Collapsible>
                    </BlockStack>
                  </Card>

                  <Card>
                    <BlockStack gap="400">
                      <Box paddingBlockEnd="200" borderBlockEndWidth="025" borderColor="border">
                        <InlineStack align="space-between" blockAlign="center">
                          <BlockStack gap="050">
                            <Text as="h2" variant="headingMd">Additional fields</Text>
                            <Text variant="bodySm" tone="subdued">Any extra information you need</Text>
                          </BlockStack>
                          <Button variant="plain" icon={extraInfoSectionOpen ? ChevronUpIcon : ChevronDownIcon} onClick={() => setExtraInfoSectionOpen((o) => !o)} accessibilityLabel={extraInfoSectionOpen ? "Collapse" : "Expand"} />
                        </InlineStack>
                      </Box>
                      <Collapsible open={extraInfoSectionOpen} id="extra-info-collapsible" transition={{ duration: "200ms", timingFunction: "ease-in-out" }}>
                        {renderFieldSection(extraInfoElements, updateExtraInfoElement, removeExtraInfoElement, moveExtraInfoElement, addExtraInfoOption, updateExtraInfoOption, removeExtraInfoOption, showExtraInfoPicker, setShowExtraInfoPicker, addExtraInfoElement)}
                      </Collapsible>
                    </BlockStack>
                  </Card>

                  <Box paddingBlockEnd="600" />
                </BlockStack>

                {/* RIGHT — Tab 2 Live Preview (identical to original) */}
                <div style={{ position: "sticky", top: 20, paddingBottom: 48 }}>
                  <Card padding="0">
                    <div style={{ border: "1px solid #e3e3db", borderRadius: 8, overflow: "hidden" }}>
                      <div style={{ padding: "10px 14px", background: "#f6f6f1", borderBottom: "1px solid #e3e3db", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                          <div style={{ width: 10, height: 10, borderRadius: "50%", background: "#ff5f57" }} />
                          <div style={{ width: 10, height: 10, borderRadius: "50%", background: "#ffbd2e" }} />
                          <div style={{ width: 10, height: 10, borderRadius: "50%", background: "#28c840" }} />
                          <Text variant="bodySm" fontWeight="semibold" tone="subdued" as="span">&nbsp;&nbsp;MOBILE PREVIEW</Text>
                        </div>
                        <Button variant="plain" icon={DesktopIcon} onClick={() => setDesktopPreviewOpen(true)}>Desktop Preview</Button>
                      </div>

                      <div style={{ background: "#f0f0eb", padding: "16px 20px 20px" }}>
                        <div style={{ maxWidth: 340, margin: "0 auto", background: "#fff", borderRadius: 12, border: "1px solid #d8d8d0", overflow: "hidden", boxShadow: "0 2px 12px rgba(0,0,0,0.08)" }}>
                          <div style={{ background: "#f6f6f1", borderBottom: "1px solid #e3e3db", padding: "8px 12px", display: "flex", alignItems: "center", gap: 8 }}>
                            <div style={{ display: "flex", gap: 5 }}>
                              <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#e0e0d8" }} />
                              <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#e0e0d8" }} />
                              <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#e0e0d8" }} />
                            </div>
                            <div style={{ flex: 1, background: "#ebebeb", borderRadius: 4, padding: "3px 8px" }}>
                              <Text variant="bodySm" tone="subdued" as="span">yourstore.com/cart</Text>
                            </div>
                          </div>

                          <div style={{ maxHeight: 500, overflowY: "auto" }}>
                            <div style={{ padding: "12px 12px 8px", borderBottom: "1px solid #e3e3db" }}>
                              <Text variant="headingMd" fontWeight="bold" as="p">{formTitle}</Text>
                            </div>
                            <div style={{ padding: "10px 12px 4px" }}>
                              <Text variant="headingSm" fontWeight="bold" as="p">Quoted Products</Text>
                            </div>
                            {previewProducts.map((p) => (
                              <div key={p.id} style={{ padding: "8px 12px 10px", borderBottom: "1px solid #f2f2ee" }}>
                                <div style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
                                  <img src={p.image} alt={p.title} style={{ width: 38, height: 38, borderRadius: 6, objectFit: "cover", border: "1px solid #e8e4dd", flexShrink: 0, display: "block" }} />
                                  <div style={{ flex: 1, minWidth: 0 }}>
                                    <Text variant="bodySm" fontWeight="semibold" as="p" truncate>{p.title}</Text>
                                    {showPrice && <Text variant="bodySm" tone="subdued" as="p">{p.price}</Text>}
                                    {showVendor && <Text variant="bodySm" tone="subdued" as="p">{p.vendor}</Text>}
                                    {showSku && <Text variant="bodySm" tone="subdued" as="p">#{p.sku}</Text>}
                                    {showOption && (
                                      <div style={{ marginTop: 3, display: "inline-flex", alignItems: "center", gap: 3, background: "#f5f5f0", border: "1px solid #e3e3db", borderRadius: 4, padding: "1px 6px" }}>
                                        <Text variant="bodySm" as="span">{p.option}</Text>
                                        <Icon source={ChevronDownIcon} tone="subdued" />
                                      </div>
                                    )}
                                  </div>
                                  <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 5, flexShrink: 0 }}>
                                    <div style={{ display: "flex", alignItems: "center", gap: 5, border: "1px solid #e3e3db", borderRadius: 5, padding: "2px 7px" }}>
                                      <button onClick={() => updatePreviewQty(p.id, -1)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 13, lineHeight: 1, color: "#555" }}>−</button>
                                      <Text variant="bodySm" as="span">{p.qty}</Text>
                                      <button onClick={() => updatePreviewQty(p.id, 1)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 13, lineHeight: 1, color: "#555" }}>+</button>
                                    </div>
                                    {showQuotePrice && (
                                      <input value={p.offerPrice} onChange={(e) => updatePreviewOfferPrice(p.id, e.target.value)} placeholder={`${currSym} Price`}
                                        style={{ width: 62, border: "1px solid #e3e3db", borderRadius: 4, padding: "2px 5px", fontSize: 11, textAlign: "right", outline: "none", color: "#333" }}
                                      />
                                    )}
                                    <Button variant="plain" tone="critical" icon={DeleteIcon} onClick={() => removePreviewProduct(p.id)} accessibilityLabel="Remove" />
                                  </div>
                                </div>
                                {showNote && (
                                  <div style={{ marginTop: 5, paddingLeft: 46 }}>
                                    <button onClick={() => togglePreviewNote(p.id)} style={{ display: "inline-flex", alignItems: "center", gap: 4, background: "none", border: "none", cursor: "pointer", padding: 0 }}>
                                      <Icon source={NoteIcon} tone="subdued" />
                                      <Text variant="bodySm" tone="subdued" as="span">{p.noteOpen ? "Hide note" : "Add note"}</Text>
                                    </button>
                                    {p.noteOpen && (
                                      <div style={{ marginTop: 4 }}>
                                        <TextField value={p.note} onChange={(val) => updatePreviewNote(p.id, val)} placeholder="Add a note..." multiline={2} autoComplete="off" />
                                      </div>
                                    )}
                                  </div>
                                )}
                              </div>
                            ))}

                            {/* Form preview — Interactive Test Mode */}
                            <div style={{ fontFamily: "inherit" }}>
                              {/* Mode toggle bar */}
                              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 14px 8px", borderTop: "1px solid #f0f0e8", background: previewMode ? "#f0f7ff" : "#fafaf7" }}>
                                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                                  <button
                                    onClick={() => { setPreviewMode((m) => !m); clearTestData(); }}
                                    style={{
                                      display: "flex", alignItems: "center", gap: 6,
                                      padding: "4px 10px", borderRadius: 20,
                                      border: `1px solid ${previewMode ? accentColor : "#c9cccf"}`,
                                      background: previewMode ? accentColor : "#fff",
                                      color: previewMode ? "#fff" : "#374151",
                                      fontSize: 11, fontWeight: 600, cursor: "pointer",
                                      transition: "all 0.2s",
                                    }}
                                  >
                                    <svg width="12" height="12" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" />
                                    </svg>
                                    {previewMode ? "Test Mode ON" : "Test Mode"}
                                  </button>
                                  {previewMode && (
                                    <button onClick={clearTestData} style={{ padding: "4px 8px", borderRadius: 20, border: "1px solid #e3e3db", background: "#fff", color: "#6b7280", fontSize: 11, cursor: "pointer" }}>
                                      Clear
                                    </button>
                                  )}
                                </div>
                                {previewMode && <span style={{ fontSize: 10, color: accentColor, fontWeight: 500 }}>✏️ You can type here</span>}
                              </div>

                              <div style={{ padding: "14px 14px 20px" }}>
                                <div style={{ fontSize: 15, fontWeight: 700, color: "#1a1a18", marginBottom: 16 }}>{formTitle || "Request a Quote"}</div>

                                {/* Success banner */}
                                {previewSubmitted && (
                                  <div style={{
                                    marginBottom: 16,
                                    padding: "12px 14px",
                                    borderRadius: 8,
                                    background: "#f0fdf4",
                                    border: "1px solid #86efac",
                                    display: "flex", alignItems: "flex-start", gap: 10
                                  }}>
                                    <svg width="18" height="18" fill="none" viewBox="0 0 24 24" stroke={successColor} strokeWidth="2" style={{ flexShrink: 0, marginTop: 1 }}>
                                      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                    </svg>
                                    <div>
                                      <div style={{ fontSize: 13, fontWeight: 600, color: successColor }}>Quote request submitted! ✓</div>
                                      <div style={{ fontSize: 11, color: successColor, marginTop: 2 }}>
                                        This test quote was sent to your store with a 🧪 TEST badge.
                                        {previewQuoteId && (
                                          <div style={{ marginTop: 4 }}>
                                            <a href={`/app/quote/${previewQuoteId}`} target="_blank" rel="noopener noreferrer" style={{ color: successColor, textDecoration: "underline", fontWeight: 600 }}>View Quote →</a>
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                    <button onClick={() => setPreviewSubmitted(false)} style={{ marginLeft: "auto", background: "none", border: "none", cursor: "pointer", color: successColor, padding: 0 }}>×</button>
                                  </div>
                                )}

                                {contactElements.length > 0 && (
                                  <div style={{ marginBottom: 20 }}>
                                    <div style={{ fontSize: 13, fontWeight: 600, color: "#1a1a18", marginBottom: 12, paddingBottom: 8, borderBottom: "1px solid #e3e3db" }}>Contact</div>
                                    {(() => {
                                      const rows = [];
                                      const els = contactElements;
                                      for (let i = 0; i < els.length; i++) {
                                        const el = els[i];
                                        const next = els[i + 1];
                                        const isNamePair = (el.label === "First name" || el.label === "Last name") && next && (next.label === "First name" || next.label === "Last name");
                                        if (isNamePair) {
                                          rows.push(
                                            <div key={el.id} style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 10 }}>
                                              {[el, next].map((f) => (
                                                <div key={f.id}>
                                                  {previewMode
                                                    ? renderInteractiveFieldPreview(f, true)
                                                    : <>
                                                      <div style={{ fontSize: 11, color: "#6d7175", marginBottom: 4 }}>{f.label}{f.required && " *"}</div>
                                                      <div style={{ height: 36, border: "1px solid #c9cccf", borderRadius: 4, background: "#fff", padding: "0 10px", display: "flex", alignItems: "center" }}>
                                                        <span style={{ fontSize: 12, color: "#ccc" }}>{f.placeholder}</span>
                                                      </div>
                                                    </>
                                                  }
                                                </div>
                                              ))}
                                            </div>
                                          );
                                          i++;
                                        } else {
                                          rows.push(previewMode ? renderInteractiveFieldPreview(el, true) : renderVisualFieldPreview(el, true));
                                        }
                                      }
                                      return rows;
                                    })()}
                                  </div>
                                )}
                                {shippingElements.length > 0 && (
                                  <div style={{ marginBottom: 20 }}>
                                    <div style={{ fontSize: 13, fontWeight: 600, color: "#1a1a18", marginBottom: 12, paddingBottom: 8, borderBottom: "1px solid #e3e3db" }}>Shipping address</div>
                                    {shippingElements.map((el) => previewMode ? renderInteractiveFieldPreview(el, true) : renderVisualFieldPreview(el, true))}
                                  </div>
                                )}
                                {extraInfoElements.length > 0 && (
                                  <div style={{ marginBottom: 20 }}>
                                    <div style={{ fontSize: 13, fontWeight: 600, color: "#1a1a18", marginBottom: 12, paddingBottom: 8, borderBottom: "1px solid #e3e3db" }}>Additional information</div>
                                    {extraInfoElements.map((el) => previewMode ? renderInteractiveFieldPreview(el, true) : renderVisualFieldPreview(el, true))}
                                  </div>
                                )}
                                <button
                                  onClick={previewMode ? handlePreviewSubmit : undefined}
                                  disabled={previewSending}
                                  style={{ width: "100%", height: 44, background: formBtnColorHsb, color: formBtnTextColorHsb, fontSize: formBtnFontSize, border: "none", borderRadius: formBtnBorderRadius, cursor: previewMode && !previewSending ? "pointer" : "default", fontWeight: 600, transition: "opacity 0.15s", opacity: previewMode && !previewSending ? 1 : 0.6 }}
                                >
                                  {previewSending ? "Sending..." : (submitButtonLabel || "Request a Quote")}
                                </button>
                                {previewMode && Object.keys(previewErrors).length > 0 && (
                                  <div style={{ marginTop: 8, fontSize: 11, color: errorColor, textAlign: "center" }}>
                                    Please fill in all required fields above.
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Card>

                  {/* Desktop Preview Modal (identical to original) */}
                  <Modal open={desktopPreviewOpen} onClose={() => setDesktopPreviewOpen(false)} title={formTitle || "Desktop Preview"} size="large">
                    <Modal.Section flush>
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", minHeight: 520 }}>
                        <div style={{ borderRight: "1px solid #e3e3db", overflowY: "auto" }}>
                          <div style={{ padding: "10px 16px", background: "#f9f9f6", borderBottom: "1px solid #e3e3db" }}>
                            <Text variant="bodySm" fontWeight="semibold" tone="subdued">QUOTED PRODUCTS</Text>
                          </div>
                          {previewProducts.map((p) => (
                            <div key={p.id} style={{ padding: "14px 16px", borderBottom: "1px solid #e3e3db" }}>
                              <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
                                <img src={p.image} alt={p.title} style={{ width: 52, height: 52, borderRadius: 8, objectFit: "cover", border: "1px solid #e3e3db", flexShrink: 0, display: "block" }} />
                                <div style={{ flex: 1, minWidth: 0 }}>
                                  <Text variant="bodyMd" fontWeight="semibold" as="p">{p.title}</Text>
                                  {showPrice && <Text variant="bodySm" tone="subdued" as="p">{p.price}</Text>}
                                  {showVendor && (
                                    <div style={{ display: "flex", gap: 4, marginTop: 3 }}>
                                      <Text variant="bodySm" fontWeight="semibold" as="span">Vendor:</Text>
                                      <Text variant="bodySm" tone="subdued" as="span">{p.vendor}</Text>
                                    </div>
                                  )}
                                  {showSku && (
                                    <div style={{ display: "flex", gap: 4, marginTop: 3 }}>
                                      <Text variant="bodySm" fontWeight="semibold" as="span">SKU:</Text>
                                      <Text variant="bodySm" tone="subdued" as="span">{p.sku}</Text>
                                    </div>
                                  )}
                                  {showOption && (
                                    <button style={{ display: "inline-flex", alignItems: "center", gap: 4, background: "#f5f5f0", border: "1px solid #e3e3db", borderRadius: 4, padding: "2px 8px", marginTop: 5, cursor: "pointer" }}>
                                      <Text variant="bodySm" as="span">{p.option}</Text>
                                      <Icon source={ChevronDownIcon} tone="subdued" />
                                    </button>
                                  )}
                                  {showNote && (
                                    <div style={{ marginTop: 6 }}>
                                      <button onClick={() => togglePreviewNote(p.id)} style={{ display: "inline-flex", alignItems: "center", gap: 4, background: "none", border: "none", cursor: "pointer", padding: 0 }}>
                                        <Icon source={NoteIcon} tone="subdued" />
                                        <Text variant="bodySm" tone="subdued" as="span">{p.noteOpen ? "Hide note" : "Add note"}</Text>
                                      </button>
                                      {p.noteOpen && (
                                        <div style={{ marginTop: 5 }}>
                                          <TextField value={p.note} onChange={(val) => updatePreviewNote(p.id, val)} placeholder="Add a note..." multiline={2} autoComplete="off" />
                                        </div>
                                      )}
                                    </div>
                                  )}
                                </div>
                                <Button variant="plain" tone="critical" icon={DeleteIcon} onClick={() => removePreviewProduct(p.id)} accessibilityLabel="Remove" />
                              </div>
                              <div style={{ display: "flex", alignItems: "center", gap: 12, marginTop: 10, paddingLeft: 64 }}>
                                <div style={{ display: "flex", alignItems: "center", gap: 2 }}>
                                  <Text variant="bodySm" tone="subdued" as="span">Qty&nbsp;</Text>
                                  <div style={{ display: "flex", alignItems: "center", gap: 8, border: "1px solid #e3e3db", borderRadius: 6, padding: "4px 10px" }}>
                                    <button onClick={() => updatePreviewQty(p.id, -1)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 15, lineHeight: 1, color: "#555" }}>−</button>
                                    <Text variant="bodyMd" as="span">{p.qty}</Text>
                                    <button onClick={() => updatePreviewQty(p.id, 1)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 15, lineHeight: 1, color: "#555" }}>+</button>
                                  </div>
                                </div>
                                {showQuotePrice && (
                                  <div style={{ display: "flex", alignItems: "center", gap: 6, flex: 1, maxWidth: 160 }}>
                                    <Text variant="bodySm" tone="subdued" as="span">Offer&nbsp;</Text>
                                    <TextField value={p.offerPrice} onChange={(val) => updatePreviewOfferPrice(p.id, val)} placeholder="Enter price" prefix={currSym} autoComplete="off" />
                                  </div>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                        <div style={{ padding: 24, overflowY: "auto", fontFamily: "inherit", display: "flex", flexDirection: "column" }}>
                          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
                            <div style={{ fontSize: 18, fontWeight: 700, color: "#1a1a18" }}>{formTitle || "Request a Quote"}</div>
                            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                              {previewMode && (
                                <button onClick={clearTestData} style={{ padding: "5px 12px", borderRadius: 20, border: "1px solid #e3e3db", background: "#fff", color: "#6b7280", fontSize: 12, cursor: "pointer" }}>
                                  Clear
                                </button>
                              )}
                              <button
                                onClick={() => { setPreviewMode((m) => !m); clearTestData(); }}
                                style={{
                                  display: "flex", alignItems: "center", gap: 6,
                                  padding: "5px 14px", borderRadius: 20,
                                  border: `1px solid ${previewMode ? accentColor : "#c9cccf"}`,
                                  background: previewMode ? accentColor : "#fff",
                                  color: previewMode ? "#fff" : "#374151",
                                  fontSize: 12, fontWeight: 600, cursor: "pointer",
                                  transition: "all 0.2s",
                                }}
                              >
                                <svg width="13" height="13" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" />
                                </svg>
                                {previewMode ? "Test Mode ON" : "Test Mode"}
                              </button>
                            </div>
                          </div>

                          {/* Success banner */}
                          {previewSubmitted && (
                            <div style={{
                              marginBottom: 20,
                              padding: "14px 16px",
                              borderRadius: 8,
                              background: "#f0fdf4",
                              border: "1px solid #86efac",
                              display: "flex", alignItems: "flex-start", gap: 12
                            }}>
                              <svg width="20" height="20" fill="none" viewBox="0 0 24 24" stroke={successColor} strokeWidth="2" style={{ flexShrink: 0, marginTop: 1 }}>
                                <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                              </svg>
                              <div>
                                <div style={{ fontSize: 14, fontWeight: 600, color: successColor }}>Quote request submitted! ✓</div>
                                <div style={{ fontSize: 12, color: successColor, marginTop: 2 }}>
                                  This test quote was sent to your store with a 🧪 TEST badge.
                                  {previewQuoteId && (
                                    <div style={{ marginTop: 4 }}>
                                      <a href={`/app/quote/${previewQuoteId}`} target="_blank" rel="noopener noreferrer" style={{ color: successColor, textDecoration: "underline", fontWeight: 600 }}>View Quote →</a>
                                    </div>
                                  )}
                                </div>
                              </div>
                              <button onClick={() => setPreviewSubmitted(false)} style={{ marginLeft: "auto", background: "none", border: "none", cursor: "pointer", color: successColor, padding: 0, fontSize: 18, lineHeight: 1 }}>×</button>
                            </div>
                          )}

                          {contactElements.length > 0 && (
                            <div style={{ marginBottom: 20 }}>
                              <div style={{ fontSize: 14, fontWeight: 600, color: "#1a1a18", marginBottom: 14, paddingBottom: 10, borderBottom: "1px solid #e3e3e3" }}>Contact</div>
                              {(() => {
                                const rows = [];
                                const els = contactElements;
                                for (let i = 0; i < els.length; i++) {
                                  const el = els[i];
                                  const next = els[i + 1];
                                  const isNamePair = (el.label === "First name" || el.label === "Last name") && next && (next.label === "First name" || next.label === "Last name");
                                  if (isNamePair) {
                                    rows.push(
                                      <div key={el.id} style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 14 }}>
                                        {[el, next].map((f) => (
                                          <div key={f.id}>
                                            {previewMode
                                              ? renderInteractiveFieldPreview(f, false)
                                              : <>
                                                <div style={{ fontSize: 13, fontWeight: 400, color: "#6d7175", marginBottom: 6 }}>{f.label}{f.required && <span style={{ color: errorColor }}> *</span>}</div>
                                                <div style={{ height: 44, border: "1px solid #c9cccf", borderRadius: 4, background: "#fff", padding: "0 12px", display: "flex", alignItems: "center" }}>
                                                  <span style={{ fontSize: 14, color: "#c4c4c4" }}>{f.placeholder}</span>
                                                </div>
                                              </>
                                            }
                                          </div>
                                        ))}
                                      </div>
                                    );
                                    i++;
                                  } else {
                                    rows.push(previewMode ? renderInteractiveFieldPreview(el, false) : renderVisualFieldPreview(el, false));
                                  }
                                }
                                return rows;
                              })()}
                            </div>
                          )}
                          {shippingElements.length > 0 && (
                            <div style={{ marginBottom: 20 }}>
                              <div style={{ fontSize: 14, fontWeight: 600, color: "#1a1a18", marginBottom: 14, paddingBottom: 10, borderBottom: "1px solid #e3e3e3" }}>Shipping address</div>
                              {shippingElements.map((el) => previewMode ? renderInteractiveFieldPreview(el, false) : renderVisualFieldPreview(el, false))}
                            </div>
                          )}
                          {extraInfoElements.length > 0 && (
                            <div style={{ marginBottom: 20 }}>
                              <div style={{ fontSize: 14, fontWeight: 600, color: "#1a1a18", marginBottom: 14, paddingBottom: 10, borderBottom: "1px solid #e3e3e3" }}>Additional information</div>
                              {extraInfoElements.map((el) => previewMode ? renderInteractiveFieldPreview(el, false) : renderVisualFieldPreview(el, false))}
                            </div>
                          )}
                          <button
                            onClick={previewMode ? handlePreviewSubmit : undefined}
                            disabled={previewSending}
                            style={{ width: "100%", height: 46, background: formBtnColorHsb, color: formBtnTextColorHsb, fontSize: formBtnFontSize, border: "none", borderRadius: formBtnBorderRadius, cursor: previewMode && !previewSending ? "pointer" : "default", fontWeight: 600, fontFamily: "inherit", opacity: previewMode && !previewSending ? 1 : 0.6, transition: "opacity 0.15s" }}
                          >
                            {submitButtonLabel || "Request a Quote"}
                          </button>
                          {previewMode && Object.keys(previewErrors).length > 0 && (
                            <div style={{ marginTop: 10, fontSize: 12, color: errorColor, textAlign: "center" }}>
                              Please fill in all required fields above.
                            </div>
                          )}
                        </div>
                      </div>
                    </Modal.Section>
                  </Modal>
                </div>
              </div>
            )}

          </BlockStack>
        </div>
      </Box>
    </Page>
  );
}

export const headers = (headersArgs) => boundary.headers(headersArgs);
export function ErrorBoundary() { return boundary.error(useRouteError()); }

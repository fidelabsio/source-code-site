export { action } from "../domain/webhooks/customersRedact.server";

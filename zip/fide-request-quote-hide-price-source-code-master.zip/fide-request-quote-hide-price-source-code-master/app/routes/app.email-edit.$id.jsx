import { useRouteError } from "react-router";
import { useEmailTemplateEditor } from "../hooks/email/useEmailTemplateEditor";
import {
  Card,
  Text,
  BlockStack,
  InlineStack,
  TextField,
  RadioButton,
  Divider,
  Box,
  Banner,
  Button,
} from "@shopify/polaris";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { TemplateEditorShell } from "../components/template-editor/TemplateEditorShell";
import { TemplateVariablesCard } from "../components/template-editor/TemplateVariablesCard";

export { loader, action } from "../domain/email/emailTemplateEditor.server";

// Mirrors the real send structure in emailTemplates.server.js's emailShell()/
// renderCustomTemplate() as closely as a mockup can: colored header (this
// templateType's actual send-time color, not a placeholder), the real logo
// if one is configured, a white body with the real CTA color, and the real
// footer copy — so nothing here shows a color or element the actual email
// won't have.
/* eslint-disable react/prop-types -- presentational preview, not worth a PropTypes dependency (covers the labels object's nested field accesses below too) */
function EmailPreview({ subject, heading, content, action, headerColor, ctaColor, logoUrl, signature, labels }) {
  return (
    <div style={{ fontFamily: "sans-serif" }}>
      <div style={{ border: "1px solid #e1e3e5", borderRadius: 8, padding: "14px 16px", marginBottom: 12, background: "#fff" }}>
        <Text variant="bodyMd" as="p">
          <span style={{ fontWeight: 600 }}>{labels.subjectLabel} </span>
          {subject || <span style={{ color: "#8c9196" }}>{labels.noSubjectFallback}</span>}
        </Text>
      </div>
      <div style={{ border: "1px solid #e1e3e5", borderRadius: 8, background: "#fff", overflow: "hidden" }}>
        <div style={{ background: headerColor, padding: "24px 32px" }}>
          {logoUrl && <img src={logoUrl} alt="" style={{ display: "block", maxHeight: 28, margin: "0 0 12px" }} />}
          <h2 style={{ fontSize: 20, fontWeight: 600, margin: 0, color: "#fff" }}>
            {heading || <span style={{ color: "rgba(255,255,255,0.7)" }}>{labels.headingFallback}</span>}
          </h2>
        </div>
        <div style={{ padding: "32px 40px 24px" }}>
          <p style={{ fontSize: 14, color: "#444", lineHeight: 1.6, margin: "0 0 24px" }}>
            {content || <span style={{ color: "#c9cccf" }}>{labels.contentFallback}</span>}
          </p>
          {action && (
            <div style={{ marginBottom: 8 }}>
              <span style={{ display: "inline-block", background: ctaColor, color: "#fff", padding: "10px 24px", borderRadius: 6, fontSize: 14, fontWeight: 600 }}>
                {action}
              </span>
            </div>
          )}
        </div>
        <div style={{ borderTop: "1px solid #e1e3e5", padding: "16px 40px", textAlign: "center" }}>
          <p style={{ fontSize: 12, color: "#aaa", margin: signature ? "0 0 4px" : 0, lineHeight: 1.6 }}>
            {labels.footerTemplate}
          </p>
          {signature && (
            <p style={{ fontSize: 12, color: "#aaa", margin: 0, lineHeight: 1.6 }}>{signature}</p>
          )}
        </div>
      </div>
    </div>
  );
}
/* eslint-enable react/prop-types */

export default function EmailEditPage() {
  const {
    config, isMobile, navigate, headerColor, ctaColor, logoUrl, signature, labels,
    status, setStatus,
    subject, setSubject,
    heading, setHeading,
    content, setContent,
    action, setAction,
    redirectUrl, setRedirectUrl,
    testToEmail, setTestToEmail,
    isSaving, saved_ok, isTesting, isValidTestEmail,
    handleSave, handleTest, handleDiscard,
  } = useEmailTemplateEditor();

  const p = labels.editorPage;

  return (
    <TemplateEditorShell
      title={config.title}
      subtitle={config.description}
      onBack={() => navigate("/app/settings?tab=email")}
      saveBarId="email-save-bar"
      isSaving={isSaving}
      onSave={handleSave}
      onDiscard={handleDiscard}
      isMobile={isMobile}
      previewStickyTop={20}
      successBanner={
        saved_ok && (
          <Box paddingBlockEnd="400">
            <Banner tone="success">{p.savedBanner}</Banner>
          </Box>
        )
      }
      leftPanel={
        <>
          <Card>
            <BlockStack gap="500">

              <BlockStack gap="200">
                <Text variant="headingSm" as="h3" fontWeight="semibold">{p.statusHeading}</Text>
                <RadioButton label={p.enabledLabel} checked={status === "enabled"} id="status-enabled" name="emailStatus" onChange={() => setStatus("enabled")} />
                <RadioButton label={p.disabledLabel} checked={status === "disabled"} id="status-disabled" name="emailStatus" onChange={() => setStatus("disabled")} />
              </BlockStack>

              <Divider />

              <TextField label={p.subjectLabel} value={subject} onChange={setSubject} autoComplete="off" />

              <Divider />

              <BlockStack gap="300">
                <Text variant="headingSm" as="h3" fontWeight="semibold">{p.contentHeading}</Text>
                <TextField label={p.headingLabel} value={heading} onChange={setHeading} autoComplete="off" />
                <TextField label={p.contentLabel} value={content} onChange={setContent} multiline={4} autoComplete="off" />
                <TextField label={p.actionLabel} value={action} onChange={setAction} autoComplete="off" />
                <TextField
                  label={p.redirectUrlLabel}
                  value={redirectUrl}
                  onChange={setRedirectUrl}
                  placeholder={p.redirectUrlPlaceholder}
                  autoComplete="off"
                  helpText={p.redirectUrlHelpText}
                />
              </BlockStack>

              <Divider />

              <BlockStack gap="200">
                <Text variant="headingSm" as="h3" fontWeight="semibold">{p.sendTestHeading}</Text>
                <InlineStack gap="200" blockAlign="end" wrap={false}>
                  <div style={{ flex: 1 }}>
                    <TextField
                      label="Recipient"
                      labelHidden
                      value={testToEmail}
                      onChange={setTestToEmail}
                      type="email"
                      placeholder={p.recipientPlaceholder}
                      autoComplete="email"
                    />
                  </div>
                  <Button
                    onClick={handleTest}
                    loading={isTesting}
                    disabled={!isValidTestEmail}
                  >
                    {p.sendTestButton}
                  </Button>
                </InlineStack>
                <Text variant="bodySm" as="p" tone="subdued">
                  {p.sendTestHelpText}
                </Text>
              </BlockStack>

            </BlockStack>
          </Card>

          <TemplateVariablesCard variables={config.variables} />
        </>
      }
      preview={
        <Card>
          <BlockStack gap="400">
            <Text variant="headingSm" as="h3" fontWeight="semibold">{p.previewHeading}</Text>
            <EmailPreview subject={subject} heading={heading} content={content} action={action} headerColor={headerColor} ctaColor={ctaColor} logoUrl={logoUrl} signature={signature} labels={p.preview} />
          </BlockStack>
        </Card>
      }
    />
  );
}

export function ErrorBoundary() { return boundary.error(useRouteError()); }
export const headers = (headersArgs) => boundary.headers(headersArgs);

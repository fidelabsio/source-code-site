export { authCallbackLoader as loader, authHeaders as headers } from "../domain/auth/auth.server";

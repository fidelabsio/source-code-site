export { loader, action } from "../domain/upload/upload.server";

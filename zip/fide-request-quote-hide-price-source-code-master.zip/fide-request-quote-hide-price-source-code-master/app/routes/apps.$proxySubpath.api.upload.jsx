/**
 * App Proxy alias route — /apps/{subpath}/api/upload
 *
 * See ./apps.$proxySubpath.api.quote.jsx for why this alias exists (and why
 * `$proxySubpath` is a wildcard rather than a hardcoded segment): under
 * `shopify app dev` the un-stripped proxy path reaches the app and would 404
 * without it. Delegates to the real handler in ../domain/upload/upload.server.js.
 */
export { loader, action } from "../domain/upload/upload.server";

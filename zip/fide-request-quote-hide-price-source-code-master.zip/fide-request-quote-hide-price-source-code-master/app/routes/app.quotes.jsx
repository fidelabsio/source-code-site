import { useRouteError } from "react-router";
import {
  useQuotesList, formatDate, initials, getPageItems, avatarColor,
} from "../hooks/quotes/useQuotesList";
import {
  Page,
  Text,
  BlockStack,
  Badge,
  TextField,
  Icon,
  Modal,
  DescriptionList,
  Popover,
  ActionList,
  Button,
  Tooltip,
  EmptyState,
} from "@shopify/polaris";
import {
  SearchIcon,
  FilterIcon,
  SortIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
  EditIcon,
  OrderDraftFilledIcon,
  PrintIcon,
  DuplicateIcon,
  DeleteIcon,
  ExportIcon,
  PlusIcon,
} from "@shopify/polaris-icons";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { formatQuoteNumber } from "../domain/quotes/quoteNumber";
import { ColorCard } from "../components/common/ColorCard";

export { loader, action } from "../domain/quotes/quotesList.server";

// ─── Component ────────────────────────────────────────────────────────────────

export default function QuotesDashboard() {
  const {
    quotes, tabCounts, page, pageSize, totalCount, totalPages,
    activeTab, activeSearch, isFetchingPage, isMobile, navigate,
    fetcher, isBusy,
    searchQuery, onSearchChange, searchOpen, setSearchOpen,
    sortPopover, setSortPopover, sortOptions, sortLabel,
    selectedQuote, setSelectedQuote, parsedCartItems, fmtPrice,
    selectedIds, isAllSelected, isIndeterminate, toggleOne, toggleAll,
    bulkDeleteModal, setBulkDeleteModal,
    deleteModal, setDeleteModal,
    convertModal, setConvertModal,
    handleTabChange, goToPage, handleRowClick,
    handleConvertToDraft, handleConvertConfirm,
    handlePrintPDF, handleDuplicate,
    handleDeleteClick, handleDeleteConfirm,
    handleExportCSV,
    primaryColor, successColor, warningColor, cardBackgroundColor,
    labels, tabs, getStatusBadge,
  } = useQuotesList();

  const t = labels.quoteDetailModal;

  const quoteDetails = selectedQuote ? [
    { term: t.termProduct,   description: selectedQuote.productTitle },
    { term: t.termCustomer,  description: selectedQuote.customerName },
    { term: t.termEmail,     description: <a href={`mailto:${selectedQuote.customerEmail}`}>{selectedQuote.customerEmail}</a> },
    selectedQuote.customerPhone && { term: t.termPhone,   description: selectedQuote.customerPhone },
    selectedQuote.companyName   && { term: t.termCompany, description: selectedQuote.companyName   },
    selectedQuote.quantity      && { term: t.termQty,     description: selectedQuote.quantity       },
    // Show customer's offered price (submitted from quote cart page)
    selectedQuote.quotedPrice != null && {
      term: t.termOfferedPrice,
      description: (
        <span style={{ fontWeight: 600, color: successColor }}>
          {fmtPrice(selectedQuote.quotedPrice, selectedQuote.quotedCurrency)}
        </span>
      ),
    },
    // If multiple cart items — show per-item breakdown with individual offer prices
    parsedCartItems && parsedCartItems.length > 1 && {
      term: t.termItems,
      description: (
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {parsedCartItems.map((item, idx) => (
            <div key={idx} style={{ fontSize: 13, padding: "6px 8px", background: "#f9f9f7", borderRadius: 4, border: "1px solid #e3e3db" }}>
              <div style={{ fontWeight: 600 }}>{item.productTitle}{item.variantTitle ? ` — ${item.variantTitle}` : ""}</div>
              <div style={{ color: "#6d7175", marginTop: 2, display: "flex", gap: 12, flexWrap: "wrap" }}>
                {item.quantity && <span>{t.itemQtyPrefix} {item.quantity}</span>}
                {item.price && <span>{t.itemPricePrefix} {fmtPrice(item.price, selectedQuote.quotedCurrency)}</span>}
                {item.offerPrice != null && (
                  <span style={{ fontWeight: 600, color: successColor }}>
                    {t.itemOfferedPrefix} {fmtPrice(item.offerPrice, selectedQuote.quotedCurrency)}
                  </span>
                )}
                {item.sku && <span>{t.itemSkuPrefix} {item.sku}</span>}
                {item.vendor && <span>{t.itemVendorPrefix} {item.vendor}</span>}
                {item.note && <span style={{ fontStyle: "italic" }}>{t.itemNotePrefix} {item.note}</span>}
              </div>
            </div>
          ))}
        </div>
      ),
    },
    selectedQuote.message && { term: t.termMessage, description: selectedQuote.message },
    { term: t.termStatus,   description: (() => { const b = getStatusBadge(selectedQuote); return <Badge tone={b.tone}>{b.label}</Badge>; })() },
    { term: t.termSubmitted, description: new Date(selectedQuote.createdAt).toLocaleString() },
    selectedQuote.merchantReply && { term: t.termPreviousReply, description: selectedQuote.merchantReply },
  ].filter(Boolean) : [];

  return (
    <Page
      title={labels.pageTitle}
      primaryAction={{
        content: labels.createQuoteAction,
        icon: PlusIcon,
        onAction: () => navigate("/app/quote/new"),
      }}
      secondaryActions={[
        {
          content: labels.exportCsvAction,
          icon: ExportIcon,
          onAction: handleExportCSV,
        },
      ]}
    >
      <ColorCard background={cardBackgroundColor}>

        {/* ── Tab bar + controls ──
            Desktop: tabs scroll on the left, controls pinned on the right.
            Mobile: stack the controls on their own full-width row below the
            tabs — otherwise the narrow row hides the last tab behind them. */}
        <div style={{ display: "flex", flexDirection: isMobile ? "column" : "row", alignItems: "stretch", borderBottom: "1px solid #e3e3db" }}>
          {/* Tabs scroll independently — controls stay pinned */}
          <div style={{ display: "flex", alignItems: "center", flex: 1, minWidth: 0, overflowX: "auto" }}>
            {tabs.map((tab) => {
              const active = activeTab === tab.key;
              const count  = tabCounts[tab.key];
              return (
                <button
                  key={tab.key}
                  onClick={() => handleTabChange(tab.key)}
                  style={{
                    display: "flex", alignItems: "center", gap: 6,
                    padding: isMobile ? "10px 12px" : "13px 16px",
                    background: "none", border: "none", cursor: "pointer",
                    borderBottom: active ? `2px solid ${primaryColor}` : "2px solid transparent",
                    fontWeight: active ? 600 : 400,
                    fontSize: isMobile ? 13 : 14,
                    color: active ? primaryColor : "#6b6b6b",
                    whiteSpace: "nowrap",
                    transition: "color 0.15s",
                  }}
                >
                  {tab.label}
                  {(count > 0 || active) && (
                    <span style={{
                      background: active ? primaryColor : "#e3e3db",
                      color: active ? "#fff" : "#555",
                      borderRadius: 10, fontSize: 11, fontWeight: 600,
                      padding: "1px 6px", lineHeight: "16px",
                    }}>
                      {count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Right controls — pinned on desktop; own full-width row on mobile */}
          <div style={{
            display: "flex", alignItems: "center", gap: 4,
            padding: isMobile ? "8px 12px" : undefined,
            paddingInline: isMobile ? undefined : "8px 12px",
            flexShrink: 0,
            justifyContent: isMobile ? "flex-end" : undefined,
            borderLeft: isMobile ? "none" : "1px solid #e3e3db",
            borderTop:  isMobile ? "1px solid #e3e3db" : "none",
            background: "#fff",
          }}>
            {/* Desktop inline search */}
            {!isMobile && searchOpen && (
              <div style={{ width: 200 }}>
                <TextField
                  value={searchQuery}
                  onChange={onSearchChange}
                  placeholder={labels.searchPlaceholder}
                  autoComplete="off"
                  autoFocus
                  onBlur={() => { if (!searchQuery) setSearchOpen(false); }}
                  prefix={<Icon source={SearchIcon} />}
                  clearButton
                  onClearButtonClick={() => { onSearchChange(""); setSearchOpen(false); }}
                />
              </div>
            )}
            <button
              onClick={() => setSearchOpen((o) => !o)}
              style={{ background: searchOpen ? "#f0f0eb" : "none", border: "1px solid #e3e3db", borderRadius: 6, padding: "6px 8px", cursor: "pointer", display: "flex", alignItems: "center", gap: 4 }}
              title={labels.searchFilterTitle}
            >
              <Icon source={SearchIcon} tone={searchOpen ? "emphasis" : "base"} />
              {!isMobile && <Icon source={FilterIcon} tone="base" />}
            </button>
            <Popover
              active={sortPopover}
              activator={
                <button
                  onClick={() => setSortPopover((o) => !o)}
                  style={{ background: sortPopover ? "#f0f0eb" : "none", border: "1px solid #e3e3db", borderRadius: 6, padding: "6px 8px", cursor: "pointer", display: "flex", alignItems: "center" }}
                  title={`${labels.sortTitlePrefix} ${sortLabel}`}
                >
                  <Icon source={SortIcon} tone="base" />
                </button>
              }
              onClose={() => setSortPopover(false)}
            >
              <ActionList items={sortOptions} />
            </Popover>
          </div>
        </div>

        {/* ── Mobile search bar — attached directly below the controls row it
              belongs to, so it reads as part of the table controls */}
        {isMobile && searchOpen && (
          <div style={{ padding: "8px 12px", borderBottom: "1px solid #e3e3db", background: "#fbfbfa" }}>
            <TextField
              value={searchQuery}
              onChange={onSearchChange}
              placeholder={labels.searchPlaceholder}
              autoComplete="off"
              autoFocus
              prefix={<Icon source={SearchIcon} />}
              clearButton
              onClearButtonClick={() => { onSearchChange(""); setSearchOpen(false); }}
            />
          </div>
        )}

        {/* ── Empty state ── */}
        {quotes.length === 0 ? (
          activeSearch || activeTab !== "all" ? (
            <EmptyState
              heading={labels.emptyFilteredHeading}
              image="https://cdn.shopify.com/s/files/1/0262/4071/2726/files/emptystate-files.png"
            >
              <Text variant="bodyMd" tone="subdued" as="p">
                {labels.emptyFilteredBody}
              </Text>
            </EmptyState>
          ) : (
            <EmptyState
              heading={labels.emptyHeading}
              action={{ content: labels.emptyViewSetupGuideAction, url: "/app" }}
              secondaryAction={{ content: labels.emptyGoToSettingsAction, url: "/app/quote-settings" }}
              image="https://cdn.shopify.com/s/files/1/0262/4071/2726/files/emptystate-files.png"
            >
              <Text variant="bodyMd" tone="subdued" as="p">
                {labels.emptyBody}
              </Text>
            </EmptyState>
          )
        ) : (
          <>
            {/* Table header — same grid as rows so columns align exactly */}
            <div style={{ display: "grid", gridTemplateColumns: isMobile ? "32px 1fr 90px 40px" : "44px 130px 100px 2fr 1fr 1.4fr", alignItems: "center", padding: "10px 20px", background: selectedIds.length > 0 ? "#f0f0eb" : "#f9f9f6", borderBottom: "1px solid #e3e3db", gap: isMobile ? 8 : 12 }}>
              <input
                type="checkbox"
                checked={isAllSelected}
                ref={(el) => { if (el) el.indeterminate = isIndeterminate; }}
                onChange={toggleAll}
                style={{ width: 16, height: 16, cursor: "pointer", accentColor: primaryColor }}
              />
              {selectedIds.length > 0 ? (
                <>
                  <span style={{ gridColumn: isMobile ? "2 / 4" : "2 / 6" }}>
                    <Text variant="bodySm" fontWeight="semibold" as="span">
                      {selectedIds.length} {labels.selectedCountSuffix}
                    </Text>
                  </span>
                  <div>
                    <Button
                      tone="critical"
                      size="slim"
                      icon={DeleteIcon}
                      onClick={() => setBulkDeleteModal(true)}
                    >
                      {isMobile ? null : labels.deleteButtonLabel}
                    </Button>
                  </div>
                </>
              ) : (
                <>
                  {/* Header labels fill the columns AFTER the always-present
                      checkbox (col 1). Mobile previously included a stray empty
                      label for the checkbox slot, shifting every label one
                      column right of its data. */}
                  {(isMobile
                    ? [labels.columnCustomer, labels.columnStatus, ""]
                    : [labels.columnQuoteId, labels.columnStatus, labels.columnCustomer, labels.columnDate, labels.columnActions]
                  ).map((h, i) => (
                    <Text key={h || `h-${i}`} variant="bodySm" fontWeight="semibold" tone="subdued" as="span">{h}</Text>
                  ))}
                </>
              )}
            </div>

            {/* Rows */}
            {quotes.map((q) => {
              const sb = getStatusBadge(q);
              const bg = avatarColor(q.customerName);
              const isChecked = selectedIds.includes(q.id);
              return (
                <div
                  key={q.id}
                  onClick={isMobile ? () => handleRowClick(q) : undefined}
                  style={{ display: "grid", gridTemplateColumns: isMobile ? "32px 1fr 90px 40px" : "44px 130px 100px 2fr 1fr 1.4fr", padding: isMobile ? "12px 16px" : "14px 20px", borderBottom: "1px solid #f0f0eb", alignItems: "center", gap: isMobile ? 8 : 12, background: isChecked ? "#f5f5ff" : "", cursor: isMobile ? "pointer" : "default" }}
                  onMouseEnter={(e) => { if (!isChecked) e.currentTarget.style.background = "#fafaf8"; }}
                  onMouseLeave={(e) => { if (!isChecked) e.currentTarget.style.background = ""; }}
                >
                  {/* Checkbox */}
                  <input
                    type="checkbox"
                    checked={isChecked}
                    onChange={() => toggleOne(q.id)}
                    onClick={(e) => e.stopPropagation()}
                    style={{ width: 16, height: 16, cursor: "pointer", accentColor: primaryColor }}
                  />

                  {/* Quote ID — desktop only */}
                  {!isMobile && (
                    <div style={{ minWidth: 0, cursor: "pointer" }} onClick={() => handleRowClick(q)}>
                      <Text variant="bodyMd" fontWeight="semibold" as="p">{formatQuoteNumber(q)}</Text>
                    </div>
                  )}

                  {/* Status — desktop only */}
                  {!isMobile && (
                    <div onClick={() => handleRowClick(q)} style={{ cursor: "pointer" }}>
                      <Badge tone={sb.tone}>{sb.label}</Badge>
                    </div>
                  )}

                  {/* Customer */}
                  <div
                    onClick={isMobile ? undefined : () => handleRowClick(q)}
                    style={{ display: "flex", alignItems: "center", gap: 10, minWidth: 0, cursor: "pointer" }}
                  >
                    <div style={{ position: "relative", flexShrink: 0 }}>
                      <div style={{ width: 34, height: 34, borderRadius: "50%", background: bg, display: "flex", alignItems: "center", justifyContent: "center" }}>
                        <span style={{ color: "#fff", fontSize: 12, fontWeight: 700 }}>{initials(q.customerName)}</span>
                      </div>
                    </div>
                    <div style={{ minWidth: 0 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap" }}>
                        <Text variant="bodyMd" fontWeight="semibold" as="p" truncate>{q.customerName}</Text>
                        {q.tags && q.tags.toLowerCase().includes("test-case") && (
                          <span style={{
                            fontSize: 10, fontWeight: 700, padding: "1px 6px",
                            borderRadius: 10, background: "#fff3cd", color: warningColor,
                            border: `1px solid ${warningColor}`, letterSpacing: "0.3px",
                            lineHeight: "16px", whiteSpace: "nowrap",
                          }}>{labels.testBadgeText}</span>
                        )}
                      </div>
                      {isMobile ? (
                        <Text variant="bodyXs" tone="subdued" as="p">{formatQuoteNumber(q)} · {formatDate(q.createdAt)}</Text>
                      ) : (
                        <Text variant="bodySm" tone="subdued" as="p" truncate>{q.customerEmail}</Text>
                      )}
                    </div>
                  </div>

                  {/* Status — mobile only (no onClick — outer row handles tap) */}
                  {isMobile && (
                    <div style={{ pointerEvents: "none" }}>
                      <Badge tone={sb.tone}>{sb.label}</Badge>
                    </div>
                  )}

                  {/* Date — desktop only */}
                  {!isMobile && (
                    <div onClick={() => handleRowClick(q)} style={{ cursor: "pointer" }}>
                      <Text variant="bodySm" tone="subdued" as="span">{formatDate(q.createdAt)}</Text>
                    </div>
                  )}

                  {/* Actions */}
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "flex-end", gap: 4 }}>
                    {isMobile ? (
                      /* Mobile: chevron is decorative — outer row div handles tap */
                      <div style={{ display: "flex", alignItems: "center", justifyContent: "flex-end", pointerEvents: "none" }}>
                        <Icon source={ChevronRightIcon} tone="subdued" />
                      </div>
                    ) : (
                      /* Desktop: full icon set */
                      <>
                        <Tooltip content={labels.tooltipViewEdit}>
                          <Button variant="plain" size="slim" icon={EditIcon} accessibilityLabel={labels.tooltipViewEdit} onClick={() => handleRowClick(q)} />
                        </Tooltip>
                        <Tooltip content={labels.tooltipConvertToDraft}>
                          <Button variant="plain" size="slim" icon={OrderDraftFilledIcon} accessibilityLabel={labels.tooltipConvertToDraft} onClick={() => handleConvertToDraft(q)} />
                        </Tooltip>
                        <Tooltip content={labels.tooltipPrintPdf}>
                          <Button variant="plain" size="slim" icon={PrintIcon} accessibilityLabel={labels.tooltipPrintPdf} onClick={(e) => { e.stopPropagation(); handlePrintPDF(q); }} />
                        </Tooltip>
                        <Tooltip content={labels.tooltipDuplicate}>
                          <Button variant="plain" size="slim" icon={DuplicateIcon} accessibilityLabel={labels.tooltipDuplicate} onClick={(e) => { e.stopPropagation(); handleDuplicate(q); }} />
                        </Tooltip>
                        <Tooltip content={labels.tooltipDelete}>
                          <Button variant="plain" size="slim" tone="critical" icon={DeleteIcon} accessibilityLabel={labels.tooltipDelete} onClick={(e) => { e.stopPropagation(); handleDeleteClick(q); }} />
                        </Tooltip>
                      </>
                    )}
                  </div>
                </div>
              );
            })}

            {/* Pagination — numbered page buttons, each fetched fresh from the backend */}
            <div style={{ display: "flex", justifyContent: "flex-end", alignItems: "center", flexWrap: "wrap", padding: "10px 16px", gap: 6, borderTop: "1px solid #f0f0eb" }}>
              {totalCount > 0 && (
                <Text variant="bodySm" tone="subdued" as="span" style={{ marginRight: 8 }}>
                  {labels.paginationSummaryTemplate
                    .replace("{from}", (page - 1) * pageSize + 1)
                    .replace("{to}", Math.min(page * pageSize, totalCount))
                    .replace("{total}", totalCount)}
                </Text>
              )}
              <button
                onClick={() => goToPage(page - 1)}
                disabled={page <= 1 || isFetchingPage}
                style={{ background: "none", border: "1px solid #e3e3db", borderRadius: 6, padding: "5px 8px", cursor: page <= 1 ? "default" : "pointer", opacity: page <= 1 ? 0.4 : 1, display: "flex", alignItems: "center" }}
              >
                <Icon source={ChevronLeftIcon} tone="base" />
              </button>
              {getPageItems(page, totalPages).map((item, i) =>
                item === "…" ? (
                  <span key={`gap-${i}`} style={{ padding: "0 4px", color: "#9b9b94", fontSize: 13, userSelect: "none" }}>…</span>
                ) : (
                  <button
                    key={item}
                    onClick={() => goToPage(item)}
                    disabled={isFetchingPage}
                    aria-current={item === page ? "page" : undefined}
                    style={{
                      minWidth: 32, height: 32, padding: "0 8px", borderRadius: 6,
                      border: item === page ? `1px solid ${primaryColor}` : "1px solid #e3e3db",
                      background: item === page ? primaryColor : "#fff",
                      color: item === page ? "#fff" : primaryColor,
                      fontSize: 13, fontWeight: item === page ? 600 : 400,
                      cursor: item === page ? "default" : "pointer",
                      display: "flex", alignItems: "center", justifyContent: "center",
                    }}
                  >
                    {item}
                  </button>
                ),
              )}
              <button
                onClick={() => goToPage(page + 1)}
                disabled={page >= totalPages || isFetchingPage}
                style={{ background: "none", border: "1px solid #e3e3db", borderRadius: 6, padding: "5px 8px", cursor: page >= totalPages ? "default" : "pointer", opacity: page >= totalPages ? 0.4 : 1, display: "flex", alignItems: "center" }}
              >
                <Icon source={ChevronRightIcon} tone="base" />
              </button>
            </div>
          </>
        )}

        {/* Empty state pagination */}
        {quotes.length === 0 && (
          <div style={{ display: "flex", justifyContent: "flex-end", padding: "10px 16px", gap: 6, borderTop: "1px solid #f0f0eb" }}>
            <button disabled style={{ background: "none", border: "1px solid #e3e3db", borderRadius: 6, padding: "5px 8px", opacity: 0.35, display: "flex", alignItems: "center", cursor: "default" }}>
              <Icon source={ChevronLeftIcon} tone="subdued" />
            </button>
            <button disabled style={{ background: "none", border: "1px solid #e3e3db", borderRadius: 6, padding: "5px 8px", opacity: 0.35, display: "flex", alignItems: "center", cursor: "default" }}>
              <Icon source={ChevronRightIcon} tone="subdued" />
            </button>
          </div>
        )}
      </ColorCard>

      {/* ── Quote Detail Modal ── */}
      <Modal
        open={selectedQuote !== null}
        onClose={() => setSelectedQuote(null)}
        title={selectedQuote ? t.titleTemplate.replace("{name}", selectedQuote.customerName) : t.titleFallback}
        primaryAction={{ content: t.closeAction, onAction: () => setSelectedQuote(null) }}
        secondaryActions={[
          selectedQuote?.status === "new"
            ? { content: t.markAsReadAction, onAction: () => fetcher.submit({ intent: "markAsRead", quoteId: selectedQuote.id }, { method: "post" }), loading: isBusy && fetcher.formData?.get("intent") === "markAsRead" }
            : null,
          selectedQuote?.quoteStatus !== "accepted" && selectedQuote?.quoteStatus !== "rejected"
            ? { content: t.acceptQuoteAction, tone: "success", onAction: () => { fetcher.submit({ intent: "acceptQuote", quoteId: selectedQuote.id }, { method: "post" }); setSelectedQuote((q) => ({ ...q, quoteStatus: "accepted" })); }, loading: isBusy && fetcher.formData?.get("intent") === "acceptQuote" }
            : null,
          selectedQuote?.quoteStatus !== "rejected" && selectedQuote?.quoteStatus !== "accepted"
            ? { content: t.rejectQuoteAction, destructive: true, onAction: () => { fetcher.submit({ intent: "rejectQuote", quoteId: selectedQuote.id }, { method: "post" }); setSelectedQuote((q) => ({ ...q, quoteStatus: "rejected" })); }, loading: isBusy && fetcher.formData?.get("intent") === "rejectQuote" }
            : null,
          { content: t.printPdfAction, onAction: () => selectedQuote && handlePrintPDF(selectedQuote) },
        ].filter(Boolean)}
      >
        <Modal.Section>
          <DescriptionList items={quoteDetails} />
        </Modal.Section>
      </Modal>

      {/* ── Delete Confirmation Modal ── */}
      <Modal
        open={deleteModal.open}
        onClose={() => setDeleteModal({ open: false, quote: null })}
        title={labels.deleteModal.title}
        primaryAction={{
          content: labels.deleteModal.confirmAction,
          destructive: true,
          loading: isBusy && fetcher.formData?.get("intent") === "delete",
          onAction: handleDeleteConfirm,
        }}
        secondaryActions={[{
          content: labels.deleteModal.cancelAction,
          onAction: () => setDeleteModal({ open: false, quote: null }),
        }]}
      >
        <Modal.Section>
          <Text variant="bodyMd">
            {(() => {
              const [before, after] = labels.deleteModal.bodyTemplate.split("{name}");
              return <>{before}<strong>{deleteModal.quote?.customerName}</strong>{after}</>;
            })()}
          </Text>
        </Modal.Section>
      </Modal>

      {/* ── Bulk Delete Confirmation Modal ── */}
      <Modal
        open={bulkDeleteModal}
        onClose={() => setBulkDeleteModal(false)}
        title={labels.bulkDeleteModal.titleTemplate.replace("{count}", selectedIds.length).replace("{plural}", selectedIds.length !== 1 ? "s" : "")}
        primaryAction={{
          content: labels.bulkDeleteModal.confirmActionTemplate.replace("{count}", selectedIds.length).replace("{plural}", selectedIds.length !== 1 ? "s" : ""),
          destructive: true,
          loading: isBusy && fetcher.formData?.get("intent") === "bulkDelete",
          onAction: () => fetcher.submit({ intent: "bulkDelete", ids: selectedIds.join(",") }, { method: "post" }),
        }}
        secondaryActions={[{ content: labels.bulkDeleteModal.cancelAction, onAction: () => setBulkDeleteModal(false) }]}
      >
        <Modal.Section>
          <Text variant="bodyMd">
            {(() => {
              const plural = selectedIds.length !== 1 ? "s" : "";
              const [before, after] = labels.bulkDeleteModal.bodyTemplate.replace("{plural}", plural).split("{count}");
              return <>{before}<strong>{selectedIds.length}</strong>{after}</>;
            })()}
          </Text>
        </Modal.Section>
      </Modal>

      {/* ── Convert to Draft Order Confirmation Modal ── */}
      <Modal
        open={convertModal.open}
        onClose={() => setConvertModal({ open: false, quote: null })}
        title={labels.convertModal.title}
        primaryAction={{
          content: labels.convertModal.confirmAction,
          loading: isBusy && fetcher.formData?.get("intent") === "convertToDraft",
          onAction: handleConvertConfirm,
        }}
        secondaryActions={[{
          content: labels.convertModal.cancelAction,
          onAction: () => setConvertModal({ open: false, quote: null }),
        }]}
      >
        <Modal.Section>
          <BlockStack gap="200">
            <Text variant="bodyMd">
              {(() => {
                const [before, mid, after] = labels.convertModal.bodyTemplate.split(/\{name\}|\{product\}/);
                return <>{before}<strong>{convertModal.quote?.customerName}</strong>{mid}<strong>{convertModal.quote?.productTitle}</strong>{after}</>;
              })()}
            </Text>
            <Text variant="bodySm" tone="subdued">
              {labels.convertModal.note}
            </Text>
          </BlockStack>
        </Modal.Section>
      </Modal>



    </Page>
  );
}

export function ErrorBoundary() { return boundary.error(useRouteError()); }
export const headers = (headersArgs) => boundary.headers(headersArgs);
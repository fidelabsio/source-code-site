export { action } from "../domain/webhooks/shopRedact.server";

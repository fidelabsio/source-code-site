import { AppProvider } from "@shopify/shopify-app-react-router/react";
import { useLoaderData } from "react-router";

export { loginLoader as loader, loginAction as action } from "../../domain/auth/auth.server";

export const meta = ({ data }) => [
  { title: `Install ${data?.appName ?? "Quote Request"}` },
];

export default function Auth() {
  const { appName } = useLoaderData();

  return (
    <AppProvider embedded={false}>
      <s-page>
        <s-section heading={`Install ${appName}`}>
          <s-text>
            To install {appName}, visit the{" "}
            <a
              href="https://apps.shopify.com"
              target="_blank"
              rel="noreferrer"
            >
              Shopify App Store
            </a>{" "}
            and install the app from there.
          </s-text>
        </s-section>
      </s-page>
    </AppProvider>
  );
}

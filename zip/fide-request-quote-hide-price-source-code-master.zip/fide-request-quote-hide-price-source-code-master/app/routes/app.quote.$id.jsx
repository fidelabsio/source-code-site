import { useQuoteDetail, fmtDate, fmtTimeOnly } from "../hooks/quotes/useQuoteDetail";
import { StickySaveBar } from "../components/template-editor/StickySaveBar";
import { EmailEditorModal } from "../components/quote-detail/EmailEditorModal";
import { useRouteError } from "react-router";
import {
  Page,
  Text,
  BlockStack,
  InlineStack,
  InlineGrid,
  TextField,
  Button,
  Badge,
  Divider,
  Box,
  Icon,
  Banner,
  Tooltip,
  Tag,
  Modal,
  Combobox,
  Listbox,
  AutoSelection,
} from "@shopify/polaris";
import {
  DeleteIcon,
  DuplicateIcon,
  NoteIcon,
  PersonIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
  ReceiptIcon,
  PrintIcon,
  SearchIcon,
  EditIcon,
} from "@shopify/polaris-icons";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { formatQuoteNumber } from "../domain/quotes/quoteNumber";
import { ColorCard } from "../components/common/ColorCard";

export { loader, action } from "../domain/quotes/quoteDetail.server";

// ─── Loader ───────────────────────────────────────────────────────────────────

// ── Client loader — always delegates to server for correct shop currency ────
export const clientLoader = async ({ serverLoader }) => {
  return serverLoader();
};
clientLoader.hydrate = true;

// ─── Component ────────────────────────────────────────────────────────────────

export default function QuoteDetailPage() {
  const {
    isNew, prevId, nextId, customerQuoteCount,
    secondaryColor, linkColor, cardBackgroundColor,
    labels,
    quote,
    lineItems, updateLineItem, removeLineItem, handlePickProduct,
    customerName, setCustomerName,
    customerEmail, setCustomerEmail,
    customerPhone, setCustomerPhone,
    message, setMessage,
    customerEditMode, setCustomerEditMode,
    lightbox, setLightbox,
    shippingAddr, setShippingAddr,
    discount, setDiscount,
    shipping, setShipping,
    tax, setTax,
    tags, tagOptions, tagInput, setTagInput, filteredTagOptions, handleTagSelect, removeTag,
    fieldErrors, clearError,
    noteText, setNoteText,
    acceptModal, setAcceptModal,
    rejectModal, setRejectModal,
    draftModal, setDraftModal, draftResult,
    acceptShowCta, setAcceptShowCta,
    rejectShowCta, setRejectShowCta,
    acceptEmailSubject, setAcceptEmailSubject,
    acceptEmailHeading, setAcceptEmailHeading,
    acceptEmailContent, setAcceptEmailContent,
    acceptEmailAction, setAcceptEmailAction,
    acceptEmailCheckoutUrl, setAcceptEmailCheckoutUrl,
    rejectEmailSubject, setRejectEmailSubject,
    rejectEmailHeading, setRejectEmailHeading,
    rejectEmailContent, setRejectEmailContent,
    rejectEmailAction, setRejectEmailAction,
    fmt, currSym, isMobile, isBusy,
    subtotal, total, sc,
    isAccepted, isRejected, isPaid, isClosed,
    hasUnsavedChanges,
    hasDraftOrder, activeDraftName, activeDraftUrl,
    otherFields, timelineGroups,
    downloadFile, downloadAll,
    submit, handleSave, handlePrintPDF,
    navigate, fetcher,
  } = useQuoteDetail();

  // Labelled read-only row used by the customer card's view mode
  const roRow = (label, value) => (
    <InlineStack gap="200" wrap={false} blockAlign="start">
      <div style={{ minWidth: 88, flexShrink: 0 }}>
        <Text variant="bodySm" tone="subdued" as="span">{label}</Text>
      </div>
      <Text variant="bodySm" as="span">{value && String(value).trim() ? value : "—"}</Text>
    </InlineStack>
  );

  function renderFieldValue(value) {
    const IMAGE_EXT = /\.(jpe?g|png|gif|webp|bmp|svg)(\?.*)?$/i;
    const arr = Array.isArray(value) ? value : [String(value || "—")];
    if (arr.length === 0) return <Text variant="bodySm" as="span">—</Text>;

    const imageUrls = arr.filter((v) => v && v !== "—" && IMAGE_EXT.test(v));
    const allUrls   = arr.filter((v) => v && v !== "—");

    return (
      <BlockStack gap="200">
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
          {arr.map((v, idx) => {
            if (!v || v === "—") return <Text key={idx} variant="bodySm" as="span">—</Text>;
            if (IMAGE_EXT.test(v)) {
              const filename = v.split("/").pop().split("?")[0] || "image";
              return (
                <div key={idx} style={{ position: "relative", display: "inline-block" }}>
                  <img
                    src={v}
                    alt={filename}
                    onClick={() => setLightbox({ open: true, images: imageUrls, index: imageUrls.indexOf(v) })}
                    style={{ width: 100, height: 100, objectFit: "cover", borderRadius: 6, border: "1px solid #e1e3e5", cursor: "zoom-in", display: "block" }}
                  />
                  <button
                    type="button"
                    title={labels.attachments.downloadTooltip}
                    onClick={() => downloadFile(v)}
                    style={{ position: "absolute", bottom: 4, right: 4, background: "rgba(0,0,0,0.55)", border: "none", borderRadius: 4, color: "#fff", fontSize: 12, cursor: "pointer", padding: "2px 5px", lineHeight: 1.4 }}
                  >
                    ↓
                  </button>
                </div>
              );
            }
            const filename = v.split("/").pop().split("?")[0] || "file";
            return (
              <div key={idx} style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <a href={v} target="_blank" rel="noreferrer" style={{ fontSize: 13 }}>📎 {filename}</a>
                <button type="button" title={labels.attachments.downloadTooltip} onClick={() => downloadFile(v)} style={{ background: "none", border: "1px solid #c9cccf", borderRadius: 4, fontSize: 11, cursor: "pointer", padding: "1px 6px", color: "#555" }}>↓</button>
              </div>
            );
          })}
        </div>
        {allUrls.length > 1 && (
          <div>
            <button
              type="button"
              onClick={() => downloadAll(allUrls)}
              style={{ background: "none", border: "1px solid #c9cccf", borderRadius: 6, fontSize: 12, cursor: "pointer", padding: "4px 10px", color: "#333", display: "inline-flex", alignItems: "center", gap: 4 }}
            >
              {labels.attachments.downloadAllTemplate.replace("{count}", allUrls.length)}
            </button>
          </div>
        )}
      </BlockStack>
    );
  }

  return (
    <Page
      backAction={{ content: labels.page.backAction, onAction: () => navigate("/app/quotes") }}
      title={isNew ? labels.page.newTitle : formatQuoteNumber(quote)}
      subtitle={isNew ? labels.page.newSubtitle : labels.page.subtitleTemplate.replace("{date}", fmtDate(quote.updatedAt || quote.createdAt))}
      titleMetadata={isNew ? null : <Badge tone={sc.tone}>{sc.label}</Badge>}
      secondaryActions={[
        ...(!isNew && !isClosed ? [
          { content: labels.headerActions.accept, onAction: () => setAcceptModal(true) },
          { content: labels.headerActions.reject, onAction: () => setRejectModal(true), destructive: true },
        ] : []),
        ...(isAccepted ? [
          { content: labels.headerActions.paymentReceived, onAction: () => submit({ intent: "paymentReceived" }) },
        ] : []),
        ...((isRejected || isPaid) ? [
          { content: labels.headerActions.reopen, onAction: () => submit({ intent: "reopen" }) },
        ] : []),
      ]}
      actionGroups={isNew ? [] : [{
        title: labels.headerActions.moreActionsTitle,
        actions: [
          ...(!hasDraftOrder ? [{ content: labels.headerActions.convertToDraft, icon: ReceiptIcon, onAction: () => submit({ intent: "convertToDraft", lineItemsJson: JSON.stringify(lineItems.map(({ _key, ...rest }) => rest)) }) }] : []),
          { content: labels.headerActions.duplicate, icon: DuplicateIcon, onAction: () => submit({ intent: "duplicate" }) },
          { content: labels.headerActions.printPdf,  icon: PrintIcon,     onAction: handlePrintPDF                        },
        ],
      }]}
      additionalNavigation={isNew ? null :
        <InlineStack gap="100">
          <Tooltip content={labels.page.tooltipPreviousQuote}>
            <Button
              variant="plain"
              icon={ChevronLeftIcon}
              disabled={!prevId}
              onClick={() => navigate(`/app/quote/${prevId}`)}
              accessibilityLabel={labels.page.tooltipPreviousQuote}
            />
          </Tooltip>
          <Tooltip content={labels.page.tooltipNextQuote}>
            <Button
              variant="plain"
              icon={ChevronRightIcon}
              disabled={!nextId}
              onClick={() => navigate(`/app/quote/${nextId}`)}
              accessibilityLabel={labels.page.tooltipNextQuote}
            />
          </Tooltip>
        </InlineStack>
      }
    >

      <BlockStack gap="400">

        {/* ── Sticky primary action ── the Polaris Page header's Save/Create
            action scrolls out of view while filling the form (both desktop and
            mobile), forcing a scroll back up to save. Pin it to the top instead
            so it's reachable from any field. Replaces the header primaryAction
            on every viewport */}
        <StickySaveBar
          label={isNew ? labels.saveBar.createAction : labels.saveBar.saveAction}
          onAction={handleSave}
          loading={isBusy && fetcher.formData?.get("intent") === "updateQuote"}
        />

        {/* ── Banners ── */}
        {hasUnsavedChanges && (
          <Banner tone="warning">
            {labels.banners.unsavedChanges}
          </Banner>
        )}
        {isAccepted && !isPaid && (
          <Banner
            tone="success"
            title={labels.banners.acceptedTitle}
            action={{ content: labels.banners.acceptedRecordAction, onAction: () => submit({ intent: "paymentReceived" }) }}
          >
            {quote.checkoutLink && (
              <div style={{ marginTop: 8 }}>
                <Text variant="bodySm" as="p" tone="subdued">{labels.banners.checkoutLinkSentLabel}</Text>
                <a href={quote.checkoutLink} target="_blank" rel="noreferrer" style={{ fontSize: 13, color: linkColor, wordBreak: "break-all" }}>
                  {quote.checkoutLink}
                </a>
              </div>
            )}
          </Banner>
        )}
        {isPaid && (
          <Banner tone="success" title={labels.banners.paidTitle} />
        )}
        {isRejected && (
          <Banner
            tone="critical"
            title={labels.banners.rejectedTitle}
            action={{ content: labels.banners.rejectedReopenAction, onAction: () => submit({ intent: "reopen" }) }}
          />
        )}
        {hasDraftOrder && (
          <Banner tone="info" title={labels.banners.draftOrderTitleTemplate.replace("{name}", activeDraftName ? ` ${activeDraftName}` : "")}>
            {activeDraftUrl && (
              <div style={{ marginTop: 6 }}>
                <Text variant="bodySm" as="span" tone="subdued">{labels.banners.draftOrderInvoiceLabel} </Text>
                <a href={activeDraftUrl} target="_blank" rel="noreferrer" style={{ fontSize: 13, color: linkColor, wordBreak: "break-all" }}>
                  {activeDraftUrl}
                </a>
              </div>
            )}
          </Banner>
        )}

{/* ── Main layout ── */}
        <InlineGrid columns={isMobile ? 1 : ["twoThirds", "oneThird"]} gap="400" alignItems="start">

          {/* ── LEFT ── */}
          <BlockStack gap="400">

            {/* Products */}
            <ColorCard background={cardBackgroundColor} padding="400">
              <BlockStack gap="300">
                <Text variant="headingMd" as="h2">{labels.productsCard.heading}</Text>

                {/* Search-style trigger for ResourcePicker */}
                <TextField
  label=""
  labelHidden
  placeholder={labels.productsCard.searchPlaceholder}
  autoComplete="off"
  readOnly
  onFocus={(e) => { e?.target?.blur?.(); handlePickProduct(); clearError("productList"); }}
  prefix={<Icon source={SearchIcon} />}
  error={fieldErrors.productList}
/>

                {/* Table header */}
                <Box borderBlockEndWidth="025" borderColor="border" paddingBlockEnd="200">
                  <InlineGrid columns={isMobile ? "1fr 36px" : "2fr 80px 120px 90px 36px"} gap="200">
                    {(isMobile
                      ? [labels.productsCard.columnProduct, ""]
                      : [labels.productsCard.columnProduct, labels.productsCard.columnQty, labels.productsCard.columnQuotePrice, labels.productsCard.columnTotal, ""]
                    ).map((h, i) => (
                      <Text key={h || `h-${i}`} variant="bodySm" tone="subdued" fontWeight="semibold" as="span">{h}</Text>
                    ))}
                  </InlineGrid>
                </Box>

                {/* Line item rows */}
                {lineItems.map((item) => {
                  const rowTotal = Math.max(0, parseFloat(item.qty) || 0) * Math.max(0, parseFloat(item.price) || 0);
                  return (
                    <div key={item._key}>
                      <InlineGrid columns={isMobile ? "1fr 36px" : "2fr 80px 120px 90px 36px"} gap="200" alignItems="start">
                        <InlineStack gap="300" blockAlign="start" wrap={false}>
                          <div style={{
                            width: 52, height: 52, flexShrink: 0, borderRadius: 8,
                            border: "1px solid #e1e3e5", overflow: "hidden",
                            background: "#f6f6f7", display: "flex", alignItems: "center", justifyContent: "center",
                          }}>
                            {item.image
                              ? <img src={item.image} alt={item.title} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                              : <Icon source={NoteIcon} tone="subdued" />
                            }
                          </div>
                          <BlockStack gap="050">
                            <Text variant="bodyMd" fontWeight="semibold" as="p">{item.title}</Text>
                            {item.vendor && <Text variant="bodySm" tone="subdued" as="p">{labels.productsCard.vendorPrefix} {item.vendor}</Text>}
                            {item.sku    && <Text variant="bodySm" tone="subdued" as="p">{labels.productsCard.skuPrefix} {item.sku}</Text>}
                            {item.options?.length > 0 && (
                              <Text variant="bodySm" tone="subdued" as="p">
                                {item.options.map((o) => `${o.name}: ${o.value}`).join(" · ")}
                              </Text>
                            )}
                            {item.customerOfferPrice != null && (
                              <Text variant="bodySm" tone="magic" as="p">
                                {labels.productsCard.customerOfferPrefix} {fmt(item.customerOfferPrice)}
                              </Text>
                            )}
                            {item.note && (
                              <Text variant="bodySm" tone="subdued" as="p">
                                {labels.productsCard.notePrefix} {item.note}
                              </Text>
                            )}
                            {/* Mobile: Qty + Price as equal-width, aligned fields
                                so they read as a balanced pair, with the
                                line total given clear visual emphasis. */}
                            {isMobile && (
                              <Box paddingBlockStart="100">
                                <BlockStack gap="200">
                                  <InlineGrid columns="1fr 1fr" gap="200" alignItems="start">
                                    <TextField label={labels.productsCard.qtyFieldLabel} value={item.qty} onChange={(v) => updateLineItem(item._key, "qty", v)} type="number" min={1} step={1} autoComplete="off" />
                                    <TextField label={labels.productsCard.priceFieldLabel} value={item.price} onChange={(v) => { updateLineItem(item._key, "price", v); clearError(`price_${item._key}`); }} type="number" min={0} step={0.01} prefix={currSym} autoComplete="off" placeholder="0.00" error={fieldErrors[`price_${item._key}`]} />
                                  </InlineGrid>
                                  <InlineStack align="space-between" blockAlign="center">
                                    <Text variant="bodySm" tone="subdued" as="span">{labels.productsCard.lineTotalLabel}</Text>
                                    <Text variant="bodyMd" fontWeight="bold" tone="success" as="span">{fmt(rowTotal)}</Text>
                                  </InlineStack>
                                </BlockStack>
                              </Box>
                            )}
                          </BlockStack>
                        </InlineStack>

                        {!isMobile && <TextField label="" labelHidden value={item.qty} onChange={(v) => updateLineItem(item._key, "qty", v)} type="number" min={1} step={1} autoComplete="off" />}
                        {!isMobile && <TextField label="" labelHidden value={item.price} onChange={(v) => { updateLineItem(item._key, "price", v); clearError(`price_${item._key}`); }} type="number" min={0} step={0.01} prefix={currSym} autoComplete="off" placeholder="0.00" error={fieldErrors[`price_${item._key}`]} />}
                        {!isMobile && (
                          <Box paddingBlockStart="150">
                            <Text variant="bodyMd" fontWeight="bold" tone="success" as="p">{fmt(rowTotal)}</Text>
                          </Box>
                        )}
                        <Button
                          variant="plain" tone="critical" icon={DeleteIcon}
                          accessibilityLabel={labels.productsCard.removeProductAction}
                          onClick={() => removeLineItem(item._key)}
                        />
                      </InlineGrid>
                      <Box paddingBlockStart="200"><Divider /></Box>
                    </div>
                  );
                })}
              </BlockStack>
            </ColorCard>

            {/* Payment */}
            <ColorCard background={cardBackgroundColor} padding="400">
              <BlockStack gap="200">
                <Text variant="headingMd" as="h2">{labels.paymentCard.heading}</Text>
                <Divider />

                <InlineStack align="space-between">
                  <Text variant="bodyMd" as="p">{labels.paymentCard.subtotalLabel}</Text>
                  <Text variant="bodyMd" fontWeight="semibold" as="p">{fmt(subtotal)}</Text>
                </InlineStack>

                {[
                  { label: labels.paymentCard.discountLabel, value: discount, set: setDiscount, sign: "-", max: subtotal },
                  { label: labels.paymentCard.shippingLabel, value: shipping, set: setShipping, sign: "+" },
                  { label: labels.paymentCard.taxLabel,      value: tax,      set: setTax,      sign: "+" },
                ].map(({ label, value, set, sign, max }) => {
                  const numVal = parseFloat(value) || 0;
                  const fieldError = max !== undefined && numVal > max
                    ? labels.paymentCard.discountExceedsSubtotalTemplate.replace("{amount}", fmt(max))
                    : undefined;
                  return (
                    <InlineGrid key={label} columns="1fr 130px" gap="200" alignItems={fieldError ? "start" : "center"}>
                      <Text variant="bodyMd" tone="subdued" as="p">{label}</Text>
                      <TextField
                        label="" labelHidden
                        value={value}
                        onChange={(v) => {
                          const sanitized = v.replace(/[^0-9.]/g, "").replace(/^(\d*\.?\d*).*$/, "$1");
                          set(sanitized);
                        }}
                        type="text"
                        inputMode="decimal"
                        prefix={`${sign}${currSym}`}
                        autoComplete="off"
                        error={fieldError}
                      />
                    </InlineGrid>
                  );
                })}

                <Divider />
                <InlineStack align="space-between">
                  <Text variant="headingSm" fontWeight="bold" as="p">{labels.paymentCard.totalLabel}</Text>
                  <Text variant="headingSm" fontWeight="bold" as="p">{fmt(total)}</Text>
                </InlineStack>
              </BlockStack>
            </ColorCard>

            {/* ── Timeline ── */}
            <ColorCard background={cardBackgroundColor} padding="400">
              <BlockStack gap="300">
                <Text variant="headingSm" fontWeight="bold" as="h3">{labels.timelineCard.heading}</Text>

                {/* Compose box */}
                <div style={{ background: "#fff", border: "1px solid #e1e3e5", borderRadius: 10, padding: "10px 12px", display: "flex", alignItems: "center", gap: 10 }}>
                  <div style={{ width: 34, height: 34, borderRadius: "50%", background: "#e4e5e7", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                    <Icon source={PersonIcon} tone="subdued" />
                  </div>
                  <input
                    value={noteText}
                    onChange={(e) => setNoteText(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && noteText.trim()) {
                        submit({ intent: "addNote", noteText: noteText.trim() });
                      }
                    }}
                    placeholder={labels.timelineCard.composePlaceholder}
                    style={{ flex: 1, border: "none", outline: "none", fontSize: 14, background: "transparent", color: "#202223" }}
                  />
                  <button
                    onClick={() => { if (noteText.trim()) submit({ intent: "addNote", noteText: noteText.trim() }); }}
                    disabled={!noteText.trim() || isBusy}
                    style={{ border: "1px solid #c9cccf", borderRadius: 8, padding: "5px 14px", fontSize: 13, fontWeight: 600, background: "#fff", cursor: noteText.trim() ? "pointer" : "default", color: noteText.trim() ? "#202223" : "#8c9196", transition: "opacity .15s" }}
                  >
                    {labels.timelineCard.postAction}
                  </button>
                </div>

                <div style={{ textAlign: "right" }}>
                  <Text variant="bodySm" tone="subdued">{labels.timelineCard.visibilityNote}</Text>
                </div>

                {/* Timeline events */}
                {timelineGroups.length > 0 && (
                  <div style={{ position: "relative", paddingLeft: 28 }}>
                    {/* Vertical line */}
                    <div style={{ position: "absolute", left: 9, top: 0, bottom: 0, width: 1, background: "#e1e3e5" }} />

                    {timelineGroups.map((group, gi) => (
                      <div key={gi} style={{ marginBottom: gi < timelineGroups.length - 1 ? 20 : 0 }}>
                        {/* Date header */}
                        <div style={{ marginBottom: 12 }}>
                          <Text variant="bodySm" fontWeight="semibold" tone="subdued">{group.label}</Text>
                        </div>

                        {group.events.map((ev, ei) => (
                          <div key={ei} style={{ position: "relative", marginBottom: ei < group.events.length - 1 ? 14 : 0 }}>
                            {/* Dot */}
                            <div style={{ position: "absolute", left: -23, top: ev.type === "note" ? 10 : 3, width: 10, height: 10, borderRadius: "50%", background: ev.type === "note" ? secondaryColor : "#202223", border: "2px solid #fff", boxShadow: "0 0 0 1px " + (ev.type === "note" ? secondaryColor : "#202223") }} />

                            {ev.type === "note" ? (
                              /* Note bubble */
                              <div style={{ background: "#f6f6f7", border: "1px solid #e1e3e5", borderRadius: 8, padding: "8px 12px" }}>
                                <Text variant="bodySm" as="p">{ev.label}</Text>
                                <div style={{ marginTop: 4, textAlign: "right" }}>
                                  <Text variant="bodySm" tone="subdued">{fmtTimeOnly(ev.date)}</Text>
                                </div>
                              </div>
                            ) : (
                              /* Activity row */
                              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                                <Text variant="bodySm" as="p">{ev.label}</Text>
                                <Text variant="bodySm" tone="subdued">{fmtTimeOnly(ev.date)}</Text>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    ))}
                  </div>
                )}
              </BlockStack>
            </ColorCard>

          </BlockStack>

          {/* ── RIGHT ── */}
          <BlockStack gap="400">

            {/* Customer + Shipping merged */}
            <ColorCard background={cardBackgroundColor} padding="400">
              <BlockStack gap="400">

                {/* Header */}
                <InlineStack align="space-between" blockAlign="center">
                  <Text variant="headingSm" fontWeight="semibold" as="h3">{labels.customerCard.heading}</Text>
                  <InlineStack gap="200" blockAlign="center">
                    <Tooltip content={labels.customerCard.quoteCountTooltipTemplate.replace("{count}", customerQuoteCount).replace("{plural}", customerQuoteCount !== 1 ? "s" : "")}>
                      <Badge tone={customerQuoteCount > 1 ? "info" : "default"}>
                        {labels.customerCard.quoteCountBadgeTemplate.replace("{count}", customerQuoteCount).replace("{plural}", customerQuoteCount !== 1 ? "s" : "")}
                      </Badge>
                    </Tooltip>
                    {!isNew && (
                      <Button
                        variant="primary"
                        icon={customerEditMode ? undefined : EditIcon}
                        onClick={() => setCustomerEditMode((v) => !v)}
                      >
                        {customerEditMode ? labels.customerCard.doneAction : labels.customerCard.editAction}
                      </Button>
                    )}
                  </InlineStack>
                </InlineStack>

                {customerEditMode ? (
                  <>
                    {/* Customer fields — edit mode */}
                    <BlockStack gap="200">
                      <TextField label={labels.customerCard.fieldName}    value={customerName}  onChange={(v) => { setCustomerName(v);  clearError("customerName");  }} autoComplete="off" error={fieldErrors.customerName} />
                      <TextField label={labels.customerCard.fieldEmail}   type="email" value={customerEmail} onChange={(v) => { setCustomerEmail(v); clearError("customerEmail"); }} autoComplete="off" error={fieldErrors.customerEmail} />
                      <TextField label={labels.customerCard.fieldPhone}   value={customerPhone} onChange={(v) => { setCustomerPhone(v); clearError("customerPhone"); }} autoComplete="off" error={fieldErrors.customerPhone} />
                      <TextField label={labels.customerCard.fieldMessage} value={message} onChange={setMessage} multiline={3} autoComplete="off" />
                    </BlockStack>

                    <Divider />

                    {/* Shipping address — edit mode */}
                    <BlockStack gap="100">
                      <Text variant="bodySm" fontWeight="semibold" as="p">{labels.customerCard.shippingHeading}</Text>
                      <TextField label={labels.customerCard.fieldStreet}   value={shippingAddr.street}   onChange={(v) => { setShippingAddr((p) => ({ ...p, street:   v })); clearError("shippingAddr.street");   }} autoComplete="off" error={fieldErrors["shippingAddr.street"]} />
                      <TextField label={labels.customerCard.fieldCity}     value={shippingAddr.city}     onChange={(v) => { setShippingAddr((p) => ({ ...p, city:     v })); clearError("shippingAddr.city");     }} autoComplete="off" error={fieldErrors["shippingAddr.city"]} />
                      <TextField label={labels.customerCard.fieldDistrict} value={shippingAddr.district} onChange={(v) => { setShippingAddr((p) => ({ ...p, district: v })); clearError("shippingAddr.district"); }} autoComplete="off" error={fieldErrors["shippingAddr.district"]} />
                      <InlineGrid columns={2} gap="200">
                        <TextField label={labels.customerCard.fieldState}   value={shippingAddr.state}   onChange={(v) => { setShippingAddr((p) => ({ ...p, state:   v })); clearError("shippingAddr.state");   }} autoComplete="off" error={fieldErrors["shippingAddr.state"]} />
                        <TextField label={labels.customerCard.fieldCountry} value={shippingAddr.country} onChange={(v) => { setShippingAddr((p) => ({ ...p, country: v })); clearError("shippingAddr.country"); }} autoComplete="off" error={fieldErrors["shippingAddr.country"]} />
                      </InlineGrid>
                      <TextField label={labels.customerCard.fieldPostal} value={shippingAddr.postal} onChange={(v) => { setShippingAddr((p) => ({ ...p, postal: v })); clearError("shippingAddr.postal"); }} autoComplete="off" error={fieldErrors["shippingAddr.postal"]} />
                    </BlockStack>
                  </>
                ) : (
                  <>
                    {/* Customer fields — view mode */}
                    <BlockStack gap="100">
                      {roRow(labels.customerCard.fieldName, customerName)}
                      {roRow(labels.customerCard.fieldEmail, customerEmail)}
                      {roRow(labels.customerCard.fieldPhone, customerPhone)}
                      {message && message.trim() ? roRow(labels.customerCard.fieldMessage, message) : null}
                    </BlockStack>

                    <Divider />

                    {/* Shipping address — view mode */}
                    <BlockStack gap="100">
                      <Text variant="bodySm" fontWeight="semibold" as="p">{labels.customerCard.shippingHeading}</Text>
                      {[shippingAddr.street, shippingAddr.city, shippingAddr.district, shippingAddr.state, shippingAddr.country, shippingAddr.postal].some((v) => v && String(v).trim()) ? (
                        <BlockStack gap="100">
                          {roRow(labels.customerCard.fieldStreet, shippingAddr.street)}
                          {roRow(labels.customerCard.fieldCity, shippingAddr.city)}
                          {roRow(labels.customerCard.fieldDistrict, shippingAddr.district)}
                          {roRow(labels.customerCard.fieldState, shippingAddr.state)}
                          {roRow(labels.customerCard.fieldCountry, shippingAddr.country)}
                          {roRow(labels.customerCard.fieldPostal, shippingAddr.postal)}
                        </BlockStack>
                      ) : (
                        <Text variant="bodySm" tone="subdued" as="span">{labels.customerCard.noShippingAddress}</Text>
                      )}
                    </BlockStack>
                  </>
                )}


                {/* Extra custom form fields from customer submission */}
                {otherFields.length > 0 && (
                  <>
                    <Divider />
                    <BlockStack gap="100">
                      <Text variant="bodySm" fontWeight="semibold" as="p">{labels.customerCard.additionalInfoHeading}</Text>
                      {otherFields.map((f, i) => (
                        <InlineStack key={i} gap="100">
                          <Text variant="bodySm" tone="subdued" as="span">{f.label || f.key}:</Text>
                          {renderFieldValue(f.value)}
                        </InlineStack>
                      ))}
                    </BlockStack>
                  </>
                )}

              </BlockStack>
            </ColorCard>

            {/* Tags */}
            {!isNew && (
              <ColorCard background={cardBackgroundColor} padding="400">
                <BlockStack gap="300">
                  <Text variant="headingSm" fontWeight="semibold" as="h3">{labels.tagsCard.heading}</Text>

                  <Combobox
                    activator={
                      <Combobox.TextField
                        label={labels.tagsCard.heading}
                        labelHidden
                        value={tagInput}
                        onChange={setTagInput}
                        placeholder={labels.tagsCard.searchPlaceholder}
                        autoComplete="off"
                      />
                    }
                  >
                    {(filteredTagOptions.length > 0 || tagInput) && (
                      <Listbox autoSelection={AutoSelection.None} onSelect={handleTagSelect}>
                        {filteredTagOptions.map((option) => (
                          <Listbox.Option key={option} value={option} selected={tags.includes(option)}>
                            {option}
                          </Listbox.Option>
                        ))}
                        {tagInput.trim() &&
                          !tagOptions.some((o) => o.toLowerCase() === tagInput.trim().toLowerCase()) && (
                            <Listbox.Action value={tagInput.trim()}>
                              {labels.tagsCard.addTagActionTemplate.replace("{tag}", tagInput.trim())}
                            </Listbox.Action>
                          )}
                      </Listbox>
                    )}
                  </Combobox>

                  {tags.length > 0 && (
                    <InlineStack gap="100">
                      {tags.map((tag) => (
                        <Tag key={tag} onRemove={() => removeTag(tag)}>{tag}</Tag>
                      ))}
                    </InlineStack>
                  )}
                </BlockStack>
              </ColorCard>
            )}

          </BlockStack>
        </InlineGrid>

      </BlockStack>

      {/* ── Accept Modal — email editor ── */}
      <EmailEditorModal
        open={acceptModal}
        onClose={() => setAcceptModal(false)}
        title={labels.acceptModal.title}
        isMobile={isMobile}
        toEmail={quote.customerEmail}
        subject={acceptEmailSubject} onSubjectChange={setAcceptEmailSubject}
        heading={acceptEmailHeading} onHeadingChange={setAcceptEmailHeading}
        content={acceptEmailContent} onContentChange={setAcceptEmailContent}
        ctaText={acceptEmailAction} onCtaTextChange={setAcceptEmailAction}
        showCta={acceptShowCta} onShowCtaChange={setAcceptShowCta}
        ctaCheckboxLabel={labels.acceptModal.ctaCheckboxLabel}
        extraFields={
          <BlockStack gap="100">
            <TextField
              label={labels.acceptModal.checkoutLinkFieldLabel}
              value={acceptEmailCheckoutUrl}
              onChange={setAcceptEmailCheckoutUrl}
              placeholder={labels.acceptModal.checkoutLinkPlaceholder}
              autoComplete="off"
              helpText={labels.acceptModal.checkoutLinkHelpText}
            />
          </BlockStack>
        }
        variables={[
          ["{customer_name}", quote.customerName],
          ["{product_title}", quote.productTitle],
          ["{quote_price}",   quote.quotedPrice != null ? fmt(quote.quotedPrice) : labels.acceptModal.variableQuotePriceFallback],
          ["{checkout_link}", labels.acceptModal.variableCheckoutLinkPlaceholder],
        ]}
        variablesTruncate
        previewHeader={<span style={{ fontSize: 13, fontWeight: 700, color: "#202223" }}>{quote.shop || labels.acceptModal.previewStoreFallback}</span>}
        previewMessage={(acceptEmailContent || "")
          .replaceAll("{customer_name}", quote.customerName || "")
          .replaceAll("{product_title}", quote.productTitle || "")
          .replaceAll("{quote_price}",   fmt(total))
          .replaceAll("{checkout_link}", acceptEmailCheckoutUrl || labels.acceptModal.previewCheckoutPlaceholder)}
        previewExtra={
          <div style={{ margin: "0 20px 16px", background: "#f6f6f7", border: "1px solid #e1e3e5", borderRadius: 6, padding: "10px 14px" }}>
            <p style={{ fontSize: 10, color: "#6d7175", margin: "0 0 4px", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.05em" }}>{labels.acceptModal.checkoutLinkPreviewLabel}</p>
            <p style={{ fontSize: 11, color: linkColor, margin: 0, wordBreak: "break-all" }}>
              {acceptEmailCheckoutUrl || <span style={{ color: "#8c9196", fontStyle: "italic" }}>{labels.acceptModal.checkoutLinkAutoGenNote}</span>}
            </p>
          </div>
        }
        ctaPadding="10px 24px"
        primaryActionLabel={labels.acceptModal.primaryActionLabel}
        isBusy={isBusy}
        onPrimaryAction={() => {
          submit({
            intent:            "acceptWithEmail",
            emailSubject:      acceptEmailSubject,
            emailHeading:      acceptEmailHeading,
            emailContent:      acceptEmailContent,
            emailAction:       acceptEmailAction,
            emailShowCta:      String(acceptShowCta),
            emailCheckoutUrl:  acceptEmailCheckoutUrl,
            lineItemsJson:     JSON.stringify(lineItems.map(({ _key, ...rest }) => rest)),
            discount,
            shipping,
            quoteTotal:        String(total),
          });
        }}
        secondaryActionLabel={labels.acceptModal.secondaryActionLabel}
        onSecondaryAction={() => {
          submit({
            intent:        "accept",
            lineItemsJson: JSON.stringify(lineItems.map(({ _key, ...rest }) => rest)),
            discount,
            shipping,
          });
        }}
      />

      {/* ── Reject Modal — email editor ── */}
      <EmailEditorModal
        open={rejectModal}
        onClose={() => setRejectModal(false)}
        title={labels.rejectModal.title}
        isMobile={isMobile}
        toEmail={quote.customerEmail}
        subject={rejectEmailSubject} onSubjectChange={setRejectEmailSubject}
        heading={rejectEmailHeading} onHeadingChange={setRejectEmailHeading}
        content={rejectEmailContent} onContentChange={setRejectEmailContent}
        ctaText={rejectEmailAction} onCtaTextChange={setRejectEmailAction}
        showCta={rejectShowCta} onShowCtaChange={setRejectShowCta}
        variables={[
          ["{customer_name}", quote.customerName],
          ["{product_title}", quote.productTitle],
        ]}
        previewHeader={<div style={{ width: 60, height: 14, borderRadius: 4, background: "#d2d5d8" }} />}
        previewHeaderStyle={{ height: 44 }}
        previewMessage={(rejectEmailContent || "")
          .replaceAll("{customer_name}", quote.customerName || "")
          .replaceAll("{product_title}", quote.productTitle || "")}
        primaryActionLabel={labels.rejectModal.primaryActionLabel}
        destructive
        isBusy={isBusy}
        onPrimaryAction={() => {
          submit({
            intent:       "rejectWithEmail",
            emailSubject: rejectEmailSubject,
            emailHeading: rejectEmailHeading,
            emailContent: rejectEmailContent,
            emailAction:  rejectEmailAction,
            emailShowCta: String(rejectShowCta),
          });
        }}
        secondaryActionLabel={labels.rejectModal.secondaryActionLabel}
        onSecondaryAction={() => submit({ intent: "reject" })}
      />

      {/* ── Draft Order Result Modal ── */}
      <Modal
        open={draftModal}
        onClose={() => setDraftModal(false)}
        title={labels.draftOrderModal.title}
        primaryAction={{ content: labels.draftOrderModal.doneAction, onAction: () => setDraftModal(false) }}
      >
        <Modal.Section>
          <BlockStack gap="200">
            <Text variant="bodyMd" as="p">
              {(() => {
                const [before, after] = labels.draftOrderModal.bodyTemplate.split("{name}");
                return <>{before}<strong>{draftResult?.draftOrderName}</strong>{after}</>;
              })()}
            </Text>
            {draftResult?.draftOrderInvoice && (
              <Button variant="plain" url={draftResult.draftOrderInvoice} external>
                {labels.draftOrderModal.viewInvoiceAction}
              </Button>
            )}
          </BlockStack>
        </Modal.Section>
      </Modal>

      <Box paddingBlockEnd="1600" />

      {/* Image lightbox */}
      {lightbox.open && (
        <div
          onClick={() => setLightbox((s) => ({ ...s, open: false }))}
          style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.88)", zIndex: 9999, display: "flex", alignItems: "center", justifyContent: "center" }}
        >
          {/* Close */}
          <button
            type="button"
            onClick={() => setLightbox((s) => ({ ...s, open: false }))}
            style={{ position: "absolute", top: 16, right: 20, background: "none", border: "none", color: "#fff", fontSize: 32, cursor: "pointer", lineHeight: 1, zIndex: 10000 }}
          >
            ×
          </button>

          {/* Prev */}
          {lightbox.images.length > 1 && (
            <button
              type="button"
              onClick={(e) => { e.stopPropagation(); setLightbox((s) => ({ ...s, index: (s.index - 1 + s.images.length) % s.images.length })); }}
              style={{ position: "absolute", left: 16, background: "rgba(255,255,255,0.15)", border: "none", color: "#fff", fontSize: 28, cursor: "pointer", borderRadius: "50%", width: 44, height: 44, display: "flex", alignItems: "center", justifyContent: "center" }}
            >
              ‹
            </button>
          )}

          {/* Image */}
          <img
            src={lightbox.images[lightbox.index]}
            alt="attachment"
            onClick={(e) => e.stopPropagation()}
            style={{ maxWidth: "90vw", maxHeight: "85vh", objectFit: "contain", borderRadius: 6, boxShadow: "0 8px 40px rgba(0,0,0,0.6)" }}
          />

          {/* Next */}
          {lightbox.images.length > 1 && (
            <button
              type="button"
              onClick={(e) => { e.stopPropagation(); setLightbox((s) => ({ ...s, index: (s.index + 1) % s.images.length })); }}
              style={{ position: "absolute", right: 16, background: "rgba(255,255,255,0.15)", border: "none", color: "#fff", fontSize: 28, cursor: "pointer", borderRadius: "50%", width: 44, height: 44, display: "flex", alignItems: "center", justifyContent: "center" }}
            >
              ›
            </button>
          )}

          {/* Bottom bar: counter + download */}
          <div
            onClick={(e) => e.stopPropagation()}
            style={{ position: "absolute", bottom: 20, left: "50%", transform: "translateX(-50%)", display: "flex", alignItems: "center", gap: 16 }}
          >
            {lightbox.images.length > 1 && (
              <span style={{ color: "rgba(255,255,255,0.7)", fontSize: 13 }}>
                {lightbox.index + 1} / {lightbox.images.length}
              </span>
            )}
            <button
              type="button"
              onClick={() => downloadFile(lightbox.images[lightbox.index])}
              style={{ background: "rgba(255,255,255,0.15)", border: "1px solid rgba(255,255,255,0.3)", color: "#fff", fontSize: 13, borderRadius: 6, padding: "6px 14px", cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 6 }}
            >
              {labels.attachments.lightboxDownload}
            </button>
            {lightbox.images.length > 1 && (
              <button
                type="button"
                onClick={() => downloadAll(lightbox.images)}
                style={{ background: "rgba(255,255,255,0.15)", border: "1px solid rgba(255,255,255,0.3)", color: "#fff", fontSize: 13, borderRadius: 6, padding: "6px 14px", cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 6 }}
              >
                {labels.attachments.lightboxDownloadAll}
              </button>
            )}
          </div>
        </div>
      )}
    </Page>
  );
}

export function ErrorBoundary() { return boundary.error(useRouteError()); }
export const headers = (headersArgs) => boundary.headers(headersArgs);

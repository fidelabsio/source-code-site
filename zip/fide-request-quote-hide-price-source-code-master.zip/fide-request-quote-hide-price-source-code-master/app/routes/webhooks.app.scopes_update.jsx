export { action } from "../domain/webhooks/appScopesUpdate.server";

import { Outlet, useLoaderData, useRouteError } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { AppProvider as ShopifyProvider } from "@shopify/shopify-app-react-router/react";
import { AppProvider as PolarisProvider } from "@shopify/polaris";
import { NavMenu } from "@shopify/app-bridge-react";
import enTranslations from "@shopify/polaris/locales/en.json";
import polarisStyles from "@shopify/polaris/build/esm/styles.css?url";
import { OfflineOverlay, OfflineScreen } from "../components/template-editor/OfflineOverlay";
import { authenticate } from "../core/shopify/shopify.server";
import { ADMIN_BUTTON_BRAND_COLOR } from "../core/app-shell/theme.server";
import { useNavInterceptor } from "../hooks/app/useNavInterceptor";
import { useNavigationLoader } from "../hooks/app/useNavigationLoader";
import { isTransientNavigationError, useOfflineReload } from "../hooks/app/useOfflineRecovery";

export const loader = async ({ request }) => {
  await authenticate.admin(request);
  // eslint-disable-next-line no-undef -- loader runs server-side; `process` isn't in this file's browser eslint env
  return { apiKey: process.env.SHOPIFY_API_KEY || "", buttonColor: ADMIN_BUTTON_BRAND_COLOR() };
};

// Darkens (negative percent) or lightens (positive) a hex color — used to
// derive Polaris's hover/active button shades from the merchant's single
// app-shell/theme.json ADMIN_BUTTON_BRAND_COLOR.
function shadeHex(hex, percent) {
  const num = parseInt(hex.slice(1), 16);
  const amt = Math.round(2.55 * percent);
  const clamp = (v) => Math.max(0, Math.min(255, v));
  const r = clamp((num >> 16) + amt);
  const g = clamp(((num >> 8) & 0xff) + amt);
  const b = clamp((num & 0xff) + amt);
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

export const links = () => [{ rel: "stylesheet", href: polarisStyles }];

export const shouldRevalidate = () => false;

function NavInterceptor() {
  useNavInterceptor();
  return null;
}

function NavigationLoader() {
  useNavigationLoader();
  return null;
}

function OfflineErrorScreen() {
  useOfflineReload();
  return <OfflineScreen />;
}

export default function App() {
  const { apiKey, buttonColor } = useLoaderData();

  return (
    <ShopifyProvider embedded apiKey={apiKey}>
      <PolarisProvider i18n={enTranslations}>
        <style>{`:root{
          --p-color-bg-fill-brand: ${buttonColor};
          --p-color-bg-fill-brand-hover: ${shadeHex(buttonColor, -12)};
          --p-color-bg-fill-brand-active: ${shadeHex(buttonColor, -20)};
          --p-color-bg-fill-brand-selected: ${shadeHex(buttonColor, -8)};
        }`}</style>
        <NavInterceptor />
        <NavigationLoader />
        <OfflineOverlay />
        <NavMenu>
          <a href="/app" rel="home">Home</a>
          <a href="/app/quotes">Quote List</a>
          <a href="/app/quote-settings">Quote Settings</a>
          <a href="/app/settings">Settings</a>
        </NavMenu>
        <Outlet />
      </PolarisProvider>
    </ShopifyProvider>
  );
}

export function ErrorBoundary() {
  const error = useRouteError();

  // Show the friendly recovery screen instead of leaking React Router's raw
  // "Application Error" stack when the merchant is offline, or when a
  // navigation failed transiently against a flaky connection (the connection
  // may already be back by the time the error surfaces). Genuine app errors
  // fall through to Shopify's default error handler.
  const offline = typeof navigator !== "undefined" && !navigator.onLine;
  if (offline || isTransientNavigationError(error)) {
    return <OfflineErrorScreen />;
  }

  return boundary.error(error);
}

export const headers = (headersArgs) => {
  return boundary.headers(headersArgs);
};

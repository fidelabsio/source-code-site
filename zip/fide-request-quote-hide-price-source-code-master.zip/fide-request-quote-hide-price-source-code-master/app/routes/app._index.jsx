import { useRouteError } from "react-router";
import { useDashboard } from "../hooks/shop/useDashboard";
import {
  Page,
  Text,
  Button,
  BlockStack,
  InlineStack,
  Box,
  ProgressBar,
  InlineGrid,
  Divider,
  Avatar,
  Badge,
  Icon,
} from "@shopify/polaris";
import { XSmallIcon, ChevronUpIcon, ChevronDownIcon, ChevronRightIcon } from "@shopify/polaris-icons";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { formatQuoteNumber } from "../domain/quotes/quoteNumber";
import { formatShortDate } from "../utils/date";
import { ColorCard } from "../components/common/ColorCard";

export { loader } from "../domain/shop/dashboard.server";

const STEP_COUNT = 3;

// Each step's destination — structural/behavioral, so it stays here rather
// than in text-labels.json (which only holds copy). Index-matched against
// labels.setupGuide.steps; "EMBED_URL" is a marker the render resolves to
// the shop's deep-linked theme-editor URL.
const STEP_HREFS = ["EMBED_URL", "/app/quote-settings", null];

// Step titles/descriptions/button text come from app/config/dashboard/text-labels.json
// (labels.setupGuide.steps); {appName} is interpolated at render time since the
// app's own name (app/config/branding.json) isn't known when that file is written.
function buildSteps(appName, labels) {
  const interpolate = (str) => str.replaceAll("{appName}", appName);
  return labels.setupGuide.steps.map((step, i) => ({
    ...step,
    title: interpolate(step.title),
    description: interpolate(step.description),
    primaryHref: STEP_HREFS[i] ?? null,
  }));
}

// Dashed circle SVG for incomplete steps — Polaris has no built-in equivalent
function DashedCircle() {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0 }}>
      <circle cx="12" cy="12" r="10" stroke="#8c9196" strokeWidth="2" strokeDasharray="4 3" strokeLinecap="round" />
    </svg>
  );
}

// eslint-disable-next-line react/prop-types -- presentational icon, not worth a PropTypes dependency
function CheckCircle({ fill }) {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0 }}>
      <circle cx="12" cy="12" r="11" fill={fill} />
      <path d="M7 12.5l3.5 3.5 6.5-7" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

const formatDate = formatShortDate;

export default function Dashboard() {
  const {
    shop, embedEditorUrl, recent, stats, topProducts, appName, primaryColor,
    statTextColor, statCardBackgroundColor, cardBackgroundColor, labels,
    navigate, isMobile, fmt, statCards,
    dismissed, collapsed, completed, expanded, setExpanded,
    dismiss, collapse, completedCount, progress, markDone,
  } = useDashboard(STEP_COUNT);

  const STEPS = buildSteps(appName, labels);

  const STATUS_BADGE = {
    new:     { tone: "attention", label: labels.recentQuotes.statusUnread  },
    read:    { tone: "info",      label: labels.recentQuotes.statusRead    },
    replied: { tone: "success",   label: labels.recentQuotes.statusReplied },
  };

  return (
    <Page>
      <Box paddingInline={{ xs: "300", md: "1600" }}>
        <BlockStack gap="400">

          {/* ── Page header ── */}
          <InlineStack align="space-between" blockAlign="center">
            <Text variant="headingXl" fontWeight="bold" as="h1">{labels.pageTitle}</Text>
          </InlineStack>

          {!dismissed && <ColorCard background={cardBackgroundColor}>
        {/* ── Header ── */}
        <Box padding="400" paddingBlockEnd={collapsed ? "400" : "300"}>
          <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 12 }}>
            <BlockStack gap="100">
              <Text variant="headingMd" fontWeight="bold" as="h2">{labels.setupGuide.heading}</Text>
              <Text variant="bodySm" tone="subdued" as="p">
                {labels.setupGuide.descriptionIntro.replace("{appName}", appName)}{" "}
                <a href="https://help.shopify.com" target="_blank" rel="noreferrer" style={{ color: "var(--p-color-text-link)", textDecoration: "none" }}>{labels.setupGuide.videoTutorialLinkText}</a>
                {" "}{labels.setupGuide.descriptionJoiner}{" "}
                <a href="https://help.shopify.com" target="_blank" rel="noreferrer" style={{ color: "var(--p-color-text-link)", textDecoration: "none" }}>{labels.setupGuide.helpDocsLinkText}</a>
              </Text>
            </BlockStack>
            <div style={{ display: "flex", alignItems: "center", gap: 0, flexShrink: 0 }}>
              <Button variant="plain" icon={XSmallIcon} accessibilityLabel={labels.setupGuide.dismissLabel} onClick={dismiss} />
              <Button variant="plain" icon={collapsed ? ChevronDownIcon : ChevronUpIcon} accessibilityLabel={collapsed ? labels.setupGuide.expandLabel : labels.setupGuide.collapseLabel} onClick={collapse} />
            </div>
          </div>

          {!collapsed && (
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 12 }}>
              <span style={{ fontSize: 13, color: "var(--p-color-text-subdued)", whiteSpace: "nowrap" }}>
                {completedCount} / {STEPS.length} {labels.setupGuide.stepsCompletedSuffix}
              </span>
              <div style={{ flex: 1 }}>
                <ProgressBar progress={progress} size="small" tone="highlight" />
              </div>
            </div>
          )}
        </Box>

        {/* ── Steps ── */}
        {!collapsed && (
          <>
            {STEPS.map((step, i) => {
              const isDone     = completed.includes(i);
              const isExpanded = expanded === i && !isDone;
              const isLast     = i === STEPS.length - 1;

              return (
                <div key={i}>
                  {/* Grey background inset like screenshot — margin on sides, not full bleed */}
                  <div style={{ margin: "0 12px", borderRadius: 8, background: isExpanded ? "var(--p-color-bg-surface-secondary)" : "transparent" }}>
                    <div style={{ padding: "12px 16px" }}>
                      <BlockStack gap="100">
                        {/* Step row */}
                        <button
                          onClick={() => !isDone && setExpanded(isExpanded ? -1 : i)}
                          style={{
                            all: "unset",
                            display: "flex",
                            alignItems: "center",
                            gap: "10px",
                            cursor: isDone ? "default" : "pointer",
                            width: "100%",
                          }}
                        >
                          {isDone ? <CheckCircle fill={primaryColor} /> : <DashedCircle />}
                          <Text variant="bodySm" fontWeight="semibold" as="span">
                            {step.title}
                          </Text>
                        </button>

                        {/* Expanded content — description aligns under title text, not icon */}
                        {isExpanded && (
                          <div style={{ paddingLeft: 34 }}>
                            <BlockStack gap="300">
                              <Text variant="bodySm" tone="subdued" as="p">
                                {step.description}
                              </Text>
                              <InlineStack gap="200">
                                {step.primaryHref ? (
                                  <a
                                    href={step.primaryHref === "EMBED_URL" ? embedEditorUrl : step.primaryHref}
                                    target="_blank"
                                    rel="noreferrer"
                                    style={{ textDecoration: "none" }}
                                  >
                                    <Button variant="primary">{step.primaryLabel}</Button>
                                  </a>
                                ) : (
                                  <Button variant="primary" onClick={() => window.open(`https://${shop}`, "_blank")}>
                                    {step.primaryLabel}
                                  </Button>
                                )}
                                <Button onClick={() => markDone(i)}>{step.doneLabel}</Button>
                              </InlineStack>
                            </BlockStack>
                          </div>
                        )}
                      </BlockStack>
                    </div>
                  </div>

                  {!isLast && <Box paddingBlockStart="0"></Box>}
                </div>
              );
            })}
            {/* Bottom gap */}
            <Box paddingBlockEnd="400" />
          </>
        )}
      </ColorCard>}

      {/* ── Stats Row ── */}
      <Box paddingBlockStart="400">
        <InlineGrid columns={{ xs: 2, md: 4 }} gap="400">
          {statCards.map((s) => (
            <ColorCard key={s.label} background={statCardBackgroundColor} padding="400">
              <BlockStack gap="100">
                <Text variant="bodySm" tone="subdued" as="p">{s.label}</Text>
                <Text variant="heading2xl" fontWeight="bold" as="p">
                  <span style={{ color: statTextColor }}>{s.value}</span>
                </Text>
              </BlockStack>
            </ColorCard>
          ))}
        </InlineGrid>
      </Box>

      {/* ── Recent Quotes ── */}
      <ColorCard background={cardBackgroundColor}>
        {/* Card header */}
        <Box paddingInline="500" paddingBlock="400">
          <InlineStack align="space-between" blockAlign="center">
            <BlockStack gap="050">
              <Text variant="headingMd" fontWeight="semibold" as="h2">{labels.recentQuotes.heading}</Text>
              <Text variant="bodySm" tone="subdued" as="p">{stats.total} {labels.recentQuotes.totalSuffix}</Text>
            </BlockStack>
            <Button variant="plain" onClick={() => navigate("/app/quotes")} icon={ChevronRightIcon}>{labels.recentQuotes.viewAllLabel}</Button>
          </InlineStack>
        </Box>

        <Divider />

        {recent.length === 0 ? (
          <Box paddingBlock="1200" paddingInline="500">
            <BlockStack gap="300" inlineAlign="center">
              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#8c9196" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/>
              </svg>
              <BlockStack gap="100" inlineAlign="center">
                <Text variant="bodyMd" fontWeight="semibold" as="p">{labels.recentQuotes.emptyTitle}</Text>
                <Text variant="bodySm" tone="subdued" as="p" alignment="center">{labels.recentQuotes.emptyDescription}</Text>
              </BlockStack>
            </BlockStack>
          </Box>
        ) : (
          <>
            {/* Column labels */}
            <Box paddingInline="500" paddingBlock="200" background="bg-surface-secondary">
              <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr 80px 28px" : "2fr 2fr 1fr 1fr 28px", gap: 12, alignItems: "center" }}>
                {(isMobile
                  ? [labels.recentQuotes.columnCustomer, labels.recentQuotes.columnStatus, ""]
                  : [labels.recentQuotes.columnCustomer, labels.recentQuotes.columnProduct, labels.recentQuotes.columnStatus, labels.recentQuotes.columnDate, ""]
                ).map((h, i) => (
                  <Text key={i} variant="bodySm" tone="subdued" fontWeight="semibold" as="span">{h}</Text>
                ))}
              </div>
            </Box>
            <Divider />

            {/* Rows */}
            {recent.map((q, i) => {
              const sb = STATUS_BADGE[q.status] || { tone: "default", label: q.status };
              return (
                <div key={q.id}>
                  <Box
                    paddingInline="500"
                    paddingBlock="300"
                    as="button"
                    width="100%"
                    onClick={() => navigate(`/app/quote/${q.id}`)}
                  >
                    <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr 80px 28px" : "2fr 2fr 1fr 1fr 28px", gap: 12, alignItems: "center", width: "100%", cursor: "pointer" }}>
                      {/* Customer */}
                      <div style={{ display: "flex", alignItems: "center", gap: 10, textAlign: "left", minWidth: 0 }}>
                        <Avatar size="sm" name={q.customerName} customer />
                        <BlockStack gap="0">
                          <Text variant="bodySm" fontWeight="semibold" as="span" truncate>{q.customerName}</Text>
                          <Text variant="bodyXs" tone="subdued" as="span">{formatQuoteNumber(q)}</Text>
                        </BlockStack>
                      </div>

                      {/* Product — desktop only */}
                      {!isMobile && (
                        <div style={{ overflow: "hidden", display: "flex", alignItems: "center" }}>
                          <Text variant="bodySm" tone="subdued" as="p" truncate>{q.productTitle || labels.recentQuotes.missingValuePlaceholder}</Text>
                        </div>
                      )}

                      {/* Status */}
                      <div style={{ display: "flex", alignItems: "center" }}>
                        <Badge tone={sb.tone} size="small">{sb.label}</Badge>
                      </div>

                      {/* Date — desktop only */}
                      {!isMobile && (
                        <div style={{ display: "flex", alignItems: "center" }}>
                          <Text variant="bodyXs" tone="subdued" as="p">{formatDate(q.createdAt)}</Text>
                        </div>
                      )}

                      {/* Chevron */}
                      <div style={{ display: "flex", alignItems: "center" }}>
                        <Icon source={ChevronRightIcon} tone="subdued" />
                      </div>
                    </div>
                  </Box>
                  {i < recent.length - 1 && <Divider />}
                </div>
              );
            })}
          </>
        )}
      </ColorCard>

      {/* ── Bottom row: Top Products + Summary ── */}
      <InlineGrid columns={isMobile ? 1 : ["twoThirds", "oneThird"]} gap="400" alignItems="start">

        {/* Top Products */}
        <ColorCard background={cardBackgroundColor}>
          <Box paddingInline="500" paddingBlock="400">
            <Text variant="headingMd" fontWeight="semibold" as="h2">{labels.topProducts.heading}</Text>
          </Box>
          <Divider />
          {topProducts.length === 0 ? (
            <Box paddingBlock="600" paddingInline="500">
              <Text variant="bodySm" tone="subdued" as="p">{labels.topProducts.emptyText}</Text>
            </Box>
          ) : (
            topProducts.map((p, i) => (
              <div key={i}>
                <Box paddingInline="500" paddingBlock="300">
                  <InlineStack align="space-between" blockAlign="center">
                    <Text variant="bodySm" as="p" truncate>{p.title || labels.recentQuotes.missingValuePlaceholder}</Text>
                    <Badge tone="info">{String(p.count)}</Badge>
                  </InlineStack>
                </Box>
                {i < topProducts.length - 1 && <Divider />}
              </div>
            ))
          )}
        </ColorCard>

        {/* Summary stats */}
        <ColorCard background={cardBackgroundColor} padding="400">
          <BlockStack gap="300">
            <Text variant="headingMd" fontWeight="semibold" as="h2">{labels.summary.heading}</Text>
            <Divider />
            {[
              { label: labels.summary.unread,          value: String(stats.unread)           },
              { label: labels.summary.replied,         value: String(stats.replied)          },
              { label: labels.summary.conversionRate,  value: `${stats.conversionRate}%`     },
              { label: labels.summary.acceptedRevenue, value: fmt(stats.revenue)             },
            ].map(({ label, value }) => (
              <InlineStack key={label} align="space-between" blockAlign="center">
                <Text variant="bodySm" tone="subdued" as="p">{label}</Text>
                <Text variant="bodySm" fontWeight="semibold" as="p">{value}</Text>
              </InlineStack>
            ))}
          </BlockStack>
        </ColorCard>

      </InlineGrid>

        </BlockStack>
        <Box paddingBlockEnd="800" />
      </Box>
    </Page>
  );
}

export function ErrorBoundary() { return boundary.error(useRouteError()); }
export const headers = (headersArgs) => boundary.headers(headersArgs);

export { loader } from "../domain/analytics/analytics.server";

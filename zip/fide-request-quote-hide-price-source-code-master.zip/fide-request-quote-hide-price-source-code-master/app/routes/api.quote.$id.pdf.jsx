/**
 * Public, token-protected PDF download for a single quote.
 *   GET /api/quote/:id/pdf?token=<hmac>
 *
 * Linked from the buyer confirmation email. The token is a per-quote HMAC
 * (see domain/pdf/pdfToken.server) so the customer — who is not logged into the
 * app — can download only their own quote. Branding/rendering is delegated to
 * domain/pdf/pdf.server.jsx.
 */
import prisma from "../db.server";
import { verifyQuoteToken } from "../domain/pdf/pdfToken.server";
import { renderQuotePdfBuffer } from "../domain/pdf/pdf.server";

export const loader = async ({ request, params }) => {
  const { id } = params;
  const token = new URL(request.url).searchParams.get("token");

  if (!verifyQuoteToken(id, token)) {
    return new Response("Forbidden", { status: 403 });
  }

  const quote = await prisma.quote.findUnique({ where: { id } }).catch(() => null);
  if (!quote) {
    return new Response("Not found", { status: 404 });
  }

  try {
    const { buffer, filename } = await renderQuotePdfBuffer(quote);
    return new Response(buffer, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="${filename}"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (err) {
    console.error("[api.quote.pdf] render error:", err.message);
    return new Response("Could not generate PDF", { status: 500 });
  }
};

export { loader, action } from "../domain/shop/shopConfig.server";

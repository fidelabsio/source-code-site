export { action } from "../domain/webhooks/appUninstalled.server";

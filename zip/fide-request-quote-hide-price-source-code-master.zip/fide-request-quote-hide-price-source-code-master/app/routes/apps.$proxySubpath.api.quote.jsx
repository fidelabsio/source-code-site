/**
 * App Proxy alias route — /apps/{subpath}/api/quote
 *
 * In production, Shopify strips the "/apps/{subpath}" prefix and forwards
 * "/api/quote" to the app (see ./api.quote.jsx). Under `shopify app dev`, the
 * CLI forwards the FULL, un-stripped path "/apps/{subpath}/api/quote", which
 * would otherwise 404 and surface as Shopify's "third-party application"
 * error page on the storefront. `$proxySubpath` is a wildcard segment so this
 * alias keeps working no matter what `[app_proxy].subpath` is set to in
 * shopify.app*.toml (or app/config/app-proxy.json) — nothing here needs to
 * change when that value changes. Delegates to the same loader/action in
 * both environments.
 */
export { loader, action } from "../domain/quotes/storefrontQuote.server";

export { action } from "../domain/webhooks/customersDataRequest.server";

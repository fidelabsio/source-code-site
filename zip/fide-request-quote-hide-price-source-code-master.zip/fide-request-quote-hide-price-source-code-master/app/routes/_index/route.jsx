import { redirect, useLoaderData } from "react-router";
import styles from "./styles.module.css";
import { APP_NAME } from "../../core/branding.server";

export const loader = async ({ request }) => {
  const url = new URL(request.url);
  if (url.searchParams.get("shop")) {
    throw redirect(`/app?${url.searchParams.toString()}`);
  }
  return { appName: APP_NAME };
};

export const meta = ({ data }) => [
  { title: `${data?.appName ?? "Quote Request"} — B2B Quoting for Shopify` },
];

export default function App() {
  const { appName } = useLoaderData();

  return (
    <div className={styles.index}>
      <div className={styles.content}>
        <h1 className={styles.heading}>{appName} — B2B Quoting for Shopify</h1>
        <p className={styles.text}>
          Let customers request a quote on any product. Manage, price, and reply
          from one dashboard — no spreadsheets needed.
        </p>
        <p className={styles.text}>
          Install the app from the{" "}
          <a
            href="https://apps.shopify.com"
            target="_blank"
            rel="noreferrer"
          >
            Shopify App Store
          </a>
          .
        </p>
        <ul className={styles.list}>
          <li>
            <strong>Quote button on any product.</strong> Add a &ldquo;Request a
            Quote&rdquo; button to specific products, collections, or your whole
            store — no code required.
          </li>
          <li>
            <strong>Custom quote forms.</strong> Drag-and-drop form builder lets
            you capture exactly the fields your sales team needs.
          </li>
          <li>
            <strong>One-click draft orders.</strong> Accept a quote and Shopify
            creates a draft order automatically — ready to invoice or pay online.
          </li>
        </ul>
      </div>
    </div>
  );
}

import { useState, useEffect } from "react";
import { useIsMobile } from "../hooks/useIsMobile";
import { useParams, useLoaderData, useFetcher, useRouteError, useNavigate } from "react-router";
import { useAppBridge } from "@shopify/app-bridge-react";
import {
  Card,
  Text,
  BlockStack,
  InlineGrid,
  InlineStack,
  TextField,
  RadioButton,
  Divider,
  Banner,
} from "@shopify/polaris";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { useTemplateDirtyState } from "../hooks/useTemplateDirtyState";
import { TemplateEditorShell } from "../components/template-editor/TemplateEditorShell";
import { TemplateVariablesCard } from "../components/template-editor/TemplateVariablesCard";

export { loader, action } from "../domain/pdf/pdfTemplateEditor.server";

// Blank seed values for fields with no sensible default copy — not UI text,
// so these stay as code rather than living in text-labels.json.
const BLANK_TEMPLATE_DEFAULTS = {
  companyName: "", companyLogo: "", companyAddress: "", companyPhone: "", companyEmail: "",
  primaryColor: "#2c6ecb",
};

/* eslint-disable react/prop-types -- presentational preview, not worth a PropTypes dependency (covers the labels object's nested field accesses below too) */
function PdfPreview({ documentTitle, companyName, companyAddress, companyEmail, companyPhone, headerNote, footerNote, primaryColor, isInvoice, labels }) {
  const color = primaryColor || "#2c6ecb";
  return (
    <div style={{
      border: "1px solid #e1e3e5",
      borderRadius: 8,
      background: "#fff",
      overflow: "hidden",
      fontFamily: "sans-serif",
      fontSize: 13,
    }}>
      {/* PDF header bar */}
      <div style={{ background: color, height: 6 }} />

      <div style={{ padding: "24px 28px" }}>
        {/* Company header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
          <div>
            <div style={{ width: 60, height: 24, borderRadius: 4, background: "#e4e5e7", marginBottom: 8 }} />
            <Text variant="bodyMd" as="p" fontWeight="semibold">{companyName || labels.companyNameFallback}</Text>
            <Text variant="bodySm" tone="subdued" as="p">{companyAddress || labels.companyAddressFallback}</Text>
            {companyPhone && <Text variant="bodySm" tone="subdued" as="p">{companyPhone}</Text>}
            {companyEmail && <Text variant="bodySm" tone="subdued" as="p">{companyEmail}</Text>}
          </div>
          <div style={{ textAlign: "right" }}>
            <Text variant="headingLg" as="h2" fontWeight="bold">{documentTitle || (isInvoice ? labels.documentTitleFallbackInvoice : labels.documentTitleFallbackQuote)}</Text>
            <Text variant="bodySm" tone="subdued" as="p">{labels.datePrefix} {new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</Text>
            {isInvoice && <Text variant="bodySm" tone="subdued" as="p">{labels.duePrefix} {new Date(Date.now() + 14 * 86400000).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</Text>}
          </div>
        </div>

        <Divider />

        {/* Header note */}
        {headerNote && (
          <div style={{ margin: "12px 0", padding: "10px 12px", background: `${color}10`, borderLeft: `3px solid ${color}`, borderRadius: 4 }}>
            <Text variant="bodySm" as="p">{headerNote}</Text>
          </div>
        )}

        {/* Bill to */}
        <div style={{ marginBottom: 16 }}>
          <Text variant="bodySm" fontWeight="semibold" as="p" tone="subdued">{labels.billToLabel}</Text>
          <Text variant="bodyMd" as="p">{"{customer_name}"}</Text>
          <Text variant="bodySm" tone="subdued" as="p">{"{customer_email}"}</Text>
          {isInvoice && <Text variant="bodySm" tone="subdued" as="p">{"{customer_address}"}</Text>}
        </div>

        {/* Line items table */}
        <div style={{ border: "1px solid #e1e3e5", borderRadius: 6, overflow: "hidden", marginBottom: 16 }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr auto auto", background: color, padding: "8px 12px", gap: 16 }}>
            <Text variant="bodySm" fontWeight="semibold" as="p" tone="magic">{labels.columnDescription}</Text>
            <Text variant="bodySm" fontWeight="semibold" as="p" tone="magic">{labels.columnQty}</Text>
            <Text variant="bodySm" fontWeight="semibold" as="p" tone="magic">{labels.columnPrice}</Text>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr auto auto", padding: "10px 12px", gap: 16 }}>
            <Text variant="bodySm" as="p">{"{product_title}"}</Text>
            <Text variant="bodySm" as="p">{isInvoice ? "{quantity}" : "{quantity}"}</Text>
            <Text variant="bodySm" as="p">{isInvoice ? "{subtotal}" : "{offer_price}"}</Text>
          </div>
          {isInvoice && (
            <>
              <Divider />
              <div style={{ padding: "8px 12px", display: "flex", justifyContent: "flex-end", gap: 32 }}>
                <div style={{ textAlign: "right" }}>
                  <Text variant="bodySm" tone="subdued" as="p">{labels.subtotalPrefix} {"{subtotal}"}</Text>
                  <Text variant="bodySm" tone="subdued" as="p">{labels.taxPrefix} {"{tax}"}</Text>
                  <Text variant="bodyMd" fontWeight="bold" as="p">{labels.totalPrefix} {"{total}"}</Text>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Footer note */}
        {footerNote && (
          <div style={{ borderTop: "1px solid #e1e3e5", paddingTop: 12, marginTop: 4 }}>
            <Text variant="bodySm" tone="subdued" as="p">{footerNote}</Text>
          </div>
        )}
      </div>

      {/* PDF footer bar */}
      <div style={{ background: color, height: 4 }} />
    </div>
  );
}
/* eslint-enable react/prop-types */

export default function PdfEditPage() {
  const { id } = useParams();
  const { saved, labels } = useLoaderData();
  const fetcher   = useFetcher();
  const shopify   = useAppBridge();
  const isMobile  = useIsMobile();
  const navigate  = useNavigate();
  const isInvoice = id === "invoice";
  const config    = { ...BLANK_TEMPLATE_DEFAULTS, ...(isInvoice ? labels.invoiceTemplate : labels.quoteTemplate) };
  const p         = labels.page;

  const savedBody = (() => {
    try { return saved ? JSON.parse(saved.htmlBody) : null; } catch { return null; }
  })();

  const [status,        setStatus]        = useState(savedBody?.status         ?? "enabled");
  const [documentTitle, setDocumentTitle] = useState(saved?.subject            ?? config.documentTitleDefault);
  const [companyName,   setCompanyName]   = useState(savedBody?.companyName    ?? config.companyName);
  const [companyLogo,   setCompanyLogo]   = useState(savedBody?.companyLogo    ?? config.companyLogo);
  const [companyAddress,setCompanyAddress]= useState(savedBody?.companyAddress ?? config.companyAddress);
  const [companyPhone,  setCompanyPhone]  = useState(savedBody?.companyPhone   ?? config.companyPhone);
  const [companyEmail,  setCompanyEmail]  = useState(savedBody?.companyEmail   ?? config.companyEmail);
  const [headerNote,    setHeaderNote]    = useState(savedBody?.headerNote     ?? config.headerNoteDefault);
  const [footerNote,    setFooterNote]    = useState(savedBody?.footerNote     ?? config.footerNoteDefault);
  const [primaryColor,  setPrimaryColor]  = useState(savedBody?.primaryColor   ?? config.primaryColor);

  const isSaving = fetcher.state !== "idle";
  const saved_ok = fetcher.data?.success;

  // Single source of truth for the current form values — reused for dirty
  // tracking, the save payload, and (via SETTERS below) discard.
  const currentValues = { documentTitle, companyName, companyLogo, companyAddress, companyPhone, companyEmail, headerNote, footerNote, primaryColor, status };
  const SETTERS = { documentTitle: setDocumentTitle, companyName: setCompanyName, companyLogo: setCompanyLogo, companyAddress: setCompanyAddress, companyPhone: setCompanyPhone, companyEmail: setCompanyEmail, headerNote: setHeaderNote, footerNote: setFooterNote, primaryColor: setPrimaryColor, status: setStatus };

  const { markClean, getBaseline } = useTemplateDirtyState(currentValues, "pdf-save-bar");

  useEffect(() => {
    if (fetcher.data?.success && fetcher.state === "idle") {
      shopify.toast.show(p.savedToast);
      markClean();
    }
  }, [fetcher.data, fetcher.state]);

  const handleDiscard = () => {
    const base = getBaseline();
    if (!base) return;
    Object.entries(SETTERS).forEach(([field, set]) => set(base[field]));
  };

  const handleSave = () => {
    fetcher.submit(currentValues, { method: "post" });
  };

  return (
    <TemplateEditorShell
      title={config.title}
      subtitle={config.description}
      onBack={() => navigate("/app/settings?tab=pdf")}
      saveBarId="pdf-save-bar"
      isSaving={isSaving}
      onSave={handleSave}
      onDiscard={handleDiscard}
      isMobile={isMobile}
      previewStickyTop={76}
      wrapInBlockStack
      successBanner={saved_ok && <Banner tone="success">{p.savedBanner}</Banner>}
      leftPanel={
        <>
          {/* Status */}
          <Card>
            <BlockStack gap="300">
              <Text variant="headingSm" as="h3" fontWeight="semibold">{p.statusHeading}</Text>
              <RadioButton
                label={p.enabledLabel}
                checked={status === "enabled"}
                id={`${id}-enabled`}
                name={`${id}-status`}
                onChange={() => setStatus("enabled")}
              />
              <RadioButton
                label={p.disabledLabel}
                checked={status === "disabled"}
                id={`${id}-disabled`}
                name={`${id}-status`}
                onChange={() => setStatus("disabled")}
              />
            </BlockStack>
          </Card>

          {/* Document settings */}
          <Card>
            <BlockStack gap="300">
              <Text variant="headingSm" as="h3" fontWeight="semibold">{p.documentSettingsHeading}</Text>
              <TextField
                label={p.documentTitleLabel}
                value={documentTitle}
                onChange={setDocumentTitle}
                autoComplete="off"
                helpText={p.documentTitleHelpText}
              />
              <InlineStack gap="200" blockAlign="end">
                <div style={{ flex: 1 }}>
                  <TextField
                    label={p.accentColorLabel}
                    value={primaryColor}
                    onChange={setPrimaryColor}
                    autoComplete="off"
                    placeholder={p.accentColorPlaceholder}
                  />
                </div>
                <div style={{
                  width: 36,
                  height: 36,
                  borderRadius: 6,
                  background: primaryColor || "#2c6ecb",
                  border: "1px solid #e1e3e5",
                  flexShrink: 0,
                }} />
              </InlineStack>
            </BlockStack>
          </Card>

          {/* Company Info */}
          <Card>
            <BlockStack gap="300">
              <Text variant="headingSm" as="h3" fontWeight="semibold">{p.companyInfoHeading}</Text>
              <TextField
                label={p.companyNameLabel}
                value={companyName}
                onChange={setCompanyName}
                placeholder={p.companyNamePlaceholder}
                autoComplete="off"
              />
              <TextField
                label={p.logoUrlLabel}
                value={companyLogo}
                onChange={setCompanyLogo}
                placeholder={p.logoUrlPlaceholder}
                autoComplete="off"
                helpText={p.logoUrlHelpText}
              />
              <TextField
                label={p.addressLabel}
                value={companyAddress}
                onChange={setCompanyAddress}
                placeholder={p.addressPlaceholder}
                multiline={2}
                autoComplete="off"
              />
              <InlineGrid columns="1fr 1fr" gap="300">
                <TextField
                  label={p.phoneLabel}
                  value={companyPhone}
                  onChange={setCompanyPhone}
                  placeholder={p.phonePlaceholder}
                  autoComplete="off"
                />
                <TextField
                  label={p.emailLabel}
                  value={companyEmail}
                  onChange={setCompanyEmail}
                  placeholder={p.emailPlaceholder}
                  type="email"
                  autoComplete="off"
                />
              </InlineGrid>
            </BlockStack>
          </Card>

          {/* Content */}
          <Card>
            <BlockStack gap="300">
              <Text variant="headingSm" as="h3" fontWeight="semibold">{p.contentHeading}</Text>
              <TextField
                label={p.headerNoteLabel}
                value={headerNote}
                onChange={setHeaderNote}
                multiline={3}
                autoComplete="off"
                helpText={p.headerNoteHelpText}
              />
              <TextField
                label={p.footerNoteLabel}
                value={footerNote}
                onChange={setFooterNote}
                multiline={3}
                autoComplete="off"
                helpText={p.footerNoteHelpText}
              />
            </BlockStack>
          </Card>

          <TemplateVariablesCard variables={config.variables} />
        </>
      }
      preview={
        <Card>
          <BlockStack gap="400">
            <Text variant="headingSm" as="h3" fontWeight="semibold">{p.previewHeading}</Text>
            <PdfPreview
              documentTitle={documentTitle}
              companyName={companyName}
              companyAddress={companyAddress}
              companyEmail={companyEmail}
              companyPhone={companyPhone}
              headerNote={headerNote}
              footerNote={footerNote}
              primaryColor={primaryColor}
              isInvoice={isInvoice}
              labels={labels.preview}
            />
          </BlockStack>
        </Card>
      }
    />
  );
}

export function ErrorBoundary() { return boundary.error(useRouteError()); }
export const headers = (headersArgs) => boundary.headers(headersArgs);

import { useShopSettingsPage } from "../hooks/shop/useShopSettingsPage";
import { Link, useRouteError } from "react-router";
import {
  Page,
  Card,
  Text,
  BlockStack,
  InlineStack,
  Box,
  Icon,
  Divider,
  InlineGrid,
  Avatar,
  ButtonGroup,
  Button,
  TextField,
  Badge,
  Select,
} from "@shopify/polaris";
import { EmailIcon, ReceiptIcon, LockIcon, GlobeIcon } from "@shopify/polaris-icons";
import { boundary } from "@shopify/shopify-app-react-router/server";

export { loader, action } from "../domain/shop/shopSettings.server";

// Ordered ids only — title/description/copy come from emailLabels/pdfLabels
// (text-labels.json), the same source the email/PDF editors read, so this
// list carries no duplicated copy of its own.
const EMAIL_TEMPLATE_IDS = ["notification", "auto-response", "accept-quote", "reject-quote"];
const PDF_TEMPLATE_IDS = ["quote", "invoice"];

function getSmtpProviders(smtpLabels) {
  return [
    { label: smtpLabels.providerAppDefault, value: "app_default" },
    { label: smtpLabels.providerGmail, value: "gmail" },
    { label: smtpLabels.providerElasticEmail, value: "elastic_email" },
  ];
}

// Fields each provider requires. key maps to smtp state.
function getProviderFields(smtpLabels) {
  return {
    app_default: [],
    gmail: [
      { key: "username", label: smtpLabels.gmailUsernameLabel, placeholder: smtpLabels.gmailUsernamePlaceholder, type: "email", helpText: smtpLabels.gmailUsernameHelpText },
      { key: "password", label: smtpLabels.gmailPasswordLabel, placeholder: smtpLabels.passwordPlaceholder, type: "password", helpText: smtpLabels.gmailPasswordHelpText },
    ],
    elastic_email: [
      { key: "username", label: smtpLabels.elasticUsernameLabel, placeholder: smtpLabels.elasticUsernamePlaceholder, type: "email", helpText: smtpLabels.elasticUsernameHelpText },
      { key: "password", label: smtpLabels.elasticPasswordLabel, placeholder: smtpLabels.passwordPlaceholder, type: "password", helpText: smtpLabels.elasticPasswordHelpText },
    ],
  };
}


/* eslint-disable react/prop-types -- presentational sections below, not worth a PropTypes dependency (covers each labels/item/smtp object's nested field accesses too) */
function SmtpSection({ smtp, onChange, onTest, testing, testToEmail, onTestToEmailChange, labels }) {
  const isDefault = smtp.provider === "app_default";
  const fields    = getProviderFields(labels)[smtp.provider] || [];

  return (
    <Card>
      <BlockStack gap="400">

        {/* Header */}
        <InlineStack align="space-between" blockAlign="center">
          <InlineStack gap="200" blockAlign="center">
            <Icon source={GlobeIcon} tone="base" />
            <BlockStack gap="0">
              <Text variant="headingMd" as="h2">{labels.heading}</Text>
              <Text variant="bodySm" tone="subdued">
                {labels.description}
              </Text>
            </BlockStack>
          </InlineStack>
          {!isDefault && <Badge tone="success">{labels.activeBadge}</Badge>}
        </InlineStack>

        <Divider />

        {/* Provider dropdown */}
        <Select
          label={labels.providerLabel}
          options={getSmtpProviders(labels)}
          value={smtp.provider}
          onChange={(v) => onChange("provider", v)}
        />

        {/* Admin notification email — always visible */}
        <TextField
          label={labels.notifyEmailLabel}
          value={smtp.notifyEmail}
          onChange={(v) => onChange("notifyEmail", v)}
          placeholder={labels.notifyEmailPlaceholder}
          type="email"
          autoComplete="off"
          helpText={labels.notifyEmailHelpText}
        />

        {/* Provider-specific fields */}
        {!isDefault && (
          <>
            <Divider />
            <BlockStack gap="300">

              {fields.map((f) => (
                <TextField
                  key={f.key}
                  label={f.label}
                  value={smtp[f.key] ?? ""}
                  onChange={(v) => onChange(f.key, v)}
                  placeholder={f.placeholder}
                  type={f.type || "text"}
                  autoComplete="off"
                  helpText={f.helpText}
                  prefix={f.type === "password" ? <Icon source={LockIcon} /> : undefined}
                />
              ))}

              {/* From Name + From Email */}
              <InlineGrid columns="1fr 1fr" gap="300">
                <TextField
                  label={labels.fromNameLabel}
                  value={smtp.fromName}
                  onChange={(v) => onChange("fromName", v)}
                  placeholder={labels.fromNamePlaceholder}
                  autoComplete="off"
                />
                <TextField
                  label={labels.fromEmailLabel}
                  value={smtp.fromEmail}
                  onChange={(v) => onChange("fromEmail", v)}
                  placeholder={labels.fromEmailPlaceholder}
                  type="email"
                  autoComplete="off"
                />
              </InlineGrid>

              {/* Test email */}
              <InlineStack align="space-between" blockAlign="end" gap="300" wrap={false}>
                <div style={{ flex: 1 }}>
                  <TextField
                    label={labels.sendTestToLabel}
                    value={testToEmail}
                    onChange={onTestToEmailChange}
                    placeholder={labels.sendTestToPlaceholder}
                    type="email"
                    autoComplete="off"
                    helpText={labels.sendTestToHelpText}
                  />
                </div>
                <div style={{ paddingBottom: 2 }}>
                  <Button
                    onClick={onTest}
                    loading={testing}
                    disabled={!testToEmail || !testToEmail.includes("@")}
                  >
                    {labels.sendTestButton}
                  </Button>
                </div>
              </InlineStack>

            </BlockStack>
          </>
        )}

      </BlockStack>
    </Card>
  );
}

function PdfRow({ item, labels }) {
  return (
    <>
      <Box paddingBlock="400" paddingInline="400">
        <InlineStack align="space-between" blockAlign="center" gap="400">
          <InlineStack gap="400" blockAlign="center">
            <div style={{
              width: "52px",
              height: "52px",
              borderRadius: "12px",
              background: "var(--p-color-bg-surface-secondary)",
              border: "1px solid var(--p-color-border)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
            }}>
              <Icon source={ReceiptIcon} tone="subdued" />
            </div>
            <BlockStack gap="100">
              <InlineStack gap="200" blockAlign="center">
                <Text variant="headingSm" as="h3" fontWeight="bold">
                  {item.title}
                </Text>
                <Badge tone="info">{labels.independentTemplateBadge}</Badge>
              </InlineStack>
              <Text variant="bodySm" tone="subdued">
                {item.description}
              </Text>
            </BlockStack>
          </InlineStack>
          <Link to={`/app/pdf-edit/${item.id}`} style={{ textDecoration: "none" }}>
            <Button>{labels.editAction}</Button>
          </Link>
        </InlineStack>
      </Box>
      <Divider />
    </>
  );
}

function EmailRow({ item, onToggle, labels }) {
  return (
    <>
      <Box paddingBlock="400" paddingInline="400">
        <InlineStack align="space-between" blockAlign="center" gap="400">
          <InlineStack gap="400" blockAlign="center">
            <div style={{
              width: "52px",
              height: "52px",
              borderRadius: "12px",
              background: "var(--p-color-bg-surface-secondary)",
              border: "1px solid var(--p-color-border)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
            }}>
              <Icon source={EmailIcon} tone="subdued" />
            </div>
            <BlockStack gap="0">
              <Text variant="headingSm" as="h3" fontWeight="bold">
                {item.title}
              </Text>
              <Text variant="bodySm" tone="subdued">
                {item.description}
              </Text>
            </BlockStack>
          </InlineStack>
          <ButtonGroup variant="segmented">
            <Button
              tone={item.enabled ? "critical" : undefined}
              onClick={() => onToggle(item.id)}
            >
              {item.enabled ? labels.turnOffAction : labels.turnOnAction}
            </Button>
            <Link to={`/app/email-edit/${item.id}`} style={{ textDecoration: "none" }}>
              <Button>{labels.editAction}</Button>
            </Link>
          </ButtonGroup>
        </InlineStack>
      </Box>
      <Divider />
    </>
  );
}
/* eslint-enable react/prop-types */

export default function EmailSettingsPage() {
  const {
    shop, appName, active, setActive, isMobile,
    testing, testToEmail, setTestToEmail,
    emailItems, smtp, emailLabels, pdfLabels,
    handleSmtpChange, handleSaveSmtp, handleDiscardSmtp, handleTestSmtp, handleToggle,
  } = useShopSettingsPage(EMAIL_TEMPLATE_IDS);

  const s = emailLabels.settingsPage;
  const pdfItems = PDF_TEMPLATE_IDS.map((id) => ({ id, ...pdfLabels.settingsPage.items[id] }));

  const renderRightContent = () => {
    if (active === "email") {
      return (
        <BlockStack gap="400">

          {/* SMTP at top */}
          <SmtpSection
            smtp={smtp}
            onChange={handleSmtpChange}
            onTest={handleTestSmtp}
            testing={testing}
            testToEmail={testToEmail}
            onTestToEmailChange={setTestToEmail}
            labels={s.smtp}
          />

          {/* Email rows below */}
          <Card padding="0">
            {emailItems.map((item) => (
              <EmailRow
                key={item.id}
                item={item}
                onToggle={handleToggle}
                labels={s}
              />
            ))}
          </Card>

        </BlockStack>
      );
    }

    if (active === "pdf") {
      const pdf = pdfLabels.settingsPage;
      return (
        <BlockStack gap="400">
          <Card>
            <BlockStack gap="200">
              <Text variant="headingMd" as="h2" fontWeight="bold">
                {pdf.heading}
              </Text>
              <Text variant="bodyMd" tone="subdued">
                {pdf.descriptionIntro} <b>{pdf.descriptionQuoteBold}</b> {pdf.descriptionQuoteRest} <b>{pdf.descriptionInvoiceBold}</b> {pdf.descriptionInvoiceRest}
              </Text>
            </BlockStack>
          </Card>
          <Card padding="0">
            {pdfItems.map((item) => (
              <PdfRow
                key={item.id}
                item={item}
                labels={pdf}
              />
            ))}
          </Card>
        </BlockStack>
      );
    }

    return null;
  };

  const navItems = [
    { id: "email", label: s.navEmailLabel, icon: EmailIcon },
    { id: "pdf",   label: s.navPdfLabel,   icon: ReceiptIcon },
  ];

  return (
    <Page title={s.pageTitle}>
      <ui-save-bar id="smtp-save-bar">
        <button variant="primary" id="smtp-save-bar-save" onClick={handleSaveSmtp}>{s.saveAction}</button>
        <button id="smtp-save-bar-discard" onClick={handleDiscardSmtp}>{s.discardAction}</button>
      </ui-save-bar>
      <InlineGrid columns={isMobile ? 1 : ["oneThird", "twoThirds"]} gap="400" alignItems="start">

        {/* Left sidebar nav */}
        <Card padding="0">
          <BlockStack gap="0">
            <Box padding="400">
              <InlineStack gap="300" blockAlign="center" align="start">
                <Avatar size="md" name={appName} initials={appName.slice(0, 1).toUpperCase()} color="highlight" />
                <BlockStack gap="0">
                  <Text variant="headingSm" as="h2" fontWeight="bold">
                    {appName}
                  </Text>
                  <Text variant="bodySm" tone="subdued">
                    {shop}
                  </Text>
                </BlockStack>
              </InlineStack>
            </Box>

            <Divider />

            <div style={{ padding: "8px" }}>
              {navItems.map((item) => {
                const isActive = active === item.id;
                return (
                  <div
                    key={item.id}
                    onClick={() => setActive(item.id)}
                    style={{
                      cursor: "pointer",
                      borderRadius: "var(--p-border-radius-200)",
                      background: isActive
                        ? "var(--p-color-bg-surface-selected)"
                        : "transparent",
                      padding: "10px 12px",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "flex-start",
                      gap: "12px",
                      width: "100%",
                      boxSizing: "border-box",
                      marginBottom: "2px",
                    }}
                  >
                    <span style={{
                      display: "flex",
                      alignItems: "center",
                      flexShrink: 0,
                    }}>
                      <Icon
                        source={item.icon}
                        tone={isActive ? "base" : "subdued"}
                      />
                    </span>
                    <Text
                      variant="bodyMd"
                      fontWeight={isActive ? "semibold" : "regular"}
                      tone={isActive ? undefined : "subdued"}
                    >
                      {item.label}
                    </Text>
                  </div>
                );
              })}
            </div>
          </BlockStack>
        </Card>

        {/* Right content */}
        {renderRightContent()}

      </InlineGrid>
      <Box paddingBlockEnd="1600" />
    </Page>
  );
}

export const headers = (headersArgs) => boundary.headers(headersArgs);
export function ErrorBoundary() { return boundary.error(useRouteError()); }

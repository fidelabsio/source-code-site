-- CreateTable
CREATE TABLE "Session" (
    "id" TEXT NOT NULL,
    "shop" TEXT NOT NULL,
    "state" TEXT NOT NULL,
    "isOnline" BOOLEAN NOT NULL DEFAULT false,
    "scope" TEXT,
    "expires" TIMESTAMP(3),
    "accessToken" TEXT NOT NULL,
    "userId" BIGINT,
    "firstName" TEXT,
    "lastName" TEXT,
    "email" TEXT,
    "accountOwner" BOOLEAN NOT NULL DEFAULT false,
    "locale" TEXT,
    "collaborator" BOOLEAN DEFAULT false,
    "emailVerified" BOOLEAN DEFAULT false,
    "refreshToken" TEXT,
    "refreshTokenExpires" TIMESTAMP(3),

    CONSTRAINT "Session_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Quote" (
    "id" TEXT NOT NULL,
    "shop" TEXT NOT NULL,
    "quoteNumber" INTEGER,
    "productTitle" TEXT NOT NULL,
    "productId" TEXT,
    "customerName" TEXT NOT NULL,
    "customerEmail" TEXT NOT NULL,
    "customerPhone" TEXT,
    "companyName" TEXT,
    "quantity" TEXT,
    "message" TEXT,
    "formData" TEXT,
    "status" TEXT NOT NULL DEFAULT 'new',
    "pipelineStatus" TEXT NOT NULL DEFAULT 'new',
    "quoteStatus" TEXT NOT NULL DEFAULT 'new',
    "quotedPrice" DOUBLE PRECISION,
    "quotedCurrency" TEXT DEFAULT 'INR',
    "discount" DOUBLE PRECISION DEFAULT 0,
    "shipping" DOUBLE PRECISION DEFAULT 0,
    "tax" DOUBLE PRECISION DEFAULT 0,
    "merchantReply" TEXT,
    "replyHistory" TEXT,
    "tags" TEXT,
    "internalNotes" TEXT,
    "notesHistory" TEXT,
    "followUpSentAt" TIMESTAMP(3),
    "merchantAlerted" TIMESTAMP(3),
    "expiresAt" TIMESTAMP(3),
    "checkoutLink" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Quote_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "QuoteConfig" (
    "id" TEXT NOT NULL,
    "shop" TEXT NOT NULL,
    "targetMode" TEXT NOT NULL DEFAULT 'all',
    "conditionMatch" TEXT NOT NULL DEFAULT 'all',
    "hidePriceMode" TEXT NOT NULL DEFAULT 'none',
    "hidePriceCondMatch" TEXT NOT NULL DEFAULT 'all',
    "hideAddToCart" BOOLEAN NOT NULL DEFAULT false,
    "hideBuyNow" BOOLEAN NOT NULL DEFAULT false,
    "hideForGuestsOnly" BOOLEAN NOT NULL DEFAULT false,
    "addToQuoteBehaviour" TEXT NOT NULL DEFAULT 'popup_and_form',
    "showOnProductPage" BOOLEAN NOT NULL DEFAULT true,
    "showOnProductList" BOOLEAN NOT NULL DEFAULT false,
    "productPageDisplay" TEXT NOT NULL DEFAULT 'button_only',
    "buttonPosition" TEXT NOT NULL DEFAULT 'below_atc',
    "showVariantsSelector" BOOLEAN NOT NULL DEFAULT false,
    "requireLogin" BOOLEAN NOT NULL DEFAULT false,
    "allowPriceEdit" BOOLEAN NOT NULL DEFAULT false,
    "addCartToQuote" BOOLEAN NOT NULL DEFAULT false,
    "buttonText" TEXT NOT NULL DEFAULT 'Request a Quote',
    "buttonBgColor" TEXT NOT NULL DEFAULT '#1a1a18',
    "buttonTextColor" TEXT NOT NULL DEFAULT '#ffffff',
    "buttonFontSize" INTEGER NOT NULL DEFAULT 14,
    "buttonBorderRadius" INTEGER NOT NULL DEFAULT 6,
    "buttonFullWidth" BOOLEAN NOT NULL DEFAULT true,
    "hidePriceReplacement" TEXT NOT NULL DEFAULT 'text',
    "replacementText" TEXT NOT NULL DEFAULT 'Price available on request',
    "replacementTextColor" TEXT NOT NULL DEFAULT '#b4b2a9',
    "modalTitle" TEXT NOT NULL DEFAULT 'Request a Quote',
    "submitButtonText" TEXT NOT NULL DEFAULT 'Send Quote Request',
    "successMessage" TEXT NOT NULL DEFAULT 'Thank you! We will be in touch within 24 hours.',
    "showProductImageInModal" BOOLEAN NOT NULL DEFAULT true,
    "showStepIndicator" BOOLEAN NOT NULL DEFAULT true,
    "showTrustSignals" BOOLEAN NOT NULL DEFAULT true,
    "trustSignal1" TEXT NOT NULL DEFAULT 'Your information is kept private',
    "trustSignal2" TEXT NOT NULL DEFAULT 'We reply within 24 hours',
    "redirectAfterAdd" TEXT,
    "redirectAfterSubmit" TEXT,
    "redirectContinueShopping" TEXT NOT NULL DEFAULT '/',
    "excludedUrls" TEXT,
    "requiredTags" TEXT,
    "notifyEmail" TEXT,
    "targetCollections" TEXT,
    "showOnHomepage" BOOLEAN NOT NULL DEFAULT false,
    "hidePriceOnProductPage" BOOLEAN NOT NULL DEFAULT false,
    "hidePriceOnCollectionPage" BOOLEAN NOT NULL DEFAULT false,
    "hidePriceOnHomePage" BOOLEAN NOT NULL DEFAULT false,
    "hidePriceOnCartPage" BOOLEAN NOT NULL DEFAULT false,
    "hidePriceOnly" BOOLEAN NOT NULL DEFAULT false,
    "hidePriceCollections" TEXT,
    "showVendorInForm" BOOLEAN NOT NULL DEFAULT false,
    "showSkuInForm" BOOLEAN NOT NULL DEFAULT false,
    "showOptionInForm" BOOLEAN NOT NULL DEFAULT false,
    "showPriceInForm" BOOLEAN NOT NULL DEFAULT false,
    "showQuotePriceInForm" BOOLEAN NOT NULL DEFAULT false,
    "showNoteInForm" BOOLEAN NOT NULL DEFAULT false,
    "shopCurrency" TEXT NOT NULL DEFAULT 'USD',
    "formBtnBgColor" TEXT NOT NULL DEFAULT '#1a1a18',
    "formBtnTextColor" TEXT NOT NULL DEFAULT '#ffffff',
    "formBtnFontSize" INTEGER NOT NULL DEFAULT 14,
    "formBtnBorderRadius" INTEGER NOT NULL DEFAULT 6,
    "widgetEnabled" BOOLEAN NOT NULL DEFAULT false,
    "widgetButtonText" TEXT NOT NULL DEFAULT 'Request a Quote',
    "widgetAction" TEXT NOT NULL DEFAULT 'popup',
    "widgetPosition" TEXT NOT NULL DEFAULT 'bottom_right',
    "widgetBgColor" TEXT NOT NULL DEFAULT '#1a1a18',
    "widgetTextColor" TEXT NOT NULL DEFAULT '#ffffff',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "QuoteConfig_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "QuoteTargetProduct" (
    "id" TEXT NOT NULL,
    "shop" TEXT NOT NULL,
    "productId" TEXT NOT NULL,
    "productTitle" TEXT NOT NULL,
    "productHandle" TEXT NOT NULL DEFAULT '',
    "productImage" TEXT NOT NULL DEFAULT '',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "QuoteTargetProduct_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "QuoteTargetCondition" (
    "id" TEXT NOT NULL,
    "shop" TEXT NOT NULL,
    "field" TEXT NOT NULL,
    "operator" TEXT NOT NULL,
    "value" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "QuoteTargetCondition_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "HidePriceProduct" (
    "id" TEXT NOT NULL,
    "shop" TEXT NOT NULL,
    "productId" TEXT NOT NULL,
    "productTitle" TEXT NOT NULL,
    "productHandle" TEXT NOT NULL DEFAULT '',

    CONSTRAINT "HidePriceProduct_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "HidePriceCondition" (
    "id" TEXT NOT NULL,
    "shop" TEXT NOT NULL,
    "field" TEXT NOT NULL,
    "operator" TEXT NOT NULL,
    "value" TEXT NOT NULL,

    CONSTRAINT "HidePriceCondition_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "FormSchema" (
    "id" TEXT NOT NULL,
    "shop" TEXT NOT NULL,
    "fields" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "FormSchema_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EmailConfig" (
    "id" TEXT NOT NULL,
    "shop" TEXT NOT NULL,
    "provider" TEXT NOT NULL DEFAULT 'app_default',
    "fromEmail" TEXT,
    "fromName" TEXT,
    "smtpHost" TEXT,
    "smtpPort" INTEGER,
    "smtpUser" TEXT,
    "smtpPassEnc" TEXT,
    "smtpSecure" BOOLEAN NOT NULL DEFAULT true,
    "apiKeyEnc" TEXT,
    "apiDomain" TEXT,
    "apiRegion" TEXT,
    "isVerified" BOOLEAN NOT NULL DEFAULT false,
    "smtpEnabled" BOOLEAN NOT NULL DEFAULT false,
    "notificationEnabled" BOOLEAN NOT NULL DEFAULT true,
    "autoResponseEnabled" BOOLEAN NOT NULL DEFAULT false,
    "acceptQuoteEnabled" BOOLEAN NOT NULL DEFAULT false,
    "rejectQuoteEnabled" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "EmailConfig_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EmailTemplate" (
    "id" TEXT NOT NULL,
    "shop" TEXT NOT NULL,
    "templateType" TEXT NOT NULL,
    "subject" TEXT NOT NULL,
    "htmlBody" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "EmailTemplate_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Settings" (
    "id" TEXT NOT NULL,
    "shop" TEXT NOT NULL,
    "planName" TEXT NOT NULL DEFAULT 'free',
    "onboardingComplete" BOOLEAN NOT NULL DEFAULT false,
    "onboardingStep" INTEGER NOT NULL DEFAULT 0,
    "quotesThisMonth" INTEGER NOT NULL DEFAULT 0,
    "quotesMonthReset" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "hidePriceEnabled" BOOLEAN NOT NULL DEFAULT false,
    "hideForGuestsOnly" BOOLEAN NOT NULL DEFAULT false,
    "notifyEmail" TEXT,
    "buttonText" TEXT NOT NULL DEFAULT 'Request a Quote',
    "buttonColor" TEXT NOT NULL DEFAULT '#1a1a18',
    "buttonTextColor" TEXT NOT NULL DEFAULT '#ffffff',
    "thankYouMessage" TEXT NOT NULL DEFAULT 'Thank you! We will be in touch within 24 hours.',
    "showPhone" BOOLEAN NOT NULL DEFAULT true,
    "showCompany" BOOLEAN NOT NULL DEFAULT true,
    "showQuantity" BOOLEAN NOT NULL DEFAULT true,
    "showMessage" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Settings_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "QuoteConfig_shop_key" ON "QuoteConfig"("shop");

-- CreateIndex
CREATE UNIQUE INDEX "QuoteTargetProduct_shop_productId_key" ON "QuoteTargetProduct"("shop", "productId");

-- CreateIndex
CREATE UNIQUE INDEX "HidePriceProduct_shop_productId_key" ON "HidePriceProduct"("shop", "productId");

-- CreateIndex
CREATE UNIQUE INDEX "FormSchema_shop_key" ON "FormSchema"("shop");

-- CreateIndex
CREATE UNIQUE INDEX "EmailConfig_shop_key" ON "EmailConfig"("shop");

-- CreateIndex
CREATE UNIQUE INDEX "EmailTemplate_shop_templateType_key" ON "EmailTemplate"("shop", "templateType");

-- CreateIndex
CREATE UNIQUE INDEX "Settings_shop_key" ON "Settings"("shop");

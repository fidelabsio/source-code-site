-- AlterTable
ALTER TABLE "Quote" ADD COLUMN "draftOrderName" TEXT;

-- AlterTable
ALTER TABLE "QuoteConfig" ADD COLUMN     "successToastEnabled" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "toastEnabled" BOOLEAN NOT NULL DEFAULT true;

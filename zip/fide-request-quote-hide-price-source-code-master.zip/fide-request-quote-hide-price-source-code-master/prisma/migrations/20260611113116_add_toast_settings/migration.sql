-- AlterTable
ALTER TABLE "QuoteConfig" ADD COLUMN     "toastBgColor" TEXT NOT NULL DEFAULT '#0f172a',
ADD COLUMN     "toastBorderColor" TEXT NOT NULL DEFAULT '#0f172a',
ADD COLUMN     "toastBorderRadius" INTEGER NOT NULL DEFAULT 40,
ADD COLUMN     "toastBorderWidth" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "toastFontSize" INTEGER NOT NULL DEFAULT 14,
ADD COLUMN     "toastMessage" TEXT NOT NULL DEFAULT 'Product added to quote cart.',
ADD COLUMN     "toastPosition" TEXT NOT NULL DEFAULT 'bottom_center',
ADD COLUMN     "toastTextColor" TEXT NOT NULL DEFAULT '#ffffff';

# Quote Request

## Project overview

A Shopify embedded app that lets merchants hide product prices behind a
"Request a Quote" flow. Customers submit a quote request from the storefront
(via a theme app extension); merchants review requests, reply with a priced
quote, and the customer can accept it to checkout, or the merchant can convert
it directly to an order. The app also generates PDF quotes/invoices and sends
email notifications at each step.

Built with [React Router](https://reactrouter.com/) (Shopify's app template),
[Polaris](https://polaris.shopify.com/) for the admin UI, and
[Prisma](https://www.prisma.io/) (PostgreSQL) for storage.

## Requirements

- Node 20+
- A Shopify Partner account and a development store
- [Shopify CLI](https://shopify.dev/docs/apps/tools/cli/getting-started)
- A PostgreSQL database (local or hosted)

## Installation

### 1. Install dependencies

```shell
npm install
```

### 2. Configure the Shopify app

Run `npm run config:link` (wraps `shopify app config link`) to connect this
codebase to your own Partner app — this populates `client_id` in
`shopify.app.toml`. Do not commit someone else's `client_id`.

## Environment setup

Copy `.env.example` to `.env` and fill in the values relevant to you:

| Variable | Required | Purpose |
|---|---|---|
| `SHOPIFY_API_KEY` / `SHOPIFY_API_SECRET` | Yes | Shopify app auth (from your Partner app) |
| `SCOPES` | Yes | Access scopes requested on install |
| `SHOPIFY_APP_URL` | Yes | Public base URL of the deployed app (used for auth redirects and PDF download links) |
| `SHOP_CUSTOM_DOMAIN` | No | Only if the embedded app is served from a custom domain |
| `DATABASE_URL` | Yes | PostgreSQL connection string |
| `ENCRYPTION_KEY` | Yes in production | 32-byte hex key used to encrypt stored SMTP passwords and sign PDF download tokens. Generate with `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`. The app refuses to start in production without it. |
| `GMAIL_USER` / `GMAIL_APP_PASSWORD` | No | App-default email sender (merchants can also configure their own SMTP per-shop in Settings) |
| `CLOUDINARY_CLOUD_NAME` / `CLOUDINARY_API_KEY` / `CLOUDINARY_API_SECRET` | No | Image uploads (e.g. PDF/company logo) |
| `FRONTEND_PORT` / `PORT` | No | Override local dev server ports |
| `TEST_SHOP_DOMAIN` / `TEST_APP_CLIENT_ID` / `TEST_APP_HOST` | Only to run `npm test` | Point Playwright at a real dev store + installed app |

## Running locally

### 1. Set up the database

```shell
npm run setup
```

Runs `prisma generate && prisma migrate deploy`. Re-run this whenever you pull
new migrations.

### 2. Start the dev server

```shell
npm run dev
```

This starts the Shopify CLI dev tunnel plus the Vite dev server. Press `p` to
open the app URL and install it on your dev store.

## Build process

```shell
npm run build
```

Produces a production build (client + SSR bundles) via `react-router build`,
output to `build/`. Serve it with:

```shell
npm start
```

which runs `react-router-serve ./build/server/index.js`.

Hosting and deployment are handled on the customer/fork side — this repo
doesn't ship any deployment-specific files or CI/CD workflow.

## Folder structure

- `app/` — the embedded admin app (routes, server logic, shared hooks/components/utils)
- `extensions/quote-request/` — the storefront theme app extension (the "Request a Quote" block/widget customers interact with)
- `prisma/` — database schema and migrations
- `tests/` — Playwright end-to-end tests against a real dev store

### `app/` folder structure

Routes stay thin — they parse the request and re-export their `loader`/`action` from `domain/`, which holds all business logic grouped by feature area. `core/` holds framework wiring that has no business meaning of its own (today just the Shopify SDK singleton). Only a handful of genuinely trivial routes (e.g. `health.jsx`) keep their loader inline instead of delegating.

| Folder / file | Purpose | Naming convention |
|---|---|---|
| `app/routes/` | React Router file-based routes — admin pages, JSON APIs, App Proxy endpoints, auth callbacks, GDPR webhooks. Each route file holds only the `clientLoader`/component/`ErrorBoundary` and re-exports its `loader`/`action` from `domain/` (e.g. `export { loader, action } from "../domain/quotes/quotesList.server"`) | Flat, dot-separated filenames matching the URL path (`app.quote-settings.jsx` → `/app/quote-settings`, `webhooks.shop.redact.jsx` → `/webhooks/shop/redact`); kebab-case for multi-word URL segments. Two routes (`auth.login/`, `_index/`) use the nested-folder convention instead, to colocate a route-specific file (`styles.module.css`) — both are valid `@react-router/fs-routes` conventions, but prefer flat files unless you need to colocate something. |
| `app/core/` | Framework/infra wiring with zero business logic | `core/<concern>/<name>.server.js`, e.g. `core/shopify/shopify.server.js` (the Shopify SDK singleton — session storage, OAuth config, `authenticate`/`login`/`registerWebhooks`). Nothing in `domain/` should need to know how this is wired, only import from it. `core/branding.server.js`/`core/appProxy.server.js` are a minor exception — thin flat readers of the two `app/config/*.json` files that aren't tied to one specific page. Every per-page theming/copy reader follows the same `core/<page>/theme.server.js` and `core/<page>/text-labels.server.js` convention as the rest of this folder, one subfolder per `app/config/<page>/` (e.g. `core/dashboard/theme.server.js` reads `config/dashboard/theme.json`) — not framework wiring, but kept here since nothing outside them should need editing either (see "Rebranding a new instance" below). |
| `app/config/` | Plain JSON config a buyer edits to rebrand this instance — no code changes | One subfolder per admin page (`dashboard/`, `quotes/`, `quote-settings/`, `pdf/`, `email/`, plus `app-shell/` for global chrome), each holding `theme.json` and/or `text-labels.json`, read by the matching `core/<page>/theme.server.js` / `core/<page>/text-labels.server.js`. The storefront widget's own colors are plain hardcoded constants in `shopConfig.server.js`, not buyer-configurable via JSON. `app-proxy.json` and `branding.json` stay flat — they aren't page-scoped. See "Rebranding a new instance" below. |
| `app/domain/` | All business logic, grouped by bounded context. This is where a route's `loader`/`action` actually lives | `domain/<area>/<name>.server.js`, one folder per feature area: `auth/` (OAuth + login), `quotes/` (CRUD, list/detail/settings pages, storefront submission, quote numbering, schema), `email/` (templates + the email template editor), `pdf/` (PDF rendering + the PDF template editor), `shop/` (per-shop config, settings, dashboard, currency cache), `analytics/`, `export/`, `upload/`, `support/` (buyer reply), `cart/`, `webhooks/` (one file per GDPR/app webhook topic). `quoteNumber.js` and `quoteSchema.js` in `domain/quotes/` have no `.server` suffix because they're isomorphic — imported from both route files (client-safe) and other domain modules (server-only). Where two routes did near-identical work (e.g. the CSV-export route and the export-dialog route), they're merged into one file with distinct named exports rather than duplicated. |
| `app/lib/` | Thin wrappers around third-party integrations — no app-specific business logic allowed here | `<vendor-or-purpose>.server.js` (`cloudinary.server.js`, `mailer.server.js`, `encrypt.server.js`). If a `domain/` module needs Cloudinary, it imports from `lib/`, never the reverse. |
| `app/components/` | Shared React components reused across routes, grouped by the feature area they belong to | `<area>/PascalCase.jsx`, e.g. `components/template-editor/StickySaveBar.jsx`. `components/common/` is reserved for components not tied to one feature area. |
| `app/hooks/` | Shared React hooks | `useThing.js`, camelCase, always prefixed `use` |
| `app/db.server.js`, `app/entry.client.jsx`, `app/entry.server.jsx`, `app/root.jsx`, `app/routes.js` | Framework entry points and app-wide singletons (Prisma client, client/server hydration entries, route manifest) | Kept at the `app/` root per React Router's own convention — these are framework wiring, not app features, so they don't belong in any of the folders above |

**A note on `clientLoader`**: React Router's `clientLoader` export runs in the browser, so it can never live in a `.server.js` file (those are stripped from the client bundle). Routes that define one (e.g. `app.quote.$id.jsx`) keep it in the route file itself, alongside the component — only `loader`/`action` move to `domain/`.

**Database**: schema and migrations live in `prisma/` (`schema.prisma`, `migrations/`), not under `app/` — this is a Prisma convention, not specific to this repo. The one Prisma client instance the rest of the app imports is `app/db.server.js`. Migration folder names are a mix of manually-numbered (`0001_init`, `0002_add_draft_order_name`) and Prisma's default `<timestamp>_<name>` auto-generated format (`20260611113116_add_toast_settings`) — this is historical (the first two predate a workflow change) and intentionally left as-is: renaming an already-applied migration folder breaks Prisma's migration-history tracking for any database that's already run it.

**Types**: this is a plain JavaScript codebase (JSDoc comments where a type is non-obvious, e.g. `app/domain/email/emailTemplates.server.js`) — there's no dedicated types folder or `.d.ts` files to organize. `react-router typegen` generates route types into `.react-router/types` at build time; that folder is gitignored and regenerated automatically, not something to hand-maintain.

## Useful commands

| Script | Purpose |
|---|---|
| `npm run dev` | Start the Shopify CLI dev tunnel + Vite dev server |
| `npm run build` | Production build (client + SSR bundles) via `react-router build` |
| `npm start` | Serve the production build (`build/server/index.js`) |
| `npm run setup` | `prisma generate && prisma migrate deploy` — run after pulling new migrations or on first setup |
| `npm run config:link` / `npm run config:use` | Link/switch this codebase's `shopify.app.toml` to a Partner app |
| `npm run lint` | ESLint across the repo (cached) |
| `npm run typecheck` | Regenerate React Router's route types, then `tsc --noEmit` (this is a JS codebase — this only typechecks the generated route types, not application code) |
| `npm test` / `npm run test:setup` / `npm run test:headed` / `npm run test:ui` | Playwright end-to-end suite (see "Running tests" below) |
| `npm run generate` / `npm run deploy` | Shopify CLI passthroughs (`shopify app generate` / `shopify app deploy`) |

## Running tests

```shell
TEST_SHOP_DOMAIN=your-store.myshopify.com TEST_APP_CLIENT_ID=your-client-id TEST_APP_HOST=your-app.fly.dev npm test
```

The suite drives the real embedded admin UI in a dev store via Playwright, so
it needs a real store + installed app to point at — see `tests/helpers.js`.
`npm run test:setup` saves a Shopify admin session for the suite to reuse;
see `tests/auth.setup.js` for one-time setup instructions.

## Gotchas / Troubleshooting

### Database tables don't exist

```
The table `main.Session` does not exist in the current database.
```

Run `npm run setup` (Prisma generate + migrate deploy).

### Navigating/redirecting breaks an embedded app

Embedded apps must maintain the user session, which can be tricky inside an
iFrame. To avoid issues:

1. Use `Link` from `react-router` or `@shopify/polaris`. Do not use `<a>`.
2. Use `redirect` returned from `authenticate.admin`. Do not use `redirect` from `react-router`.
3. Use `useSubmit` from `react-router`.

### "nbf" claim timestamp check failed

The JWT token is expired — usually a clock-sync issue. Ensure "Set time and
date automatically" is enabled on your machine.

## Rebranding a new instance

This app is sold as white-label source code. Its own product identity (as
opposed to a merchant's per-shop settings, which is a separate,
already-complete system — see below) lives in plain JSON config files under
`app/config/` — edit these, not the `.server.js` modules that read them:

| File | Controls |
|---|---|
| `app/config/branding.json` | The app's display name (`APP_NAME`) — shown in transactional-email sender/footers, the pre-install login and landing pages, dashboard onboarding copy, the Settings page sidebar, and the PDF/print-view document-title fallback. Also `EMAIL_LOGO_URL` and `EMAIL_SIGNATURE` — both optional and blank by default; when set, every transactional email (notification, confirmation, accept, reject, merchant reply, GDPR data-access) shows a logo image in its header and a signature line in its footer. |
| `app/config/app-shell/theme.json` | Global admin chrome that applies to every page, not just one: `ADMIN_BUTTON_BRAND_COLOR` (Polaris primary-button brand color), set once in the root layout (`app/routes/app.jsx`). |
| `app/config/dashboard/theme.json` + `text-labels.json` | Dashboard-only colors (setup-guide checklist checkmark, stat-card text/background, the other cards' background) and every string on that page — headings, setup-guide steps, stat labels, table columns, empty states. |
| `app/config/quotes/theme.json` + `text-labels.json` | Quotes list + Quote Detail admin pages' colors and copy. |
| `app/config/quote-settings/theme.json` | Quote Settings page's live-preview accent/success/error colors — independent of the Quotes list/Detail pages. |
| `app/config/pdf/theme.json` + `text-labels.json` | The generated quote PDF's header accent and page background, plus the PDF/Invoice Editor page's default template content (title, description, default header/footer copy, merge-variable descriptions) and its own UI copy (field labels, headings). |
| `app/config/email/theme.json` | Fixed accent colors for transactional emails only: `EMAIL_HEADER_COLOR`/`EMAIL_CTA_COLOR` (header/CTA-button background), `EMAIL_ACCEPT_COLOR`/`EMAIL_REJECT_COLOR` (accept/reject header colors), and `EMAIL_EDITOR_LINK_COLOR` (the Email Template Editor's own link color). Kept separate from the other `theme.json` files since email rendering is its own concern with its own constraints (inline styles, email-client support). |

Per-shop merchant color settings (button/widget/toast colors a merchant sets in Quote Settings) are a separate, already-complete system and aren't affected by any of the files above — only the *default* a new shop starts with comes from them.
| `extensions/quote-request/locales/en.default.json` | Default storefront widget copy (modal title, submit button text, popup prompt) — also a plain JSON file, already Shopify's own i18n/defaults mechanism for theme app extensions. Keys here stay lowercase `snake_case` — that's Shopify's own convention for this file, not this project's. |
| `public/favicon.svg` | Browser-tab icon for the standalone pre-install landing and login pages (these render outside the Shopify admin iframe, so they need their own favicon). Replace the file directly — it's referenced by path, not by config. |

Every `theme.json` uses `SCREAMING_SNAKE_CASE` keys (each color is `{ "value": "#hex", "usedIn": "..." }` — `usedIn` documents exactly which UI element that color reaches, for editing without reading the codebase). Every `text-labels.json` uses ordinary nested `camelCase` keys instead, matching how the copy is actually grouped on the page — this project's plain JSON convention has no fixed casing rule across the board, follow whichever of these two shapes matches the file you're editing.

None of these require a code change, an env var, or touching a `core/*.server.js` file — those just read the JSON and re-export it for the rest of the app to import.

**A few identifiers genuinely can't be driven by a config file**, because
Shopify CLI evaluates them as static manifests at setup time, not at
runtime:

| File | Field | Notes |
|---|---|---|
| `shopify.app.toml` | `name` | The app's display name in the Partner Dashboard and Shopify admin nav. Populated by `shopify app config link`, but the value itself is yours to change. |
| `extensions/quote-request/shopify.extension.toml` | `name` | The theme app extension's display name in the merchant's Theme Editor block picker. |
| `extensions/quote-request/blocks/quote-request.liquid` | `{% schema %}` `"name"` | Same display name, duplicated in the block schema — keep both in sync. |
| `package.json` | `name` | npm package identifier only (never published), cosmetic. |
| `README.md` | Title (`# Quote Request`) and any prose referring to the app by name | This file itself — a plain-text edit, not something a config file can drive. |

Per-shop merchant-facing customization (button text/colors, form fields,
email template content, PDF company/logo) is a separate, already-complete
system — see the Quote Settings and Email/PDF template editor pages in the
admin UI. The files above are specifically the software vendor's own
identity/defaults, not something a merchant installing the app has to touch.

**The app icon and admin navigation icons aren't config-driven at all** —
the app icon is uploaded once to the Partner Dashboard (outside this
codebase), and the sidebar/navigation icons come from Shopify's own
`@shopify/polaris-icons` set, kept as-is so the embedded admin UI stays
visually consistent with the rest of Shopify admin.

## Developer notes

### Documentation conventions

This is a plain JavaScript codebase, so types live in JSDoc comments rather
than `.d.ts` files (see "Types" above). The convention, applied across
`domain/`, `lib/`, `utils/`, `hooks/`, and `components/`:

- **Every file** that isn't trivially self-explanatory from its name starts
  with a short header comment stating what it's responsible for and which
  route(s)/component(s) consume it.
- **Every exported function** gets a JSDoc block: a one-line summary, then
  `@param`/`@returns` for anything not obvious from the signature. For a
  `loader`/`action` in `domain/`, that means documenting what URL/route
  params it reads, what `intent` values an action switches on (for
  multi-intent action handlers), and the shape of what it returns — that
  return value flows straight into the route's `useLoaderData()`/`useFetcher()`.
- Comments explain **why**, not what — the code already says what a line
  does; a comment earns its place by covering a non-obvious constraint, a
  security-sensitive detail (HTML-escaping before interpolation, signed
  tokens, PII handling in the GDPR webhooks), or a workaround for a specific
  bug/quirk.
- Existing comments are never removed or rewritten wholesale — only gaps get
  filled in.

### Custom hooks pattern

Route `.jsx` files are meant to stay thin views: all client-side state,
effects, and handlers for a page live in one custom hook under
`app/hooks/<area>/`, named to match (e.g. `app/routes/app.quotes.jsx` calls
`useQuotesList()` from `app/hooks/quotes/useQuotesList.js`). A few rules that
keep this pattern from rotting:

- The page hook calls `useLoaderData`/`useFetcher`/`useNavigate`/etc.
  internally — it takes no required params, so the route just calls it once
  and destructures what it needs.
- Hooks can (and should) call other hooks — e.g. a page hook composes
  `useTemplateDirtyState`/`useFormFieldList` rather than duplicating their logic.
- **Hook files are `.js`, not `.jsx` — they must never contain JSX.** A
  derived value that builds React elements (a `<Badge>`, styled markup, an
  `<a>` tag) is a rendering concern: keep the raw data in the hook, build the
  actual elements in the route's render body. Mixing the two back into a
  hook file breaks the JSX transform and the separation of concerns.
- Small pure helpers/constants used directly in a route's JSX (formatters,
  badge-tone lookups, tab definitions) can live as named exports alongside
  the hook in the same file, rather than forcing every trivial helper into
  `app/utils/`.

`app/utils/` holds framework-agnostic helpers with no React/route
dependency at all (currency/date formatting, HTML escaping, CSV building,
color conversion) — reach for these first before adding a one-off helper
inside a hook or component.

## Resources

Full documentation for the frameworks and platform this app is built on:

- [Shopify App React Router docs](https://shopify.dev/docs/api/shopify-app-react-router)
- [Shopify CLI](https://shopify.dev/docs/apps/tools/cli)
- [Shopify App Bridge](https://shopify.dev/docs/api/app-bridge-library)
- [Polaris Web Components](https://shopify.dev/docs/api/app-home/polaris-web-components)
- [App extensions](https://shopify.dev/docs/apps/app-extensions/list)
- [React Router](https://reactrouter.com/)
- [Prisma](https://www.prisma.io/docs)

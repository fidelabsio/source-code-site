(function () {
  "use strict";

  window.QuoteRequestApp = window.QuoteRequestApp || {};
  var app = window.QuoteRequestApp;

  // 1. Shared mutable state object
  app.state = {
    cfg: null,
    currentProduct: null,
    variants: [],
    dynamicFields: null,
    // Purchase-action race guard (see quote-request.liquid). cfgLoaded flips to
    // true once config resolves; block* are the final, gating-aware decisions
    // the capture-phase click/submit guard reads to allow or abort ATC/Buy Now.
    cfgLoaded: false,
    blockAddToCart: false,
    blockBuyNow: false
  };

  // 2. Context detection
  var pdEl = document.getElementById("qr-product-data");
  var collEl = document.getElementById("qr-collection-data");
  var homeEl = document.getElementById("qr-homepage-data");
  var cartDataEl = document.getElementById("qr-cart-data");
  var pageDataEl = document.getElementById("qr-page-data");
  var pd = pdEl ? pdEl.dataset : {};
  var _contextEl = pdEl || collEl || homeEl || cartDataEl || pageDataEl; // whichever page type is active
  var shop = (_contextEl && _contextEl.dataset.shop) || (window.Shopify && window.Shopify.shop) || window.location.hostname;
  var backdrop = document.getElementById("qr-backdrop");
  var modal = document.getElementById("qr-modal");
  var isProductPage = !!pdEl;
  var isCollectionPage = !!collEl;
  var isHomepage = !!homeEl;
  var isCartPage = !!cartDataEl;

  var customerJson = (_contextEl && _contextEl.dataset.customer) || "null";
  var _customer = null;
  var isLoggedIn = false;
  try {
    _customer = JSON.parse(decodeURIComponent(customerJson));
    isLoggedIn = _customer !== null;
  } catch (e) { }

  // Parse product variants and collection handles from Liquid JSON
  var _variants = [];
  try { _variants = JSON.parse(decodeURIComponent(pd.variants || "[]")); } catch (e) { }

  var _productCollections = []; // handles of every collection this product belongs to
  try { _productCollections = JSON.parse(decodeURIComponent(pd.collections || "[]")); } catch (e) { }

  app.context = {
    pdEl: pdEl,
    collEl: collEl,
    homeEl: homeEl,
    cartDataEl: cartDataEl,
    pageDataEl: pageDataEl,
    contextEl: _contextEl,
    shop: shop,
    backdrop: backdrop,
    modal: modal,
    isProductPage: isProductPage,
    isCollectionPage: isCollectionPage,
    isHomepage: isHomepage,
    isCartPage: isCartPage,
    customer: _customer,
    isLoggedIn: isLoggedIn,
    productCollections: _productCollections,
    pd: pd
  };

  // Set initial state
  app.state.currentProduct = pd;
  app.state.variants = _variants;

  // i18n lookup for static UI strings. The Liquid block renders each string
  // through Shopify's {{ 'key' | t }} filter into window.QR_I18N, so they follow
  // the storefront's active language. Merchant-configured text (cfg.*) is not
  // translated here. Supports {name} placeholder substitution via the vars arg.
  app.t = function (key, fallback, vars) {
    var dict = window.QR_I18N || {};
    var val = dict[key];
    if (val === undefined || val === null || val === "") val = fallback || "";
    if (vars) {
      val = val.replace(/\{(\w+)\}/g, function (m, name) {
        return vars[name] != null ? vars[name] : m;
      });
    }
    return val;
  };

  // Locale-aware storefront URL builder. On multi-language / multi-market stores
  // Shopify serves localized URLs prefixed with Shopify.routes.root (e.g.
  // "/fr-ca/"); a hardcoded leading "/" would hit the wrong locale or 404. Use
  // this for any storefront (Ajax/section/navigation) path. NOT for app-proxy
  // calls (app.proxyUrl below) — those are never locale-prefixed.
  app.storeUrl = function (path) {
    var root = (window.Shopify && window.Shopify.routes && window.Shopify.routes.root) || "/";
    if (root.charAt(root.length - 1) !== "/") root += "/";
    return root + String(path == null ? "" : path).replace(/^\/+/, "");
  };

  // Synced from shopify.app.toml's [app_proxy].subpath by
  // scripts/sync-app-proxy-subpath.js (runs via predev/prebuild/predeploy) —
  // edit the toml, not this literal. Shopify routes storefront requests to
  // /apps/{subpath}/... verbatim, so a mismatch 404s every request before it
  // reaches the app.
  app.PROXY_SUBPATH = "quote-request";

  // Builds an app-proxy API URL, e.g. app.proxyUrl("/api/quote") ->
  // "/apps/" + app.PROXY_SUBPATH + "/api/quote". Use for every /apps/... fetch call.
  app.proxyUrl = function (path) {
    return "/apps/" + app.PROXY_SUBPATH + "/" + String(path == null ? "" : path).replace(/^\/+/, "");
  };

  // 3. Lightweight Zod-inspired schema validator (no external deps)
  app.QRSchema = (function () {
    function _str() {
      var _rules = [];
      var api = {
        min: function (n, msg) { _rules.push({ t: "min", n: n, msg: msg }); return api; },
        max: function (n, msg) { _rules.push({ t: "max", n: n, msg: msg }); return api; },
        email: function (msg) { _rules.push({ t: "email", msg: msg }); return api; },
        phone: function (msg) { _rules.push({ t: "phone", msg: msg }); return api; },
        optional: function () { _rules.push({ t: "optional" }); return api; },
        _run: function (value) {
          var v = (value || "").trim();
          var isOpt = _rules.some(function (r) { return r.t === "optional"; });
          if (!v) {
            if (isOpt) return null;
            var minRule = _rules.find(function (r) { return r.t === "min" && r.n >= 1; });
            return (minRule && minRule.msg) || "This field is required";
          }
          for (var i = 0; i < _rules.length; i++) {
            var r = _rules[i];
            if (r.t === "min" && v.length < r.n) return r.msg || ("Minimum " + r.n + " characters required");
            if (r.t === "max" && v.length > r.n) return r.msg || ("Maximum " + r.n + " characters allowed");
            if (r.t === "email") {
              if (v.length > 100) return "Email must be 100 characters or less";
              if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) return r.msg || "Enter a valid email address (e.g. name@example.com)";
            }
            if (r.t === "phone") {
              var digits = v.replace(/[\s\-\(\)\.]/g, "");
              if (!/^\+?[0-9]{7,15}$/.test(digits)) return r.msg || "Enter a valid phone number (7–15 digits)";
            }
          }
          return null;
        },
      };
      return api;
    }
    function _obj(shape) {
      return {
        safeParse: function (data) {
          var errors = {};
          Object.keys(shape).forEach(function (key) {
            var err = shape[key]._run(data[key]);
            if (err) errors[key] = err;
          });
          var ok = Object.keys(errors).length === 0;
          return ok ? { success: true, data: data } : { success: false, errors: errors };
        },
      };
    }
    return { string: _str, object: _obj };
  })();

  app.getRate = function () {
    return (window.Shopify && window.Shopify.currency && typeof window.Shopify.currency.rate === 'number')
      ? window.Shopify.currency.rate
      : (window.Shopify && window.Shopify.currency && !isNaN(parseFloat(window.Shopify.currency.rate))
          ? parseFloat(window.Shopify.currency.rate)
          : 1);
  };

  app.getCurrencySymbol = function (currencyCode) {
    try {
      var formatter = new Intl.NumberFormat(undefined, { style: 'currency', currency: currencyCode });
      if (typeof formatter.formatToParts === 'function') {
        var parts = formatter.formatToParts(1);
        for (var i = 0; i < parts.length; i++) {
          if (parts[i].type === 'currency') return parts[i].value;
        }
      }
    } catch (e) {}
    var symbols = {
      USD: "$", EUR: "€", GBP: "£", INR: "₹", AUD: "A$", CAD: "C$", SGD: "S$", AED: "AED", JPY: "¥", CNY: "¥", CHF: "Fr", MXN: "MX$", BRL: "R$", ZAR: "R", SEK: "kr", NOK: "kr", DKK: "kr", NZD: "NZ$", HKD: "HK$", KRW: "₩"
    };
    return symbols[currencyCode] || currencyCode + " ";
  };

  app.formatPrice = function (price) {
    if (price == null || price === "") return "";
    var num = typeof price === 'number' ? price : parseFloat(price);
    if (isNaN(num)) return String(price);
    var currency = (window.Shopify && window.Shopify.currency && window.Shopify.currency.active)
      || (app.context.contextEl && app.context.contextEl.dataset.currency)
      || (app.state.cfg && app.state.cfg.shopCurrency)
      || "USD";
    try {
      // Use Intl for robust currency formatting (symbol, decimal places, etc.)
      return new Intl.NumberFormat(undefined, { style: 'currency', currency: currency }).format(num);
    } catch (e) {
      var symbol = app.getCurrencySymbol(currency);
      return symbol + num.toFixed(2);
    }
  };

  // Quote cart (localStorage + memory fallback)
  var QR_CART_KEY = "qr_cart";
  var _memCart = null;

  app.getQrCart = function () {
    if (_memCart) return JSON.parse(JSON.stringify(_memCart));
    try { return JSON.parse(localStorage.getItem(QR_CART_KEY) || "[]"); } catch (e) { return []; }
  };

  app.saveQrCart = function (cart) {
    _memCart = JSON.parse(JSON.stringify(cart));
    try { localStorage.setItem(QR_CART_KEY, JSON.stringify(cart)); } catch (e) { }
    if (typeof app.updateWidgetBadge === "function") app.updateWidgetBadge();
  };

  app.addToQrCart = function () {
    var p = app.state.currentProduct;
    var cart = app.getQrCart();
    var id = p.productId || "";
    var normId = id ? String(id).split("/").pop() : "";
    var existing = normId ? cart.find(function (i) { 
      return i.productId && String(i.productId).split("/").pop() === normId; 
    }) : null;

    var isMainPdpProduct = false;
    if (app.context.isProductPage && app.context.pd && app.context.pd.productId && p.productId) {
      var id1 = String(p.productId).split("/").pop();
      var id2 = String(app.context.pd.productId).split("/").pop();
      if (id1 === id2) {
        isMainPdpProduct = true;
      }
    }

    // Capture quantity from the product page input if available for main PDP product
    var qtyVal = 1;
    if (isMainPdpProduct) {
      var qtyInput = document.querySelector('form[action*="/cart"] [name="quantity"], .product-form [name="quantity"], [name="quantity"]');
      qtyVal = qtyInput ? parseInt(qtyInput.value, 10) : 1;
      if (isNaN(qtyVal) || qtyVal < 1) qtyVal = 1;
    }


    if (existing) {
      existing.quantity = (existing.quantity || 0) + qtyVal;
      // Also update variant/price if they changed on page for main PDP product
      var varInput = isMainPdpProduct ? document.querySelector('form[action*="/cart"] [name="id"], .product-form [name="id"], [name="id"]') : null;
      var selVarId = p.selectedVariantId || (varInput ? varInput.value : null);
      var selVar = selVarId ? app.state.variants.find(function (v) { return String(v.id) === String(selVarId); }) : null;
      // If no variant selected (e.g. collection page) but existing item has no variant info, fill it with first variant
      if (!selVar && (!existing.variantId || existing.variantId === "") && app.state.variants && app.state.variants.length > 0) {
        selVar = app.state.variants[0];
      }
      if (selVar) {
        existing.variantId = String(selVar.id);
        existing.variantTitle = selVar.title !== "Default Title" ? selVar.title : "";
        existing.productPrice = (selVar.price / 100).toFixed(2);
        existing.productSku = selVar.sku || "";
      }
      app.saveQrCart(cart);
    } else {
      // Capture currently-selected variant from the product form for main PDP product
      var varInput = isMainPdpProduct ? document.querySelector('form[action*="/cart"] [name="id"], .product-form [name="id"], [name="id"]') : null;
      var selVarId = p.selectedVariantId || (varInput ? varInput.value : null);
      var selVar = selVarId
        ? app.state.variants.find(function (v) { return String(v.id) === String(selVarId); })
        : (app.state.variants && app.state.variants.length === 1 ? app.state.variants[0] : null);

      cart.push({
        productId: id,
        productTitle: p.productTitle || "",
        productImage: p.productImage || "",
        productHandle: p.productHandle || "",
        productVendor: p.productVendor || "",
        productPrice: selVar ? (selVar.price / 100).toFixed(2) : ((parseFloat(p.productPrice || 0) / 100) || 0).toFixed(2),
        productSku: selVar ? (selVar.sku || "") : (p.productSku || ""),
        variantTitle: selVar && selVar.title !== "Default Title" ? selVar.title : "",
        variantId: selVar ? String(selVar.id) : "",
        quantity: qtyVal,
        shop: app.context.shop,
        addedAt: new Date().toISOString(),
      });
      app.saveQrCart(cart);
    }
    return cart;
  };

  app.evalConditions = function (conds, condMatch, src) {
    if (!conds || conds.length === 0) return true;
    var tags = (src.productTags || "").split(",").map(function (t) { return t.trim().toLowerCase(); });
    var price = parseFloat(src.productPrice || "0") / 100;
    function evalOne(c) {
      var field = c.field; var op = c.operator; var val = (c.value || "").toLowerCase(); var target = "";
      if (field === "product_type") target = (src.productType || "").toLowerCase();
      else if (field === "vendor") target = (src.productVendor || "").toLowerCase();
      else if (field === "title") target = (src.productTitle || "").toLowerCase();
      else if (field === "tag") return op === "not_equals" ? !tags.includes(val) : (op === "contains" ? tags.some(function (t) { return t.includes(val); }) : tags.includes(val));
      else if (field === "price") {
        var n = parseFloat(val) || 0;
        if (op === "greater_than") return price > n;
        if (op === "less_than") return price < n;
        if (op === "equals") return price === n;
        return false;
      }
      if (op === "equals") return target === val;
      if (op === "not_equals") return target !== val;
      if (op === "contains") return target.includes(val);
      return false;
    }
    return condMatch === "all" ? conds.every(evalOne) : conds.some(evalOne);
  };

  app.isProductTargeted = function (cfg) {
    if (cfg.targetMode === "all") return true;

    if (cfg.targetMode === "products") {
      var myId = String(app.context.pd.productId || "");
      return (cfg.targetProducts || []).some(function (p) { return String(p.productId) === myId; });
    }

    if (cfg.targetMode === "collections") {
      var allowedColls = cfg.targetCollections || [];
      // No collections configured yet → show nowhere
      if (allowedColls.length === 0) return false;
      // Check whether any of the product's collections matches an allowed one
      return allowedColls.some(function (c) {
        var ch = (c.handle || "").toLowerCase();
        return app.context.productCollections.some(function (h) {
          return h.toLowerCase() === ch;
        });
      });
    }

    if (cfg.targetMode === "conditions") {
      return app.evalConditions(cfg.targetConditions, cfg.conditionMatch === "all" ? "all" : "any", app.context.pd);
    }

    return true;
  };

  app.shouldHidePrice = function (cfg) {
    var mode = cfg.hidePriceMode || "none";
    if (mode === "none") return false;
    if (mode === "all") return true;

    var myId = String(app.context.pd.productId || "");
    var myHandle = (app.context.pd.productHandle || "").toLowerCase();

    if (mode === "specific_products") {
      return (cfg.hidePriceProducts || []).some(function (p) {
        return String(p.productId) === myId || (p.productHandle && p.productHandle.toLowerCase() === myHandle);
      });
    }

    if (mode === "specific_collections") {
      var allowedHpColls = cfg.hidePriceCollections || [];
      if (allowedHpColls.length === 0) return false;
      // Product page — check via Liquid-rendered collection handles
      if (app.context.isProductPage) {
        return allowedHpColls.some(function (c) {
          var ch = (c.handle || "").toLowerCase();
          return app.context.productCollections.some(function (h) { return h.toLowerCase() === ch; });
        });
      }
      // Collection page — check if this collection is in the allowed list
      if (app.context.isCollectionPage && app.context.collEl) {
        var myCollHandle = (app.context.collEl.dataset.collectionHandle || "").toLowerCase();
        return allowedHpColls.some(function (c) {
          return (c.handle || "").toLowerCase() === myCollHandle;
        });
      }
      return false;
    }

    if (mode === "quoted_products") {
      return (cfg.targetProducts || []).some(function (p) {
        return String(p.productId) === myId;
      });
    }

    if (mode === "conditions") {
      return app.evalConditions(cfg.targetConditions, cfg.conditionMatch === "all" ? "all" : "any", app.context.pd);
    }

    return false;
  };

  app.esc = function (s) {
    return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  };

  app.fixImgUrl = function (url) {
    if (!url) return "";
    if (url.indexOf("//") === 0) return "https:" + url;
    return url;
  };

})();

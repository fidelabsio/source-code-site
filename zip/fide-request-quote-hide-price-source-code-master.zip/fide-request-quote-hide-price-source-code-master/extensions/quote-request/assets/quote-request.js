(function () {
  "use strict";

  var app = window.QuoteRequestApp;
  var state = app.state;
  var context = app.context;

  var _CFG_CACHE_KEY = "qr_cfg_v1_" + context.shop;
  var _CFG_TTL = 5 * 1000;

  var _DISPLAY_KEYS = [
    "isEnabled", "hideAddToCart", "hideBuyNow", "hidePriceMode",
    "hidePriceOnProductPage", "hidePriceOnCollectionPage", "hidePriceOnHomePage", "hidePriceOnCartPage",
    "buttonText", "buttonBgColor", "buttonTextColor", "buttonFontSize", "buttonBorderRadius",
    "buttonPosition", "buttonFullWidth", "hidePriceReplacement", "replacementText", "replacementTextColor",
    "widgetEnabled", "widgetBgColor", "widgetTextColor", "widgetButtonText", "widgetPosition", "widgetAction",
    "showVendorInForm", "showSkuInForm", "showOptionInForm", "showPriceInForm", "showQuotePriceInForm", "showNoteInForm",
    "modalTitle", "submitButtonText", "successMessage", "showProductImageInModal", "showStepIndicator", "showTrustSignals",
    "formBtnBgColor", "formBtnTextColor", "formBtnFontSize", "formBtnBorderRadius"
  ];

  function _displaySnapshot(cfg) {
    if (!cfg) return "";
    return _DISPLAY_KEYS.map(function (k) { return k + "=" + String(cfg[k]); }).join("|");
  }

  function _reapplyChangedConfig(freshCfg) {
    if (!freshCfg || !state.cfg) return;

    var prevSnap = _displaySnapshot(state.cfg);
    state.cfg = Object.assign({}, state.cfg, freshCfg);
    var newSnap = _displaySnapshot(state.cfg);

    // Keep the purchase-action guard flags in sync with the fresh config.
    state.blockAddToCart = !!(state.cfg.isEnabled && state.cfg.hideAddToCart);
    state.blockBuyNow = !!(state.cfg.isEnabled && state.cfg.hideBuyNow);

    if (prevSnap === newSnap) return;

    app.applyColors(state.cfg);

    if (!state.cfg.isEnabled) {
      var qBtn = document.getElementById("qr-open-btn");
      if (qBtn) qBtn.parentNode.removeChild(qBtn);
      document.querySelectorAll(
        ".product-form__submit, [name='add'], .btn--add-to-cart, " +
        ".product-form__cart-submit, button[type='submit'][name='add'], " +
        "form[action*='/cart/add'] button[type='submit']"
      ).forEach(function (el) { el.style.display = ""; });
      document.querySelectorAll(
        ".shopify-payment-button, [data-shopify='payment-button']"
      ).forEach(function (el) { el.style.display = ""; });
      return;
    }

    if (context.isProductPage) {
      if (state.cfg.hideAddToCart) {
        document.querySelectorAll(
          ".product-form__submit, [name='add'], .btn--add-to-cart, " +
          ".product-form__cart-submit, button[type='submit'][name='add'], " +
          "form[action*='/cart/add'] button[type='submit']"
        ).forEach(function (el) { el.style.display = "none"; });
      } else {
        document.querySelectorAll(
          ".product-form__submit, [name='add'], .btn--add-to-cart, " +
          ".product-form__cart-submit, button[type='submit'][name='add'], " +
          "form[action*='/cart/add'] button[type='submit']"
        ).forEach(function (el) { el.style.display = ""; });
      }
      if (state.cfg.hideBuyNow) {
        document.querySelectorAll(
          ".shopify-payment-button, [data-shopify='payment-button']"
        ).forEach(function (el) { el.style.display = "none"; });
      } else {
        document.querySelectorAll(
          ".shopify-payment-button, [data-shopify='payment-button']"
        ).forEach(function (el) { el.style.display = ""; });
      }
    }

    var qBtn2 = document.getElementById("qr-open-btn");
    if (qBtn2 && state.cfg.buttonText) qBtn2.textContent = state.cfg.buttonText;

    app.applyColors(state.cfg);
    app.applyModalConfig(state.cfg);
    app.applyFieldVisibility(state.cfg);

    if (context.backdrop && (context.backdrop.style.display === "flex" || context.backdrop.style.display === "block")) {
      app._renderProductList();
    }
  }

  function fetchConfig() {
    var networkPromise = fetch(app.proxyUrl("/api/config") + "?shop=" + encodeURIComponent(context.shop))
      .then(function (res) {
        if (!res.ok) throw new Error("HTTP " + res.status);
        return res.json();
      })
      .then(function (data) {
        try {
          localStorage.setItem(_CFG_CACHE_KEY, JSON.stringify({ exp: Date.now() + _CFG_TTL, data: data }));
        } catch (e) { }
        return data;
      })
      .catch(function (err) {
        console.warn("[QuoteRequest] Could not load config:", err.message);
        return null;
      });

    var cached = null;
    try {
      cached = JSON.parse(localStorage.getItem(_CFG_CACHE_KEY) || "null");
    } catch (e) { }

    // Only serve the stored copy while it is still within its TTL (see _CFG_TTL).
    // An expired (or missing) entry falls through to the network so merchant
    // setting changes surface within seconds instead of being frozen forever.
    if (cached && cached.data && cached.exp && cached.exp > Date.now()) {
      networkPromise.then(function (freshData) {
        _reapplyChangedConfig(freshData);
      });
      return Promise.resolve(cached.data);
    }

    return networkPromise;
  }

  function init() {
    fetchConfig().then(function (cfg) {
      // Config resolved — publish authoritative purchase-action guard flags for
      // the capture-phase guard in quote-request.liquid. Default to "allow";
      // only the enabled + eligible path below re-enables blocking. This closes
      // the window where ATC/Buy Now were live before config loaded.
      state.cfgLoaded = true;
      state.blockAddToCart = false;
      state.blockBuyNow = false;

      var preHide = document.getElementById("qr-prehide");
      if (preHide) {
        preHide.parentNode.removeChild(preHide);
      }

      var btnPreHide = document.getElementById("qr-btn-prehide");
      if (btnPreHide) btnPreHide.parentNode.removeChild(btnPreHide);

      if (!cfg || !cfg.isEnabled) return;

      if (cfg.requireLogin && !context.isLoggedIn) return;

      var requiredTags = Array.isArray(cfg.requiredTags) ? cfg.requiredTags : [];
      if (requiredTags.length > 0) {
        if (!context.isLoggedIn) return;
        var custTags = (context.customer && Array.isArray(context.customer.tags)) ? context.customer.tags : [];
        var hasTag = requiredTags.some(function (rt) {
          return custTags.some(function (ct) {
            return String(ct).toLowerCase() === String(rt).toLowerCase();
          });
        });
        if (!hasTag) return;
      }

      state.cfg = cfg;
      // Enabled + eligible: honor the merchant's hide settings at the handler
      // level, so the actions are blocked even if the buttons aren't yet hidden.
      state.blockAddToCart = !!cfg.hideAddToCart;
      state.blockBuyNow = !!cfg.hideBuyNow;
      app.applyColors(state.cfg);
      app.applyModalConfig(state.cfg);

      if (!state.dynamicFields) {
        app.applyFieldVisibility(state.cfg);
      }

      app.wireNavButtons();

      // Never hide our own quote button: it borrows the theme's add-to-cart
      // class (for visual parity) and would otherwise match these selectors.
      function _isQuoteBtn(el) {
        return el.id === "qr-open-btn" ||
          (el.classList && el.classList.contains("qr-quote-btn")) ||
          !!(el.closest && el.closest("#qr-open-btn, .qr-quote-btn"));
      }
      function hideAtcBuyNow() {
        document.querySelectorAll(
          ".product-form__submit, [name='add'], .btn--add-to-cart, " +
          ".product-form__cart-submit, button[type='submit'][name='add'], " +
          "form[action*='/cart/add'] button[type='submit']"
        ).forEach(function (el) {
          if (_isQuoteBtn(el)) return;
          el.style.display = "none";
        });
      }
      function hideBuyNowBtns() {
        document.querySelectorAll(
          ".shopify-payment-button, [data-shopify='payment-button']"
        ).forEach(function (el) {
          if (_isQuoteBtn(el)) return;
          el.style.display = "none";
        });
      }

      // Cart-specific price selectors (line items, subtotals, totals, summary).
      var QR_CART_PRICE_SELECTORS = [
        ".cart__price", ".cart-item__price", ".cart__item-price",
        "[data-cart-item-price]", ".cart-item__discounted-prices",
        ".cart-item__price-wrapper",
        ".product-option",
        ".cart-item__totals", ".totals__subtotal-value", ".totals__total-value",
        ".cart-subtotal__price", "[data-cart-subtotal]", "[data-cart-total]",
        ".cart__total", ".cart-total__price", ".cart__footer .price",
        ".order-summary__emphasis", ".totals",
      ];
      // Generic price selectors — only applied WITHIN a cart drawer/popup so the
      // underlying page's own price isn't touched when only cart hiding is on.
      var QR_DRAWER_PRICE_SELECTORS = [
        ".price", ".money", "[data-product-price]", "[itemprop='price']",
        ".price__amount", ".product-price", ".price-item",
      ];
      // Cart drawer / mini-cart / add-to-cart notification containers. Themes
      // pop these up on the CURRENT page after "add to cart" (not /cart), so the
      // isCartPage branch never fires there and prices would leak.
      var QR_CART_DRAWER_SELECTORS = [
        "cart-drawer", "#CartDrawer", ".cart-drawer", ".drawer--cart", "#cart-drawer",
        ".js-cart-drawer", ".mini-cart", ".mini_cart", ".cart-popup", ".cart-modal",
        "#sidebar-cart", ".header__cart-drawer", ".ajaxcart", "[data-cart-drawer]",
        "cart-notification", "#cart-notification", ".cart-notification",
      ];

      // Hide prices inside any cart drawer/mini-cart/notification present in the
      // DOM. Scoped to the drawer container (not page-wide) so a product page's
      // price stays visible while the drawer's price is hidden. Idempotent.
      function hideCartDrawerPrices() {
        var sels = QR_CART_PRICE_SELECTORS.concat(QR_DRAWER_PRICE_SELECTORS);
        QR_CART_DRAWER_SELECTORS.forEach(function (dsel) {
          var drawers;
          try { drawers = document.querySelectorAll(dsel); } catch (e) { return; }
          drawers.forEach(function (scope) {
            sels.forEach(function (sel) {
              var nodes;
              try { nodes = scope.querySelectorAll(sel); } catch (e) { return; }
              nodes.forEach(function (el) {
                if (!el.closest("#qr-quote-page") && !el.closest("#qr-backdrop")) {
                  el.style.display = "none";
                }
              });
            });
          });
        });
      }

      // Apply all price/button hiding for the current page. Safe to call repeatedly:
      // every underlying op is idempotent (sets display:none / skips existing nodes).
      function runHiding() {
        if (context.isProductPage && cfg.hidePriceOnProductPage) {
          if (app.shouldHidePrice(cfg)) app.hidePriceElements(cfg);
        }
        if (context.isCollectionPage && cfg.hidePriceOnCollectionPage) {
          if (app.shouldHidePrice(cfg)) app.hidePriceElements(cfg);
        }
        if (context.isHomepage && cfg.hidePriceOnHomePage && cfg.hidePriceMode !== "none") {
          app.hidePriceElements(cfg);
        }
        if (cfg.hidePriceOnCartPage && cfg.hidePriceMode !== "none") {
          // Full /cart page: hide every cart price element page-wide.
          if (context.isCartPage) {
            QR_CART_PRICE_SELECTORS.forEach(function (sel) {
              document.querySelectorAll(sel).forEach(function (el) {
                if (!el.closest("#qr-quote-page")) el.style.display = "none";
              });
            });
            app.hidePriceElements(cfg);
          }
          // Cart drawer / mini-cart / add-to-cart popup on ANY page.
          hideCartDrawerPrices();
        }

        if (cfg.hideAddToCart) hideAtcBuyNow();
        if (cfg.hideBuyNow) hideBuyNowBtns();
      }

      runHiding();

      // Inject quote buttons for the current page. Idempotent (the main button is
      // guarded by its id, cards by data-qr-injected), so safe to re-run from the
      // observer when async content (recommendations, infinite scroll) appears.
      function runButtonInjection() {
        if (context.isProductPage) {
          if (app.isProductTargeted(cfg) && cfg.showOnProductPage) {
            app.injectQuoteButton(cfg);
          }
          // "You may also like" / related product cards behave like a product list.
          if (cfg.showOnProductList || cfg.targetMode === "collections") {
            app.injectCollectionButtons(cfg);
          }
        } else if (context.isCollectionPage && (cfg.showOnProductList || cfg.targetMode === "collections")) {
          app.injectCollectionButtons(cfg);
        } else if (context.isHomepage && cfg.showOnHomepage) {
          app.injectCollectionButtons(cfg);
        }
      }

      // The floating widget only belongs on the home, collection, and product
      // pages. Never inject it on cart, the quote-cart modal page, checkout,
      // account, search, or any other template — those pages have their own
      // primary actions the widget would obscure.
      var widgetPageAllowed =
        context.isHomepage || context.isCollectionPage || context.isProductPage;
      if (cfg.widgetEnabled && widgetPageAllowed && !document.getElementById("qr-widget")) {
        app.injectFloatingWidget(cfg);
      }

      runButtonInjection();

      // Themes inject content after initial load: product recommendations
      // ("You may also like"), quick views, ajax cart drawers, infinite scroll.
      // Re-run hiding + button injection (debounced) whenever new DOM is added so
      // prices never leak and buttons appear on async-loaded cards.
      var _injectsCards =
        (context.isProductPage && (cfg.showOnProductList || cfg.targetMode === "collections")) ||
        (context.isCollectionPage && (cfg.showOnProductList || cfg.targetMode === "collections")) ||
        (context.isHomepage && cfg.showOnHomepage);

      var _needsObserver =
        (context.isProductPage && cfg.hidePriceOnProductPage) ||
        (context.isCollectionPage && cfg.hidePriceOnCollectionPage) ||
        (context.isHomepage && cfg.hidePriceOnHomePage && cfg.hidePriceMode !== "none") ||
        (cfg.hidePriceOnCartPage && cfg.hidePriceMode !== "none") ||
        cfg.hideAddToCart || cfg.hideBuyNow || _injectsCards;

      if (_needsObserver && !state._priceObserver && typeof MutationObserver !== "undefined") {
        var _rehideScheduled = false;
        var _observer = new MutationObserver(function (mutations) {
          if (_rehideScheduled) return;
          // Only react to added element nodes (ignore our own display/style changes,
          // which aren't observed since we watch childList/subtree only).
          var hasAdded = mutations.some(function (m) { return m.addedNodes && m.addedNodes.length; });
          if (!hasAdded) return;
          _rehideScheduled = true;
          window.setTimeout(function () {
            _rehideScheduled = false;
            runHiding();
            runButtonInjection();
          }, 50);
        });
        _observer.observe(document.body, { childList: true, subtree: true });
        state._priceObserver = _observer;
      }
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

})();

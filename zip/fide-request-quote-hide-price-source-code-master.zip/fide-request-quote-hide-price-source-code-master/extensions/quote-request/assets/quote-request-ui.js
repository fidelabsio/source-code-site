(function () {
  "use strict";

  var app = window.QuoteRequestApp;
  var state = app.state;
  var context = app.context;
  var esc = app.esc;
  var fixImgUrl = app.fixImgUrl;
  var formatPrice = app.formatPrice;
  var getQrCart = app.getQrCart;
  var saveQrCart = app.saveQrCart;
  var addToQrCart = app.addToQrCart;

  // ── Country / dial-code data ──────────────────────────────────────────────
  var _COUNTRIES = [
    { c: "AF", n: "Afghanistan", d: "+93" }, { c: "AL", n: "Albania", d: "+355" }, { c: "DZ", n: "Algeria", d: "+213" },
    { c: "AS", n: "American Samoa", d: "+1" }, { c: "AD", n: "Andorra", d: "+376" }, { c: "AO", n: "Angola", d: "+244" },
    { c: "AI", n: "Anguilla", d: "+1" }, { c: "AG", n: "Antigua and Barbuda", d: "+1" }, { c: "AR", n: "Argentina", d: "+54" },
    { c: "AM", n: "Armenia", d: "+374" }, { c: "AW", n: "Aruba", d: "+297" }, { c: "AU", n: "Australia", d: "+61" },
    { c: "AT", n: "Austria", d: "+43" }, { c: "AZ", n: "Azerbaijan", d: "+994" }, { c: "BS", n: "Bahamas", d: "+1" },
    { c: "BH", n: "Bahrain", d: "+973" }, { c: "BD", n: "Bangladesh", d: "+880" }, { c: "BB", n: "Barbados", d: "+1" },
    { c: "BY", n: "Belarus", d: "+375" }, { c: "BE", n: "Belgium", d: "+32" }, { c: "BZ", n: "Belize", d: "+501" },
    { c: "BJ", n: "Benin", d: "+229" }, { c: "BM", n: "Bermuda", d: "+1" }, { c: "BT", n: "Bhutan", d: "+975" },
    { c: "BO", n: "Bolivia", d: "+591" }, { c: "BA", n: "Bosnia and Herzegovina", d: "+387" }, { c: "BW", n: "Botswana", d: "+267" },
    { c: "BR", n: "Brazil", d: "+55" }, { c: "BN", n: "Brunei", d: "+673" }, { c: "BG", n: "Bulgaria", d: "+359" },
    { c: "BF", n: "Burkina Faso", d: "+226" }, { c: "BI", n: "Burundi", d: "+257" }, { c: "KH", n: "Cambodia", d: "+855" },
    { c: "CM", n: "Cameroon", d: "+237" }, { c: "CA", n: "Canada", d: "+1" }, { c: "CV", n: "Cape Verde", d: "+238" },
    { c: "KY", n: "Cayman Islands", d: "+1" }, { c: "CF", n: "Central African Republic", d: "+236" }, { c: "TD", n: "Chad", d: "+235" },
    { c: "CL", n: "Chile", d: "+56" }, { c: "CN", n: "China", d: "+86" }, { c: "CO", n: "Colombia", d: "+57" },
    { c: "KM", n: "Comoros", d: "+269" }, { c: "CG", n: "Republic of Congo", d: "+242" }, { c: "CD", n: "DR Congo", d: "+243" },
    { c: "CK", n: "Cook Islands", d: "+682" }, { c: "CR", n: "Costa Rica", d: "+506" }, { c: "HR", n: "Croatia", d: "+385" },
    { c: "CU", n: "Cuba", d: "+53" }, { c: "CW", n: "Curacao", d: "+599" }, { c: "CY", n: "Cyprus", d: "+357" },
    { c: "CZ", n: "Czech Republic", d: "+420" }, { c: "DK", n: "Denmark", d: "+45" }, { c: "DJ", n: "Djibouti", d: "+253" },
    { c: "DM", n: "Dominica", d: "+1" }, { c: "DO", n: "Dominican Republic", d: "+1" }, { c: "EC", n: "Ecuador", d: "+593" },
    { c: "EG", n: "Egypt", d: "+20" }, { c: "SV", n: "El Salvador", d: "+503" }, { c: "GQ", n: "Equatorial Guinea", d: "+240" },
    { c: "ER", n: "Eritrea", d: "+291" }, { c: "EE", n: "Estonia", d: "+372" }, { c: "ET", n: "Ethiopia", d: "+251" },
    { c: "FK", n: "Falkland Islands", d: "+500" }, { c: "FO", n: "Faroe Islands", d: "+298" }, { c: "FJ", n: "Fiji", d: "+679" },
    { c: "FI", n: "Finland", d: "+358" }, { c: "FR", n: "France", d: "+33" }, { c: "GF", n: "French Guiana", d: "+594" },
    { c: "PF", n: "French Polynesia", d: "+689" }, { c: "GA", n: "Gabon", d: "+241" }, { c: "GM", n: "Gambia", d: "+220" },
    { c: "GE", n: "Georgia", d: "+995" }, { c: "DE", n: "Germany", d: "+49" }, { c: "GH", n: "Ghana", d: "+233" },
    { c: "GI", n: "Gibraltar", d: "+350" }, { c: "GR", n: "Greece", d: "+30" }, { c: "GL", n: "Greenland", d: "+299" },
    { c: "GD", n: "Grenada", d: "+1" }, { c: "GP", n: "Guadeloupe", d: "+590" }, { c: "GU", n: "Guam", d: "+1" },
    { c: "GT", n: "Guatemala", d: "+502" }, { c: "GN", n: "Guinea", d: "+224" }, { c: "GW", n: "Guinea-Bissau", d: "+245" },
    { c: "GY", n: "Guyana", d: "+592" }, { c: "HT", n: "Haiti", d: "+509" }, { c: "HN", n: "Honduras", d: "+504" },
    { c: "HK", n: "Hong Kong", d: "+852" }, { c: "HU", n: "Hungary", d: "+36" }, { c: "IS", n: "Iceland", d: "+354" },
    { c: "IN", n: "India", d: "+91" }, { c: "ID", n: "Indonesia", d: "+62" }, { c: "IR", n: "Iran", d: "+98" },
    { c: "IQ", n: "Iraq", d: "+964" }, { c: "IE", n: "Ireland", d: "+353" }, { c: "IL", n: "Israel", d: "+972" },
    { c: "IT", n: "Italy", d: "+39" }, { c: "CI", n: "Ivory Coast", d: "+225" }, { c: "JM", n: "Jamaica", d: "+1" },
    { c: "JP", n: "Japan", d: "+81" }, { c: "JO", n: "Jordan", d: "+962" }, { c: "KZ", n: "Kazakhstan", d: "+7" },
    { c: "KE", n: "Kenya", d: "+254" }, { c: "KI", n: "Kiribati", d: "+686" }, { c: "KW", n: "Kuwait", d: "+965" },
    { c: "KG", n: "Kyrgyzstan", d: "+996" }, { c: "LA", n: "Laos", d: "+856" }, { c: "LV", n: "Latvia", d: "+371" },
    { c: "LB", n: "Lebanon", d: "+961" }, { c: "LS", n: "Lesotho", d: "+266" }, { c: "LR", n: "Liberia", d: "+231" },
    { c: "LY", n: "Libya", d: "+218" }, { c: "LI", n: "Liechtenstein", d: "+423" }, { c: "LT", n: "Lithuania", d: "+370" },
    { c: "LU", n: "Luxembourg", d: "+352" }, { c: "MO", n: "Macau", d: "+853" }, { c: "MK", n: "North Macedonia", d: "+389" },
    { c: "MG", n: "Madagascar", d: "+261" }, { c: "MW", n: "Malawi", d: "+265" }, { c: "MY", n: "Malaysia", d: "+60" },
    { c: "MV", n: "Maldives", d: "+960" }, { c: "ML", n: "Mali", d: "+223" }, { c: "MT", n: "Malta", d: "+356" },
    { c: "MH", n: "Marshall Islands", d: "+692" }, { c: "MQ", n: "Martinique", d: "+596" }, { c: "MR", n: "Mauritania", d: "+222" },
    { c: "MU", n: "Mauritius", d: "+230" }, { c: "MX", n: "Mexico", d: "+52" }, { c: "FM", n: "Micronesia", d: "+691" },
    { c: "MD", n: "Moldova", d: "+373" }, { c: "MC", n: "Monaco", d: "+377" }, { c: "MN", n: "Mongolia", d: "+976" },
    { c: "ME", n: "Montenegro", d: "+382" }, { c: "MA", n: "Morocco", d: "+212" }, { c: "MZ", n: "Mozambique", d: "+258" },
    { c: "MM", n: "Myanmar", d: "+95" }, { c: "NA", n: "Namibia", d: "+264" }, { c: "NR", n: "Nauru", d: "+674" },
    { c: "NP", n: "Nepal", d: "+977" }, { c: "NL", n: "Netherlands", d: "+31" }, { c: "NC", n: "New Caledonia", d: "+687" },
    { c: "NZ", n: "New Zealand", d: "+64" }, { c: "NI", n: "Nicaragua", d: "+505" }, { c: "NE", n: "Niger", d: "+227" },
    { c: "NG", n: "Nigeria", d: "+234" }, { c: "NU", n: "Niue", d: "+683" }, { c: "KP", n: "North Korea", d: "+850" },
    { c: "NO", n: "Norway", d: "+47" }, { c: "OM", n: "Oman", d: "+968" }, { c: "PK", n: "Pakistan", d: "+92" },
    { c: "PW", n: "Palau", d: "+680" }, { c: "PS", n: "Palestine", d: "+970" }, { c: "PA", n: "Panama", d: "+507" },
    { c: "PG", n: "Papua New Guinea", d: "+675" }, { c: "PY", n: "Paraguay", d: "+595" }, { c: "PE", n: "Peru", d: "+51" },
    { c: "PH", n: "Philippines", d: "+63" }, { c: "PL", n: "Poland", d: "+48" }, { c: "PT", n: "Portugal", d: "+351" },
    { c: "PR", n: "Puerto Rico", d: "+1" }, { c: "QA", n: "Qatar", d: "+974" }, { c: "RE", n: "Reunion", d: "+262" },
    { c: "RO", n: "Romania", d: "+40" }, { c: "RU", n: "Russia", d: "+7" }, { c: "RW", n: "Rwanda", d: "+250" },
    { c: "KN", n: "Saint Kitts and Nevis", d: "+1" }, { c: "LC", n: "Saint Lucia", d: "+1" }, { c: "VC", n: "Saint Vincent", d: "+1" },
    { c: "WS", n: "Samoa", d: "+685" }, { c: "SM", n: "San Marino", d: "+378" }, { c: "ST", n: "Sao Tome and Principe", d: "+239" },
    { c: "SA", n: "Saudi Arabia", d: "+966" }, { c: "SN", n: "Senegal", d: "+221" }, { c: "RS", n: "Serbia", d: "+381" },
    { c: "SC", n: "Seychelles", d: "+248" }, { c: "SL", n: "Sierra Leone", d: "+232" }, { c: "SG", n: "Singapore", d: "+65" },
    { c: "SK", n: "Slovakia", d: "+421" }, { c: "SI", n: "Slovenia", d: "+386" }, { c: "SB", n: "Solomon Islands", d: "+677" },
    { c: "SO", n: "Somalia", d: "+252" }, { c: "ZA", n: "South Africa", d: "+27" }, { c: "KR", n: "South Korea", d: "+82" },
    { c: "SS", n: "South Sudan", d: "+211" }, { c: "ES", n: "Spain", d: "+34" }, { c: "LK", n: "Sri Lanka", d: "+94" },
    { c: "SD", n: "Sudan", d: "+249" }, { c: "SR", n: "Suriname", d: "+597" }, { c: "SZ", n: "Eswatini", d: "+268" },
    { c: "SE", n: "Sweden", d: "+46" }, { c: "CH", n: "Switzerland", d: "+41" }, { c: "SY", n: "Syria", d: "+963" },
    { c: "TW", n: "Taiwan", d: "+886" }, { c: "TJ", n: "Tajikistan", d: "+992" }, { c: "TZ", n: "Tanzania", d: "+255" },
    { c: "TH", n: "Thailand", d: "+66" }, { c: "TL", n: "Timor-Leste", d: "+670" }, { c: "TG", n: "Togo", d: "+228" },
    { c: "TO", n: "Tonga", d: "+676" }, { c: "TT", n: "Trinidad and Tobago", d: "+1" }, { c: "TN", n: "Tunisia", d: "+216" },
    { c: "TR", n: "Turkey", d: "+90" }, { c: "TM", n: "Turkmenistan", d: "+993" }, { c: "TV", n: "Tuvalu", d: "+688" },
    { c: "UG", n: "Uganda", d: "+256" }, { c: "UA", n: "Ukraine", d: "+380" }, { c: "AE", n: "United Arab Emirates", d: "+971" },
    { c: "GB", n: "United Kingdom", d: "+44" }, { c: "US", n: "United States", d: "+1" }, { c: "UY", n: "Uruguay", d: "+598" },
    { c: "UZ", n: "Uzbekistan", d: "+998" }, { c: "VU", n: "Vanuatu", d: "+678" }, { c: "VE", n: "Venezuela", d: "+58" },
    { c: "VN", n: "Vietnam", d: "+84" }, { c: "VI", n: "US Virgin Islands", d: "+1" }, { c: "YE", n: "Yemen", d: "+967" },
    { c: "ZM", n: "Zambia", d: "+260" }, { c: "ZW", n: "Zimbabwe", d: "+263" },
  ];

  function _flag(code) {
    if (!code || code.length !== 2) return "";
    try {
      return String.fromCodePoint(
        0x1F1E6 + code.charCodeAt(0) - 65,
        0x1F1E6 + code.charCodeAt(1) - 65
      );
    } catch (e) { return ""; }
  }

  function _dialCodeOptions() {
    var POPULAR = ["US", "GB", "CA", "AU", "IN", "DE", "FR", "SG", "AE", "NZ", "ZA", "JP"];
    var opts = "";
    for (var p = 0; p < POPULAR.length; p++) {
      for (var q = 0; q < _COUNTRIES.length; q++) {
        if (_COUNTRIES[q].c === POPULAR[p]) {
          opts += "<option value=\"" + _COUNTRIES[q].d + "\"" + (POPULAR[p] === "US" ? " selected" : "") + ">" +
            _flag(_COUNTRIES[q].c) + " " + _COUNTRIES[q].d + "</option>";
          break;
        }
      }
    }
    opts += "<option disabled>────────</option>";
    for (var i = 0; i < _COUNTRIES.length; i++) {
      opts += "<option value=\"" + _COUNTRIES[i].d + "\">" +
        _flag(_COUNTRIES[i].c) + " " + _COUNTRIES[i].d + " " + _COUNTRIES[i].n + "</option>";
    }
    return opts;
  }

  function _countryOptions() {
    var opts = "";
    for (var i = 0; i < _COUNTRIES.length; i++) {
      opts += "<option value=\"" + _COUNTRIES[i].c + "\">" + _COUNTRIES[i].n + "</option>";
    }
    return opts;
  }

  // ── Visual logic ──────────────────────────────────────────────────────────
  function applyColors(cfg) {
    function hexAlpha(hex, a) {
      try {
        var r = parseInt(hex.slice(1, 3), 16);
        var g = parseInt(hex.slice(3, 5), 16);
        var b = parseInt(hex.slice(5, 7), 16);
        return "rgba(" + r + "," + g + "," + b + "," + a + ")";
      } catch (e) { return "rgba(0,0,0," + a + ")"; }
    }
    var root = document.documentElement;
    root.style.setProperty("--qr-color", cfg.buttonColor || "#222222");
    root.style.setProperty("--qr-txt", cfg.buttonTextColor || "#ffffff");
    root.style.setProperty("--qr-shadow", hexAlpha(cfg.buttonColor || "#222222", 0.18));
    root.style.setProperty("--qr-accent", cfg.accentColor || "#3b82f6");
    root.style.setProperty("--qr-success", cfg.successColor || "#1a7f4b");
    root.style.setProperty("--qr-warning", cfg.warningColor || "#f59e0b");
    root.style.setProperty("--qr-error", cfg.errorColor || "#dc2626");
  }
  app.applyColors = applyColors;

  function applyModalConfig(cfg) {
    var label = document.getElementById("qr-modal-label");
    if (label && cfg.modalTitle) label.textContent = cfg.modalTitle;
    var formTitle = document.getElementById("qr-form-title");
    if (formTitle && cfg.modalTitle) formTitle.textContent = cfg.modalTitle;

    var sb = document.getElementById("qr-submit-btn");
    if (sb) {
      if (cfg.submitButtonText) sb.textContent = cfg.submitButtonText;
      var fBg = cfg.formBtnBgColor || "#1a1a18";
      var fTxt = cfg.formBtnTextColor || "#ffffff";
      var fSz = (cfg.formBtnFontSize || 14) + "px";
      var fRad = (cfg.formBtnBorderRadius || 6) + "px";
      sb.style.cssText += ";background:" + fBg + ";color:" + fTxt + ";font-size:" + fSz + ";border-radius:" + fRad + ";";
    }

    var stepsBar = document.getElementById("qr-steps-bar");
    if (stepsBar) stepsBar.classList.toggle("qr-hidden", cfg.showStepIndicator === false);

    var trustRow = document.querySelector(".qr-trust-row");
    if (trustRow) trustRow.classList.toggle("qr-hidden", cfg.showTrustSignals === false);

    var prodImg = document.getElementById("qr-product-img");
    if (prodImg) prodImg.classList.toggle("qr-hidden", cfg.showProductImageInModal === false);

    var metaEl = document.getElementById("qr-product-meta");
    if (metaEl) {
      var metaParts = [];
      if (cfg.showVendorInForm && context.pd.productVendor) metaParts.push(context.pd.productVendor);
      if (cfg.showOptionInForm && state.variants.length > 0 && state.variants[0].title !== "Default Title") {
        var optNames = (state.variants[0].selectedOptions || []).map(function (o) { return o.name; }).join(" / ");
        if (optNames) metaParts.push(optNames);
      }
      if (cfg.showSkuInForm && state.variants.length > 0 && state.variants[0].sku) {
        metaParts.push("SKU: " + state.variants[0].sku);
      }
      if (metaParts.length > 0) {
        metaEl.textContent = metaParts.join("  ·  ");
        metaEl.style.display = "block";
      }
    }

    var varField = document.getElementById("qr-field-variant");
    var varSel = document.getElementById("qr-variant");
    if (varField && varSel && cfg.showVariantsSelector && state.variants.length > 1) {
      varSel.innerHTML = "";
      state.variants.forEach(function (v) {
        var opt = document.createElement("option");
        opt.value = v.id;
        opt.textContent = v.title;
        varSel.appendChild(opt);
      });
      varField.classList.remove("qr-hidden");
    }

    var priceField = document.getElementById("qr-field-offer-price");
    if (priceField && cfg.allowPriceEdit) {
      priceField.classList.remove("qr-hidden");
    }

    if (cfg.formSchema) {
      var allEls = (cfg.formSchema.contactElements || [])
        .concat(cfg.formSchema.shippingElements || [])
        .concat(cfg.formSchema.extraInfoElements || []);
      if (allEls.length > 0) buildDynamicForm(cfg.formSchema);
    }
  }
  app.applyModalConfig = applyModalConfig;

  // ── Forms / Dynamic Forms ──────────────────────────────────────────────────
  function makeFieldHtml(field, fid) {
    var html = '<div class="qr-field">';
    var tNorm = (field.type || "").toLowerCase().trim();
    if (tNorm === "paragraph") {
      return html + '<p style="font-size:14px;color:#555;line-height:1.6;margin:0 0 4px;">' + esc(field.content || "") + '</p></div>';
    }
    if (tNorm !== "checkbox") {
      html += '<label class="qr-label" for="' + fid + '">' + esc(field.label || field.type);
      if (field.required) html += ' <span class="qr-req" aria-hidden="true">*</span>';
      html += '</label>';
    }
    var ph = ' placeholder="' + esc(field.placeholder || "") + '"';
    switch (tNorm) {
      case "text":
        html += '<input class="qr-input" type="text" id="' + fid + '"' + ph + '>'; break;
      case "email":
        html += '<input class="qr-input" type="email" id="' + fid + '"' + ph + '>'; break;
      case "phone":
        html += '<input class="qr-input" type="tel" id="' + fid + '"' + ph + '>'; break;
      case "number":
        html += '<input class="qr-input" type="number" id="' + fid + '"' + ph +
          (field.min !== "" && field.min != null ? ' min="' + esc(String(field.min)) + '"' : '') +
          (field.max !== "" && field.max != null ? ' max="' + esc(String(field.max)) + '"' : '') + '>'; break;
      case "date field":
      case "date":
        html += '<input class="qr-input" type="date" id="' + fid + '">'; break;
      case "textarea":
        html += '<textarea class="qr-input qr-textarea" id="' + fid + '" rows="' + (field.rows || 4) + '"' + ph + '></textarea>'; break;
      case "dropdown":
        html += '<select class="qr-input" id="' + fid + '"><option value="">' + esc(app.t('dropdown_placeholder', 'Select…')) + '</option>';
        (field.options || []).forEach(function (o) { html += '<option value="' + esc(o) + '">' + esc(o) + '</option>'; });
        html += '</select>'; break;
      case "radio group":
      case "radio":
        html += '<div id="' + fid + '" style="display:flex;flex-direction:column;gap:8px;">';
        (field.options || []).forEach(function (o) {
          html += '<label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:14px;font-weight:400;">' +
            '<input type="radio" name="' + fid + '" value="' + esc(o) + '" style="width:16px;height:16px;"> ' + esc(o) + '</label>';
        });
        html += '</div>'; break;
      case "checkbox":
        html += '<label style="display:flex;align-items:center;gap:10px;cursor:pointer;font-size:14px;font-weight:400;">' +
          '<input type="checkbox" id="' + fid + '" style="width:16px;height:16px;flex-shrink:0;"> <span>' +
          esc(field.label || "Checkbox") + (field.required ? ' <span style="color:var(--qr-error, #dc2626)">*</span>' : '') + '</span></label>'; break;
      case "country":
        html += '<select class="qr-input" id="' + fid + '"><option value="">' + esc(app.t('dropdown_country_placeholder', 'Select country…')) + '</option>' +
          _countryOptions() + '</select>'; break;
      case "file upload":
      case "file":
      case "fileupload":
        html += '<div class="qr-file-upload-container">' +
          '<input type="file" id="' + fid + '"' +
          (field.accept ? ' accept="' + esc(field.accept) + '"' : '') +
          (field.multiple ? ' multiple' : '') +
          ' style="position:absolute;top:0;left:0;width:100%;height:100%;opacity:0;cursor:pointer;z-index:2;margin:0;padding:0;border:none;">' +
          '<div class="qr-file-upload-placeholder">' +
          '<svg style="display:block;margin:0 auto 10px;width:32px;height:32px;color:#94a3b8;" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/></svg>' +
          '<p style="margin:0;font-size:14px;font-weight:500;color:#374151;">' + esc(app.t('file_upload_instruction', 'Click to upload or drag & drop')) + '</p>' +
          '<p style="margin:4px 0 0;font-size:12px;color:#6b7280;">' +
          (field.accept ? esc(field.accept) + ' files' : esc(app.t('file_upload_types_default', 'Images & Documents'))) +
          ' &middot; ' +
          (field.multiple ? esc(app.t('file_upload_max_multiple', 'Max 5 files')) : esc(app.t('file_upload_max_single', 'Single file only'))) +
          '</p>' +
          '</div>' +
          '</div>' +
          '<div id="' + fid + '-preview-list" style="display:flex;flex-wrap:wrap;gap:10px;margin-top:8px;margin-bottom:8px;"></div>';
        break;
      default:
        html += '<input class="qr-input" type="text" id="' + fid + '"' + ph + '>';
    }
    if (field.helpText) html += '<div style="font-size:12px;color:#888;margin-top:4px;">' + esc(field.helpText) + '</div>';
    html += '<div id="' + fid + '-err" class="qr-field-error" role="alert"></div>';
    return html + '</div>';
  }

  function buildDynamicForm(schema) {
    var sections = [
      { title: app.t("section_contact", "Contact"), els: schema.contactElements || [] },
      { title: app.t("section_shipping", "Shipping address"), els: schema.shippingElements || [] },
      { title: app.t("section_extra_info", "Additional information"), els: schema.extraInfoElements || [] },
    ];
    var allEls = sections.reduce(function (acc, section) {
      return acc.concat(section.els);
    }, []);

    state.dynamicFields = [];

    var fieldsWrap = document.getElementById("qr-modal-fields");
    if (fieldsWrap && allEls.length) {
      var html = "";
      var fieldIndex = 0;
      var isNamePair = function (field, next) {
        var a = (field.label || "").toLowerCase();
        var b = (next && next.label || "").toLowerCase();
        return (a.indexOf("first") !== -1 && b.indexOf("last") !== -1) ||
          (a.indexOf("last") !== -1 && b.indexOf("first") !== -1);
      };

      sections.forEach(function (section) {
        if (!section.els || !section.els.length) return;
        html += '<p class="qr-section-heading">' + esc(section.title) + '</p>';
        var i = 0;
        while (i < section.els.length) {
          var field = section.els[i];
          var next = section.els[i + 1];
          if (next && isNamePair(field, next)) {
            var fid1 = "qr-df-" + fieldIndex++;
            var fid2 = "qr-df-" + fieldIndex++;
            state.dynamicFields.push({ id: fid1, field: field, step: 2 });
            state.dynamicFields.push({ id: fid2, field: next, step: 2 });
            html += '<div class="qr-form-row">' + makeFieldHtml(field, fid1) + makeFieldHtml(next, fid2) + '</div>';
            i += 2;
          } else {
            var fid = "qr-df-" + fieldIndex++;
            state.dynamicFields.push({ id: fid, field: field, step: 2 });
            html += makeFieldHtml(field, fid);
            i++;
          }
        }
      });
      fieldsWrap.innerHTML = html;
    }
  }

  function _detectFieldRole(field) {
    var t = (field.type || "").toLowerCase().trim();
    var lbl = (field.label || "").toLowerCase().trim();
    if (t === "email" || lbl.indexOf("email") !== -1) return "email";
    if (t === "phone" || lbl.indexOf("phone") !== -1 || lbl.indexOf("mobile") !== -1) return "phone";
    if (t === "country" || lbl === "country") return "country";
    if (lbl.indexOf("zip") !== -1 || lbl.indexOf("postal") !== -1) return "zip";
    if (lbl.indexOf("street") !== -1 || lbl === "address" || lbl === "address line 1" || (lbl.indexOf("address") !== -1 && lbl.indexOf("email") === -1)) return "street";
    if (lbl === "city" || lbl === "town" || lbl === "town/city" || lbl.indexOf("city") !== -1) return "city";
    if (lbl === "district" || lbl.indexOf("district") !== -1) return "district";
    if (lbl.indexOf("state") !== -1 || lbl.indexOf("province") !== -1 || lbl.indexOf("region") !== -1) return "state";
    if (lbl.indexOf("first") !== -1 && (lbl.indexOf("name") !== -1 || lbl === "first")) return "firstname";
    if ((lbl.indexOf("last") !== -1 || lbl.indexOf("surname") !== -1) && lbl.indexOf("company") === -1) return "lastname";
    if (t === "textarea" || lbl.indexOf("message") !== -1 || lbl.indexOf("comment") !== -1 || lbl.indexOf("note") !== -1 || lbl.indexOf("remark") !== -1) return "message";
    if (t === "checkbox") return "checkbox";
    if (t === "paragraph") return "paragraph";
    if (t === "file upload" || t === "file" || t === "fileupload") return "file";
    if (t === "number") return "number";
    if (lbl.indexOf("name") !== -1 && lbl.indexOf("company") === -1 && lbl.indexOf("brand") === -1) return "fullname";
    return "text";
  }

  function _validateField(role, value, field) {
    var v = (value || "").trim();
    var lbl = (field && field.label) ? field.label : "This field";

    // Universal required check — enforced for EVERY field regardless of its
    // type or detected role, and run BEFORE any format checks. This is the
    // single source of truth for "required", so a required field can never
    // slip through because of how its label/type happened to be classified
    // (previously message/checkbox/file skipped it entirely). Empty + not
    // required is always valid; format checks below only see non-empty values.
    if (!v) {
      return (field && field.required)
        ? lbl + app.t("validation_required_suffix", " is required")
        : null;
    }

    switch (role) {
      case "firstname":
        if (!v) return (field && field.required) ? app.t("validation_firstname_required", "First name is required") : null;
        if (v.length < 2) return app.t("validation_firstname_min", "First name must be at least 2 characters");
        if (v.length > 50) return app.t("validation_firstname_max", "First name must be 50 characters or less");
        if (!/^[A-Za-z\s\-'\.]+$/.test(v)) return app.t("validation_firstname_letters", "First name can only contain letters");
        return null;
      case "lastname":
        if (!v) return (field && field.required) ? app.t("validation_lastname_required", "Last name is required") : null;
        if (v.length > 50) return app.t("validation_lastname_max", "Last name must be 50 characters or less");
        if (!/^[A-Za-z\s\-'\.]+$/.test(v)) return app.t("validation_lastname_letters", "Last name can only contain letters");
        return null;
      case "fullname":
        if (!v) return (field && field.required) ? lbl + app.t("validation_required_suffix", " is required") : null;
        if (v.length < 2) return lbl + app.t("validation_min2_suffix", " must be at least 2 characters");
        if (v.length > 100) return lbl + app.t("validation_max100_suffix", " must be 100 characters or less");
        return null;
      case "email":
        if (!v) return (field && field.required) ? app.t("validation_email_required", "Email address is required") : null;
        if (v.length > 100) return app.t("validation_email_max", "Email must be 100 characters or less");
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) return app.t("validation_email_format", "Enter a valid email address (e.g. name@example.com)");
        return null;
      case "phone":
        if (!v) return (field && field.required) ? app.t("validation_phone_required", "Phone number is required") : null;
        var digits = v.replace(/[\s\-\(\)\.]/g, "");
        if (!/^\+?[0-9]{7,15}$/.test(digits)) return app.t("validation_phone_format", "Enter a valid phone number (7–15 digits, digits only)");
        return null;
      case "street":
        if (!v) return (field && field.required) ? app.t("validation_street_required", "Street address is required") : null;
        if (v.length < 5) return app.t("validation_street_min", "Street address must be at least 5 characters");
        if (v.length > 150) return app.t("validation_street_max", "Street address must be 150 characters or less");
        return null;
      case "city":
        if (!v) return (field && field.required) ? app.t("validation_city_required", "City is required") : null;
        if (v.length < 2) return app.t("validation_city_min", "City must be at least 2 characters");
        if (v.length > 50) return app.t("validation_city_max", "City must be 50 characters or less");
        if (!/^[A-Za-z\s\-'\.]+$/.test(v)) return app.t("validation_city_letters", "City can only contain letters");
        return null;
      case "district":
        if (!v) return (field && field.required) ? app.t("validation_district_required", "District is required") : null;
        if (v.length < 2) return app.t("validation_district_min", "District must be at least 2 characters");
        if (v.length > 50) return app.t("validation_district_max", "District must be 50 characters or less");
        return null;
      case "state":
        if (!v) return (field && field.required) ? app.t("validation_state_required", "State / Province is required") : null;
        if (v.length < 2) return app.t("validation_state_min", "State must be at least 2 characters");
        if (v.length > 50) return app.t("validation_state_max", "State must be 50 characters or less");
        return null;
      case "zip":
        if (!v) return (field && field.required) ? app.t("validation_zip_required", "Zip / Postal code is required") : null;
        if (v.length < 4) return app.t("validation_zip_min", "Zip / Postal code must be at least 4 characters");
        if (v.length > 10) return app.t("validation_zip_max", "Zip / Postal code must be 10 characters or less");
        if (!/^[A-Za-z0-9\s\-]+$/.test(v)) return app.t("validation_zip_format", "Enter a valid zip / postal code");
        return null;
      case "country":
        if (!v) return (field && field.required) ? app.t("validation_country_required", "Please select a country") : null;
        return null;
      case "message":
        if (v.length > 500) return app.t("validation_message_max", "Message must be 500 characters or less");
        return null;
      case "number":
        if (!v) return lbl + app.t("validation_required_suffix", " is required");
        var num = parseFloat(v);
        if (isNaN(num)) return app.t("validation_number_format", "Enter a valid number");
        var fMin = (field && field.min !== "" && field.min != null) ? parseFloat(field.min) : null;
        var fMax = (field && field.max !== "" && field.max != null) ? parseFloat(field.max) : null;
        if (fMin !== null && !isNaN(fMin) && num < fMin) return lbl + app.t("validation_number_min", " must be at least {min}", { min: fMin });
        if (fMax !== null && !isNaN(fMax) && num > fMax) return lbl + app.t("validation_number_max", " must be at most {max}", { max: fMax });
        return null;
      case "checkbox":
      case "paragraph":
      case "file":
        return null;
      default:
        if (!v) return lbl + app.t("validation_required_suffix", " is required");
        return null;
    }
  }

  function validateDynamicStep(step) {
    var ok = true;
    (state.dynamicFields || []).filter(function (item) { return item.step === step; }).forEach(function (item) {
      var field = item.field;
      var fid = item.id;
      var ft = (field.type || "").toLowerCase().trim();
      if (ft === "paragraph") return;

      var value = "";
      if (ft === "checkbox") {
        var el = document.getElementById(fid);
        value = (el && el.checked) ? "yes" : "";
      } else if (ft === "radio group" || ft === "radio") {
        var sel = document.querySelector('input[name="' + fid + '"]:checked');
        value = sel ? sel.value : "";
      } else if (ft === "file upload" || ft === "file" || ft === "fileupload") {
        // File inputs use a custom `_files` array (drag-drop/multi), not .value.
        var elf = document.getElementById(fid);
        value = (elf && elf._files && elf._files.length) ? "1" : "";
      } else {
        var el = document.getElementById(fid);
        value = el ? (el.value || "").trim() : "";
      }

      var role = _detectFieldRole(field);
      var err = _validateField(role, value, field);
      if (err) {
        showFieldErr(fid, fid + "-err", err);
        ok = false;
      }
    });
    return ok;
  }

  function applyFieldVisibility(cfg) {
    var toggle = function (id, show) {
      var el = document.getElementById(id);
      if (el) el.classList.toggle("qr-hidden", !show);
    };
    toggle("qr-field-phone", cfg.showPhone);
    toggle("qr-field-company", cfg.showCompany);
    toggle("qr-field-message", cfg.showMessage);
    var phoneCodeSel = document.getElementById("qr-phone-code");
    if (phoneCodeSel && !phoneCodeSel.options.length) {
      phoneCodeSel.innerHTML = _dialCodeOptions();
    }
  }
  app.applyFieldVisibility = applyFieldVisibility;

  // ── Step wireup ────────────────────────────────────────────────────────────
  function wireNavButtons() {
    var step1Continue = document.getElementById("qr-step1-continue");
    var step2Back = document.getElementById("qr-step2-back");
    var step2Next = document.getElementById("qr-step2-next");
    var step3Back = document.getElementById("qr-step3-back");
    if (!step1Continue || !step2Back || !step2Next || !step3Back) return;
    step1Continue.onclick = function () { qrNextStep(2); };
    step2Back.onclick = function () { qrNextStep(1); };
    step2Next.onclick = function () { qrNextStep(3); };
    step3Back.onclick = function () { qrNextStep(2); };
  }
  app.wireNavButtons = wireNavButtons;

  // ── Quote button injection on PDP ──────────────────────────────────────────
  var _atcBtnCache = undefined;
  function _findAtcButton() {
    if (_atcBtnCache !== undefined) return _atcBtnCache;
    _atcBtnCache = document.querySelector(
      ".product-form__submit, [name='add'], .btn--add-to-cart, " +
      ".product-form__cart-submit, button[type='submit'][name='add'], " +
      ".quick-add__submit, .card__button, [data-add-to-cart]"
    ) || null;
    return _atcBtnCache;
  }

  function _applyQuoteBtnStyle(btn, cfg, extraCss) {
    var atc = _findAtcButton();
    if (atc && atc.className) {
      btn.className = atc.className + " qr-quote-btn";
      var btnBg = cfg.buttonColor || "#222222";
      var btnTxt = cfg.buttonTextColor || "#ffffff";
      var radius = (cfg.buttonBorderRadius !== undefined ? cfg.buttonBorderRadius : 6) + "px";
      btn.style.cssText =
        "display:block;width:100%;box-sizing:border-box;cursor:pointer;" +
        "opacity:1 !important;visibility:visible !important;transform:none !important;" +
        "position:relative !important;top:auto !important;bottom:auto !important;left:auto !important;right:auto !important;margin-top:10px;" +
        "z-index:2 !important;pointer-events:auto !important;" +
        "background:" + btnBg + " !important;color:" + btnTxt + " !important;border-radius:" + radius + " !important;" +
        (extraCss || "");
      return false;
    }
    btn.className = "qr-quote-btn";
    btn.style.cssText =
      "display:block;width:100%;padding:14px 24px;border:1px solid #000000;" +
      "border-radius:6px;font-size:14px;font-weight:600;cursor:pointer;" +
      "letter-spacing:0.02em;font-family:inherit;box-sizing:border-box;" +
      "transition:opacity 0.15s,transform 0.1s;" +
      "position:relative;z-index:2;pointer-events:auto;" +
      "background:" + (cfg.buttonColor || "#222222") + " !important;" +
      "color:" + (cfg.buttonTextColor || "#ffffff") + " !important;" +
      "border-radius:" + (cfg.buttonBorderRadius !== undefined ? cfg.buttonBorderRadius : 6) + "px !important;" +
      (extraCss || "");
    return false;
  }

  function makeQuoteBtn(cfg, btnWidth) {
    var btn = document.createElement("button");
    btn.type = "button";
    btn.id = "qr-open-btn";
    btn.textContent = cfg.buttonText || app.t("request_a_quote", "Request a Quote");
    var usedAtcClass = _applyQuoteBtnStyle(btn, cfg);
    if (btnWidth) btn.style.width = btnWidth;
    if (!usedAtcClass) {
      btn.addEventListener("mouseenter", function () { btn.style.opacity = "0.88"; });
      btn.addEventListener("mouseleave", function () { btn.style.opacity = "1"; });
    }
    btn.addEventListener("click", function (e) { handleQuoteClick(cfg, e); });
    return btn;
  }

  function injectQuoteButton(cfg) {
    var display = cfg.productPageDisplay || "button_only";
    var position = cfg.buttonPosition || "below_atc";
    var btnWidth = cfg.buttonFullWidth !== false ? "100%" : "auto";

    var cartBtn = document.querySelector(
      ".product-form__submit, [name='add'], .btn--add-to-cart, " +
      ".product-form__cart-submit, button[type='submit'][name='add']"
    );

    if (cfg.hideAddToCart) {
      if (cartBtn) cartBtn.style.display = "none";
    }
    if (cfg.hideBuyNow) {
      document.querySelectorAll(
        ".shopify-payment-button, [data-shopify='payment-button']"
      ).forEach(function (el) { el.style.display = "none"; });
    }

    if (display === "hide" || display === "none") return;

    // Idempotent: the main quote button is injected once (safe to re-call from observer).
    if (document.getElementById("qr-open-btn")) return;

    var btn = makeQuoteBtn(cfg, btnWidth);

    // Preferred anchor: place the quote button relative to the add-to-cart button.
    if (cartBtn) {
      if (position === "above_atc") {
        btn.style.marginBottom = "10px";
        cartBtn.parentNode.insertBefore(btn, cartBtn);
      } else {
        btn.style.marginTop = "10px";
        cartBtn.parentNode.insertBefore(btn, cartBtn.nextSibling);
      }
      return;
    }

    // No add-to-cart button on the page. This is exactly when the quote button
    // matters most: the theme (or this product) doesn't render a cart form, or
    // Add-to-Cart / Buy-Now are disabled. Fall back through progressively broader
    // anchors so the button still appears instead of silently vanishing.
    btn.style.marginTop = "10px";

    var formAnchor = document.querySelector(".product-form, .product__form, form[action*='/cart']");
    if (formAnchor) {
      formAnchor.appendChild(btn);
      return;
    }

    // Anchor near the price block (reliably present even when hidden), attaching
    // to a sensible product-info container so the button lands in the buy area.
    var priceAnchor = document.querySelector(
      ".price, .product__price, .product-price, [data-product-price], " +
      ".money, [itemprop='price'], .price__amount"
    );
    if (priceAnchor) {
      var priceHost =
        priceAnchor.closest(
          ".product__info-container, .product-single__meta, .product__info-wrapper, " +
          ".product__details, .product-form__buttons, .product__info"
        ) || priceAnchor.parentNode;
      if (priceHost) {
        priceHost.appendChild(btn);
        return;
      }
    }

    // Last resort: any product-info container on the page.
    var infoAnchor = document.querySelector(
      ".product__info-container, .product-single__meta, .product__info-wrapper, " +
      ".product__details, .product__info"
    );
    if (infoAnchor) {
      infoAnchor.appendChild(btn);
    }
  }
  app.injectQuoteButton = injectQuoteButton;

  // ── Price element hiding ──────────────────────────────────────────────────
  function hidePriceElements(cfg) {
    var preHide = document.getElementById("qr-prehide");
    if (preHide) preHide.parentNode.removeChild(preHide);

    [
      ".price", ".price__regular", ".price__sale", ".price__current",
      ".price-item", ".price-item--regular", ".price-item--sale",
      ".product__price", ".product-price", ".product-single__price",
      ".price-section", ".price--main", "[data-product-price]",
      "[data-regular-price]", ".product-form__price",
      ".card__price", ".price-wrapper", ".product-card__price",
      ".product-item__price", ".product__price-wrapper",
      ".card-information__price", ".product-grid-item__price",
      "[class*='ProductPrice']", "[class*='CardPrice']",
      // Common across many premium / non-Dawn themes (Brooklyn, Narrative,
      // Out-of-the-Sandbox/Pipeline, microdata) — closes price-leak gaps.
      ".money", '[itemprop="price"]', ".price__amount", ".product-price__amount",
      ".ProductMeta__Price", ".ProductItem__Price", "[class*='ProductMeta__Price']",
    ].forEach(function (sel) {
      document.querySelectorAll(sel).forEach(function (el) {
        if (!el.closest("#qr-backdrop") && !el.closest("#qr-quote-page")) {
          el.style.display = "none";
        }
      });
    });
    if (cfg.hidePriceReplacement !== "nothing" && cfg.replacementText && !document.getElementById("qr-replacement-text")) {
      var priceEl = document.querySelector(".price, .product__price, .product-price, [data-product-price], .money, [itemprop=\"price\"], .price__amount");
      if (priceEl) {
        var rep = document.createElement("span");
        rep.id = "qr-replacement-text";
        rep.textContent = cfg.replacementText;
        rep.style.cssText = "display:block;font-size:15px;color:" + (cfg.replacementTextColor || "#b4b2a9") + ";margin-bottom:8px;";
        priceEl.parentNode.insertBefore(rep, priceEl.nextSibling);
      }
    }
  }
  app.hidePriceElements = hidePriceElements;

  // ── File Upload Handlers ───────────────────────────────────────────────────
  function _renderFilePreviews(inputEl) {
    var listEl = document.getElementById(inputEl.id + "-preview-list");
    if (!listEl) return;
    
    // Revoke old object URLs to avoid memory leaks
    var oldImgs = listEl.querySelectorAll("img[data-object-url]");
    oldImgs.forEach(function(img) {
      try { URL.revokeObjectURL(img.getAttribute("data-object-url")); } catch (e) {}
    });

    var files = inputEl._files || [];
    if (files.length === 0) {
      listEl.innerHTML = "";
      return;
    }

    var html = "";
    for (var i = 0; i < files.length; i++) {
      var file = files[i];
      var isImg = file.type && file.type.match(/^image\//);
      
      html += '<div class="qr-preview-item">';
      if (isImg) {
        var objUrl = URL.createObjectURL(file);
        html += '<img src="' + objUrl + '" data-object-url="' + objUrl + '" alt="' + esc(file.name) + '">';
      } else {
        html += '<div style="width:100%;height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:4px;text-align:center;">' +
          '<svg style="width:24px;height:24px;color:#9ca3af;margin-bottom:2px;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>' +
          '<span style="font-size:8px;font-weight:600;color:#4b5563;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:100%;">' + esc(file.name) + '</span>' +
          '</div>';
      }
      
      html += '<button type="button" class="qr-preview-item-remove" data-qr-remove-idx="' + i + '" data-qr-input="' + inputEl.id + '" title="Remove file">&times;</button>';
      html += '</div>';
    }
    listEl.innerHTML = html;
  }

  function _handleFileSelection(inputEl, files) {
    var existing = inputEl._files || [];
    var limitExceeded = false;
    var maxLimit = inputEl.multiple ? 5 : 1;

    if (!inputEl.multiple) {
      existing = [files[0]];
    } else {
      for (var i = 0; i < files.length; i++) {
        if (existing.length >= maxLimit) {
          if (files.length > maxLimit || (existing.length + files.length - i) > maxLimit) {
            limitExceeded = true;
          }
          break;
        }
        var file = files[i];
        var isDup = existing.some(function(f) {
          return f.name === file.name && f.size === file.size;
        });
        if (!isDup) {
          existing.push(file);
        }
      }
    }
    inputEl._files = existing;
    inputEl.value = ""; // Clear file input value to allow re-upload

    // Clear input/file errors
    var errEl = document.getElementById(inputEl.id + "-err");
    if (limitExceeded) {
      if (errEl) {
        errEl.textContent = app.t("validation_file_max", "Maximum {n} files allowed.", { n: maxLimit });
        errEl.style.display = "block";
      }
      inputEl.classList.add("qr-input-error");
    } else {
      if (errEl) {
        errEl.textContent = "";
        errEl.style.display = "none";
      }
      inputEl.classList.remove("qr-input-error");
    }

    _renderFilePreviews(inputEl);
  }

  async function _uploadFileFields(fields) {
    for (var i = 0; i < fields.length; i++) {
      var f = fields[i];
      var filesList = (f._fileInput && f._fileInput._files) || (f._fileInput ? f._fileInput.files : null);
      if (!filesList || filesList.length === 0) continue;
      
      var maxFiles = f._multiple ? 5 : 1;
      if (filesList.length > maxFiles) {
        showFieldErr(f.id, f.id + "-err", f._multiple ? app.t("validation_file_max", "Maximum {n} files allowed.", { n: 5 }) : "Only one file allowed.");
        return null;
      }
      
      var fd = new FormData();
      for (var j = 0; j < filesList.length; j++) {
        fd.append("files[]", filesList[j]);
      }
      
      try {
        var res  = await fetch(app.proxyUrl("/api/upload"), { method: "POST", body: fd });
        var data = await res.json();
        if (data.error) {
          showFieldErr(f.id, f.id + "-err", data.error);
          return null;
        }
        f.value = data.urls;
      } catch (e) {
        showFieldErr(f.id, f.id + "-err", "Upload failed. Please try again.");
        return null;
      }
    }
    return fields;
  }

  // File upload change/click/drag delegations
  document.addEventListener("change", function(e) {
    if (e.target && e.target.type === "file") {
      var files = Array.from(e.target.files || []);
      if (files.length > 0) {
        _handleFileSelection(e.target, files);
      }
    }
  });

  document.addEventListener("click", function(e) {
    var btn = e.target && e.target.closest ? e.target.closest("[data-qr-remove-idx]") : null;
    if (!btn) return;
    var inputEl = document.getElementById(btn.getAttribute("data-qr-input"));
    if (!inputEl) return;
    var idx = parseInt(btn.getAttribute("data-qr-remove-idx"), 10);
    
    var existing = inputEl._files || [];
    if (idx >= 0 && idx < existing.length) {
      existing.splice(idx, 1);
      inputEl._files = existing;
    }
    _renderFilePreviews(inputEl);
  });

  document.addEventListener("dragover", function(e) {
    var container = e.target && e.target.closest ? e.target.closest(".qr-file-upload-container") : null;
    if (container) {
      e.preventDefault();
      container.classList.add("drag-over");
    }
  });

  document.addEventListener("dragleave", function(e) {
    var container = e.target && e.target.closest ? e.target.closest(".qr-file-upload-container") : null;
    if (container) {
      container.classList.remove("drag-over");
    }
  });

  document.addEventListener("drop", function(e) {
    var container = e.target && e.target.closest ? e.target.closest(".qr-file-upload-container") : null;
    if (container) {
      e.preventDefault();
      container.classList.remove("drag-over");
      
      var inputEl = container.querySelector("input[type='file']");
      if (!inputEl) return;

      var files = Array.from((e.dataTransfer && e.dataTransfer.files) || []);
      if (files.length === 0) return;

      _handleFileSelection(inputEl, files);
    }
  });

  // ── Collection / listing page injection ───────────────────────────────────
  function _buildCardButton(cfg, product) {
    var btn = document.createElement("button");
    btn.type = "button";
    btn.textContent = cfg.buttonText || app.t("request_a_quote", "Request a Quote");
    var usedAtcClass = _applyQuoteBtnStyle(btn, cfg, "margin-top:8px;");
    if (!usedAtcClass) {
      btn.addEventListener("mouseenter", function () { btn.style.opacity = "0.88"; });
      btn.addEventListener("mouseleave", function () { btn.style.opacity = "1"; });
    }
    btn.addEventListener("click", (function (p) {
      return function (e) {
        if (e) {
          e.preventDefault();
          e.stopPropagation();
        }
        var clickedBtn = e ? e.currentTarget : null;
        if (p.fetched) {
          state.currentProduct = p;
          handleQuoteClick(cfg, e);
          return;
        }
        var oldTxt = btn.textContent;
        btn.textContent = app.t("loading", "Loading...");
        btn.disabled = true;
        fetch(app.storeUrl("products/" + p.productHandle + ".js"))
          .then(function (r) { return r.json(); })
          .then(function (data) {
            p.productId = data.id || p.productId;
            p.productTitle = data.title || p.productTitle;
            p.productImage = data.featured_image || p.productImage;
            p.productVendor = data.vendor || "";
            var rate = app.getRate();
            p.productPrice = (data.price || 0) * rate;
            if (data.variants && data.variants.length > 0) {
              data.variants.forEach(function(v) { v.price = (v.price || 0) * rate; });
              state.variants = data.variants;
              p.productSku = data.variants[0].sku || "";
            }
            p.fetched = true;
            state.currentProduct = p;
            btn.textContent = oldTxt;
            btn.disabled = false;
            handleQuoteClick(cfg, { currentTarget: clickedBtn });
          })
          .catch(function () {
            p.fetched = true;
            state.currentProduct = p;
            btn.textContent = oldTxt;
            btn.disabled = false;
            handleQuoteClick(cfg, { currentTarget: clickedBtn });
          });
      };
    })(product));
    return btn;
  }


  function _doInjectCards(cfg, filterFn) {
    var cardSelectors = [
      ".card-wrapper", ".product-card-wrapper", ".product-item",
      ".grid-product", "[data-product-id]", ".product", ".collection-item",
    ];

    // On the product page, only scan recommendation/related sections so the main
    // product never receives a card-style button (it gets the dedicated one).
    var roots = [document];
    if (context.isProductPage) {
      roots = Array.from(document.querySelectorAll(
        "product-recommendations, .product-recommendations, [data-product-recommendations], " +
        ".related-products, .complementary-products, .product__recommendations, " +
        "#recommendations, .recommendations"
      ));
      if (roots.length === 0) return; // recommendations not in DOM yet; observer retries
    }

    var cards = [];
    for (var r = 0; r < roots.length; r++) {
      for (var s = 0; s < cardSelectors.length; s++) {
        var found = Array.from(roots[r].querySelectorAll(cardSelectors[s]));
        if (found.length > 0) { cards = cards.concat(found); break; }
      }
    }

    cards = cards.filter(function (c) {
      return !cards.some(function (other) {
        return other !== c && other.contains(c);
      });
    });

    cards.forEach(function (card) {
      if (card.dataset.qrInjected) return;

      var link = card.querySelector("a[href*='/products/']");
      var handle = link ? link.href.split("/products/")[1].split(/[?#]/)[0] : "";
      handle = handle.replace(/\/+$/, "");
      var imgEl = card.querySelector("img");
      var imgSrc = imgEl ? (imgEl.getAttribute("data-src") || imgEl.src || "") : "";
      var titleEl = card.querySelector(".card__heading a, h3 a, h2 a, [class*='title'] a");
      var title = (titleEl || link || {}).textContent || handle;
      var idAttr = card.querySelector("[data-product-id]");
      var prodId = idAttr ? (idAttr.getAttribute("data-product-id") || "") : "";
      
      var cardForm = card.querySelector('form[action*="/cart"]');
      var varInput = cardForm ? cardForm.querySelector('[name="id"]') : card.querySelector('[name="id"]');
      var selVarId = varInput ? varInput.value : null;

      if (filterFn && !filterFn(prodId, handle)) return;

      // Never inject onto a card for the product whose page we're on.
      if (context.isProductPage && context.pd) {
        var _curId = String(context.pd.productId || "");
        var _curHandle = (context.pd.productHandle || "").toLowerCase();
        if ((prodId && String(prodId) === _curId) ||
            (handle && _curHandle && handle.toLowerCase() === _curHandle)) return;
      }

      var product = {
        productId: prodId,
        productTitle: (title || "").trim(),
        productImage: imgSrc,
        productHandle: handle,
        selectedVariantId: selVarId,
        fetched: false
      };

      var toInsert = _buildCardButton(cfg, product);

      var cardInner = card.querySelector(".card__inner");
      var infoEl = null;
      var directChildren = Array.from(card.children);
      for (var ci = 0; ci < directChildren.length; ci++) {
        if (directChildren[ci].matches(
          ".card__information, .product-item__info, .product-card__info"
        )) {
          infoEl = directChildren[ci];
          break;
        }
      }
      if (!infoEl) {
        var infoCandidates = Array.from(card.querySelectorAll(
          ".card__information, .product-item__info, .product-card__info"
        ));
        infoEl = infoCandidates.find(function (el) {
          return !cardInner || !cardInner.contains(el);
        }) || infoCandidates[0] || null;
      }

      (infoEl || card).appendChild(toInsert);
      card.dataset.qrInjected = "1";
    });
  }

  function injectCollectionButtons(cfg) {
    var display = cfg.productPageDisplay || "button_only";
    if (display === "hide" || display === "none") return;

    var allowedCollections = cfg.targetCollections || [];
    var allowedProducts = cfg.targetProducts || [];
    var mode = cfg.targetMode || "all";

    if (mode === "all") {
      _doInjectCards(cfg, null);
      return;
    }

    if (mode === "products") {
      _doInjectCards(cfg, allowedProducts.length === 0 ? null : function (prodId, handle) {
        return allowedProducts.some(function (p) {
          return (prodId && String(p.productId) === String(prodId)) ||
            (handle && p.productHandle &&
              p.productHandle.toLowerCase() === handle.toLowerCase());
        });
      });
      return;
    }

    if (mode === "collections") {
      // Product page recommendation/related cards: inject when the current
      // product belongs to an allowed collection (mirrors shouldHidePrice).
      if (context.isProductPage) {
        if (allowedCollections.length === 0) return;
        var inAllowedColl = allowedCollections.some(function (c) {
          var ch = (c.handle || "").toLowerCase();
          return (context.productCollections || []).some(function (h) {
            return h.toLowerCase() === ch;
          });
        });
        if (inAllowedColl) _doInjectCards(cfg, null);
        return;
      }

      if (context.isCollectionPage && context.collEl) {
        if (allowedCollections.length > 0) {
          var myCollId = String(context.collEl.dataset.collectionId || "");
          var myCollHandle = (context.collEl.dataset.collectionHandle || "").toLowerCase();
          var collMatch = allowedCollections.some(function (c) {
            return String(c.id) === myCollId ||
              (c.handle && c.handle.toLowerCase() === myCollHandle);
          });
          if (!collMatch) return;
        }
        _doInjectCards(cfg, null);
        return;
      }

      if (context.isHomepage) {
        if (allowedCollections.length === 0) return;
        var handles = allowedCollections.map(function (c) { return c.handle; }).filter(Boolean);
        var fetches = handles.map(function (h) {
          return fetch(app.storeUrl("collections/" + h + "/products.json?limit=250"), {
            headers: { Accept: "application/json" },
          })
            .then(function (r) { return r.ok ? r.json() : { products: [] }; })
            .then(function (d) { return d.products || []; })
            .catch(function () { return []; });
        });
        Promise.all(fetches).then(function (results) {
          var allowed = {};
          results.forEach(function (products) {
            products.forEach(function (p) {
              if (p.id) allowed[String(p.id)] = true;
              if (p.handle) allowed[p.handle.toLowerCase()] = true;
            });
          });
          _doInjectCards(cfg, function (prodId, handle) {
            return !!(
              (prodId && allowed[String(prodId)]) ||
              (handle && allowed[handle.toLowerCase()])
            );
          });
        });
        return;
      }
    }
  }
  app.injectCollectionButtons = injectCollectionButtons;

  // ── Actions & Submission ───────────────────────────────────────────────────
  // Product "Request a Quote" buttons (home, product, collection) behave based
  // on whether the floating quote widget is enabled:
  //   • Widget ENABLED  → buttons feed the quote cart (add + toast); the widget
  //                       (cart icon) is what opens the modal.
  //   • Widget DISABLED → buttons follow the merchant's "What happens when
  //                       customer clicks" setting (addToQuoteBehaviour).
  function handleQuoteClick(cfg, event) {
    if (cfg.requireLogin && !context.isLoggedIn) {
      window.location.href = "/account/login?return_url=" + encodeURIComponent(window.location.pathname);
      return;
    }

    if (cfg.widgetEnabled) {
      addToQrCart();
      showToast(cfg.toastMessage || app.t("toast_added_default", "Product added to quote cart."));
      return;
    }

    var beh = cfg.addToQuoteBehaviour || "popup_and_form";
    if (beh === "popup") {
      // Quick confirm popup — on confirm it adds the item and opens the form.
      openMiniPopup(cfg, event && event.currentTarget);
    } else {
      // "popup_and_form" (and any legacy values) — open the full form directly.
      addToQrCart();
      openQRModal();
    }
  }

  // ── Mini Popup & Toast ─────────────────────────────────────────────────────
  function openMiniPopup(cfg, targetBtn) {
    var popup = document.getElementById("qr-popup");
    var overlay = document.getElementById("qr-popup-overlay");
    var img = document.getElementById("qr-popup-img");
    var title = document.getElementById("qr-popup-title");
    var p = state.currentProduct;

    if (img) { img.src = p.productImage || ""; img.alt = p.productTitle || ""; }
    if (title) title.textContent = p.productTitle || "";

    var triggerBtn = targetBtn || document.getElementById("qr-open-btn") || document.querySelector(".qr-collection-btn");
    if (triggerBtn && popup) {
      popup.style.visibility = "hidden";
      popup.style.display = "block";

      var rect = triggerBtn.getBoundingClientRect();
      var top = rect.top - popup.offsetHeight - 10;
      var left = rect.left;
      if (top < 10) top = rect.bottom + 10;
      
      var maxLeft = window.innerWidth - popup.offsetWidth - 20;
      if (left > maxLeft) left = Math.max(10, maxLeft);

      popup.style.top = top + "px";
      popup.style.left = left + "px";
      
      popup.style.visibility = "visible";
    } else if (popup) {
      popup.style.display = "block";
    }

    if (popup) { popup.setAttribute("aria-hidden", "false"); }
    if (overlay) overlay.style.display = "block";

    document.getElementById("qr-popup-confirm").onclick = function (e) {
      if (e) e.preventDefault();
      closeMiniPopup();
      addToQrCart();
      openQRModal();
    };
    document.getElementById("qr-popup-cancel").onclick = closeMiniPopup;
    overlay.onclick = closeMiniPopup;
  }

  function closeMiniPopup() {
    var popup = document.getElementById("qr-popup");
    var overlay = document.getElementById("qr-popup-overlay");
    if (popup) { popup.style.display = "none"; popup.setAttribute("aria-hidden", "true"); }
    if (overlay) overlay.style.display = "none";
  }

  var _toastTimer = null;
  function showToast(msg, isSuccessToast) {
    var t = document.getElementById("qr-toast");
    if (!t) return;
    var cfg = state.cfg || {};
    if (isSuccessToast) {
      if (cfg.successToastEnabled === false) return;
    } else {
      if (cfg.toastEnabled === false) return;
    }

    var pos = cfg.toastPosition || "bottom_center";
    var isTop = pos.indexOf("top") !== -1;
    var isLeft = pos.indexOf("left") !== -1;
    var isRight = pos.indexOf("right") !== -1;
    var isCenter = !isLeft && !isRight;
    var baseX = isCenter ? "translateX(-50%)" : "";
    var hiddenY = isTop ? "-80px" : "80px";

    var fontSize = (cfg.toastFontSize != null ? cfg.toastFontSize : 14) + "px";
    var radius = (cfg.toastBorderRadius != null ? cfg.toastBorderRadius : 40) + "px";
    var bw = (cfg.toastBorderWidth != null ? cfg.toastBorderWidth : 0);

    t.textContent = msg || "";
    t.style.cssText = [
      "position:fixed", "z-index:999999", "white-space:nowrap", "pointer-events:none",
      "padding:12px 20px", "font-weight:500", "font-family:inherit",
      "background:" + (cfg.toastBgColor || "#0f172a"),
      "color:" + (cfg.toastTextColor || "#ffffff"),
      "font-size:" + fontSize,
      "border-radius:" + radius,
      "border:" + bw + "px solid " + (cfg.toastBorderColor || "transparent"),
      "box-shadow:0 10px 15px -3px rgba(0,0,0,0.1),0 4px 6px -4px rgba(0,0,0,0.1)",
      "transition:transform 0.3s cubic-bezier(0.34,1.56,0.64,1),opacity 0.2s",
      "opacity:0",
    ].join(";");

    // Anchor to the chosen edge/corner. Use "auto" (not "") so these inline
    // values fully override the stylesheet's #qr-toast { bottom; left } — an
    // empty string falls back to the stylesheet, which would leave top+bottom
    // (and left+right) both set and stretch the fixed box across the screen.
    t.style.top = isTop ? "24px" : "auto";
    t.style.bottom = isTop ? "auto" : "24px";
    t.style.left = isLeft ? "24px" : (isCenter ? "50%" : "auto");
    t.style.right = isRight ? "24px" : "auto";
    t.style.transform = (baseX + " translateY(" + hiddenY + ")").trim();

    // Animate in next frame.
    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        t.style.opacity = "1";
        t.style.transform = (baseX + " translateY(0)").trim();
        t.style.pointerEvents = "auto";
      });
    });

    if (_toastTimer) clearTimeout(_toastTimer);
    _toastTimer = setTimeout(function () {
      t.style.opacity = "0";
      t.style.transform = (baseX + " translateY(" + hiddenY + ")").trim();
      t.style.pointerEvents = "none";
    }, 3000);
  }

  // ── Modal Product List & rendering ─────────────────────────────────────────
  // Enable/disable the modal's submit button. A quote can't be requested with
  // an empty cart, so the button is disabled (and explained) until a product
  // is added.
  function _setSubmitEnabled(enabled) {
    var sb = document.getElementById("qr-submit-btn");
    if (!sb) return;
    sb.disabled = !enabled;
    if (enabled) {
      sb.removeAttribute("aria-disabled");
      sb.removeAttribute("title");
    } else {
      sb.setAttribute("aria-disabled", "true");
      sb.setAttribute("title", app.t("add_product_disabled_title", "Add at least one product to request a quote"));
    }
  }

  // When the quote has no products, keep the form visible but show a clear
  // message at the top and disable the submit button until a product is added.
  function _applyQuoteEmptyState(isEmpty) {
    var notice = document.getElementById("qr-empty-notice");
    if (notice) notice.classList.toggle("qr-hidden", !isEmpty);
    _setSubmitEnabled(!isEmpty);
  }

  function _renderProductList() {
    var productsEl = document.getElementById("qr-step1-products");
    if (!productsEl) return;
    var items = getQrCart();
    var cfg = state.cfg || {};
    var _cur = (window.Shopify && window.Shopify.currency && window.Shopify.currency.active) || (context.contextEl && context.contextEl.dataset.currency) || cfg.shopCurrency || "USD";
    var _sym = app.getCurrencySymbol(_cur);
    var rate = app.getRate();

    if (items.length === 0) {
      // Empty cart is a dead-end without a way out — give the customer a clear
      // recovery action back to product browsing instead of just a message.
      var browseUrl = (cfg.continueShoppingUrl && String(cfg.continueShoppingUrl)) || app.storeUrl("collections/all");
      productsEl.innerHTML =
        '<div class="qr-empty-cart">' +
          '<div class="qr-empty-cart-icon" aria-hidden="true">' +
            '<svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' +
              '<circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle>' +
              '<path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>' +
            '</svg>' +
          '</div>' +
          '<p class="qr-empty-cart-title">' + esc(app.t("empty_cart_title", "No products selected")) + '</p>' +
          '<p class="qr-empty-cart-text">' + esc(app.t("empty_cart_desc", "Browse our products and add items to request a quote.")) + '</p>' +
          '<a class="qr-btn qr-empty-cart-cta" href="' + esc(browseUrl) + '">' + esc(app.t("empty_cart_cta", "Browse products")) + '</a>' +
        '</div>';
      _applyQuoteEmptyState(true);
      return;
    }

    productsEl.innerHTML = items.map(function (item, i) {
      var rawImg = item.productImage || item.image || "";
      var img = fixImgUrl(rawImg);
      var title = item.productTitle || item.title || "Product";
      var qty = item.quantity || 1;
      var vendor = item.vendor || item.productVendor || "";
      var sku = item.sku || item.productSku || "";
      var price = item.price || item.productPrice || "";

      var activePriceVal = price ? parseFloat(price) * rate : 0;
      var showImage = cfg.showProductImageInModal !== false;
      var hasImg = !!img;

      var h = '<div class="qr-prod-card' + ((showImage && hasImg) ? '' : ' qr-no-image') + '">';
      h += '<div style="display:flex; gap:12px; align-items:flex-start; width:100%;">';

      if (showImage) {
        if (hasImg) {
          h += '<img src="' + esc(img) + '" alt="' + esc(title) + '" class="qr-prod-img" data-idx="' + i + '" width="56" height="56">';
        } else {
          h += '<div class="qr-prod-img-ph" style="width:56px; height:56px;"></div>';
        }
      }

      h += '<div class="qr-prod-info">';
      h += '<p class="qr-prod-title">' + esc(title) + '</p>';

      if (cfg.showPriceInForm && price) {
        h += '<p class="qr-prod-price">' + esc(formatPrice(activePriceVal)) + '</p>';
      }

      // Each detail on its own line, in order: Price (above) → Vendor → SKU.
      if (cfg.showVendorInForm && vendor) {
        h += '<div class="qr-prod-meta"><span style="font-weight:600; color:#1a1a18; margin-right:4px;">' + esc(app.t("vendor_label", "Vendor:")) + '</span><span style="color:#6d7175;">' + esc(vendor) + '</span></div>';
      }
      if (cfg.showSkuInForm && sku) {
        h += '<div class="qr-prod-meta"><span style="font-weight:600; color:#1a1a18; margin-right:4px;">' + esc(app.t("sku_label", "SKU:")) + '</span><span style="color:#6d7175;">' + esc(sku) + '</span></div>';
      }

      var variantTitle = item.variantTitle && item.variantTitle !== "Default Title" ? item.variantTitle : "";
      if (variantTitle) {
        h += '<div style="margin-top:5px; display:inline-flex; align-items:center; gap:4px; background:#f5f5f0; border:1px solid #e3e3db; border-radius:4px; padding:2px 8px;">' +
          '<span style="font-size:12px; color:#6d7175;">' + esc(variantTitle) + '</span>' +
          '</div>';
      }

      if (cfg.showNoteInForm) {
        var existingNote = item.note ? item.note : '';
        h += '<div style="margin-top:6px;">' +
          '<button type="button" class="qr-prod-note-btn" data-note="qr-prod-note-' + i + '">' +
          '<svg class="qr-prod-note-icon" viewBox="0 0 20 20" width="16" height="16" fill="currentColor"><path d="M6.55 7.25a.7.7 0 0 1 .7-.7h5.5a.7.7 0 0 1 0 1.4h-5.5a.7.7 0 0 1-.7-.7Z"/><path d="M7 9.05a.7.7 0 0 0 0 1.4h2.25a.7.7 0 1 0 0-1.4h-2.25Z"/><path fill-rule="evenodd" d="M3.5 6.25a2.75 2.75 0 0 1 2.75-2.75h7.5a2.75 2.75 0 0 1 2.75 2.75v5.5a.75.75 0 0 1-.22.53l-4 4a.75.75 0 0 1-.53.22h-5.5a2.75 2.75 0 0 1-2.75-2.75v-7.5Zm2.75-1.25c-.69 0-1.25.56-1.25 1.25v7.5c0 .69.56 1.25 1.25 1.25h4.75v-2.25c0-.966.784-1.75 1.75-1.75h2.25v-4.75c0-.69-.56-1.25-1.25-1.25h-7.5Zm7.69 7.5h-1.19a.25.25 0 0 0-.25.25v1.19l1.44-1.44Z"/></svg>' +
          '<span class="qr-note-text" style="margin-left:4px;">' + esc(existingNote ? app.t('note_hide', 'Hide note') : app.t('note_add', 'Add note')) + '</span>' +
          '</button>' +
          '<textarea id="qr-prod-note-' + i + '" class="qr-prod-note-area' + (existingNote ? ' qr-note-open' : '') + '" placeholder="' + esc(app.t('note_placeholder', 'Add a note…')) + '">' +
          esc(existingNote) + '</textarea>' +
          '</div>';
      }

      h += '</div>';
      h += '<button type="button" class="qr-prod-remove" data-remove-idx="' + i + '" title="' + esc(app.t('remove', 'Remove')) + '">' +
        '<svg width="18" height="18" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">' +
        '<path d="M2.5 5H4.16667M4.16667 5H17.5M4.16667 5V16.6667C4.16667 17.1087 4.34226 17.5326 4.65482 17.8452C4.96738 18.1577 5.39131 18.3333 5.83333 18.3333H14.1667C14.6087 18.3333 15.0326 18.1577 15.3452 17.8452C15.6577 17.5326 15.8333 17.1087 15.8333 16.6667V5H4.16667ZM6.66667 5V3.33333C6.66667 2.89131 6.84226 2.46738 7.15482 2.15482C7.46738 1.84226 7.89131 1.66667 8.33333 1.66667H11.6667C12.1087 1.66667 12.5326 1.84226 12.8452 2.15482C13.1577 2.46738 13.3333 2.89131 13.3333 3.33333V5" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>' +
        '<path d="M8.33333 9.16667V14.1667" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>' +
        '<path d="M11.6667 9.16667V14.1667" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>' +
        '</svg></button>';

      h += '</div>';
      h += '<div class="qr-prod-controls-row">';
      h += '<div class="qr-prod-qty-row">' +
        '<span style="font-size:13px; color:#6d7175; margin-right:2px;">' + esc(app.t('product_qty_label', 'Qty ')) + '</span>' +
        '<div class="qr-prod-stepper">' +
        '<button type="button" data-qty-idx="' + i + '" data-qty-delta="-1" aria-label="Decrease quantity">−</button>' +
        '<input type="number" id="qr-prod-qty-' + i + '" data-qty-idx="' + i + '" value="' + Number(qty) + '" min="1" step="1">' +
        '<button type="button" data-qty-idx="' + i + '" data-qty-delta="1" aria-label="Increase quantity">+</button>' +
        '</div>' +
        '</div>';

      if (cfg.showQuotePriceInForm) {
        // The offer field always starts empty: the customer must enter their own
        // price (we never pre-fill the original price). Only a value the customer
        // already typed for this item is restored when the form re-renders.
        var existingQp = item.offerPrice != null ? item.offerPrice : "";
        var activeQp = (existingQp && !isNaN(parseFloat(existingQp))) ? parseFloat(existingQp) : NaN;
        var qpStr = !isNaN(activeQp) ? activeQp.toFixed(2) : "";
        var initTotal = (!isNaN(activeQp) && qty) ? (activeQp * parseInt(qty, 10)) : 0;
        var initTotalStr = initTotal > 0 ? formatPrice(initTotal) : "";
        var showCalc = initTotal > 0;
        var displayStyle = showCalc ? "inline-flex" : "none";
        h += '<div style="display:flex; align-items:center; gap:4px; flex:1; max-width:170px;">' +
          '<span style="font-size:13px; color:#6d7175;">' + esc(app.t('offer_label', 'Offer ')) + '</span>' +
          '<div class="qr-prod-qprice-input-wrap">' +
          '<span class="qr-prod-qprice-sym">' + esc(_sym) + '</span>' +
          '<input type="number" id="qr-prod-qprice-' + i + '" min="0" step="0.01" placeholder="' + esc(app.t('offer_placeholder', 'Enter price')) + '"' +
          (qpStr ? ' value="' + qpStr + '"' : '') + '>' +
          '</div>' +
          '</div>' +
          '<div style="display:flex; align-items:center; gap:4px; flex-shrink:0;">' +
          '<span style="font-size:12px; color:#94a3b8; font-weight:500; display:' + displayStyle + ';">=</span>' +
          '<span id="qr-prod-total-' + i + '" style="font-size:13px; font-weight:600; color:#0f172a; background:#f1f5f9; border:1px solid #cbd5e1; border-radius:6px; padding:0 8px; height:32px; display:' + displayStyle + '; align-items:center; box-sizing:border-box; white-space:nowrap;">' +
          esc(initTotalStr) + '</span>' +
          '</div>';
      }

      h += '</div>';
      h += '</div>';
      return h;
    }).join("");

    productsEl.querySelectorAll(".qr-prod-img").forEach(function (imgEl) {
      imgEl.addEventListener("error", function () {
        var ph = document.createElement("div");
        ph.className = "qr-prod-img-ph";
        imgEl.parentNode.insertBefore(ph, imgEl);
        imgEl.style.display = "none";
      });
    });

    _applyQuoteEmptyState(false);
  }
  app._renderProductList = _renderProductList;

  // ── Modal management ───────────────────────────────────────────────────────
  function openQRModal() {
    if (context.isProductPage && state.currentProduct) {
      var pageQtyInput = document.querySelector('form[action*="/cart"] [name="quantity"], .product-form [name="quantity"], [name="quantity"]');
      if (pageQtyInput) {
        var pageQty = parseInt(pageQtyInput.value, 10);
        if (!isNaN(pageQty) && pageQty > 0) {
          state.currentProduct.quantity = pageQty;
        }
      }
    }
    _renderProductList();
    showQRStep(1);

    var msg = document.getElementById("qr-success-msg");
    if (msg && state.cfg) msg.textContent = state.cfg.thankYouMessage || app.t("success_message_default", "Thank you! We will be in touch shortly.");

    context.backdrop.style.display = "flex";
    context.backdrop.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";

    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        context.backdrop.classList.add("qr-active");
        context.modal.classList.add("qr-active");
      });
    });
  }
  app.openQRModal = openQRModal;

  function closeQRModal() {
    context.backdrop.classList.remove("qr-active");
    context.modal.classList.remove("qr-active");
    setTimeout(function () {
      context.backdrop.style.display = "none";
      context.backdrop.setAttribute("aria-hidden", "true");
      document.body.style.overflow = "";
      resetQRForm();
    }, 360);
  }
  app.closeQRModal = closeQRModal;

  function resetQRForm() {
    ["qr-fullname", "qr-email", "qr-phone", "qr-company", "qr-message"]
      .forEach(function (id) { var el = document.getElementById(id); if (el) el.value = ""; });
    if (state.dynamicFields) {
      state.dynamicFields.forEach(function (item) {
        var field = item.field;
        var fid = item.id;
        var ft = (field.type || "").toLowerCase().trim();
        if (ft === "checkbox") {
          var el = document.getElementById(fid); if (el) el.checked = false;
        } else if (ft === "radio group" || ft === "radio") {
          document.querySelectorAll('input[name="' + fid + '"]').forEach(function (el) { el.checked = false; });
        } else if (ft !== "paragraph") {
          var el = document.getElementById(fid);
          if (el) {
            el.value = "";
            if (ft === "file upload" || ft === "file" || ft === "fileupload") {
              el._files = [];
              _renderFilePreviews(el);
            }
          }
        }
      });
    }
    clearQRErrors();
    var se = document.getElementById("qr-submit-error");
    if (se) se.classList.add("qr-hidden");
    var sb = document.getElementById("qr-submit-btn");
    if (sb) {
      sb.disabled = false;
      sb.textContent = (state.cfg && state.cfg.submitButtonText) || app.t("submit_button_default", "Send Quote Request");
    }
    showQRStep(1);
    var success = document.getElementById("qr-success");
    if (success) success.classList.add("qr-hidden");
    state.currentProduct = context.pd;
  }

  // ── Step Navigation ────────────────────────────────────────────────────────
  function qrNextStep(target) {
    var cur = getCurrentStep();
    if (cur === 2 && target > 2 && !validateContact()) return;
    if (target === 3) buildReview();
    showQRStep(target);
    updateQRStepIndicator(target);
    context.modal.scrollTop = 0;
    if (target === 2) {
      setTimeout(function () {
        var f = document.getElementById("qr-fullname") || document.querySelector("#qr-step-2 .qr-input");
        if (f) f.focus();
      }, 120);
    }
  }

  function getCurrentStep() {
    var v = document.querySelector(".qr-form-step:not(.qr-hidden)");
    return v ? (parseInt(v.id.replace("qr-step-", "")) || 1) : 1;
  }

  function showQRStep(step) {
    var body = document.querySelector(".qr-modal-body");
    document.querySelectorAll(".qr-form-step").forEach(function (s) { s.classList.add("qr-hidden"); });
    var success = document.getElementById("qr-success");
    if (step === "success") {
      if (body) body.classList.add("qr-hidden");
      if (success) success.classList.remove("qr-hidden");
      return;
    }
    if (body) body.classList.remove("qr-hidden");
    if (success) success.classList.add("qr-hidden");
    var t = document.getElementById("qr-step-" + step);
    if (t) t.classList.remove("qr-hidden");
  }

  function updateQRStepIndicator(active) {
    document.querySelectorAll(".qr-step").forEach(function (dot) {
      dot.classList.toggle("qr-step--active", parseInt(dot.dataset.step) <= active);
    });
  }

  // ── Form Validation ────────────────────────────────────────────────────────
  function validateContact() {
    clearQRErrors();
    if (state.dynamicFields) return validateDynamicStep(2);

    var fullname = (document.getElementById("qr-fullname") || {}).value || "";
    var email = (document.getElementById("qr-email") || {}).value || "";
    var phoneField = document.getElementById("qr-phone");
    var phoneWrap = document.getElementById("qr-field-phone");
    var phoneVisible = phoneWrap && !phoneWrap.classList.contains("qr-hidden");
    var phone = phoneField ? (phoneField.value || "").trim() : "";

    var schemaShape = {
      customerName: app.QRSchema.string().min(2, "Full name must be at least 2 characters").max(100, "Full name must be 100 characters or less"),
      customerEmail: app.QRSchema.string().min(1, "Email is required").max(100, "Email must be 100 characters or less").email("Enter a valid email address (e.g. name@example.com)"),
    };
    if (phoneVisible && phone) {
      schemaShape.customerPhone = app.QRSchema.string().phone("Enter a valid phone number (7–15 digits)");
    }

    var result = app.QRSchema.object(schemaShape).safeParse({
      customerName: fullname,
      customerEmail: email,
      customerPhone: phone,
    });

    if (!result.success) {
      if (result.errors.customerName) showFieldErr("qr-fullname", "qr-fullname-err", result.errors.customerName);
      if (result.errors.customerEmail) showFieldErr("qr-email", "qr-email-err", result.errors.customerEmail);
      if (result.errors.customerPhone) showFieldErr("qr-phone", "qr-phone-err", result.errors.customerPhone);
      return false;
    }
    return true;
  }

  function showFieldErr(inputId, errId, msg) {
    var input = document.getElementById(inputId);
    var err = document.getElementById(errId);
    if (input) input.classList.add("qr-input-error");
    if (err) { err.textContent = msg; err.style.display = "block"; }
  }
  app.showFieldErr = showFieldErr;

  function clearQRErrors() {
    document.querySelectorAll(".qr-field-error").forEach(function (el) { el.textContent = ""; el.style.display = "none"; });
    document.querySelectorAll(".qr-input-error").forEach(function (el) { el.classList.remove("qr-input-error"); });
  }

  function _clearFieldErr(inputId, errId) {
    var input = document.getElementById(inputId);
    var err = document.getElementById(errId);
    if (input) input.classList.remove("qr-input-error");
    if (err) { err.textContent = ""; err.style.display = "none"; }
  }

  document.addEventListener("input", function (e) {
    var target = e.target;
    if (!target || !target.classList.contains("qr-input")) return;
    if (!target.classList.contains("qr-input-error")) return;
    var id = target.id;
    var v = target.value.trim();
    if (id === "qr-fullname" && v) {
      _clearFieldErr("qr-fullname", "qr-fullname-err");
    } else if (id === "qr-email") {
      if (v && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) _clearFieldErr("qr-email", "qr-email-err");
    } else if (id === "qr-phone") {
      var _ph = v.replace(/[\s\-\(\)\.]/g, "");
      if (!v || /^\+?[0-9]{7,15}$/.test(_ph)) _clearFieldErr("qr-phone", "qr-phone-err");
    } else if (id.indexOf("qr-df-") === 0) {
      if (v) _clearFieldErr(id, id + "-err");
    }
  });

  // ── Review Panel ───────────────────────────────────────────────────────────
  function getFormData() {
    if (state.dynamicFields) {
      var result = { customerName: "", customerEmail: "", customerPhone: null, companyName: null, quantity: null, message: null, _fields: [], _firstName: "", _lastName: "" };
      state.dynamicFields.forEach(function (item) {
        var field = item.field;
        var fid = item.id;
        var ft = (field.type || "").toLowerCase().trim();
        if (ft === "paragraph") return;
        var value = "";
        if (ft === "checkbox") {
          var el = document.getElementById(fid);
          value = (el && el.checked) ? (field.label || "Yes") : "";
        } else if (ft === "radio group" || ft === "radio") {
          var sel = document.querySelector('input[name="' + fid + '"]:checked');
          value = sel ? sel.value : "";
        } else if (ft === "phone") {
          var numEl = document.getElementById(fid);
          var codeEl = document.getElementById(fid + "-code");
          value = numEl ? (numEl.value || "").trim() : "";
          if (value && codeEl && codeEl.value) value = codeEl.value + " " + value;
        } else {
          var el = document.getElementById(fid);
          if (ft === "file upload" || ft === "file" || ft === "fileupload") {
            result._fields.push({ id: fid, label: field.label || field.type, value: [], _fileInput: el, _multiple: !!field.multiple });
            return;
          }
          value = el ? (el.value || "").trim() : "";
        }
        var lbl = (field.label || "").toLowerCase();
        if (ft === "email" || lbl.indexOf("email") !== -1) {
          result.customerEmail = value;
        } else if (ft === "phone" || lbl.indexOf("phone") !== -1) {
          result.customerPhone = value || null;
        } else if (lbl.indexOf("company") !== -1 || lbl.indexOf("organisation") !== -1 || lbl.indexOf("organization") !== -1) {
          result.companyName = value || null;
        } else if (lbl.indexOf("quantity") !== -1 || lbl.indexOf("qty") !== -1) {
          result.quantity = value || null;
        } else if (lbl === "message" || lbl.indexOf("message") !== -1 || lbl.indexOf("comment") !== -1) {
          result.message = value || null;
        } else if ((lbl === "first name" || lbl.indexOf("first") !== -1) && !result._firstName) {
          result._firstName = value;
        } else if ((lbl === "last name" || lbl.indexOf("last") !== -1) && !result._lastName) {
          result._lastName = value;
        } else if (lbl.indexOf("name") !== -1 && !result.customerName) {
          result.customerName = value;
        }
        result._fields.push({ label: field.label || field.type, value: value });
      });
      if (result._firstName || result._lastName) {
        result.customerName = ((result._firstName || "") + " " + (result._lastName || "")).trim();
      }
      return result;
    }
    var get = function (id) { var el = document.getElementById(id); return (el && el.value.trim()) || ""; };
    var _pNum = get("qr-phone");
    var _pCode = document.getElementById("qr-phone-code");
    var _pVal = _pNum ? ((_pCode && _pCode.value) ? _pCode.value + " " + _pNum : _pNum) : null;
    return {
      customerName: get("qr-fullname"),
      customerEmail: get("qr-email"),
      customerPhone: _pVal,
      companyName: get("qr-company") || null,
      message: get("qr-message") || null,
      _fields: null,
    };
  }

  function buildReview() {
    var d = getFormData();
    var reviewHtml = "";

    var qrCart = getQrCart();
    var items = qrCart && qrCart.length > 0
      ? qrCart
      : (state.currentProduct && (state.currentProduct.productTitle || state.currentProduct.productId)
        ? [state.currentProduct]
        : []);

    if (items.length > 0) {
      reviewHtml += '<p style="font-size:11px;font-weight:700;color:#999;text-transform:uppercase;letter-spacing:0.07em;margin:0 0 8px;">' + esc(app.t('review_products', 'Products')) + '</p>';
      items.forEach(function (item, i) {
        var title = item.productTitle || item.title || "Product";
        var variant = item.variantTitle && item.variantTitle !== "Default Title" ? " — " + item.variantTitle : "";
        var qty = item.quantity || 1;
        var qpEl = document.getElementById("qr-prod-qprice-" + i);
        var noteEl = document.getElementById("qr-prod-note-" + i);
        var qpVal = qpEl ? qpEl.value.trim() : "";
        var noteVal = noteEl ? noteEl.value.trim() : "";
        reviewHtml +=
          '<div style="margin-bottom:8px;">' +
          '<div style="display:flex;justify-content:space-between;align-items:baseline;">' +
          '<span style="font-size:13px;color:#1a1a18;">' + esc(title + variant) + '</span>' +
          '<span style="font-size:12px;color:#999;flex-shrink:0;margin-left:12px;">' + esc(app.t('product_qty_label', 'Qty ')) + Number(qty) + '</span>' +
          '</div>' +
          (qpVal ? '<div style="font-size:12px;color:#555;margin-top:2px;">' + esc(app.t('review_your_price', 'Your Price:')) + ' ' + esc(qpVal) + '</div>' : '') +
          (noteVal ? '<div style="font-size:12px;color:#888;margin-top:2px;font-style:italic;">' + esc(noteVal) + '</div>' : '') +
          '</div>';
      });
      reviewHtml += '<div style="margin:12px 0 14px;border-top:1px solid #ebebeb;"></div>';
    }

    reviewHtml += '<p style="font-size:11px;font-weight:700;color:#999;text-transform:uppercase;letter-spacing:0.07em;margin:0 0 8px;">' + esc(app.t('review_contact', 'Contact')) + '</p>';
    var contactRows = [];
    if (d._fields) {
      d._fields.forEach(function (f) { if (f.value) contactRows.push([f.label, f.value]); });
    } else {
      if (d.customerName) contactRows.push([app.t("review_name", "Name"), d.customerName]);
      if (d.customerEmail) contactRows.push([app.t("review_email", "Email"), d.customerEmail]);
      if (d.customerPhone) contactRows.push([app.t("review_phone", "Phone"), d.customerPhone]);
      if (d.companyName) contactRows.push([app.t("review_company", "Company"), d.companyName]);
      if (d.message) contactRows.push([app.t("review_message", "Message"), d.message]);
    }
    reviewHtml += contactRows.map(function (pair) {
      return '<div style="display:flex;gap:10px;margin-bottom:6px;">' +
        '<span style="font-size:13px;font-weight:600;color:#888;min-width:60px;flex-shrink:0;">' + esc(pair[0]) + '</span>' +
        '<span style="font-size:13px;color:#1a1a18;word-break:break-word;">' + esc(pair[1]) + '</span>' +
        '</div>';
    }).join("");

    document.getElementById("qr-review-content").innerHTML = reviewHtml;
  }

  // ── Modal Submit ──────────────────────────────────────────────────────────
  async function submitQRForm() {
    var sb = document.getElementById("qr-submit-btn");
    var se = document.getElementById("qr-submit-error");
    // A quote must contain at least one product.
    if (getQrCart().length === 0) {
      if (se) {
        se.textContent = app.t("error_no_products", "Please add at least one product before requesting a quote.");
        se.classList.remove("qr-hidden");
      }
      _setSubmitEnabled(false);
      return;
    }
    if (!validateContact()) return;
    var d = getFormData();
    var p = state.currentProduct;

    if (!d.customerEmail) {
      if (se) {
        se.textContent = app.t("error_email_required", "Email address is required.");
        se.classList.remove("qr-hidden");
      }
      return;
    }

    if (sb) { sb.disabled = true; sb.textContent = app.t("sending", "Sending…"); }
    if (se) se.classList.add("qr-hidden");

    var rate = app.getRate();
    var activeCurrency = (window.Shopify && window.Shopify.currency && window.Shopify.currency.active) || (state.cfg && state.cfg.shopCurrency) || "USD";

    var qrCart = getQrCart();
    var submitBody = {
      shop: context.shop,
      shopCurrency: activeCurrency,
      customerName: d.customerName,
      customerEmail: d.customerEmail,
      customerPhone: d.customerPhone || null,
      companyName: d.companyName || null,
      message: d.message || null,
    };

    var baseItems = qrCart && qrCart.length > 0
      ? qrCart
      : (p && (p.productId || p.productTitle) ? [p] : []);
    var enrichedItems = baseItems.map(function (item, i) {
      var qpEl = document.getElementById("qr-prod-qprice-" + i);
      var noteEl = document.getElementById("qr-prod-note-" + i);
      var qtyEl = document.getElementById("qr-prod-qty-" + i);

      var itemPrice = item.productPrice || item.price || "";
      var activeProdPrice = itemPrice ? (parseFloat(itemPrice) * rate).toFixed(2) : "";

      // When the merchant shows the offer field the customer's entry is the
      // only source of truth — never fall back to the original price (an empty
      // field is blocked by validation below). Only default to the original
      // price when the offer field is not shown at all.
      var offerShown = !!(state.cfg && state.cfg.showQuotePriceInForm);
      var qpVal;
      if (qpEl && qpEl.value.trim()) {
        qpVal = parseFloat(qpEl.value) || null;
      } else if (offerShown) {
        qpVal = null;
      } else {
        qpVal = item.offerPrice != null ? (parseFloat(item.offerPrice) * rate).toFixed(2) : (activeProdPrice || null);
      }
      var noteVal = noteEl && noteEl.value.trim() ? noteEl.value.trim() : (item.note || "");
      var qtyVal = qtyEl ? parseInt(qtyEl.value, 10) : (parseInt(item.quantity, 10) || 1);

      return Object.assign({}, item, {
        productId: item.productId ? String(item.productId) : "",
        price: activeProdPrice,
        productPrice: activeProdPrice,
        offerPrice: qpVal,
        note: noteVal,
        quantity: qtyVal
      });
    });

    var offerRequired = !!(state.cfg && state.cfg.showQuotePriceInForm);
    for (var k = 0; k < enrichedItems.length; k++) {
      if (!enrichedItems[k].quantity || enrichedItems[k].quantity < 1) {
        if (se) {
          se.textContent = app.t("error_invalid_quantity", "Please enter a valid quantity for all items.");
          se.classList.remove("qr-hidden");
        }
        if (sb) { sb.disabled = false; sb.textContent = app.t("request_a_quote", "Request a Quote"); }
        return;
      }
      // Offer price is mandatory whenever the merchant shows the offer field:
      // the customer must enter their own price (checked against the raw input,
      // since enrichedItems is now null rather than the original price).
      if (offerRequired) {
        var offEl = document.getElementById("qr-prod-qprice-" + k);
        var offRaw = offEl ? offEl.value.trim() : "";
        var offNum = parseFloat(offRaw);
        if (!offRaw || isNaN(offNum) || offNum <= 0) {
          if (se) {
            se.textContent = app.t("error_offer_required", "Please enter your offer price for all items.");
            se.classList.remove("qr-hidden");
          }
          if (sb) { sb.disabled = false; sb.textContent = app.t("request_a_quote", "Request a Quote"); }
          if (offEl) { try { offEl.focus(); } catch (e) { } }
          return;
        }
      }
    }

    if (enrichedItems.length > 0) {
      submitBody.cartItems = enrichedItems;
      submitBody.productId = enrichedItems[0].productId ? String(enrichedItems[0].productId) : "";
      submitBody.productTitle = enrichedItems[0].productTitle || "";
    } else {
      submitBody.productId = p ? (p.productId ? String(p.productId) : "") : "";
      submitBody.productTitle = p ? (p.productTitle || "") : "";
    }

    if (d._fields && d._fields.length) {
      var uploadedFields = await _uploadFileFields(d._fields);
      if (!uploadedFields) {
        if (sb) { sb.disabled = false; sb.textContent = app.t("request_a_quote", "Request a Quote"); }
        return;
      }
      d._fields = uploadedFields;
      submitBody.formFields = d._fields;
    }

    fetch(app.proxyUrl("/api/quote"), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(submitBody),
    })
      .then(function (res) {
        // Read as text first: the App Proxy can return an HTML error page
        // (e.g. "third-party application error") instead of JSON, and calling
        // res.json() on that throws an opaque "Unexpected token '<'" error.
        return res.text().then(function (text) {
          var json = null;
          try { json = JSON.parse(text); } catch (e) { /* non-JSON response */ }
          if (!res.ok || !json || !json.success) {
            throw new Error(
              (json && json.error) ||
              app.t("error_submission_generic", "We couldn't submit your request right now. Please try again in a moment.")
            );
          }
          saveQrCart([]);
          var msgText = (state.cfg && state.cfg.thankYouMessage) || app.t("success_message_default", "Thank you! We will be in touch shortly.");
          // Confirmation is handled by the toast notification — skip the
          // in-modal "Quote Sent!" success screen and just close the modal.
          showToast(msgText, true);
          closeQRModal();
        });
      })
      .catch(function (err) {
        console.error("[QuoteRequest]", err.message);
        if (sb) { sb.disabled = false; sb.textContent = (state.cfg && state.cfg.submitButtonText) || app.t("submit_button_default", "Send Quote Request"); }
        if (se) {
          se.textContent = err.message || app.t("error_banner_generic", "Something went wrong. Please try again.");
          se.classList.remove("qr-hidden");
        }
      });
  }
  app.submitQRForm = submitQRForm;

  // Static button binds
  var closeBtn = document.getElementById("qr-close-btn");
  if (closeBtn) closeBtn.onclick = closeQRModal;
  var successClose = document.getElementById("qr-success-close");
  if (successClose) successClose.onclick = closeQRModal;
  var submitBtn = document.getElementById("qr-submit-btn");
  if (submitBtn) submitBtn.onclick = submitQRForm;

  // Step 1 Product-list delegation
  var _productsContainer = document.getElementById("qr-step1-products");
  if (_productsContainer) {
    _productsContainer.addEventListener("click", function (e) {
      var noteBtn = e.target.closest(".qr-prod-note-btn");
      if (noteBtn) {
        var noteEl = document.getElementById(noteBtn.dataset.note);
        if (!noteEl) return;
        var isOpen = noteEl.classList.contains("qr-note-open");
        noteEl.classList.toggle("qr-note-open", !isOpen);
        var txtEl = noteBtn.querySelector(".qr-note-text");
        if (txtEl) {
          txtEl.textContent = isOpen ? app.t("note_add", "Add note") : app.t("note_hide", "Hide note");
        }
        return;
      }
      var qtyBtn = e.target.closest("button[data-qty-idx]");
      if (qtyBtn) {
        var idx = parseInt(qtyBtn.getAttribute("data-qty-idx"), 10);
        var delta = parseInt(qtyBtn.getAttribute("data-qty-delta"), 10);
        var qrCart = getQrCart();
        if (qrCart && qrCart.length > 0) {
          var item = qrCart[idx];
          if (item) {
            item.quantity = Math.max(1, (parseInt(item.quantity, 10) || 1) + delta);
            saveQrCart(qrCart);
          }
        } else if (state.currentProduct) {
          state.currentProduct.quantity = Math.max(1, (parseInt(state.currentProduct.quantity, 10) || 1) + delta);
        }
        _renderProductList();
        return;
      }
      var removeBtn = e.target.closest(".qr-prod-remove");
      if (removeBtn) {
        var idx = parseInt(removeBtn.getAttribute("data-remove-idx"), 10);
        var qrCart = getQrCart();
        if (qrCart && qrCart.length > 0) {
          qrCart.splice(idx, 1);
          saveQrCart(qrCart);
        } else {
          state.currentProduct = null;
        }
        _renderProductList();
      }
    });

    _productsContainer.addEventListener("input", function (e) {
      var target = e.target;
      var qrCart = getQrCart();
      var isCart = qrCart && qrCart.length > 0;

      function _updateLineTotal(tidx) {
        var priceEl = document.getElementById("qr-prod-qprice-" + tidx);
        var qtyEl   = document.getElementById("qr-prod-qty-"    + tidx);
        var totEl   = document.getElementById("qr-prod-total-"  + tidx);
        if (!totEl) return;
        var p = priceEl ? parseFloat(priceEl.value) : NaN;
        var q = qtyEl   ? parseInt(qtyEl.value, 10) : NaN;
        if (!isNaN(p) && p > 0 && !isNaN(q) && q > 0) {
          totEl.textContent = formatPrice(p * q);
          totEl.style.display = "inline-flex";
          if (totEl.previousElementSibling) totEl.previousElementSibling.style.display = "inline-flex";
        } else {
          totEl.textContent = "";
          totEl.style.display = "none";
          if (totEl.previousElementSibling) totEl.previousElementSibling.style.display = "none";
        }
      }

      if (target.id && target.id.indexOf("qr-prod-qprice-") === 0) {
        var idx = parseInt(target.id.replace("qr-prod-qprice-", ""), 10);
        var activeVal = parseFloat(target.value);
        var rate = app.getRate();
        var shopVal = (!isNaN(activeVal) && activeVal >= 0) ? (activeVal / rate).toFixed(2) : null;
        if (isCart && qrCart[idx]) {
          qrCart[idx].offerPrice = shopVal;
          saveQrCart(qrCart);
        } else if (state.currentProduct) {
          state.currentProduct.offerPrice = shopVal;
        }
        _updateLineTotal(idx);
      }
      if (target.id && target.id.indexOf("qr-prod-note-") === 0) {
        var idx = parseInt(target.id.replace("qr-prod-note-", ""), 10);
        if (isCart && qrCart[idx]) {
          qrCart[idx].note = target.value;
          saveQrCart(qrCart);
        } else if (state.currentProduct) {
          state.currentProduct.note = target.value;
        }
      }
      if (target.id && target.id.indexOf("qr-prod-qty-") === 0) {
        var idx = parseInt(target.id.replace("qr-prod-qty-", ""), 10);
        var val = parseInt(target.value, 10);
        if (isNaN(val) || val < 1) val = 1;
        if (isCart && qrCart[idx]) {
          qrCart[idx].quantity = val;
          saveQrCart(qrCart);
        } else if (state.currentProduct) {
          state.currentProduct.quantity = val;
        }
        _updateLineTotal(idx);
      }
    });

    _productsContainer.addEventListener("keydown", function (e) {
      if (e.target.id && e.target.id.indexOf("qr-prod-qty-") === 0) {
        if (["e", "E", "+", "-", "."].includes(e.key)) {
          e.preventDefault();
        }
      }
      if (e.target.id && e.target.id.indexOf("qr-prod-qprice-") === 0) {
        if (["e", "E", "+", "-"].includes(e.key)) {
          e.preventDefault();
        }
      }
    });

    _productsContainer.addEventListener("focusout", function (e) {
      var target = e.target;
      if (target.id && target.id.indexOf("qr-prod-qty-") === 0) {
        var val = parseInt(target.value, 10);
        if (isNaN(val) || val < 1) {
          target.value = 1;
          var idx = parseInt(target.id.replace("qr-prod-qty-", ""), 10);
          var qrCart = getQrCart();
          if (qrCart && qrCart.length > 0 && qrCart[idx]) {
            qrCart[idx].quantity = 1;
            saveQrCart(qrCart);
          } else if (state.currentProduct) {
            state.currentProduct.quantity = 1;
          }
        }
      }
      if (target.id && target.id.indexOf("qr-prod-qprice-") === 0) {
        var pval = parseFloat(target.value);
        if (!isNaN(pval) && pval < 0) {
          target.value = "";
          var pidx = parseInt(target.id.replace("qr-prod-qprice-", ""), 10);
          var qrCart = getQrCart();
          if (qrCart && qrCart.length > 0 && qrCart[pidx]) {
            qrCart[pidx].offerPrice = null;
            saveQrCart(qrCart);
          } else if (state.currentProduct) {
            state.currentProduct.offerPrice = null;
          }
        }
      }
    });
  }

  if (context.backdrop) {
    context.backdrop.addEventListener("click", function (e) { if (e.target === context.backdrop) closeQRModal(); });
  }
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && context.backdrop && context.backdrop.style.display !== "none") closeQRModal();
  });

  // ── Floating widget ───────────────────────────────────────────────────────
  function injectFloatingWidget(cfg) {
    var btn = document.createElement("button");
    btn.id = "qr-widget";
    btn.textContent = cfg.widgetButtonText || app.t("request_a_quote", "Request a Quote");

    var pos = cfg.widgetPosition || "bottom_right";
    var isRight = pos.indexOf("right") !== -1;
    var isHalf = pos.indexOf("half") !== -1;
    var isTop = pos.indexOf("top") !== -1;

    var css = [
      "position:fixed",
      "z-index:2147483647",
      "border:none",
      "cursor:pointer",
      "font-weight:600",
      "font-family:inherit",
      "line-height:1",
      "box-shadow:0 4px 16px rgba(0,0,0,0.18)",
      "transition:opacity 0.15s,transform 0.1s",
      "background:" + (cfg.widgetBgColor || "#1a1a18"),
      "color:" + (cfg.widgetTextColor || "#ffffff"),
    ];

    if (!isHalf) {
      css.push("border-radius:8px", "padding:12px 20px", "font-size:14px");
      css.push("bottom:24px");
      css.push(isRight ? "right:24px" : "left:24px");
    } else {
      css.push("font-size:13px", "padding:14px 8px");
      css.push("writing-mode:vertical-rl");
      css.push(isTop ? "top:30%" : "bottom:30%");
      if (isRight) {
        css.push("right:0", "border-radius:8px 0 0 8px", "transform:rotate(180deg)");
      } else {
        css.push("left:0", "border-radius:0 8px 8px 0");
      }
    }

    btn.style.cssText = css.join(";");

    // Cart-style count badge — shows how many products are in the quote cart.
    var badge = document.createElement("span");
    badge.id = "qr-widget-badge";
    badge.setAttribute("aria-hidden", "true");
    badge.style.cssText = [
      "position:absolute", "top:-8px", "right:-8px",
      "min-width:20px", "height:20px", "padding:0 5px", "box-sizing:border-box",
      "border-radius:10px", "background:var(--qr-error, #dc2626)", "color:#fff",
      "font-size:12px", "font-weight:700", "line-height:20px", "text-align:center",
      "writing-mode:horizontal-tb", "display:none",
      "box-shadow:0 1px 4px rgba(0,0,0,0.25)", "pointer-events:none",
    ].join(";");
    btn.appendChild(badge);

    btn.addEventListener("mouseenter", function () { btn.style.opacity = "0.88"; });
    btn.addEventListener("mouseleave", function () { btn.style.opacity = "1"; });
    btn.addEventListener("click", function () {
      if (cfg.requireLogin && !context.isLoggedIn) {
        window.location.href = "/account/login?return_url=" + encodeURIComponent(window.location.pathname);
        return;
      }
      openQRModal();
    });
    document.body.appendChild(btn);
    updateWidgetBadge();
    watchCartDrawer();
  }
  app.injectFloatingWidget = injectFloatingWidget;

  // ── Hide widget while a cart drawer/mini-cart is open ──────────────────────
  // The floating button is position:fixed bottom, so on mobile it overlaps the
  // cart drawer's Checkout button. Themes differ wildly, so we detect
  // an open drawer by its open-state markers (open attr, aria-hidden=false, or
  // an "open/active" class token) and hide the widget while it's showing.
  var QR_DRAWER_SELECTORS = [
    "cart-drawer", "#CartDrawer", ".cart-drawer", ".drawer--cart", "#cart-drawer",
    ".js-cart-drawer", ".mini-cart", ".mini_cart", ".cart-popup", ".cart-modal",
    "#sidebar-cart", ".header__cart-drawer", ".drawer.drawer--right", ".ajaxcart",
    "[data-cart-drawer]",
  ];
  var QR_OPEN_TOKENS = [
    "active", "open", "is-open", "is-active", "drawer--is-open", "drawer-open",
    "expanded", "visible", "opened", "is-visible", "showing", "js-active",
  ];

  function qrTokenMatch(el) {
    var raw = el.className && el.className.toString ? el.className.toString() : "";
    var tokens = raw.toLowerCase().split(/\s+/);
    for (var i = 0; i < QR_OPEN_TOKENS.length; i++) {
      if (tokens.indexOf(QR_OPEN_TOKENS[i]) !== -1) return true;
    }
    return false;
  }

  function isCartDrawerOpen() {
    // Body/html-level open flags some themes set when any drawer is open.
    var rootTokens = (
      (document.body.className || "") + " " + (document.documentElement.className || "")
    ).toLowerCase().split(/\s+/);
    var rootFlags = ["cart-drawer-open", "js-drawer-open", "drawer-open", "cart-open", "cart--opened", "js-cart-open"];
    for (var r = 0; r < rootFlags.length; r++) {
      if (rootTokens.indexOf(rootFlags[r]) !== -1) return true;
    }
    for (var s = 0; s < QR_DRAWER_SELECTORS.length; s++) {
      var nodes;
      try { nodes = document.querySelectorAll(QR_DRAWER_SELECTORS[s]); } catch (e) { continue; }
      for (var j = 0; j < nodes.length; j++) {
        var el = nodes[j];
        if (el.hasAttribute("open")) return true;
        if (el.getAttribute("aria-hidden") === "false") return true;
        if (qrTokenMatch(el)) return true;
      }
    }
    return false;
  }

  // The floating widget is fixed bottom-right; the theme cart drawer is
  // right-anchored with its Checkout button in a sticky bottom footer, so the
  // two overlap on EVERY viewport — not just mobile. The standalone
  // /cart page has the same problem. So the widget hides whenever a cart is
  // showing, regardless of width, so it never covers a checkout button.
  function isCartPage() {
    var p = ((window.location && window.location.pathname) || "").toLowerCase();
    return /(^|\/)cart\/?$/.test(p);
  }

  // Our own quote-cart / request modal is open. It covers the screen on every
  // viewport, so the floating widget must hide regardless of width — otherwise
  // it overlaps the modal's submit button (both mobile and desktop).
  function isQRModalOpen() {
    var bd = (context && context.backdrop) || document.getElementById("qr-backdrop");
    if (!bd) return false;
    return bd.classList.contains("qr-active") ||
      (bd.style.display && bd.style.display !== "none");
  }

  // ── Hide widget while ANY blocking overlay is open ─────────────────────────
  // Filter/facet drawers, nav menus, search overlays, newsletter popups,
  // lightboxes and generic modals all float over the page; the fixed widget
  // would sit on top of them. The reliable, theme-agnostic signal is that these
  // overlays lock body scroll (overflow-y:hidden) — verified on Dawn's mobile
  // "Filter and sort" drawer, which sets body{overflow:hidden} while open. We
  // complement that with explicit open-state class flags and visible native
  // dialogs, and restore the widget once the overlay closes.
  var QR_OVERLAY_ROOT_FLAGS = [
    "menu-open", "js-menu-open", "nav-open", "js-nav-open",
    "filters-open", "facets-open", "filter-open", "mobile-facets-open",
    "search-open", "search-modal-open", "modal-open", "modal--open",
    "popup-open", "lightbox-open", "overlay-open", "no-scroll", "scroll-lock",
  ];

  function _qrVisible(el) {
    if (!el) return false;
    var r = el.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) return false;
    var cs = null;
    try { cs = getComputedStyle(el); } catch (e) { }
    if (cs) {
      // A closed drawer often keeps its box (transformed off-screen) but is
      // visibility:hidden / opacity:0 — do not treat that as visible.
      if (cs.visibility === "hidden" || cs.display === "none" || parseFloat(cs.opacity) === 0) {
        return false;
      }
    }
    // position:fixed elements report offsetParent null even when visible.
    if (el.offsetParent !== null) return true;
    return cs ? cs.position === "fixed" : true;
  }

  // Body/html scroll is locked — the strongest signal a blocking overlay is up.
  // Check overflow-Y specifically so a theme's permanent overflow-x:hidden
  // (anti horizontal-scroll) does not read as a lock.
  function _rootScrollLocked() {
    try {
      if (getComputedStyle(document.body).overflowY === "hidden") return true;
      if (getComputedStyle(document.documentElement).overflowY === "hidden") return true;
    } catch (e) { }
    return false;
  }

  function isBlockingOverlayOpen() {
    if (_rootScrollLocked()) return true;
    var rootTokens = (
      (document.body.className || "") + " " + (document.documentElement.className || "")
    ).toLowerCase().split(/\s+/);
    for (var r = 0; r < QR_OVERLAY_ROOT_FLAGS.length; r++) {
      if (rootTokens.indexOf(QR_OVERLAY_ROOT_FLAGS[r]) !== -1) return true;
    }
    // Any open native <dialog> or aria-modal container that is actually visible.
    var dialogs;
    try { dialogs = document.querySelectorAll("dialog[open], [aria-modal='true']"); }
    catch (e) { dialogs = []; }
    for (var d = 0; d < dialogs.length; d++) {
      if (dialogs[d].getAttribute("aria-hidden") === "true") continue;
      if (_qrVisible(dialogs[d])) return true;
    }
    return false;
  }

  function applyCartDrawerState() {
    var btn = document.getElementById("qr-widget");
    if (!btn) return;
    // Hide on all viewports whenever our modal, the theme cart drawer, the
    // /cart page, or any blocking overlay (filter/menu/search/popup) is showing
    // — the widget must never cover another surface's actions.
    if (isQRModalOpen() || isCartDrawerOpen() || isCartPage() || isBlockingOverlayOpen()) {
      if (btn.getAttribute("data-qr-cart-hidden") !== "1") {
        btn.setAttribute("data-qr-cart-hidden", "1");
        btn.setAttribute("data-qr-prev-display", btn.style.display || "");
        btn.style.display = "none";
      }
    } else if (btn.getAttribute("data-qr-cart-hidden") === "1") {
      btn.removeAttribute("data-qr-cart-hidden");
      btn.style.display = btn.getAttribute("data-qr-prev-display") || "";
      btn.removeAttribute("data-qr-prev-display");
    }
  }

  function watchCartDrawer() {
    if (app._cartWatchOn) { applyCartDrawerState(); return; }
    app._cartWatchOn = true;
    var scheduled = false;
    var schedule = function () {
      if (scheduled) return;
      scheduled = true;
      (window.requestAnimationFrame || window.setTimeout)(function () {
        scheduled = false;
        applyCartDrawerState();
      }, 0);
    };
    try {
      var mo = new MutationObserver(schedule);
      mo.observe(document.documentElement, {
        subtree: true,
        attributes: true,
        attributeFilter: ["class", "open", "aria-hidden", "style"],
        childList: true,
      });
    } catch (e) { /* observer unsupported — fall back to events/poll */ }
    // Cart toggles are often clicks/links; re-check right after interaction.
    document.addEventListener("click", schedule, true);
    document.addEventListener("keyup", schedule, true);
    // Re-evaluate on resize/rotate so the widget's state stays correct as the
    // layout reflows while a drawer is open.
    window.addEventListener("resize", schedule);
    window.addEventListener("orientationchange", schedule);
    applyCartDrawerState();
  }

  // Reflect the number of products in the quote cart on the widget badge.
  function updateWidgetBadge() {
    var badge = document.getElementById("qr-widget-badge");
    if (!badge) return;
    var count = getQrCart().length;
    if (count > 0) {
      badge.textContent = count > 99 ? "99+" : String(count);
      badge.style.display = "block";
    } else {
      badge.style.display = "none";
    }
  }
  app.updateWidgetBadge = updateWidgetBadge;


})();

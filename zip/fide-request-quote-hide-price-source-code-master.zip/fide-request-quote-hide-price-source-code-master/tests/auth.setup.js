/**
 * Authentication setup for Playwright tests.
 *
 * Connects to YOUR already-running Chrome (which is logged into Shopify admin)
 * via Chrome DevTools Protocol (CDP) on port 9222, then saves the session
 * cookies to tests/auth-state.json so all test files reuse it automatically.
 *
 * One-time setup:
 *   1. Start Chrome with a remote debug port, e.g.:
 *        google-chrome --remote-debugging-port=9222 --user-data-dir=/tmp/chrome-debug-profile
 *      (use a non-default --user-data-dir; Chrome requires this to enable remote debugging)
 *   2. Log into admin.shopify.com in that Chrome window
 *   3. npm run test:setup   ← saves your Shopify session
 *   4. npm test             ← runs all tests (no Chrome needed)
 */

import { test as setup, chromium } from "@playwright/test";
import path from "path";
import fs from "fs";
import { STORE, APP_KEY } from "./helpers.js";

const SHOPIFY_APP_URL = `https://admin.shopify.com/store/${STORE}/apps/${APP_KEY}`;
const AUTH_STATE_PATH = path.join("tests", "auth-state.json");
const CDP_URL = "http://localhost:9222";

setup("save Shopify session from running Chrome", async () => {
  // Skip if auth state is fresh (< 12 hours)
  if (fs.existsSync(AUTH_STATE_PATH)) {
    const age = (Date.now() - fs.statSync(AUTH_STATE_PATH).mtimeMs) / 3_600_000;
    if (age < 12) {
      console.log(`Auth state is ${age.toFixed(1)}h old — skipping.`);
      return;
    }
  }

  // Connect to your running Chrome (must be started with --remote-debugging-port=9222)
  let browser;
  try {
    browser = await chromium.connectOverCDP(CDP_URL);
  } catch (err) {
    throw new Error(
      `Could not connect to Chrome on ${CDP_URL}.\n` +
      `Start Chrome first with:  google-chrome --remote-debugging-port=9222 --user-data-dir=/tmp/chrome-debug-profile\n` +
      `Original error:  ${err.message}`
    );
  }

  // Use the first (existing) browser context — this has all your cookies
  const context =
    browser.contexts()[0] ?? (await browser.newContext());

  const page = await context.newPage();

  console.log(`Navigating to Shopify admin app…`);
  await page.goto(SHOPIFY_APP_URL, { waitUntil: "networkidle", timeout: 30_000 });

  // Make sure we're actually in Shopify admin (not a login page)
  const url = page.url();
  if (!url.includes(`admin.shopify.com/store/${STORE}`)) {
    throw new Error(
      `Not logged in! Current URL: ${url}\n` +
      `Please log in to admin.shopify.com in Chrome and re-run this setup.`
    );
  }

  // Save all cookies + localStorage for the session
  await context.storageState({ path: AUTH_STATE_PATH });
  console.log(`✓ Auth state saved to ${AUTH_STATE_PATH}`);

  await page.close();
  await browser.close();
});

/**
 * Email Template editors — verifies all 4 templates load with correct content.
 */
import { test, expect } from "@playwright/test";
import { appFrame, waitForApp, STORE, APP_KEY } from "./helpers.js";

const BASE = `https://admin.shopify.com/store/${STORE}/apps/${APP_KEY}`;

const TEMPLATES = [
  { id: "notification",   title: "Email Notification",  subjectHint: "New quote request" },
  { id: "auto-response",  title: "Auto Response Email",  subjectHint: "We received your"  },
  { id: "accept-quote",   title: "Email Accept Quote",   subjectHint: "has been accepted"  },
  { id: "reject-quote",   title: "Email Reject Quote",   subjectHint: "Update on your"     },
];

for (const tmpl of TEMPLATES) {
  test.describe(`Email — ${tmpl.title}`, () => {
    test.beforeEach(async ({ page }) => {
      await page.goto(`${BASE}/app/email-edit/${tmpl.id}`, { waitUntil: "domcontentloaded" });
      await waitForApp(page);
    });

    test(`page title is "${tmpl.title}"`, async ({ page }) => {
      const frame = appFrame(page);
      await expect(frame.getByRole("heading", { name: tmpl.title })).toBeVisible({ timeout: 20_000 });
    });

    test("Enabled / Disabled radio buttons are present", async ({ page }) => {
      const frame = appFrame(page);
      await expect(frame.getByLabel("Enabled")).toBeVisible({ timeout: 20_000 });
      await expect(frame.getByLabel("Disabled")).toBeVisible();
    });

    test("Subject field has a pre-filled default value", async ({ page }) => {
      const frame = appFrame(page);
      const subjectField = frame.getByLabel("Subject");
      await expect(subjectField).toBeVisible({ timeout: 20_000 });
      const value = await subjectField.inputValue().catch(() => "");
      expect(value.length, "Subject should have a default value").toBeGreaterThan(0);
    });

    test("Heading and Content fields are present and have values", async ({ page }) => {
      const frame = appFrame(page);
      const headingField  = frame.getByLabel("Heading");
      const contentField  = frame.getByLabel("Content");
      await expect(headingField).toBeVisible({ timeout: 20_000 });
      await expect(contentField).toBeVisible();
      expect((await headingField.inputValue()).length).toBeGreaterThan(0);
      expect((await contentField.inputValue()).length).toBeGreaterThan(0);
    });

    test("live preview panel shows subject and heading", async ({ page }) => {
      const frame = appFrame(page);
      await expect(frame.getByText("Preview")).toBeVisible({ timeout: 20_000 });
      // Preview section renders "Subject:" label
      await expect(frame.getByText(/Subject:/i).first()).toBeVisible();
    });

    test("Save and Send test buttons are present", async ({ page }) => {
      const frame = appFrame(page);
      await expect(frame.getByRole("button", { name: "Save" })).toBeVisible({ timeout: 20_000 });
      await expect(frame.getByRole("button", { name: "Send test" })).toBeVisible();
    });
  });
}

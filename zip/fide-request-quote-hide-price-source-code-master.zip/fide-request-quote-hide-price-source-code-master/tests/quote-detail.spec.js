/**
 * Quote Detail — verifies a real quote loads with correct data AND the new-quote form works.
 */
import { test, expect } from "@playwright/test";
import { appFrame, waitForApp, STORE, APP_KEY } from "./helpers.js";

const BASE        = `https://admin.shopify.com/store/${STORE}/apps/${APP_KEY}`;
const QUOTES_URL  = `${BASE}/app/quotes`;
const NEW_QUOTE   = `${BASE}/app/quote/new`;

test.describe("Quote Detail — open first real quote", () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(QUOTES_URL, { waitUntil: "domcontentloaded" });
    await waitForApp(page);
    const frame = appFrame(page);
    await expect(frame.getByText("All quotes")).toBeVisible({ timeout: 20_000 });
    // Skip if no quotes exist
    const hasQuotes = await frame.getByText("Quote ID").first().isVisible({ timeout: 10_000 }).catch(() => false);
    if (!hasQuotes) { test.skip(); return; }
    // Click the first row to open the detail
    await frame.locator('div[style*="14px 20px"]').first().click();
    await waitForApp(page);
  });

  test("quote number or customer name appears as page heading", async ({ page }) => {
    const frame = appFrame(page);
    await expect(frame.locator("h1, h2").first()).toBeVisible({ timeout: 20_000 });
    // Heading should not be empty
    const heading = await frame.locator("h1, h2").first().textContent();
    expect(heading?.trim().length).toBeGreaterThan(0);
  });

  test("customer Email field is visible and not empty", async ({ page }) => {
    const frame = appFrame(page);
    // Label is "Email" (short form) in the quote detail form
    const emailField = frame.getByLabel("Email").first();
    await expect(emailField).toBeVisible({ timeout: 20_000 });
    const value = await emailField.inputValue().catch(() => "");
    expect(value.length).toBeGreaterThan(0);
  });

  test("action buttons are present (Accept/Reject for open quotes; Reopen for closed)", async ({ page }) => {
    const frame = appFrame(page);
    // Accept + Reject appear on open quotes; Reopen appears on accepted/rejected quotes
    const hasAccept = await frame.getByRole("button", { name: "Accept" }).isVisible({ timeout: 10_000 }).catch(() => false);
    const hasReject = await frame.getByRole("button", { name: "Reject" }).isVisible({ timeout: 5_000 }).catch(() => false);
    const hasReopen = await frame.getByRole("button", { name: "Reopen" }).isVisible({ timeout: 5_000 }).catch(() => false);
    const hasMarkPaid = await frame.getByRole("button", { name: /Payment/i }).isVisible({ timeout: 5_000 }).catch(() => false);
    expect(hasAccept || hasReject || hasReopen || hasMarkPaid).toBe(true);
  });

  test("Timeline section is visible", async ({ page }) => {
    const frame = appFrame(page);
    // Section heading is "Timeline" (not "Internal Notes")
    await expect(frame.getByText("Timeline")).toBeVisible({ timeout: 20_000 });
  });

  test("navigation back to quotes list works", async ({ page }) => {
    const frame = appFrame(page);
    // Back button or breadcrumb
    const backBtn = frame.getByRole("button", { name: /back|Back|Quotes/i }).first();
    const hasBack = await backBtn.isVisible({ timeout: 5_000 }).catch(() => false);
    if (hasBack) {
      await backBtn.click();
      await expect(frame.getByRole("heading", { name: "Quote Lists" })).toBeVisible({ timeout: 20_000 });
    }
  });
});

test.describe("Quote Detail — new quote form", () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(NEW_QUOTE, { waitUntil: "domcontentloaded" });
    await waitForApp(page);
  });

  test("New Quote page title loads", async ({ page }) => {
    const frame = appFrame(page);
    await expect(frame.getByRole("heading", { name: "New Quote" })).toBeVisible({ timeout: 20_000 });
  });

  test("Name and Email fields are editable", async ({ page }) => {
    const frame = appFrame(page);
    // Labels are "Name" and "Email" (short form)
    const nameField  = frame.getByLabel("Name").first();
    const emailField = frame.getByLabel("Email").first();
    await expect(nameField).toBeVisible({ timeout: 20_000 });
    await expect(emailField).toBeVisible({ timeout: 20_000 });
    await nameField.fill("Test Customer");
    await expect(nameField).toHaveValue("Test Customer");
    await emailField.fill("test@example.com");
    await expect(emailField).toHaveValue("test@example.com");
  });

  test("Save button is present", async ({ page }) => {
    const frame = appFrame(page);
    await expect(frame.getByRole("button", { name: /Save|Create/i }).first()).toBeVisible({ timeout: 20_000 });
  });
});

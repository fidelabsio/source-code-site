/**
 * Quote Settings page — verifies both tabs load with real config data.
 */
import { test, expect } from "@playwright/test";
import { appFrame, waitForApp, STORE, APP_KEY } from "./helpers.js";

const URL = `https://admin.shopify.com/store/${STORE}/apps/${APP_KEY}/app/quote-settings`;

test.describe("Quote Settings page", () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(URL, { waitUntil: "domcontentloaded" });
    await waitForApp(page);
  });

  test("page has Quote Settings and Form Builder tabs", async ({ page }) => {
    const frame = appFrame(page);
    await expect(frame.getByRole("tab", { name: "Quote Settings" })).toBeVisible({ timeout: 20_000 });
    await expect(frame.getByRole("tab", { name: "Form Builder" })).toBeVisible();
  });

  test("Tab 1 — button label field is visible and has a value", async ({ page }) => {
    const frame = appFrame(page);
    // Label is "Button text" (line 1267 of quote-settings.jsx)
    const labelField = frame.getByLabel("Button text");
    await expect(labelField).toBeVisible({ timeout: 20_000 });
    const value = await labelField.inputValue().catch(() => "");
    expect(value.length, "Button text should not be empty").toBeGreaterThan(0);
  });

  test("Tab 1 — target mode (All / Specific products / Collections) is visible", async ({ page }) => {
    const frame = appFrame(page);
    await expect(frame.getByText(/All products|Specific products/i).first()).toBeVisible({ timeout: 20_000 });
  });

  test("Tab 1 — Hide Price section is visible", async ({ page }) => {
    const frame = appFrame(page);
    await expect(frame.getByText(/Hide Price|hide price/i).first()).toBeVisible({ timeout: 20_000 });
  });

  test("Tab 1 — Save changes button is present", async ({ page }) => {
    const frame = appFrame(page);
    await expect(
      frame.getByRole("button", { name: /Save/i }).first()
    ).toBeVisible({ timeout: 20_000 });
  });

  test("Tab 2 — Form Builder loads with default Contact fields", async ({ page }) => {
    const frame = appFrame(page);
    await frame.getByRole("tab", { name: "Form Builder" }).click();
    // Default fields: First name, Last name, Email address, Phone number
    await expect(frame.getByText(/First name/i).first()).toBeVisible({ timeout: 15_000 });
    await expect(frame.getByText(/Email address/i).first()).toBeVisible();
  });

  test("Tab 2 — Form Builder Save button is present", async ({ page }) => {
    const frame = appFrame(page);
    await frame.getByRole("tab", { name: "Form Builder" }).click();
    await expect(
      frame.getByRole("button", { name: /Save/i }).first()
    ).toBeVisible({ timeout: 15_000 });
  });
});

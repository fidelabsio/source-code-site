/**
 * Settings page — verifies email config and PDF template sections load with real data.
 */
import { test, expect } from "@playwright/test";
import { appFrame, waitForApp, STORE, APP_KEY } from "./helpers.js";

const URL = `https://admin.shopify.com/store/${STORE}/apps/${APP_KEY}/app/settings`;

test.describe("Settings page", () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(URL, { waitUntil: "domcontentloaded" });
    await waitForApp(page);
  });

  test("Settings page title loads", async ({ page }) => {
    const frame = appFrame(page);
    await expect(frame.getByRole("heading", { name: "Settings" })).toBeVisible({ timeout: 20_000 });
  });

  test("sidebar shows Email Settings and PDF Template nav items", async ({ page }) => {
    const frame = appFrame(page);
    await expect(frame.getByText("Email Settings")).toBeVisible({ timeout: 20_000 });
    await expect(frame.getByText("PDF Template")).toBeVisible();
  });

  test("Email Settings tab — SMTP section loads with provider dropdown", async ({ page }) => {
    const frame = appFrame(page);
    const providerSelect = frame.getByLabel("Email Provider");
    await expect(providerSelect).toBeVisible({ timeout: 20_000 });
    // Should have "Use the app's default email" as an option
    const selectedValue = await providerSelect.inputValue().catch(() => null);
    expect(selectedValue).not.toBeNull();
  });

  test("Email Settings tab — Admin Notification Email field is visible", async ({ page }) => {
    const frame = appFrame(page);
    await expect(frame.getByLabel("Admin Notification Email")).toBeVisible({ timeout: 20_000 });
  });

  test("Email Settings tab — four email toggle rows are visible", async ({ page }) => {
    const frame = appFrame(page);
    await expect(frame.getByText("Email Notification")).toBeVisible({ timeout: 20_000 });
    await expect(frame.getByText("Auto Response Email")).toBeVisible();
    await expect(frame.getByText("Email Accept Quote")).toBeVisible();
    await expect(frame.getByText("Email Reject Quote")).toBeVisible();
  });

  test("Email Settings tab — Save button works (click does not throw)", async ({ page }) => {
    const frame = appFrame(page);
    const saveBtn = frame.getByRole("button", { name: "Save" });
    await expect(saveBtn).toBeVisible({ timeout: 20_000 });
    await saveBtn.click();
    // Should show a toast or remain on page — no error dialog
    await page.waitForTimeout(1500);
    // Page should still be on settings
    await expect(frame.getByRole("heading", { name: "Settings" })).toBeVisible();
  });

  test("PDF Template tab — shows Quote PDF and Invoice PDF rows", async ({ page }) => {
    const frame = appFrame(page);
    await frame.getByText("PDF Template").click();
    await expect(frame.getByText("Quote PDF")).toBeVisible({ timeout: 15_000 });
    await expect(frame.getByText("Invoice PDF")).toBeVisible();
  });

  test("PDF Template tab — Edit buttons navigate to PDF editors", async ({ page }) => {
    const frame = appFrame(page);
    await frame.getByText("PDF Template").click();
    await expect(frame.getByText("Quote PDF")).toBeVisible({ timeout: 15_000 });
    // Two Edit buttons should be present
    const editBtns = frame.getByRole("button", { name: "Edit" });
    await expect(editBtns.first()).toBeVisible({ timeout: 5_000 });
  });
});

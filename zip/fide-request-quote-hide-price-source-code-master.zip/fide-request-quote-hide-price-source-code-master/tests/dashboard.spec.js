/**
 * Dashboard — verifies real data loads and all sections are functional.
 */
import { test, expect } from "@playwright/test";
import { gotoApp, appFrame, waitForApp } from "./helpers.js";

test.describe("Dashboard", () => {
  test.beforeEach(async ({ page }) => {
    await gotoApp(page);
    await waitForApp(page);
  });

  test("Overview page title loads", async ({ page }) => {
    const frame = appFrame(page);
    await expect(frame.getByRole("heading", { name: "Overview" })).toBeVisible({ timeout: 20_000 });
  });

  test("stats cards show real numbers (Total Quotes, This Month, Accepted, Revenue)", async ({ page }) => {
    const frame = appFrame(page);
    await expect(frame.getByText("Total Quotes").first()).toBeVisible({ timeout: 20_000 });
    await expect(frame.getByText("This Month").first()).toBeVisible();
    await expect(frame.getByText("Accepted").first()).toBeVisible();
    await expect(frame.getByText("Revenue").first()).toBeVisible();
  });

  test("setup guide card renders with progress bar", async ({ page }) => {
    const frame = appFrame(page);
    await expect(frame.getByText("Setup guide")).toBeVisible({ timeout: 20_000 });
    // Progress bar exists inside the setup card
    await expect(frame.locator('[class*="Polaris-ProgressBar"]').first()).toBeVisible({ timeout: 10_000 });
  });

  test("Recent Quotes section shows at least one quote row OR empty state", async ({ page }) => {
    const frame = appFrame(page);
    await expect(frame.getByText("Recent Quotes")).toBeVisible({ timeout: 20_000 });
    const hasRows  = await frame.getByText(/Customer/i).first().isVisible({ timeout: 5_000 }).catch(() => false);
    const hasEmpty = await frame.getByText("No quotes yet").isVisible({ timeout: 5_000 }).catch(() => false);
    expect(hasRows || hasEmpty).toBe(true);
  });

  test("View all button navigates to Quotes list", async ({ page }) => {
    const frame = appFrame(page);
    await frame.getByRole("button", { name: "View all" }).click();
    await expect(frame.getByRole("heading", { name: "Quote Lists" })).toBeVisible({ timeout: 20_000 });
  });
});

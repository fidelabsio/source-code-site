/**
 * Quotes List — verifies quote data loads, all controls work, and navigation is functional.
 */
import { test, expect } from "@playwright/test";
import { appFrame, waitForApp, STORE, APP_KEY } from "./helpers.js";

const URL = `https://admin.shopify.com/store/${STORE}/apps/${APP_KEY}/app/quotes`;

test.describe("Quotes list", () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(URL, { waitUntil: "domcontentloaded" });
    await waitForApp(page);
  });

  test("page title is 'Quote Lists'", async ({ page }) => {
    const frame = appFrame(page);
    await expect(frame.getByRole("heading", { name: "Quote Lists" })).toBeVisible({ timeout: 20_000 });
  });

  test("all status tabs are rendered: All quotes / Unread / Read / Cancelled / Accepted / Done", async ({ page }) => {
    const frame = appFrame(page);
    await expect(frame.getByText("All quotes")).toBeVisible({ timeout: 20_000 });
    await expect(frame.getByText("Unread").first()).toBeVisible();
    await expect(frame.getByText("Read").first()).toBeVisible();
    await expect(frame.getByText("Accepted").first()).toBeVisible();
  });

  test("column headers are visible when quotes exist (Quote ID, Status, Customer, Date)", async ({ page }) => {
    const frame = appFrame(page);
    await expect(frame.getByText("All quotes")).toBeVisible({ timeout: 20_000 });
    const hasTable = await frame.getByText("Quote ID").first().isVisible({ timeout: 15_000 }).catch(() => false);
    const hasEmpty = await frame.getByText("You have no quote requests yet").isVisible({ timeout: 5_000 }).catch(() => false);
    expect(hasTable || hasEmpty, "Should show quote table OR empty state").toBe(true);
  });

  test("clicking a quote row opens the quote detail page", async ({ page }) => {
    const frame = appFrame(page);
    // Only run this check if quotes exist
    const hasQuotes = await frame.getByText("Quote ID").first().isVisible({ timeout: 15_000 }).catch(() => false);
    if (!hasQuotes) {
      test.skip();
      return;
    }
    // Click on the first data row (below the header)
    const firstDataRow = frame.locator('div[style*="14px 20px"]').first();
    await firstDataRow.click();
    // Detail page should load — title will be a quote number or customer name
    await expect(frame.locator("h1, h2").first()).toBeVisible({ timeout: 20_000 });
    // Back to quotes list for next tests
    await page.goto(URL, { waitUntil: "domcontentloaded" });
    await waitForApp(page);
  });

  test("search toggle opens search field, typing filters the list", async ({ page }) => {
    const frame = appFrame(page);
    const searchToggle = frame.locator('button[title="Search & filter"]');
    await expect(searchToggle).toBeVisible({ timeout: 20_000 });
    await searchToggle.click();
    const input = frame.getByPlaceholder("Search quotes…");
    await expect(input).toBeVisible({ timeout: 5_000 });
    await input.fill("xyz_no_match_test");
    // Either empty-state or filtered rows
    await expect(
      frame.getByText(/No quotes found|You have no quote/i).first()
    ).toBeVisible({ timeout: 10_000 });
  });

  test("sort popover opens and shows sort options", async ({ page }) => {
    const frame = appFrame(page);
    await frame.locator('button[title^="Sort:"]').click();
    await expect(frame.getByText("Newest first")).toBeVisible({ timeout: 5_000 });
    await expect(frame.getByText("Oldest first")).toBeVisible();
    await expect(frame.getByText("Name A → Z")).toBeVisible();
  });

  test("Export CSV button is present", async ({ page }) => {
    const frame = appFrame(page);
    await expect(frame.getByRole("button", { name: "Export CSV" })).toBeVisible({ timeout: 20_000 });
  });

  test("Create quote button is present", async ({ page }) => {
    const frame = appFrame(page);
    await expect(frame.getByRole("button", { name: /Create quote/i })).toBeVisible({ timeout: 20_000 });
  });

  test("switching to Unread tab filters the list", async ({ page }) => {
    const frame = appFrame(page);
    await frame.getByText("Unread").first().click();
    // List re-renders — heading should still be Quote Lists
    await expect(frame.getByRole("heading", { name: "Quote Lists" })).toBeVisible({ timeout: 10_000 });
  });
});

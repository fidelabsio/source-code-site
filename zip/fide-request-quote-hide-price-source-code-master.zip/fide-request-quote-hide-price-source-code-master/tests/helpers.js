/**
 * Shared helpers for Playwright tests.
 *
 * Shopify embeds our app inside an iframe whose src is on the deployed app's
 * own host (TEST_APP_HOST). All locators that target the app UI must go
 * through `appFrame()`.
 *
 * Requires TEST_SHOP_DOMAIN, TEST_APP_CLIENT_ID, and TEST_APP_HOST to be set —
 * no default is committed, since these point at a real dev store + Partner
 * app installation.
 */

function requireEnv(name) {
  const value = process.env[name];
  if (!value) {
    throw new Error(`Set ${name} to run e2e tests (see .env.example).`);
  }
  return value;
}

// TEST_SHOP_DOMAIN is the full myshopify.com domain (e.g. "your-store.myshopify.com");
// the Shopify admin URL uses just the store handle, so strip the suffix here.
export const STORE = requireEnv("TEST_SHOP_DOMAIN").replace(/\.myshopify\.com$/, "");
export const APP_KEY = requireEnv("TEST_APP_CLIENT_ID");
export const APP_HOST = requireEnv("TEST_APP_HOST");

/** Navigates to the Shopify admin app page (from any starting URL). */
export async function gotoApp(page) {
  await page.goto(
    `https://admin.shopify.com/store/${STORE}/apps/${APP_KEY}`,
    { waitUntil: "domcontentloaded" }
  );
}

/**
 * Returns a FrameLocator for the embedded app iframe.
 * All app element selectors must be chained from this.
 */
export function appFrame(page) {
  return page.frameLocator(`iframe[src*="${APP_HOST}"]`);
}

/**
 * Waits for the app iframe to appear and the app shell to finish loading.
 * Call this once after navigation before asserting on app content.
 */
export async function waitForApp(page, timeoutMs = 20_000) {
  await page
    .locator(`iframe[src*="${APP_HOST}"]`)
    .waitFor({ state: "attached", timeout: timeoutMs });
  // Wait for Polaris skeleton/spinner to disappear
  const frame = appFrame(page);
  await frame
    .locator('[class*="Polaris-SkeletonPage"], [class*="Polaris-Spinner"]')
    .waitFor({ state: "detached", timeout: timeoutMs })
    .catch(() => {});
}

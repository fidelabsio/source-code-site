/**
 * Unit tests for the PDF download token.
 * Run with: node tests/unit/pdfToken.test.mjs
 */
import assert from "node:assert/strict";
import { signQuoteToken, verifyQuoteToken } from "../../app/domain/pdf/pdfToken.server.js";

let passed = 0;
function test(name, fn) {
  fn();
  passed++;
  console.log(`  ok - ${name}`);
}

test("valid token verifies", () => {
  const t = signQuoteToken("quote_123");
  assert.equal(verifyQuoteToken("quote_123", t), true);
});

test("token is bound to the quote id", () => {
  const t = signQuoteToken("quote_123");
  assert.equal(verifyQuoteToken("quote_999", t), false);
});

test("tampered token fails", () => {
  const t = signQuoteToken("quote_123");
  assert.equal(verifyQuoteToken("quote_123", t.slice(0, -1) + "0"), false);
});

test("missing token fails", () => {
  assert.equal(verifyQuoteToken("quote_123", ""), false);
  assert.equal(verifyQuoteToken("quote_123", null), false);
});

console.log(`\n${passed} passed`);

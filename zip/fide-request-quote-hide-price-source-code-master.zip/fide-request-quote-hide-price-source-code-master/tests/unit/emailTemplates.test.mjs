/**
 * Unit tests for email template helpers.
 * Run with: node tests/unit/emailTemplates.test.mjs
 */
import assert from "node:assert/strict";
import {
  parseCartItems,
  renderProductTable,
  customerDataAccessEmail,
} from "../../app/domain/email/emailTemplates.server.js";

let passed = 0;
function test(name, fn) {
  fn();
  passed++;
  console.log(`  ok - ${name}`);
}

// ── parseCartItems ────────────────────────────────────────────────────────────

test("parseCartItems reads __v:2 cartItems array", () => {
  const quote = {
    formData: JSON.stringify({
      __v: 2,
      cartItems: [{ productTitle: "A" }, { productTitle: "B" }],
    }),
  };
  const items = parseCartItems(quote);
  assert.equal(items.length, 2);
  assert.equal(items[0].productTitle, "A");
});

test("parseCartItems reads legacy plain array", () => {
  const quote = { formData: JSON.stringify([{ productTitle: "X" }]) };
  assert.equal(parseCartItems(quote).length, 1);
});

test("parseCartItems falls back to single product on empty/bad data", () => {
  const quote = { formData: "not json", productTitle: "Solo", quantity: "3" };
  const items = parseCartItems(quote);
  assert.equal(items.length, 1);
  assert.equal(items[0].productTitle, "Solo");
  assert.equal(items[0].quantity, "3");
});

// ── renderProductTable ────────────────────────────────────────────────────────

test("renderProductTable renders a row per product (THE BUG: 2 in → 2 out)", () => {
  const items = [
    { productTitle: "Selling Plans Ski Wax", quantity: 2, offerPrice: 10 },
    { productTitle: "Snowboard", quantity: 1, offerPrice: 250 },
  ];
  const html = renderProductTable(items, "USD");
  assert.ok(html.includes("Selling Plans Ski Wax"));
  assert.ok(html.includes("Snowboard"), "second product must appear");
});

test("renderProductTable handles 5 products", () => {
  const items = Array.from({ length: 5 }, (_, i) => ({
    productTitle: `P${i}`,
    quantity: i + 1,
    offerPrice: (i + 1) * 10,
  }));
  const html = renderProductTable(items, "INR");
  for (let i = 0; i < 5; i++) assert.ok(html.includes(`P${i}`), `P${i} missing`);
});

test("renderProductTable shows variant on its own line when present", () => {
  const html = renderProductTable(
    [{ productTitle: "Tee", variantTitle: "Large / Red", quantity: 1 }],
    "USD",
  );
  assert.ok(html.includes("Tee"));
  assert.ok(html.includes("Large / Red"));
});

test("renderProductTable escapes HTML in titles", () => {
  const html = renderProductTable(
    [{ productTitle: "<script>x</script>", quantity: 1 }],
    "USD",
  );
  assert.ok(!html.includes("<script>x</script>"));
  assert.ok(html.includes("&lt;script&gt;"));
});

test("renderProductTable shows line total (qty × offer)", () => {
  const html = renderProductTable(
    [{ productTitle: "Selling Plans Ski Wax", quantity: 4, offerPrice: 30 }],
    "USD",
  );
  // 4 × $30 = $120 — both the unit offer and the line total must appear
  assert.ok(html.includes("$30.00"), "unit offer must remain");
  assert.ok(html.includes("$120.00"), "line total (4 × 30) must appear");
  assert.ok(html.includes(">Total<"), "Total column header must appear");
});

test("renderProductTable sums a grand total across products", () => {
  const html = renderProductTable(
    [
      { productTitle: "A", quantity: 2, offerPrice: 10 }, // 20
      { productTitle: "B", quantity: 3, offerPrice: 50 }, // 150
    ],
    "USD",
  );
  assert.ok(html.includes("$170.00"), "grand total (20 + 150) must appear");
});

test("renderProductTable omits totals when price is missing", () => {
  const html = renderProductTable(
    [{ productTitle: "No price", quantity: 4, offerPrice: null }],
    "USD",
  );
  assert.ok(!html.includes("$"), "no money should render without a price");
});

// ── customerDataAccessEmail (GDPR customers/data_request) ──────────────────────

test("customerDataAccessEmail lists every stored record for the customer", () => {
  const quotes = [
    { id: "c1", quoteNumber: 1012, productTitle: "Pump", customerName: "udhay",
      customerEmail: "a@b.com", quantity: "2", status: "new", createdAt: "2026-06-18T15:48:00Z" },
    { id: "c2", quoteNumber: 1007, productTitle: "Bracket", customerName: "udhay",
      customerEmail: "a@b.com", quantity: "50", status: "replied", createdAt: "2026-06-10T09:00:00Z" },
  ];
  const { subject, html } = customerDataAccessEmail(quotes, "a@b.com", "shop.myshopify.com");
  assert.ok(subject.includes("a@b.com"), "subject names the customer");
  assert.ok(html.includes("1012") && html.includes("1007"), "both records appear");
  assert.ok(html.includes("Stored quote requests (2)"), "count reflects record total");
});

test("customerDataAccessEmail escapes HTML in stored data", () => {
  const { html } = customerDataAccessEmail(
    [{ id: "c1", productTitle: "<script>x</script>", customerName: "x",
       customerEmail: "a@b.com", createdAt: "2026-06-18T15:48:00Z" }],
    "a@b.com",
    "shop.myshopify.com",
  );
  assert.ok(!html.includes("<script>x</script>"));
  assert.ok(html.includes("&lt;script&gt;"));
});

console.log(`\n${passed} passed`);
